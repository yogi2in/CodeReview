import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCustomerUserComponent } from './create-customer-user.component';

describe('CreateCustomerUserComponent', () => {
  let component: CreateCustomerUserComponent;
  let fixture: ComponentFixture<CreateCustomerUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateCustomerUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateCustomerUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
