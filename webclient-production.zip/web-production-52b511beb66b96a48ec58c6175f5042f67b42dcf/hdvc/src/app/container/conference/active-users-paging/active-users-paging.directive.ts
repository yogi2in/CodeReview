import { Directive, Renderer2, ElementRef, AfterViewInit, OnInit, Output, OnDestroy } from '@angular/core';
import { JoinMeetignService } from '../../join-meeting/join-meeting.service';
import { Subscription } from 'rxjs';
import { PagingInfo } from '../paging-info';
import { EventEmitter } from 'events';
import Swiper from 'swiper';
import { environment } from 'src/environments/environment';
import { ConferencePageService } from '../conference-page-service.service';
import { UserInfo } from '../_models/user-info';
declare var Participant;

@Directive({
  selector: '[appActiveUsersPaging]'
})
export class ActiveUsersPagingDirective implements AfterViewInit, OnInit, OnDestroy{
  private _prevSwiperArrow: any;
  private _nextSwiperArrow: any;
  private _gridViewBtn: any;
  private _nonGridViewBtn: any;
  private _selfElem: any;

  private _prevPagingInfo: PagingInfo;
  private curPageNumber: number = 1;
  private curLayoutCount: number = 2;
  private totalPageSize: number = 1;
  private _layoutTypeENUMS: any;
  private _layoutType: string;
  private _vDetIntervalId: any;
  public mySwiper: Swiper;
  public placeHoldersElem: any = [];
  public addPlaceHolderTimeoutId: any;
  private _isVideoStreamAvailableTimeoutId: any;
  private _checkVideWidthIntervalIds: any = {};

  // for subscription and observable
  private _pagingInfoSubs = new Subscription();

  @Output() fetchActiveUsers = new EventEmitter();

  constructor(
    private _renderer: Renderer2,
    private _element: ElementRef,
    private _joinMeetingservice: JoinMeetignService,
    private _confPageService: ConferencePageService
  ) {
    this._layoutTypeENUMS = environment.LAYOUT_TYPE_ENUMS;
   }

  ngOnInit() {
    this._layoutType = this._confPageService.getLayoutType();

    this._pagingInfoSubs = this._confPageService.pagingInfoListener().subscribe(
      (response: any) => {
        // const layoutType = this._confPageService.getLayoutType();
        this._layoutType = this._confPageService.getLayoutType();
        this.curLayoutCount = response.pagingInfo.curPageSizeCount;
        this.toggleSwipperArrow(response.pagingInfo, this._prevSwiperArrow, this._nextSwiperArrow);
        this.updatePanelView(response.pagingInfo, this._layoutTypeENUMS, this._layoutType);
        this._confPageService.setCurPageMostActiveUsersInfo(response.pagingInfo);
        this._prevPagingInfo = response.pagingInfo;

        this.clearAllInterval(this._checkVideWidthIntervalIds);
        clearTimeout(this._isVideoStreamAvailableTimeoutId);
        this._isVideoStreamAvailableTimeoutId = setTimeout(() => {
          this.isVideoStreamAvailable(response.pagingInfo.curActiveUsers);
        }, 2000);
      }
    )
  }

  ngAfterViewInit() {
    this._prevSwiperArrow = this.selectElementFromDOM(this._element, '.swiper-button-prev');
    this._nextSwiperArrow = this.selectElementFromDOM(this._element, '.swiper-button-next');
    this.addEventHandler(this._prevSwiperArrow, 'click', this.prevSwiperClickHandler.bind(this));
    this.addEventHandler(this._nextSwiperArrow, 'click', this.nextSwiperClickHandler.bind(this));
  }

  addEventHandler(element: HTMLElement, evtType: string, callBack: any) {
    if (element === undefined || element === null || typeof callBack !== 'function') {
      return;
    }
    element.addEventListener(evtType, callBack);
  }

  prevSwiperClickHandler(evt: Event) {
    this._confPageService.fetchActiveParticipantList$(this.curPageNumber - 1, this.curLayoutCount, this._layoutType);
  }

  nextSwiperClickHandler(evt: Event) {
    this._confPageService.fetchActiveParticipantList$(this.curPageNumber + 1, this.curLayoutCount, this._layoutType);
  }


  toggleSwipperArrow(pagingInfo: PagingInfo, prevArrow: any, nextArrow: any) {
    if (pagingInfo === undefined || prevArrow === undefined || nextArrow === undefined) {
      return;
    }

    let totalParticipantCount = pagingInfo.curParticipantCount;
    this.totalPageSize = totalParticipantCount <= pagingInfo.curPageSizeCount ? 1 : Math.ceil(totalParticipantCount / Math.floor(pagingInfo.curPageSizeCount));
    this.curPageNumber = pagingInfo.curPageNo;
    this.curLayoutCount = pagingInfo.curPageSizeCount;

    if (this.curPageNumber === 1) {
      this.toggleClassElement(prevArrow, 'disabled-arrow', 'add');
    } else  {
      this.toggleClassElement(prevArrow, 'disabled-arrow', 'remove');
    }

    if (this.curPageNumber === this.totalPageSize) {
      this.toggleClassElement(nextArrow, 'disabled-arrow', 'add');
    } else {
      this.toggleClassElement(nextArrow, 'disabled-arrow', 'remove');
    }
  }

  updatePanelView(pagingInfo: PagingInfo, layoutTypeENUMS: any, layoutType: string) {
    const participantsWrapperElemList = this.selectElementFromDOM(this._element, '.participant.participant-user', 'all');
    participantsWrapperElemList.forEach((participentWrapperElem, key) => {
      this.toggleClassElement(participentWrapperElem, 'd-none', 'add');
    });

    if (pagingInfo.curActiveUsers !== undefined && typeof pagingInfo.curActiveUsers === 'object') {
      pagingInfo.curActiveUsers.forEach((activeUser, arrIdx) => {
        let activeUserElem = this.selectElementFromDOM(this._element, "#"+activeUser.userId);
        if (activeUserElem !== null) {
          this.toggleClassElement(activeUserElem, 'd-none', 'remove');
        }
      });

      if (
        layoutType === layoutTypeENUMS[2] &&
        pagingInfo.curPageNo > 1 &&
        pagingInfo.curActiveUsers.length < 3
      ) {
        this.removePlaceHolderElems();
        clearTimeout(this.addPlaceHolderTimeoutId);
        this.addPlaceHolderTimeoutId = setTimeout(() => {
          const checkPlaceHolderElem = this.selectElementFromDOM(this._element, "#place-holder-1");
          if (checkPlaceHolderElem !== null) {
            return;
          }
          const placeHolderPart1 = new Participant("place-holder-1", "");
          const placeHolderPart2 = new Participant("place-holder-2", "");
          const firstPlaceHolder: any = this.selectElementFromDOM(this._element, "#place-holder-1");
          const secondPlaceHolder: any = this.selectElementFromDOM(this._element, "#place-holder-2");
          this.placeHoldersElem.push(firstPlaceHolder);
          this.placeHoldersElem.push(secondPlaceHolder);
          this.togglePlaceHolderElem(true, layoutTypeENUMS, layoutType, this.placeHoldersElem);
        });
      }
    }
  }

  isVideoStreamAvailable(activeUsersArr: any) {
    // console.log('activeUsersArr ', activeUsersArr)
    if (activeUsersArr !== undefined && activeUsersArr.length >= 1) {
      activeUsersArr.forEach((user, arrIdx) => {
        const userInfo: UserInfo = this._confPageService.getUserInfo(user.userId);
        let userVideoElem = this.selectElementFromDOM(this._element, "#video-"+user.userId);
        // console.log('userVideoElem --> ', userVideoElem)
        if (userVideoElem !== null) {
          let videoWrapper = this.selectElementFromDOM(this._element, "#"+user.userId);
          this.toggleClassElement(videoWrapper, 'show-no-video', 'remove');
          if (videoWrapper !== null) {
            let intervalCheckCounter = 0;
              // let checkVideWidthIntervalId: any;
              this._checkVideWidthIntervalIds[user.userId] = setInterval(() => {
                // console.log('users.userId ----> ', user.userId, intervalCheckCounter, userVideoElem.videoHeight)
                if (userVideoElem.videoHeight > 10) {
                  // hide no video
                  this.toggleClassElement(videoWrapper, 'show-no-video', 'remove');
                  clearInterval(this._checkVideWidthIntervalIds[user.userId]);
                } else {
                  if (intervalCheckCounter > 25) {
                    // show no video
                    this.toggleClassElement(videoWrapper, 'show-no-video', 'add');
                    this._confPageService.updateUserInfo(user.userId, userInfo, 'isStreamAvailable', false);
                    clearInterval(this._checkVideWidthIntervalIds[user.userId]);
                  }
                }
                ++intervalCheckCounter;
              }, 500);
            // if (userInfo.isStreamAvailable === false) {
            //   this.toggleClassElement(videoWrapper, 'show-no-video', 'add');
            // } else {

            // }

          }

          // if (videoWrapper !== null) {
          //   if (userVideoElem.videoHeight < 10) {
          //     // show no video
          //     this.toggleClassElement(videoWrapper, 'show-no-video', 'add');
          //   }else {
          //     // hide no video
          //     this.toggleClassElement(videoWrapper, 'show-no-video', 'remove');
          //   }
          // }
          //console.log('user video element height widht --> ', userVideoElem.videoHeight);
        }
      });
    }
  }

  togglePlaceHolderElem(
    toggleState: boolean,
    layoutTypesENUMS: any,
    layoutType: string,
    placeHolderElems: any
  ) {
    if (layoutType === layoutTypesENUMS[1]) {
      if (placeHolderElems !== null && placeHolderElems.length > 1) {
        if (toggleState) {
          placeHolderElems.forEach((elem, key) => {
            this.toggleClassElement(elem, 'd-none', 'remove');
          });
        } else {
          placeHolderElems.forEach((elem, key) => {
            this.toggleClassElement(elem, 'd-none', 'add');
          });
        }
      }
    }
  }

  removePlaceHolderElems() {
    const firstPlaceHolder: any = this.selectElementFromDOM(this._element, "#place-holder-1");
    const secondPlaceHolder: any = this.selectElementFromDOM(this._element, "#place-holder-2");
    const body: any = document.body;
    if (firstPlaceHolder !== null && secondPlaceHolder !== null) {
      firstPlaceHolder.parentNode.removeChild(firstPlaceHolder);
      secondPlaceHolder.parentNode.removeChild(secondPlaceHolder);
    }
  }

  /**
   * @description The below function will handle to return the element as per selector passed
   * @param selector
   */
  selectElementFromDOM(selectorDOM: any, selector: string, selectorType?: string) {
    let selectedDOM = null;
    if (selectorDOM === undefined || selectorDOM === null) {
      return selectedDOM;
    }

    switch(selectorType) {
      case 'all':
        selectedDOM = selectorDOM.nativeElement.querySelectorAll(selector);
        break;
      default:
        if (selector.indexOf("#") > -1) {
          selector = selector.slice(1);
          selectedDOM = document.getElementById(selector);
        } else {
          selectedDOM = selectorDOM.nativeElement.querySelector(selector);
        }
        break;
    }
    return selectedDOM;
  }

  /**
   * @description The below function will handle to add/remove class in DOM Element
   * @param listOfElements
   * @param clsName
   * @param optType
   */
  toggleClassElement(listOfElements: any, clsName: string, optType: string) {
    if (listOfElements === undefined || listOfElements === null || clsName === undefined || typeof clsName !== 'string') {
      return;
    }

    if (listOfElements.length > 0) {
      listOfElements.forEach((element, key) => {
        if (optType === 'add') {
          this._renderer.addClass(element, clsName);
        } else {
          this._renderer.removeClass(element, clsName);
        }
      });
    } else {
      if (optType === 'add') {
        this._renderer.addClass(listOfElements, clsName);
      } else {
        this._renderer.removeClass(listOfElements, clsName);
      }
    }
  }

  clearAllInterval(allIntervalIds): void {
    if (allIntervalIds == undefined) {
      return;
    }

    let intervalIds = Object.keys(allIntervalIds);
    if (intervalIds.length >= 1) {
      intervalIds.map((id, key) => {
        if (allIntervalIds[id] !== undefined) {
          clearInterval(allIntervalIds[id]);
        }
      });
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearInterval(this._vDetIntervalId);
    this.clearAllInterval(this._checkVideWidthIntervalIds);
    this._pagingInfoSubs.unsubscribe();
    clearTimeout(this._isVideoStreamAvailableTimeoutId);
    clearTimeout(this.addPlaceHolderTimeoutId);
  }
}
