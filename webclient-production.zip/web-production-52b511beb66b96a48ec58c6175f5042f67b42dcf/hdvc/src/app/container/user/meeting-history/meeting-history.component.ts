import { Component, OnInit } from '@angular/core';
import {MeetingHistoryService} from './meeting-history.service'
import { UtilService } from '../../../shared/services/utils.services';
import {NgxPaginationModule} from 'ngx-pagination'
import { getDate } from 'ngx-bootstrap/chronos/utils/date-getters';
import * as moment from 'moment';
import { environment } from 'src/environments/environment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-meeting-history',
  templateUrl: './meeting-history.component.html',
  styleUrls: ['./meeting-history.component.css']
})
export class MeetingHistoryComponent implements OnInit {
  public allmeetings: any;
  public totalrecords: number;
  public pageize: Number=10;
  p: Number = 1;
  public maxdate=moment().subtract(1,'days').toDate();
  public mindate:any;
  public title: string;
  public selecteddate: Date;
  momentdate= moment();

  constructor(
    private meetingsistoryservice: MeetingHistoryService,
    private _objUtils: UtilService,
    public _bsDatePickerConfig: BsDatepickerConfig
    ) {
      this._bsDatePickerConfig.minDate = moment().toDate();
      this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
      this._bsDatePickerConfig.showWeekNumbers = false;
  }

  ngOnInit() {
   this.title='';
   this.pageize==environment.PAGE_SIZE;
   this.selecteddate=null;
    this.gethistory(1);
  }
 //get the user details from local storage
 getUserInfo(): any {
  return this._objUtils.getInfoFromStorage('localStorage', 'currentUser');
}
  gethistory(page:Number)
  {
   if(this.maxdate >= this.selecteddate || this.selecteddate===null){
    const filter={
      emailId:  this.getUserInfo().email.replace("+", "%2B"),//environment.MEETING_CREATOR_EMAIL;
      title: this.title,
      fromdate: this.selecteddate,
      pageIndex: page==undefined?1:page
    }

    this.meetingsistoryservice.getMeetingHistoryDetails(filter)
    .subscribe((response:any) => {
      this.allmeetings = response.body.data;
      this.totalrecords = response.body.total_records;
      this.p = page;
  },
  error => {
    console.log('error', error);
  });
  }
  else
  {
    if(this.selecteddate.toString()!="Invalid Date"){
      alert('Select date can not be greater than yesterday date');
      this.selecteddate=null;
    }
  }
}


}
