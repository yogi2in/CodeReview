import { Component, OnInit,  Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { LicenceManagementService } from  '../../licence-management/licence-management.service';
import { MyProfileService } from '../../user/my-profile/my-profile.service';
import { Subscription, Observable } from 'rxjs';
import {debounceTime, map } from 'rxjs/operators';

declare var $;
@Component({
  selector: 'app-create-customer-user',
  templateUrl: './create-customer-user.component.html',
  styleUrls: ['./create-customer-user.component.css']
})
export class CreateCustomerUserComponent implements OnInit {
  createUserForm: FormGroup;
  @Input() panasonicUserid = null;
  @Input() routerName;
  @Input() lotId;
  @Input() editUserDataObj;
  countryList:any;
  CountryCodeList: {name: string, code: string}[] = [];
  countryCode:string="+91";
  showGlobalError = true;
  constructor(private licenceService : LicenceManagementService, private myProfileService: MyProfileService) { }
  ngOnInit() {

    this.createUserForm = new FormGroup({
      fullName: new FormControl(null, Validators.required),
      countryCode: new FormControl(null, Validators.required),
      mobile: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.required,Validators.email]),
      status: new FormControl(null)
    });

    if(this.routerName == 'EDIT-USER'){
      this.createUserForm.setValue(this.editUserDataObj);
    }

    if(this.routerName == 'ADD-USER'){
      this.createUserForm.reset();
      this.createUserForm.controls['email'].setValidators([Validators.required, Validators.email]);
    }

    this.myProfileService.getCountryCode()
    .subscribe(
      (res) => {
        if(res["result"] != undefined && res["result"] != null && res["result"].length != 0){
          this.countryList = res["result"];
          for(let countrycode in this.countryList ) {
          this.CountryCodeList.push({name: this.countryList[countrycode].code,code: " "+this.countryList[countrycode].name})
          }
        }
      }
    );
  }

  search = (text$: Observable<string>) =>
  text$.pipe(
    debounceTime(200),
    map(term => term === '' ? []
      : this.CountryCodeList.filter(v => +v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
  )

formatter = (x: {name: string}) => {
  if(x.name != undefined){
    return x.name;
  }else{
    return x;
  }
}

  createUser() {
    // When user click on form submit button without filling the fields then error will display.
    this.createUserForm.controls['fullName'].markAsTouched();
    this.createUserForm.controls['countryCode'].markAsTouched();
    this.createUserForm.controls['mobile'].markAsTouched();
    this.createUserForm.controls['email'].markAsTouched();
    if (this.createUserForm.valid) {
      let data = {
        "fullName":this.createUserForm.value.fullName,
        "countryCode":this.createUserForm.value.countryCode.name==undefined?this.createUserForm.value.countryCode:this.createUserForm.value.countryCode.name,
        "mobile":this.createUserForm.value.mobile
       }
      if(this.routerName == 'ADD-USER'){
        data["lotId"] = this.lotId;
        data["email"] = this.createUserForm.value.email;
        this.licenceService.assignLicenceToUser(data)
      }else{
        data["status"] = this.createUserForm.value.status //inactive
        this.licenceService.updateCustomerUser(this.panasonicUserid, this.lotId, data)
      }
      /* else if(this.routerName == 'EDIT-USER'){
        this.userService.updatePanasonicUserById(
          this.panasonicUserid,
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode,
          this.createUserForm.value.mobile
        );
      } */
      /* else{
        this.profileService.updateUserProfile(
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode,
          this.createUserForm.value.mobile
        );
      } */
      /* if(this.panasonicUserid != null){
        $('#add-user-modal'+this.panasonicUserid).modal('hide')
      }else{ */
        //this.createUserForm.reset();
       // $('#add-user-modal').modal('hide');
        //this.closeModal.emit();
      //}

    } else {
      console.log('form invalid!');
    }

  }

  ngAfterViewInit() {
    console.log("ngAfterViewInit")
    $('#add-user-modal').on('hidden.bs.modal', () => {
      if(!this.panasonicUserid){
        this.createUserForm.reset();
        this.createUserForm.patchValue({countryCode:'+91'});
      }
    });
  }
}
