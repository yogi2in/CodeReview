import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenDesktopAppPopupComponent } from './open-desktop-app-popup.component';

describe('OpenDesktopAppPopupComponent', () => {
  let component: OpenDesktopAppPopupComponent;
  let fixture: ComponentFixture<OpenDesktopAppPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenDesktopAppPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenDesktopAppPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
