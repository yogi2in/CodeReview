import { Component, OnInit } from '@angular/core';
import { ReportsService } from './reports.service';
import { environment, Enums } from 'src/environments/environment';
import { UtilService } from 'src/app/shared/services/utils.services';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  public reportsArr;
  public reportHeaders = [
    'Lot Id',
    'Start Date',
    'Expiry Date',
    'Total Licence',
    'Used Licence',
    'Available Licence',
    'Status'
  ];
  public utilizationFields = [
    'Licence Number',
    'Assigned to User',
    'Email',
    'Start Date',
  ];
  public reportMeetingHeaders = [
		'Meeting ID',
		'Title',
		'Scheduled Date',
		'Actual Date',
		'Scheduled Start Time',
		'Scheduled Duration (hh:mm)',
		'Actual Start Time',
		'Actual End Time'
	]
  public downloadAsXls;
  public downloadAsPdf;
  public utilizationDownloadAsXls;
  public utilizationDownloadAsPdf;
  public totalrecords;
  public upComingRecordsNo: Number = 1;
  public upComingUtilizationRecordsNo: Number = 1;
  public default_page_size = environment.PAGE_SIZE;
  public customerName;
  public reportsNoRecordFound: boolean = false;
  public utilizationNoRecordFound: boolean = false;
  public licenceStatus;
  public customerLotId;
  public utilizationTotalrecords;
  public utilizationReportData;
  public usedLicence;
  public availableLicence;
  public startItemNumber;
  public lastItemNumber;
  public UtilizationStartItemNumber;
  public UtilizationLastItemNumber;
  public selectLotId: any;
  public licenceLotId: any;
  public showLoader: boolean = false;
  public enum = Enums;
  public enumStatusKeys: any;
  public renewalReminderMsg: any;
  public meetingReportsData: any = null;
  public licenceCurrentPage: any;
  public numPerPage: any;
  public utilizationCurrentPage: any;
  public usedLicenceData: any;
  public usedLicenceTotalItemCount: any;
  public usedLicenceFirstItemNumber: any;
  public usedLicenceLastItemNumber: any;
  public usedLicenceCurrentPage: any;
  public meetingReports: FormGroup;
  public currentDate = moment().toDate();
  public showRecordsHeader: boolean = false;
  public meetingReportTotalRecords: any;
  public currentPageIndex: any;
  public meetingUsers: any;
  maxDate: Date;
  private clearSetTimeOut;

  constructor(
    private _reports: ReportsService, 
    private _Utils: UtilService,
    public _bsDatePickerConfig: BsDatepickerConfig) {
    this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
		this._bsDatePickerConfig.showWeekNumbers = false;
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
   }

  ngOnInit() {
    this.enumStatusKeys = Object.keys(this.enum);
    this.meetingReports = new FormGroup({
			fromDate: new FormControl(this.currentDate, Validators.required),
			toDate: new FormControl(this.currentDate, Validators.required)
		})
    this.getLicenceReports(1);
  }

  //get the user details from local storage
  getUserInfo(): any {
    return this._Utils.getInfoFromStorage('localStorage', 'currentUser');
  }

  /*
  * The below function get the lincence report form services.
  */
  getLicenceReports(page) {
    this.upComingRecordsNo = page;
    this.customerName = this.getUserInfo().customerName
    const filter = {
      pageIndex: page == undefined ? 1 : page,
      customerName: this.getUserInfo().customerName,
      status: this.licenceStatus
    }
    this._reports.getLicenceReports(filter).subscribe(
      (res: any) => {
        if (res.result != undefined && res.result != null && res.result.data != undefined && res.result.data != null) {
          this.reportsArr = res.result.data;
          this.totalrecords = res.pagination.totalItemCount;
          this.licenceCurrentPage = res.pagination.currentPage;
          this.numPerPage = res.pagination.numPerPage;
          this.startItemNumber = res.pagination.firstItemNumber;
          this.lastItemNumber = res.pagination.lastItemNumber;
          this.downloadAsXls = res.result.downloadAsXls;
          this.downloadAsPdf = res.result.downloadAsPdf;
          if (this.reportsArr.length > 0) {
            this.reportsNoRecordFound = false;
          } else {
            this.reportsNoRecordFound = true;
          }

        } else {
          return;
        }
        //importedSaveAs(blob, 'file')
        console.log("Get reports data", res.result.data);

      },
      (error) => {
        console.log("Reports Error", error)
      }
    )
  }

  /*
  * The below function download the PDF file.
  */
  downloadPdf() {
    if (this.downloadAsPdf) {
      window.open(this.downloadAsPdf, '_blank');
    }

    //window.location.href = this.downloadAsPdf
  }

  /*
  * The below function download the PDF file.
  */
  utilizationDownloadPdf() {

    if (this.utilizationDownloadAsPdf) {
      window.open(this.utilizationDownloadAsPdf, '_blank');
    }

    //window.location.href = this.downloadAsPdf
  }

  /*
  * The below function download the Excel file.
  */
  downloadXls() {
    // window.open(this.downloadAsXls);

    if (this.downloadAsXls) {
      window.location.href = this.downloadAsXls;
    }

  }

  /*
  * The below function download the Excel file.
  */
  utilizationDownloadXls() {
    // window.open(this.downloadAsXls);

    if (this.utilizationDownloadAsXls) {
      window.location.href = this.utilizationDownloadAsXls;
    }
  }

  /*
  * The below function work when change the status.
  */
  onChangeStatus(event) {
    this.licenceStatus = event.target.value;
    this.getLicenceReports(1);     // when change the status then default page should be first.
  }

  /*
  * The below function get the LotId from licence-management.
  */
  getLotIdLicenceManagementPage() {
    let customerId = this.getUserInfo().customerId;
    this._reports.getCustomerLotId(customerId).subscribe(
      (res: any) => {
        this.customerLotId = res.result.licences;
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          this.onPageLoadGetLotId();
        }, 10);
      },
      (error) => {
        console.log("Error => ", error);
      }
    )

  }

  /*
  * The below function get the select box selected value on page load.
  */
  onPageLoadGetLotId() {
    let selectLotId: any = document.getElementById('selectLotId');
    this.selectLotId = selectLotId.value
    this.getUtilizationReport(1);
  }

  /*
  * The below function get the select box value on change.
  */
  onChangeLotId(event) {
    this.selectLotId = event.target.value;
    this.getUtilizationReport(1);
  }

  /*
  * The below function get the Utilization Report form services.
  */
  getUtilizationReport(page) {
    this.upComingUtilizationRecordsNo = page;
    const filter = {
      pageIndex: page == undefined ? 1 : page,
      lotId: this.selectLotId
    }
    this._reports.getUtilizationReport(filter).subscribe(
      (res: any) => {
        this.utilizationReportData = res.result.data;
        this.utilizationTotalrecords = res.pagination.totalItemCount;
        this.utilizationCurrentPage = res.pagination.currentPage;
        this.UtilizationStartItemNumber = res.pagination.firstItemNumber;
        this.UtilizationLastItemNumber = res.pagination.lastItemNumber;
        this.utilizationDownloadAsXls = res.result.downloadAsXls;
        this.utilizationDownloadAsPdf = res.result.downloadAsPdf;
        this.usedLicence = res.result.usedLicence;
        this.availableLicence = res.result.availableLicence;
        if (this.utilizationReportData.length > 0) {
          this.utilizationNoRecordFound = false;
        } else {
          this.utilizationNoRecordFound = true;
        }
      }
    )
  }


  /*
  * The below function get the Used Licence Report if Used Licence is > 0.
  */
  getUsedLicenceUserDetails(lotId) {
    this.showLoader = true;
    this.usedLicenceData = []
    this.licenceLotId = lotId
    const filter = {
      lotId: lotId
    }
    this.usedLicenceTotalItemCount = 0;
    // this._reports.getUtilizationReport(filter).subscribe(
    //   (res: any) => {

    //     setTimeout(() => {
    //       this.showLoader = false;
    //       this.usedLicenceData = res.result.data;
    //       this.usedLicenceCurrentPage = res.pagination.currentPage
    //       this.usedLicenceFirstItemNumber = res.pagination.firstItemNumber;
    //       this.usedLicenceLastItemNumber = res.pagination.lastItemNumber;
    //       this.usedLicenceTotalItemCount = res.pagination.totalItemCount;
    //     }, 1000);

    //   }
    // )
    this.getUsedLicenceData(filter);
  }

  getUsedLicenceReport(page) {
    const filter = {
      lotId: this.licenceLotId,
      pageIndex: page
    }
    this.getUsedLicenceData(filter);

  }

  getUsedLicenceData(filter) {
    this._reports.getUtilizationReport(filter).subscribe(
      (res: any) => {
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          this.showLoader = false;
          this.usedLicenceData = res.result.data;
          this.usedLicenceCurrentPage = res.pagination.currentPage
          this.usedLicenceFirstItemNumber = res.pagination.firstItemNumber;
          this.usedLicenceLastItemNumber = res.pagination.lastItemNumber;
          this.usedLicenceTotalItemCount = res.pagination.totalItemCount;
        }, 1000);

      }
    )
  }
  /*
  * The below function send the mail when status is Expiring Soon on click the mail icon.
  */
  postLicenceRenewalReminder(lotId) {
    const data = {
      "lotId": lotId
    }
    this._reports.postLicenceRenewalReminder(data).subscribe(
      (res: any) => {
        this.renewalReminderMsg = res.message;
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          this.renewalReminderMsg = false;
        }, 1000);
      }
    )
  }

  /*
  * The below function get the Meeting Report Api data.
  */
	getMeetingReports(pageIndex) {
		// this.isSubmitted = true;
		this.showRecordsHeader = false;
		// this.totalRecords = 0;
		// this.showExportButton = false;
    //this.meetingReportsData = [];
    let fromDate = this.meetingReports.controls.fromDate.value;
			let toDate = this.meetingReports.controls.toDate.value;
      let userInfo = this.getUserInfo();

      const data = {
        'from_date': moment(fromDate).format("YYYY-MM-DD"),
        'to_date': moment(toDate).format("YYYY-MM-DD"),
        'pageIndex': pageIndex,
        customerId : userInfo.customerId
      }
      if(data.to_date >= data.from_date){
        //this.meetingReports.controls.toDate.setErrors({'invalid': false});
        if (!this.meetingReports.invalid) {
          this.showLoader = true;
          this.currentPageIndex = pageIndex;
          this._reports.getMeetingReports(data).subscribe(
            (res) => {
              this.meetingReportsData = res['body'].data;
              this.showLoader = false;
              this.showRecordsHeader = true;
              this.meetingReportTotalRecords = res['body'].total_records;
            },
            (error) => {
              console.log(error);
            }
          )
        }
      } else {
        this.meetingReports.controls.toDate.setErrors({'invalid': true});
      return;
    }
	}

  /**
   * filter meeting report data based on meeting id and actual start datetime to show participants list
   */
	showParticipantsList(meetingId: string, actualStartDateTime: string) {
    if(meetingId != null && meetingId != undefined && 
      actualStartDateTime != null && actualStartDateTime != undefined){

      let userList = this.meetingReportsData.filter( 
        (meetingData) => {
        if(meetingData !=null && meetingData != undefined){
          return meetingData.meetingid == meetingId
          && meetingData.meetingstarttime == actualStartDateTime
        } else {
          return;
        }
      });

      this.meetingUsers = userList[0].users;
    }
	}

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }


}


