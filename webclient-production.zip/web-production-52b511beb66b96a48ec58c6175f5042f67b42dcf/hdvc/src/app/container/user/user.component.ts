import { Component, OnInit } from '@angular/core';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  public profilePicUrl: string;

  constructor(private _userService: UserService) {  }

  ngOnInit() {
    this.profilePicUrl = this._userService.profilePicUrl;
  }

  /* This function called after profile pic model close */
  onCloseModal() {
    this.profilePicUrl = this._userService.onCloseModal();
  }
}
