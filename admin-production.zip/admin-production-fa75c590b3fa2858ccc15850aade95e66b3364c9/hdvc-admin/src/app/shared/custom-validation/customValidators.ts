import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';

export class CustomValidators {
  
  static strongpassword(control: AbstractControl):{[key: string]: boolean} {
  
    let totalstrength=0;
    if(control.value=== "" || control.value==null){
      return null
    }
    let hasNumber = /\d/.test(control.value);
    if(hasNumber)
    {
      totalstrength += 20;
    }
    let hasUpper = /[A-Z]/.test(control.value);
    if(hasUpper)
    {
      totalstrength += 20;
    }
    let hasLower = /[a-z]/.test(control.value);
    if(hasLower)
    {
      totalstrength += 20;
    }
    
    let val = control.value;
    if(val!=""){
    if(val.length>= 8)
    {
      totalstrength += 20;
    }
  }
    
    let specialchar = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(control.value)
    if(specialchar)
    {
      totalstrength += 20;
    }

    if (totalstrength>0 && totalstrength<60) {
        return {'Weak': true};
    }
    if (totalstrength<=80) {
      return {'Good': true};
    }
    if(totalstrength==100)
    {
      return {'Strong': true};
    }
    else
    {
      return null;
    }
}

}
