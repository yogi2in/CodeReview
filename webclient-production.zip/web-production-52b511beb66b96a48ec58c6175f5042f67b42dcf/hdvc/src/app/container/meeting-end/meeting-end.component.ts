import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meeting-end',
  templateUrl: './meeting-end.component.html',
  styleUrls: ['./meeting-end.component.css']
})
export class MeetingEndComponent implements OnInit {
  public isLoggedIn: boolean = true;
  constructor() { }

  ngOnInit() {
    let userInfo = localStorage.getItem('currentUser');
    if(userInfo != undefined && userInfo != null) {
      this.isLoggedIn = false;
    }
  }
  
}
