import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { MyMeetingService } from '../my-meeting.service';
import * as moment from 'moment-timezone';
import { environment } from 'src/environments/environment';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Router } from '@angular/router';
import { JoinMeetignService } from '../../join-meeting/join-meeting.service';
import { Subscription } from 'rxjs';
import { ConferencePageService } from '../../conference/conference-page-service.service';
import { LogService } from 'src/app/shared/logger/log.service';

declare var $;

enum RecurringType {
  Daily = 1,
  Weekly = 2,
  Monthly = 3
}

enum Weeks {
  First = 1,
  Second,
  Third,
  Fourth,
  Last
}

enum DaysList {
  Sun = 0,
  Mon,
  Tue,
  Wed,
  Thu,
  Fri,
  Sat
}



@Component({
  selector: 'app-meeting-details',
  templateUrl: './meeting-details.component.html',
  styleUrls: ['./meeting-details.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class MeetingDetailsComponent implements OnInit, OnDestroy {
  @Input() meeting;
  @Input() totalRecords;
  @Input() index;
  //@Output() refreshData = new EventEmitter<string>();
  @Input() upComingMeetingPageNo;
  public meeting_url: string;
  public expandPanel: boolean;
  public copyText: any;
  public meeting_refid: any;
  public zone: string = moment.tz(moment.tz.guess()).zoneAbbr();
  public pageSize = environment.PAGE_SIZE;
  public selectedMeetingId;
  isDesktopApp = false;
  public disabledMeetingBtn = false;
  public manageSetIntervalObj = [];
  public hideEditDeleteBtn: boolean = false;

  private clearSetTimeOut;
  @Output() deleteMeetingData: EventEmitter<deleteDataEvent> = new EventEmitter<deleteDataEvent>();

  constructor(
    private _router: Router,
    private _utilService: UtilService,
    public _objMeetingService: MyMeetingService,
    private _joinMeetingService: JoinMeetignService,
    private _confPageService: ConferencePageService,
    private _logService: LogService
  ) { }

  ngOnInit() {
    if (typeof this.meeting == "object") {
      this.meeting.isEnabled = true;
      /* PLEASE COMMENT BELOW CODE IF PAST/FUTURE MEETING NOT APPLIED, OPEN FOR DEV*/
      if (moment().format("YYYY-MM-DD") <= this.meeting.start_date) {
        this.meeting.isEnabled = false;
        if (moment().format("YYYY-MM-DD") == this.meeting.start_date) {
          let timeDiff = Math.round((moment(this.meeting.start_date + this.meeting.start_time).diff(new Date()))),
            enabledMeeting = timeDiff - 900000;
            clearTimeout(this.clearSetTimeOut)
          if (enabledMeeting > 0) {
            this.manageSetIntervalObj.push(              
              this.clearSetTimeOut = setTimeout(() => {
                this.meeting.isEnabled = true;

              }, enabledMeeting)
            )
          }
          else {
            this.meeting.isEnabled = true;
          }
        }
      }
    }
    this.isDesktopApp = this._utilService.checkIsDesktopApp();
    this.meeting_url = environment.HOST + '/join-meeting/';
    // $('.fa-sync-alt').tooltip({ boundary: 'window' });
    //this.hideEditButtonOnStartMeeting(this.meeting.start_date + this.meeting.start_time);
  }

  formatMeetingTime(date) {
    return moment.tz(date, moment.tz.guess()).format("hh:mm A");
  }


  // hideEditButtonOnStartMeeting(date){
  //   let meetingTime = new Date(date);    
  //   let currentTime =  new Date();  

  //   if(meetingTime <= currentTime) {
  //     this.hideEditDeleteBtn = false;
  //   } else {
  //     this.hideEditDeleteBtn = true;
  //   }
  // }


  ngOnDestroy() {
    //this.onStartReJoinListenerSubs.unsubscribe()
    this.manageSetIntervalObj.forEach(ele => {
      clearInterval(ele)
    });
    clearTimeout(this.clearSetTimeOut)
  }
  
  formatMeetingDate(date) {
    return moment.tz(date, moment.tz.guess()).format("dddd, MMMM DD, YYYY");
  }

  showRecMeetingDetails() {
    if (this.meeting.recurrence_type > 0) {
      let recurringType = RecurringType[this.meeting.recurrence_type];
      switch (this.meeting.recurrence_type) {
        case 1:
          recurringType = " Daily" + " until " + this.formatMeetingDate(this.meeting.recurrence_end_date);;
          break;
        case 2:
          recurringType = " " + recurringType + " on " + this.getDaysDetails() + " until " + this.formatMeetingDate(this.meeting.recurrence_end_date);
          break;
        case 3:
          recurringType = " " + recurringType + " on " + Weeks[this.meeting.recurrence_week] + " " + this.getDaysDetails() + " until " + this.formatMeetingDate(this.meeting.recurrence_end_date);;
          break;
      }
      return recurringType;
    }
  }

  getDaysDetails() {
    if (this.meeting.recurrence_day) {
      let daysDetails: any = [];
      this.meeting.recurrence_day.split(",").forEach(function (value, index) {
        let day: string;
        if (value == "true") {
          day = DaysList[index];
        }
        if (day != null && daysDetails.indexOf(day) === -1) {
          daysDetails.push(day);
        }
        return daysDetails.join(",");
      });
      return daysDetails.join(",");
    }
  }

  fatchViewData() {
    this.expandPanel = !this.expandPanel;
  }

  copyPath(elem: any) {
    elem.select();
    document.execCommand('copy');
  }

  /**
   * delete the seleted meeting
   */
  deleteMeeting(meetingId, type, pageIndex) {
    this.deleteMeetingData.emit({ meetingId: meetingId, type: type, pageIndex: pageIndex });
  }

  //open the modal popup
  openModalPopup(id, modalId, index) {
    this.meeting_refid = id;
    $('#' + modalId + '_' + index).modal('show')
  }

  /**
   *
   * @param currentPageIndex current page index
   * return the new page based on calculation to fetch the data
   */
  getNewPageIndex(currentPageIndex) {
    let previousPage = currentPageIndex > 1 ? currentPageIndex - 1 : currentPageIndex;
    let recordsCount = this.pageSize * previousPage;
    if ((this.totalRecords - 1) > recordsCount) {
      return currentPageIndex;
    }
    else {
      return currentPageIndex - 1;
    }
  }

  /**
   * @description The below function will handle redirect the user direct to confernce page
   *              when clicked on join meeting button instead of join meeting page.
   * @param evt
   * @param meetingId
   */
  onJoinMeetingBtnClick(meetingId: string) {
    // stop the click event propagation
    //$event.stopPropagation();
    // get curuser info from localstorage
    const curUserInfo = this._utilService.getInfoFromStorage('local', 'currentUser');
    if (meetingId === undefined || typeof meetingId !== 'string') {
      return;
    }
    // set the meeting index number to show if any error msge in my meeting page
    this._joinMeetingService.meetingValidationIndex = this.index;

    // if user info not available then  redirect to  join-meeting page
    if (curUserInfo === null) {
      return this._router.navigate(['/join-meeting', meetingId]);
    }
    this._joinMeetingService.isUserClickJoinButton = true;
    console.log('on join meeting butn clicked ------> ')
    this._joinMeetingService.validateMeeting(
      meetingId,
      curUserInfo.email,
      curUserInfo.fullName,
      "MEETING-DETAILS"
    )
  }

  openDeskTopAppInfo(evt: Event, meetingId: string) {
    // stop the click event propagation
    evt.stopPropagation();
    this.onJoinMeetingBtnClick(meetingId);
  }
  /*
  openDeskTopAppInfo(evt: Event,  meetingId: string){
    // stop the click event propagation
    evt.stopPropagation();
    if(this.isDesktopApp) {
      this.onJoinMeetingBtnClick(meetingId);
    } else {
      this.selectedMeetingId = meetingId;
      let currentUserObj = this._utilService.getInfoFromStorage('localStorage', 'currentUser');
      let name = currentUserObj.fullName;

	    /*
      let deviceInfo = this._utilService.getDeviceDetection();
      let downloadApplicationObj = this._utilService.getInfoFromStorage('localStorage', 'downloadApplication');
      if (
        downloadApplicationObj != null &&
        downloadApplicationObj.browser == deviceInfo.browser
        // downloadApplicationObj.userId == currentUserObj.userId
      ) {
        this.onJoinMeetingBtnClick(meetingId);
      } else {
        return this._router.navigate(['/download-meeting-app', 'MEETING-DETAILS', this.selectedMeetingId]);
      }
	    /*
      if (this._utilService.isAppDownloadEnabled()) {
	      return this._router.navigate(['/download-meeting-app', 'MEETING-DETAILS', this.selectedMeetingId, name]);
      }
      else {
        this.onJoinMeetingBtnClick(meetingId);
      }
    }
  }
  */

  /*
   * The Below function stop the event handeling.
   */
  stopEvent(evt: Event) {
    evt.stopPropagation();
    $(".bg-transparent").dropdown();
  }

  /*
   * The Below function calculate the end time of the meeting.
   */
  getEndTime(start_time, duration) {
    let convertInToMinutes = moment.duration(duration).asMinutes();
    let end_time = moment.tz(start_time, moment.tz.guess()).add(convertInToMinutes, 'minutes').format("hh:mm A");
    return end_time;
  }
}

export class deleteDataEvent {
  meetingId: number;
  type: string;
  pageIndex: string;
}
