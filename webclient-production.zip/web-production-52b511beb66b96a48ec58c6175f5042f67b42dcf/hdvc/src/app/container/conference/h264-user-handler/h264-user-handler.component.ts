import { Component, OnInit, Input } from '@angular/core';
import { UtilService } from 'src/app/shared/services/utils.services';
import { SocketService } from 'src/app/shared/services/socket.service';
import { ConferencePageService } from '../conference-page-service.service';
import { environment } from 'src/environments/environment.prod';
import * as kurentoUtils from 'kurento-utils';
import { Subscription } from 'rxjs';
import { DeviceSettingService } from '../../device-setting/device-setting.service';
import { LogService } from 'src/app/shared/logger/log.service';
declare var Participant;
declare var window;

@Component({
  selector: 'app-h264-user-handler',
  templateUrl: './h264-user-handler.component.html',
  styleUrls: ['./h264-user-handler.component.css']
})
export class H264UserHandlerComponent implements OnInit {
  @Input() meetingRoomInfo;
  public userId: string;
  private _webSocket: any;
  //private _participant: any;
  private _participant: any = {};
  private _browserInfo: any;
  private stopAnswer = false;
  private heartBeatIntervalId: any;
  private _turnsConfig: any = [];
  private statsInterval: any;
  private _bitrateChangeSubs = new Subscription();
  private _isFirstTimeUpdate: boolean = true;
  private _selfUserId: any;
  private _audioTrack: any;
  private _videoTrack: any;
  private _updateBitrateTimeoutId: any;

  constructor(
    private _utilService: UtilService,
    private socketService: SocketService,
    private _confPageService: ConferencePageService,
    private _deviceSettingService: DeviceSettingService,
    private _logService: LogService
  ) { }

  ngOnInit() {
    setTimeout(() => {
      if (this.meetingRoomInfo && this.meetingRoomInfo.roomID !== undefined) {
        this._browserInfo = this._utilService.getBrowserInfo();
        this._turnsConfig = this._utilService.getTurnsConf(environment.ENVIRONMENT_TYPE);
        this._webSocket = new WebSocket(this.socketService.getSocketUrl());
        this._webSocket.onopen = this.onSocketOpenHandler.bind(this);
        this._webSocket.onmessage = this.onSocketMessageHandler.bind(this);
        window.addEventListener('message', this.messageEventHandler.bind(this));
      }
    }, 10000);
    this._bitrateChangeSubs = this._confPageService.onBitrateChange().subscribe(
      (response: any) => {
        if (this._isFirstTimeUpdate === false) {
          if (response.layoutType && response.layoutType === 'SPEAKER_VIEW') {
            this.stopAnswer = false;
            this.joinH264User({}, true);
          }
        }

        if (this._isFirstTimeUpdate) {
          this._isFirstTimeUpdate = false;
        }

      }, (error: any) => {

      }
    )

  }

  messageEventHandler(event) {
    if (event.data.type === undefined && typeof event.data === 'string' && event.data.length > 1) {
      if (event.data == 'ice-connected') {
        return;
      }
      let payLoad = JSON.parse(event.data);
      if (payLoad.userId && payLoad.userId === this._selfUserId) {
        this.sendMsg(JSON.parse(event.data), this._webSocket);
      }
    }
  }

  onSocketOpenHandler() {
    let kip = this._utilService.getInfoFromStorage('localStorage', 'kip');
    let jip = this._utilService.getInfoFromStorage('localStorage', 'jip');
    const joinMeetingPayLoad = this.meetingRoomInfo;
    joinMeetingPayLoad.user = joinMeetingPayLoad.user;// + '_H264_USER';
    joinMeetingPayLoad.clientId = joinMeetingPayLoad.clientId;
    joinMeetingPayLoad.connection_mode = 'H264';

    this.sendMsg(joinMeetingPayLoad, this._webSocket);
  }

  onSocketMessageHandler(socketMsg) {
    const parsedMsge = JSON.parse(socketMsg.data);
    this._logService.debug('H264 Socket Handler -> Data From Kurento <<<<<< ', parsedMsge);
    switch (parsedMsge.rsp) {
      case 'exisUsr':
        this._selfUserId = parsedMsge.userId;
        // this.connectionHeartBeat();
        this._participant = new Participant(parsedMsge.userId, 'WEB-H264');
        this.joinH264User(parsedMsge, false);
        break;
      case 'iceCandidate':
        this.iceCandidateHandler(parsedMsge, this._webSocket);
        break;
      case 'answer':
        if (this.stopAnswer === true) {
          return;
        }
        this.receiveVideoResponse(parsedMsge);
        this.stopAnswer = true;
        break;
    }
  }

  joinH264User(parsedMsg: any, resendOffer: boolean) {
    let self = this;
    const browserName = this._browserInfo.name;
    const isDesktopApp = this._utilService.checkIsDesktopApp();
    // console.log('window.localStream.getAudioTracks()[0] ', window.localStream.getAudioTracks()[0]);
    // console.log('window.localStream.getVideoTracks()[0]', window.localStream.getVideoTracks()[0])
    // this._audioTrack = window.localStream.getAudioTracks();
    // this._videoTrack = window.localStream.getVideoTracks();
    let _audioMediaStream = this._deviceSettingService.getStoredStream('audio');
    let _videoMediaStream = this._deviceSettingService.getStoredStream('video');
    const options = {
      audioStream: _audioMediaStream, //this._audioTrack, //window.localStream.getAudioTracks()[0],
      videoStream: _videoMediaStream,
      onicecandidate: self._participant.onIceCandidate.bind(self._participant),
      browserType: browserName,
      turnsConfig: self._turnsConfig,
      H264Codec: true
    };

    self._participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendonly(options,
      function (kurentoError) {
        if (kurentoError) {
          console.log('---error---- ', kurentoError);
        }
        // self._confPageService.initLocalPeerStatsObs(self._participant);
        // this will mute the audio of the user
        // self._participant.rtcPeer.audioEnabled = false;
        clearTimeout(this._updateBitrateTimeoutId);
        if (!resendOffer) {
          self._participant.rtcPeer.generateOffer(self._participant.offerToSendH264Video.bind(self._participant));
          this._updateBitrateTimeoutId = setTimeout(() => {
            self.updateBitrate(512);
          }, 3000);
        } else {
          self._participant.rtcPeer.generateOffer(self._participant.offerToChangeQualityVideo.bind(self._participant));
          this._updateBitrateTimeoutId = setTimeout(() => {
            self.updateBitrate(512);
          }, 3000);
        }

      }
    );
    // setTimeout(() => {
    //   self._participant.rtcPeer.videoEnabled = false;
    // }, 5000)
  }
  iceCandidateHandler(parsedMsg, webSocket) {
    if (this._participant.rtcPeer === undefined) {
      return;
    }
    this._participant.rtcPeer.addIceCandidate(parsedMsg.candidate, function (error) {
      if (error) {
        console.log('Error adding candidate: ' + error);
        return;
      }
    });
  }

  receiveVideoResponse(result) {
    if (this._participant.rtcPeer === undefined) {
      return;
    }
    if (result !== undefined) {
      this._participant.rtcPeer.processAnswer(result.answer, function (error) {
        if (error) { return console.error(error); }
      });
    }
  }

  sendMsg(payLoad, webSocket) {
    if (payLoad !== undefined && this._webSocket !== null && this._webSocket.readyState === 1) {
      const reqFor = payLoad.req;
      payLoad = JSON.stringify(payLoad);
      this._logService.debug('H264 Socket Handler -> Data Sent to Kurento >>>>', payLoad);
      this._webSocket.send(payLoad);
    }
  }

  connectionHeartBeat() {
    if (this.heartBeatIntervalId) {
      clearInterval(this.heartBeatIntervalId);
    }

    this.heartBeatIntervalId = setInterval(() => {
      this.sendMsg({
        'req': 'hrtbeat'
      }, this._webSocket);
    }, 5000);
  }

  updateBitrate(bandwidth: any): void {
    if ('RTCRtpSender' in window) {
      const pc1 = this._participant.rtcPeer;
      const videoSender = pc1.getSenders()[1];
      pc1.getSenders().forEach(sender => {
        if (sender.track !== undefined) {
          if (sender.getParameters !== undefined) {
            const parameters = sender.getParameters();
            if (sender.track !== null && sender.track.kind === 'video') {
              if (!parameters.encodings) {
                parameters.encodings = [{}];
              }
              if (bandwidth === 'Unlimited') {
                delete parameters.encodings[0].maxBitrate;
              } else {
                if (bandwidth !== 64) {
                  parameters.encodings[0].maxBitrate = (bandwidth - 15) * 1000;
                } else {
                  parameters.encodings[0].maxBitrate = bandwidth * 1000;
                }

              }
              if (sender.setParameters !== undefined) {
                sender.setParameters(parameters)
                  .then(() => {
                    clearInterval(this.statsInterval);
                    // this._confPageService.initLocalPeerStatsObs(this._participant);
                    //this.getSenderStats(this.participant);
                  })
                  .catch(e => console.error(e));
              } else {
                console.log("sender ", sender);
              }
              return;
            }
          } else {
            // this._confPageService.initLocalPeerStatsObs(this._participant);
          }

        }
      });
    }
  }
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState === 1) {

      this.sendMsg({
        'req': 'leaveMeetingRoom'
      }, this._webSocket);
      this._webSocket.close();
      this._webSocket = null;
      clearInterval(this.heartBeatIntervalId);
    }
    this._bitrateChangeSubs.unsubscribe();
  }

}
