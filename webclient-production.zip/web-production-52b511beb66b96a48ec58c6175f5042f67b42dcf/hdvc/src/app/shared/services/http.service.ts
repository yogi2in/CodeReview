import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { catchError,tap} from 'rxjs/operators';
import { error } from '@angular/compiler/src/util';

import { HttpResponseModel } from '../model/http.response.model';
//import { UtilService } from './utils.services';

@Injectable({providedIn: 'root'})

export class HttpService {
  public httpResponseObservable$ = new Subject<HttpResponseModel>();
  private errorProcessor = new Subject<{isError:boolean,errorObj: {}, successMsg:string}>();
  //public accessToken="";

  errorProcessorListener() {
    return this.errorProcessor.asObservable();
  }
  constructor(
    private _httpClient: HttpClient
  ) {}

  private httpOptions = {
    // headers: new HttpHeaders({
    //   'Content-Type':  'application/json'
    // })
    //withCredentials: true
  };

  /**
   * @param params to create a meeting
   */
  post(params) {
    return this._httpClient.post(params.url, params.body, this.httpOptions)
    .pipe(
      tap(
          //data => this.errorProcessor.next({isError:false, errorObj: {}}),
          data => {
              /* if(data.message != undefined && data.message != null){
                  this.errorProcessor.next({isError:false, errorObj: {},successMsg:data.message})
              } */
              this.errorProcessor.next({isError:false, errorObj: {},successMsg:""})
          },
          error => this.errorProcessor.next({isError:true, errorObj: error, successMsg:""})
      )
    );
    //.pipe(catchError(this.errorHandler));
  }

  /**
   * params to get the meetings list
   */
  get(params) {
    return this._httpClient.get(params.url, this.httpOptions)
    .pipe(
      tap(
          //data => this.errorProcessor.next({isError:false, errorObj: {}}),
          data => {
              /* if(data.message != undefined && data.message != null){
                  this.errorProcessor.next({isError:false, errorObj: {},successMsg:data.message})
              } */
              this.errorProcessor.next({isError:false, errorObj: {},successMsg:""})
          },
          error => this.errorProcessor.next({isError:true, errorObj: error, successMsg:""})
      )
    );
  }

  /**
   * params to delete the selected meeting
   */
  delete(params){
    return this._httpClient.delete(params.url, this.httpOptions)
    .pipe(
      tap(
          //data => this.errorProcessor.next({isError:false, errorObj: {}}),
          data => {
              /* if(data.message != undefined && data.message != null){
                  this.errorProcessor.next({isError:false, errorObj: {},successMsg:data.message})
              } */
              this.errorProcessor.next({isError:false, errorObj: {},successMsg:""})
          },
          error => this.errorProcessor.next({isError:true, errorObj: error, successMsg:""})
      )
    );
  }

 /**
   * params to delete the selected meeting
   */
  put(params){
    return this._httpClient.put(params.url, params.body, this.httpOptions)
    .pipe(
      tap(
          //data => this.errorProcessor.next({isError:false, errorObj: {}}),
          data => {
              /* if(data.message != undefined && data.message != null){
                  this.errorProcessor.next({isError:false, errorObj: {},successMsg:data.message})
              } */
              this.errorProcessor.next({isError:false, errorObj: {},successMsg:""})
          },
          error => this.errorProcessor.next({isError:true, errorObj: error, successMsg:""})
      )
    );
  }

    //this.httpOptions.headers.append("body", params.body);
    //return this._httpClient.request(params.method, params.url, this.httpOptions);
      //.pipe<IEmployee[]>(catchError(this.errorHandler));
      // .subscribe(
      //   (response: any) => {
      //     this.httpResponseObservable$.next({status: 'Success', data: response.data, reqFor: reqParams.reqFor});
      //   }, (error: any) => {
      //     this.httpResponseObservable$.next({status: 'Success', data: error.error, reqFor: reqParams.reqFor});
      //   }
      // );
  }

  // httpResponseObservableListener() {
  //   this.httpResponseObservable$.asObservable();
  // }
