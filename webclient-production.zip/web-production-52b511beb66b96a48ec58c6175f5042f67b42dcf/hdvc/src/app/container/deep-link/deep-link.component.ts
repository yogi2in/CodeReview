import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../shared/services/utils.services';
import { ConfirmDialogService } from '../../shared/services/confirm-dialog.services';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-deep-link',
  templateUrl: './deep-link.component.html',
  styleUrls: ['./deep-link.component.css']
})

export class DeepLinkComponent implements OnInit {

  constructor(
    private _utilService: UtilService,
    private _confirmDialogService: ConfirmDialogService,
    private _activeRoute: ActivatedRoute,
    private _router: Router
  ) { }

  ngOnInit() {
    console.log("deeplink called");
  }

  //continue with mobile browser
  continueWithBrowser(){
    // the below code will subscribe params to check the url has meeting id or not
    this._activeRoute.params.subscribe(
      (param: Params) => {
        // check the current url has meeting id or not
        if (param.meetingId !== undefined) {
          if(this._utilService.isMobile()){
            this._router.navigate(['/join-meeting', param.meetingId], { queryParams: { continue: 'Y'}});
          }
        }
      }
    );
  }

  //Downoad the app from play/app store
  downloadApp(){
    // the below code will subscribe params to check the url has meeting id or not
    this._activeRoute.params.subscribe(
      (param: Params) => {
        // check the current url has meeting id or not
        if (param.meetingId !== undefined) {
          if(this._utilService.isMobile()){
            // Download URL (TUNE link) for new users to download the app
            if(this._utilService.isIOS()){
              window.location.href = 'https://itunes.apple.com/us/app/hdvc-wave/id1460224649?mt=8';
            }
            if(this._utilService.isAndroid()){
              window.location.href = 'https://play.google.com/store/apps/details?id=com.panasonic.hdvcwave';
            }
          }
        }
      }
    );
  }

  //launch the app if it is already installed in device
  launchApp(){
    // the below code will subscribe params to check the url has meeting id or not
    this._activeRoute.params.subscribe(
      (param: Params) => {
        // check the current url has meeting id or not
        if (param.meetingId !== undefined) {
          if(this._utilService.isMobile()){
            // Deep link URL for existing users with app already installed on their device
            window.location.href = 'hdvcwave://join-meeting/' + param.meetingId;
            //setTimeout(()=>{
              console.log("setTimeout called");
              this._confirmDialogService.confirmThis("HDVC Wave app is not installed in this device. Do you want to install it now?", function () {
                // Download URL (TUNE link) for new users to download the app
                if(this._utilService.isIOS()){
                  window.location.href = 'https://itunes.apple.com/us/app/hdvc-wave/id1460224649?mt=8';
                }
                if(this._utilService.isAndroid()){
                  window.location.href = 'https://play.google.com/store/apps/details?id=com.panasonic.hdvcwave';
                }
              }, function () {
                //alert("No clicked");
              })
            //} , 1000);
          }
        }
      }
    );
  }
}
