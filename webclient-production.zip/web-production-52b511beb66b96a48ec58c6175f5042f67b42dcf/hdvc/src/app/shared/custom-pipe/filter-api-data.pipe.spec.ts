import { FilterApiDataPipe } from './filter-api-data.pipe';

describe('FilterApiDataPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterApiDataPipe();
    expect(pipe).toBeTruthy();
  });
});
