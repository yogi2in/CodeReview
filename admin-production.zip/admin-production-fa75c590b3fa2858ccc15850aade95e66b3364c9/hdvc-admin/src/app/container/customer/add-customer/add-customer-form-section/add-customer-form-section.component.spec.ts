import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCustomerFormSectionComponent } from './add-customer-form-section.component';

describe('AddCustomerFormSectionComponent', () => {
  let component: AddCustomerFormSectionComponent;
  let fixture: ComponentFixture<AddCustomerFormSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddCustomerFormSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCustomerFormSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
