import { Component, OnInit, Input } from '@angular/core';
import { PollService } from './poll.service';
import { Subscription } from 'rxjs';
declare var $;

@Component({
  selector: 'app-poll',
  templateUrl: './poll.component.html',
  styleUrls: ['./poll.component.css']
})
export class PollComponent implements OnInit {

  @Input() meetingId;
  @Input() hostUser;
  @Input() userId;
  public showCreateModal: boolean = false;
  public createdPoll: boolean = true;
  public launchPollModal: boolean = false;
  public createModalFirstPanel: boolean = true;
  public pollResData;
  public editPollData = null;
  public pollLaunchData;
  public editPollId = null;
  public pollId;
  public pollStart: any;
  public livePoll: boolean = false;
  public launchPollId;
  private sharePollSubscription = new Subscription();
  private clearTimeOutObj: any;
  public showLoader: boolean = false;
  public showThankYouModal: boolean = false;
  public isPollModalCloseByUser: boolean = false;
  public thankYouMsge: string = "";
  public pollSummaryView: boolean = false;

  constructor(
    private pollService: PollService) {}

  ngOnInit() {
    this.pollSummaryView = false;
    if(this.hostUser === 1){
      this.getPollList(false);
    }
    
    /*
    * The below function subscribe here. When socket send an observable poll start/end.
    */
    this.sharePollSubscription = this.pollService.sharePollListener().subscribe(
      (res) => {
        console.log("Poll share data", res, res.sharePollInfo.pollStatus);
        if(res.sharePollInfo.pollStatus === 'start' && res.sharePollInfo.pollId != undefined && res.sharePollInfo.pollId != null){
          this.createModalFirstPanel = false;
          this.showCreateModal = false;
          this.pollStart = 'start';
          this.pollId = res.sharePollInfo.pollId;
          this.showThankYouModal = false;
          this.thankYouMsge = "Thank you for participating in the poll."
        } else {
          this.pollStart = 'end';
          this.livePoll = false;
          if(this.isPollModalCloseByUser == false){
            this.thankYouMsge = "Poll is ended by meeting owner.";
            this.showThankYouModal = true;
          }
        }
        this.isPollModalCloseByUser = false;
      }
    )

  }

  /*
   * The below function show the poll create form.
  */
  showCreatePoll(){
    this.showCreateModal = true;
    this.createModalFirstPanel = false;
    this.editPollId = null;
    this.editPollData = null;
  }

  getPollSummary(pollId: number) {
    this.launchPollId = pollId;
    this.userId = this.userId;
    this.livePoll = true;
    this.pollSummaryView = true;
    this.createModalFirstPanel = false;
    //this.showLoader = true;
  }
  /*
   * The below function call when modal close and click on close icon.
  */
  closeModal(evt){
    this.showCreateModal = false;
    this.launchPollModal = false;
    clearTimeout(this.clearTimeOutObj);
    this.clearTimeOutObj = setTimeout(() => {
      this.createModalFirstPanel = true;
    }, 1000);
    if(evt === true) {
      this.getPollList(true);
    } else {
      $('#createPollModal').modal('hide');
    }

  }

  /*
   * The below function get the poll list.
  */
  getPollList(showPollListModal: boolean) {
    let data = {
        meetingId: this.meetingId,
      }
    this.showLoader = true;

    this.pollService.getPollList(data).subscribe(
      (res: any) => {
        if(res.result != undefined && res.result != null) {
          
          this.pollResData = res.result;
          if(showPollListModal){
            $('#createPollModal').modal('show');
            this.createdPoll = true;
            this.createModalFirstPanel = true;
          } else {
            this.createModalFirstPanel = true;
          }
          this.showLoader = false;
          console.log("Get Poll list =>>>", res.result);
          if(res.result.length > 0){
            this.createdPoll = true;
          } else {
            this.createdPoll = false;
          }
        }
      },
      (err) => {
        console.log("Get Poll list error =>>>", err);
        this.createdPoll = false;
      }
    )
  }

  /*
   * The below function delete the poll.
  */
  deletePoll(pollId){
    let data = {
      pollId: pollId
    }
    this.showLoader = true;
    this.pollService.deletePoll(data).subscribe(
      (res) => {
        console.log("Delete poll ====>>>>", res);
        this.getPollList(true);
      },
      (err) => {
        console.log("Error", err);
      }
    )
  }

  /*
   * The below function editing the form.
  */
  editPoll(pollId){
    let data = {
        pollId: pollId
      }
    this.pollService.pollRead(data)
    .subscribe(
      (res) => {
        console.log("Edit Poll ====>>>", res['result']);
        this.editPollData = res['result'];
        this.showCreateModal = true;
        this.createModalFirstPanel = false;
      },
      (err) => {
        console.log("Edit Poll Error ====>>>", err);
      }
    )
  }

  /*
   * The below function call when click on launch btn and show the poll details to the participant.
  */
  launchPoll(pollId) {
    const pollInfo = {
      pollId: pollId,
      pollStatus :'start',
      req : 'sharePollStatus',
      userId : this.userId
    }
    this.pollSummaryView = false;
    this.pollService.startPollObs(pollInfo);
    this.createModalFirstPanel = false;
    this.showCreateModal = false;
    this.livePoll = true;
    this.launchPollId = pollId
  }

  /*
   * The below function call when live poll end and this function get the updated poll list.
  */
  endLivePoll(eve){
    if(eve === true){
      this.livePoll = false;
      // this.createModalFirstPanel = true;
      console.log("end live poll", eve);
      this.pollResData = [];
      this.getPollList(false);
    } else {
      console.log("end live poll", eve);
    }
  }


  onPollSubmit(){
    this.isPollModalCloseByUser = true;
    this.showThankYouModal = true;
  }

  /*
   * The below function destroy the event.
  */
  ngOnDestroy(): void {
    this.sharePollSubscription.unsubscribe();
    clearTimeout(this.clearTimeOutObj);
  }

}
