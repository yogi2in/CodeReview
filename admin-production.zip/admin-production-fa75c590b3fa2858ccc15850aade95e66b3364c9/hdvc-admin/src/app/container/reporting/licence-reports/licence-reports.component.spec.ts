import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenceReportsComponent } from './licence-reports.component';

describe('CallReportsComponent', () => {
  let component: LicenceReportsComponent;
  let fixture: ComponentFixture<LicenceReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LicenceReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenceReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
