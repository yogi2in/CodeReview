import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import {ForgotPasswordService} from './forgot-password.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  // creates instance of FormGroup called myProfile
  forgetPasswordForm: FormGroup;
  Errormsg:any;
  alertClass:any;
  submitted = false;
  public resetMessage;
  public userNotExist;
  public hideRestForm: boolean = true;
  public forgotMessage = 'Email to reset password is sent to registered email address';
  public userNotExistMessage = 'This Email is not registered';
  private clearSetTimeOut;
  constructor(
    private fb: FormBuilder, 
    private _objForgotPasswordService: ForgotPasswordService,
    private router: Router ) {
    this.buildForm();
   }

  ngOnInit() {
  }

  public buildForm() {
    // use FormBuilder to create a form group
    this.forgetPasswordForm = this.fb.group({
      'email': [null, [Validators.required, Validators.email]]
    });
  }

  /* This function called for sending emails after forget password form submitt */
  public sendEmail() {
    this.submitted = true;
    if (this.forgetPasswordForm.invalid) {
      return;
    } else {
      this.submitted = false;
      this._objForgotPasswordService.setPassword({"email":this.forgetPasswordForm.value.email})
      .subscribe((response:any) => {
        this.resetMessage = response.message;
        this.hideRestForm = false;
        let self = this;
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(function() {
          self.router.navigate(['/login']);
        },1000)
    },
    error => {
      console.log('error', error);
      this.userNotExist = error.message;
      this.hideRestForm = false;
    });
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }
}
