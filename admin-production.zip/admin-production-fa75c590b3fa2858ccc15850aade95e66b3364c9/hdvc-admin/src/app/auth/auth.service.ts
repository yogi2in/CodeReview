/**
 * AuthService contains all authentication related methods
 */
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { RestApiService } from '../_sharedService/restApi.service';
import { environment } from '../../environments/environment';
import { CookieService } from 'ngx-cookie-service';
import { LocalStorageService } from 'angular-2-local-storage';
import { Router } from '@angular/router';
import * as moment from 'moment';


@Injectable({
    providedIn: 'root'
})
export class AuthService {
    private isAuthenticate: boolean;
    private authProcess = new Subject<{isSuccess: boolean, data: any}>();
    private authPermissionError = new Subject<{isError: boolean, errorObj: {}}>();
    private userPrivlegeProcess = new Subject<{isSuccess: boolean, data: any}>();
    constructor(private http: HttpClient, private restService :RestApiService, private cookieService: CookieService, private router: Router, private localStorageService: LocalStorageService) { }

    authProcessListener() {
      return this.authProcess.asObservable();
    }

    authPermissionErrorListener() {
      return this.authPermissionError.asObservable();
    }

    userPrivlegeListener() {
      return this.userPrivlegeProcess.asObservable();
    }
    
    /* This method executed for login api */
    login(email: string, password: string, remindMe: boolean) {
      const authdata = {
        email: email,
        password: password,
        isRememberMe:remindMe
      };
      this.restService.sendRequest('Post',environment.BASE_URI+'login',authdata)
        .subscribe(
          (res) => {
            // if sucees set auth token
            if(res["result"] != null){
                if(this.checkUserBasedOnRole(res["result"].user.roleName)){
                  this.removeToken();
                  // remove user from local storage to log user out
                  this.localStorageService.remove('currentUser');

                  this.setToken(res["result"]);
                  this.isAuthenticate = true;
                  //this.getLoggedInUserPrivilege();
                  // call next for subscribe in component
                  this.authProcess.next({isSuccess: true, data: res['result']});
                }else{
                  // for other role login show error msg(permission denied)
                  let errorObj = {status: 403, message: "Permission denied"}
                  this.authPermissionError.next({isError:true, errorObj: errorObj})

                }
                
            }
            
          }
        );
    }


    /* This method set auth token and current user details in localStorage */
    public setToken(response): void {
      //this.localStorageService.set('currentUser', JSON.stringify(response.user));
      this.localStorageService.set('currentUser', response.user);
      this.localStorageService.set('authToken', response.token);
      //this.cookieService.set('authToken',response.token, 365000, 'path', window.location.hostname);
      this.localStorageService.set('tokenExpirationTime',response.tokenExpirationTime); //response.tokenExpirationTime
    }

    /* This method return auth token */
    public getToken(): string {
      
        return this.localStorageService.get('authToken');
    }

    /* This method remove auth token */
    public removeToken(){
      //this.localStorageService.remove('authToken');
      this.localStorageService.remove('authToken');
      this.localStorageService.remove('tokenExpirationTime');
    }

    public getCurrentUserObj(){
      let currentUser = this.localStorageService.get('currentUser');
      console.log("currentUser",currentUser)
      return currentUser;
      //return JSON.parse(currentUser)
    }

     /* This method call for logout and remove token and current user details from local storage */
    logout() {
      console.log("logout called")
      let data = {
        "registrationId":null
      }
      this.restService.sendRequest('Post',environment.BASE_URI+'logout',data)
      .subscribe(
        (res) => {
          this.removeToken();
          // remove user from local storage to log user out
          this.localStorageService.remove('currentUser');
          setTimeout(() => {
            this.router.navigate(['/']);
          },1000);
          this.authProcess.next({isSuccess: false, data: res['result']});
        }
      );
    }

    checkUserBasedOnRole(roleName){
      /* if(roleName == 'CUSTOMER_ADMIN'){
        return false;
      }else{
        return true;
      } */
      return true;
    }

    getLoggedInUserPrivilege(){
      let data = {};
      return this.restService.sendRequest('Get',environment.BASE_URI+'role/userPrivilege',data)
    }

    checkTokenExpiryTime(time){
      let timeExp = Number(time);
       let tokenExpiryTime = moment(timeExp).format();
       let today = moment().format();
       let isAfter = moment(today).isAfter(tokenExpiryTime);
       return isAfter;
    }

}
