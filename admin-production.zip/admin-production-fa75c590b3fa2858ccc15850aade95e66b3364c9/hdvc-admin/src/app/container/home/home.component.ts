import { Component, OnInit, Renderer2 } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public bodyElem = document.getElementsByTagName('body')[0];
  constructor(private render: Renderer2) { }

  ngOnInit() {
    this.render.addClass(this.bodyElem, 'home-page');
  }

  // Destory the subscription.
  ngOnDestroy(): void {
    this.render.removeClass(this.bodyElem, 'home-page');
  }

}
