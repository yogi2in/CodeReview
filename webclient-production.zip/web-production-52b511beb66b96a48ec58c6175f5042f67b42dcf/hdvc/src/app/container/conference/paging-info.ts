export interface PagingInfo {
  curPageNo: number;
  curActiveUsers: any;
  curPageSizeCount: number;
  curParticipantCount: number
}
