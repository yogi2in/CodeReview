import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  private userSubscription = new Subscription();
  public profileData: any;
  public profilePicUrl: string;
  loadEditProfile = false;
  showGlobalError = true;
  constructor(private profileService: ProfileService) { }

  ngOnInit() {
    // Subscribe the Observables after success and set profile data
    this.userSubscription = this.profileService.userProfileListner()
      .subscribe(
        (res) => {
          if (res.isSuccess === true) {
            this.profileData = res.userProfileData;
            this.profilePicUrl = res.userProfileData.profileImage + "?" + Math.random() * 100000000000000000000;
          }
        }
      );

    // call getUserProfile from profile service
    this.profileService.getUserProfile();

    this.profileService.change.subscribe(isOpenChangePwd => {
      this.showGlobalError = !isOpenChangePwd;
    });
  }

  toggleProfile() {
    this.loadEditProfile = !this.loadEditProfile
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.userSubscription.unsubscribe();
  }

}
