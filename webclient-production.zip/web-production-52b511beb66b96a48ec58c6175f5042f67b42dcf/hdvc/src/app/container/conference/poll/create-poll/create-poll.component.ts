import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators, AbstractControl, FormControl } from '@angular/forms';
import { PollService } from '../poll.service';
declare var $;

@Component({
  selector: 'app-create-poll',
  templateUrl: './create-poll.component.html',
  styleUrls: ['./create-poll.component.css']
})
export class CreatePollComponent implements OnInit {
  pollInfo = {
    pollTitle: "",
    pollQuestionInfo: [
      {
        pollQuestion: {
          id: "",
          ques: ""
        },
        pollOptions: [
          {
            id: "",
            option: "",
          }
        ]
      }
    ]
  }

  createPoll: FormGroup;
  public formJsonData: any;
  public pollJsonData: any;
  public pollQuesData: any;
  public editPollId;
  @Output() loadPollList = new EventEmitter();
  @Input() editPollData;
  @Input() meetingId;
  public createPollFormSubmited;
  public hideAddNewOptionBtn: boolean = true;
  public showLoader: boolean = false;
  public disableCreatePoll: boolean = false;
  private clearTimeout: any;
  public formFieldEmpty:boolean = false;

  constructor(private formBuilder: FormBuilder, private pollService: PollService) { }

  ngOnInit() {
    this.createFormFields();

    if (this.editPollData != undefined && this.editPollData != null) {
      this.editPollView(this.editPollData);
    }
  }

  createFormFields() {
    this.createPoll = this.formBuilder.group({
      pollTitle: ['', [Validators.required, this.removeSpaceKey]],
      pollQuestionInfo: this.formBuilder.array([])
    })
    this.setFormFields();
  }

  setFormFields() {
    let control = <FormArray>this.createPoll.controls.pollQuestionInfo;
    //console.log("skjdhfkjsd", control);
    let idx = 0;
    this.pollInfo.pollQuestionInfo.forEach(x => {
      control.push(this.formBuilder.group({
        pollQuestion: this.formBuilder.group({
          id: [idx + 1],
          ques: [x.pollQuestion.ques, [Validators.required, this.removeSpaceKey]]
        }),
        pollOptions: this.setPollOptions(x)
      }))
      ++idx;
    })
  }

  setPollOptions(x) {
    let arr = new FormArray([])
    x.pollOptions.forEach(y => {
      arr.push(this.formBuilder.group({
        id: 1,
        option: [y.option, [Validators.required, this.removeSpaceKey]]
      }))
      arr.push(this.formBuilder.group({
        id: 2,
        option: [y.option, [Validators.required, this.removeSpaceKey]]
      }))
    })
    return arr;
  }

  /*
   * The below function add new options.
  */
  addNewOption(control) {
    if (control.length < 10) {
      control.push(
        this.formBuilder.group({
          id: control.length + 1,
          option: ['', [Validators.required, this.removeSpaceKey]]
        })
      )
      this.hideAddNewOptionBtn = true;
    } else {
      this.hideAddNewOptionBtn = false;
    }
  }

  /*
   * The below function remove options.
  */
  removeOption(control, index) {
    control.removeAt(index);
    //console.log("Remove ioption ==>>", control)
    let arr = new FormArray([])
    let idx = 1;
    control.value.forEach(y => {
      arr.push(this.formBuilder.group({
        id: y.id = idx
      }))
      idx++;
    });
    if (control.length < 10) {
      this.hideAddNewOptionBtn = true;
    } else {
      this.hideAddNewOptionBtn = false;
    }
  }

  /*
   * The below function add new question.
  */
  addNewQuestion() {
    this.createPollFormSubmited = false;
    let control = <FormArray>this.createPoll.controls.pollQuestionInfo;
    control.push(
      this.formBuilder.group({
        pollQuestion: this.formBuilder.group({
          id: [control.length + 1],
          ques: ['', [Validators.required, this.removeSpaceKey]]
        }),
        pollOptions: this.formBuilder.array([
          this.formBuilder.group({
            id: 1,
            option: ['', [Validators.required, this.removeSpaceKey]]
          }),
          this.formBuilder.group({
            id: 2,
            option: ['', [Validators.required, this.removeSpaceKey]]
          })
        ])
      })
    )
  }

  /*
   * The below function delete the poll question.
  */
  deleteQuestion(control, index) {
    // let control = <FormArray>this.createPoll.controls.pollQuestionInfo;
    control.removeAt(index);

    let arr = new FormArray([])
    let idx = 1;
    control.value.forEach(y => {
      arr.push(this.formBuilder.group({
        id: y.pollQuestion.id = idx
      }))
      idx++;
    });
  }

  /*
   * The below function save the form data when creating the poll.
  */
  postCreatePoll() {
    this.createPollFormSubmited = true;
    let currentUser = localStorage.getItem('currentUser');
    currentUser = JSON.parse(currentUser)
    if (this.createPoll.valid) {
      this.disableCreatePoll = true;
      this.formJsonData = JSON.stringify(this.createPoll.value)
      this.pollJsonData = JSON.parse(this.formJsonData);
      this.pollQuesData = this.pollJsonData.pollQuestionInfo;
      let data = {
        meetingId: this.meetingId,
        pollTitle: this.pollJsonData.pollTitle,
        pollInfo: this.pollJsonData,
        creator_email: currentUser["email"]
      }
      this.showLoader = true;
      this.pollService.createPoll(data).subscribe(
        (res) => {
          console.log("res", res);
          this.createFormFields();
          this.loadPollList.emit(true);
          this.disableCreatePoll = false;
        },
        (err) => {
          console.log("error", err);
          this.disableCreatePoll = false;
        }
      )
    } else {
      return;
    }
  }

  /*
   * The below function call when click on edit btn and edit form visiable.
  */
  editPollView(editPollData) {
    this.editPollId = editPollData.pollId;
    this.createPoll = this.formBuilder.group({
      pollTitle: [editPollData.pollTitle],
      pollQuestionInfo: this.formBuilder.array([])
    })
    this.setEditFormFields(editPollData.pollQuestionInfo)
  }

  /*
   * The below function set the form fields.
  */
  setEditFormFields(pollQuestionInfo) {
    let control = <FormArray>this.createPoll.controls.pollQuestionInfo;
    console.log("pollQuestionInfopollQuestionInfo", pollQuestionInfo);
    pollQuestionInfo.forEach(x => {
      control.push(this.formBuilder.group({
        pollQuestion: this.formBuilder.group({
          id: [x.pollQuestion.id],
          ques: [x.pollQuestion.ques]
        }),
        pollOptions: this.setEditPollOptions(x)
      }))
    })
  }

  /*
   * The below function set the form option fields.
  */
  setEditPollOptions(x) {
    let arr = new FormArray([])
    x.pollOptions.forEach(y => {
      arr.push(this.formBuilder.group({
        id: [y.id],
        option: [y.option]
      }))
    })
    return arr;
  }

  /*
   * The below function call when poll update.
  */
  updatePoll(editPollId) {
    this.createPollFormSubmited = true;
    let currentUser = localStorage.getItem('currentUser');
    currentUser = JSON.parse(currentUser)
    if (this.createPoll.valid) {
      this.disableCreatePoll = true;
      this.formJsonData = JSON.stringify(this.createPoll.value)
      this.pollJsonData = JSON.parse(this.formJsonData);
      let data = {
        pollInfo: this.pollJsonData,
        creator_email: currentUser["email"],
        pollId: editPollId
      }
      this.showLoader = true;
      this.pollService.pollUpdate(data).subscribe(
        (res) => {
          console.log("Res", res);
          this.loadPollList.emit(true);
          this.createFormFields();
          this.disableCreatePoll = false;
        },
        (err) => {
          console.log("error", err);
          this.disableCreatePoll = false;
        }
      )
    } else {
      return;
    }
  }

  /*
   * The below function close the modal.
  */
  closeModal() {
    $('#createPollModal').modal('hide');

    clearTimeout(this.clearTimeout);
    this.clearTimeout = setTimeout(() => {
      this.createFormFields();
      this.loadPollList.emit(false);
    }, 100);
  }

  /*
   * The below function control the space key when no any text enter in input box// control the whitespace.
  */
  removeSpaceKey(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    if (control && control.value && !control.value.replace(/\s/g, '').length){
      control.setValue('');
    }
    return isValid ? null : { 'whitespace': true };
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearTimeout);
  }


}
