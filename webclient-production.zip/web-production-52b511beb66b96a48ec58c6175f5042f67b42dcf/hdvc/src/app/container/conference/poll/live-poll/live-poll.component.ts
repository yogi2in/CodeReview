import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { PollService } from '../poll.service';
import { Subscription } from 'rxjs';
import { ConferencePageService } from '../../conference-page-service.service';
declare var $;

@Component({
  selector: 'app-live-poll',
  templateUrl: './live-poll.component.html',
  styleUrls: ['./live-poll.component.css']
})
export class LivePollComponent implements OnInit {

  @Input() pollId;
  @Input() userId;
  @Input() pollSummaryView;
  @Output() endLivePoll = new EventEmitter;
  public pollSummary: any;
  public totalAnswerCountPerQuestion = {};
  private answerSubscription = new Subscription();
  public showLoader: boolean =  false;
  public hostName: string = "";
  private clearTimeout: any;
  public cunterIndex: number = 1;

  constructor(
    private pollService: PollService,
    private _confPageService: ConferencePageService) { }

  ngOnInit() {
    this.hostName = this._confPageService.hostName;
    if (this.pollSummaryView === false) {
      this.pollAnswerModal(this.pollId);
      this.answerSubscription = this.pollService.answerPollListener().subscribe(
        (res) => {
          console.log("Response", res.answerInfo);
          this.updatePollSummary(res.answerInfo.questionId, res.answerInfo.answerId);
          console.log('updated poll summary ', this.pollSummary);
        }
      )
    } else {
      this.getPollSummary(this.pollId);
    }




  }

  pollAnswerModal(pollId) {
    this.showLoader = true;
    const data = {
      pollId: pollId
    }
    this.pollService.pollRead(data).subscribe(
      (res: any) => {
        if (res.result !== undefined) {
          this.pollSummary = this.createPollSummary(res.result);
          this.showLoader = false;

          console.log('this.pollSummary begenning -->', this.pollSummary);
        }
      },
      (err) => {
        console.log("", err);
      }
    )
  }

  createPollSummary(pollInfo) {
    if (pollInfo !== undefined && pollInfo.pollId !== undefined) {
      pollInfo.totalParticipant = 20;
      pollInfo.pollQuestionInfo = pollInfo.pollQuestionInfo.map((pollItem) => {
        if (pollItem.pollQuestion.responseCounter === undefined) {
          pollItem.pollQuestion.responseCounter = 0;
        }
        return {
          pollQuestion: pollItem.pollQuestion,
          pollOptions: this.addPollAnswerCounter(pollItem.pollOptions)
        }
      })
    }
    return pollInfo;
  }

  addPollAnswerCounter(pollOptions) {
    if (pollOptions !== undefined && pollOptions.length >= 1) {
      pollOptions = pollOptions.map(answerItem => {
        return {
          id: answerItem.id,
          option: answerItem.option,
          answerCounter: 0
        }
      })
    }
    return pollOptions;
  }

  updatePollSummary(qIdx, aIdx) {
    this.pollSummary = this.updateAnswerCount(this.pollSummary, qIdx, aIdx);
    this.updateTotalAnswerCountPerQuestion(qIdx, aIdx);
    console.log('this.totalAnswerCountPerQuestion[qIdx] ---> ', this.totalAnswerCountPerQuestion);
  }

  updateAnswerCount(pollSummary, qIdx, aIdx) {
    pollSummary.pollQuestionInfo = pollSummary.pollQuestionInfo.map((pollItem) => {
      if (pollItem.pollQuestion.id === qIdx) {
        pollItem.pollQuestion.responseCounter = pollItem.pollQuestion.responseCounter + 1;
        return {
          pollQuestion: pollItem.pollQuestion,
          pollOptions: this.increaseAnswerCounter(pollItem.pollOptions, aIdx)
        }
      } else {
        return {
          pollQuestion: pollItem.pollQuestion,
          pollOptions: pollItem.pollOptions
        }
      }
    });
    return pollSummary;
  }

  increaseAnswerCounter(answerItems, aIdx) {
    answerItems = answerItems.map(items => {
      if (items.id === aIdx) {
        items.answerCounter = items.answerCounter + 1;
      }
      return items;
    })
    return answerItems;
  }

  updateTotalAnswerCountPerQuestion(qIdx, aIdx) {
    if (qIdx !== undefined && aIdx !== undefined) {
      if (this.totalAnswerCountPerQuestion[qIdx] !== undefined) {
        this.totalAnswerCountPerQuestion[qIdx] = this.totalAnswerCountPerQuestion[qIdx] + 1;
      } else {
        this.totalAnswerCountPerQuestion[qIdx] = 1;
      }
    }
  }

  getPollSummary(pollId: number): void {
    if (pollId === undefined) {
      return;
    }
    // var response = {"summary":{"pollId":619,"pollTitle":"SHow Me","pollQuestionInfo":[{"pollQuestion":{"id":1,"ques":"Testing","responseCounter":2},"pollOptions":[{"id":1,"option":"A","answerCounter":2},{"id":2,"option":"B","answerCounter":0}]}],"totalParticipant":20}}
    // this.pollSummary = this.createPollSummary(response.summary);
    this.showLoader = true;
    this.pollService.getPollSummary(pollId).subscribe(
      (response: any) => {

        if (response.summary !== undefined) {
          this.pollSummary = response.summary; //this.createPollSummary(response.summary);
          this.hostName = this._confPageService.hostName;
          this.showLoader = false;
          console.log('this.pollSummary begenning -->', this.pollSummary);
        }
      },
      (error)=> {

      }
    )
  }

  /*
   * The below function end the live poll.
  */
  stopPoll(){
    //$('#createPollModal').modal('hide');
    const data ={
      pollId: this.pollId,
      pollSummary: this.pollSummary
    }
    console.log('data -->', data)
    const pollInfo = {
      pollId: this.pollId,
      pollStatus :'end',
      req : 'sharePollStatus',
      userId : this.userId
    }
    this.showLoader = true;
    this.pollService.pollEnd(data).subscribe(
      (res) => {
        console.log("Poll End", res);
        this.showLoader = false;
        this.endLivePoll.emit(true);
      },
      (err) =>{
        console.log("Poll End Error", err);
      }
    )

    this.pollService.startPollObs(pollInfo);
  }

  /*
   * The below function close the modal.  
  */
  closeModal(){
    $('#createPollModal').modal('hide');
    clearTimeout(this.clearTimeout);
    this.clearTimeout = setTimeout(() => {
      this.endLivePoll.emit(true);
    }, 100);
    
  }

  nextSlide(idxNum){
    if(idxNum > 0){
      this.cunterIndex++;
    }
  }

  prevSlide(idxNum){
    if(idxNum > 1){
      this.cunterIndex--;
    }
  }

  ngOnDestroy(): void {
    this.answerSubscription.unsubscribe();
    clearTimeout(this.clearTimeout);
  }
}
