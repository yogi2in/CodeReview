import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { DeviceSettingService } from '../device-setting/device-setting.service';
import { Subscription } from 'rxjs';
import { device } from './_model/device';
import { Router } from '@angular/router';
import { LogService } from 'src/app/shared/logger/log.service';
import { timeout } from 'rxjs/operators';
import { UtilService } from 'src/app/shared/services/utils.services';
import { FormBuilder, FormGroup } from '@angular/forms';
declare var window;
declare var SoundMeter;

@Component({
  selector: 'app-device-setting',
  templateUrl: './device-setting.component.html',
  styleUrls: ['./device-setting.component.css']
})
export class DeviceSettingComponent implements OnInit, OnDestroy {
  @Input() executeContext;
  @Output() deviceSettingModalClose = new EventEmitter();

  public prevAudioDeviceId: any;
  public audioDeviceId: any;
  public videoDeviceId: any;
  public prevVideoDeviceId: any;
  public currentBandWidth: any = 128;
  public configureLayout: any = {};
  public isAdaptiveLayoutEnabled: boolean = false;
  public videoConstraints: any;

  public videoPreviewElem: any;
  public audioFile = "assets/images/join-conference.mp3";
  public audioOutputTestVideoElm: any;

  public audioInputDeviceListArr: any = [];
  public videoInputDeviceListArr: any = [];
  public audioOutputDeviceListArr: any = [];
  public selectedAudioDeviceId: string = "";
  public selectedVideoDeviceId: string = "";
  public selectedOutputDeviceId: string = "";
  public onUpdateDeviceListSubs = new Subscription();
  private _onAccessAudioDevice = new Subscription();
  private _onAccessVideoDevice = new Subscription();

  private _isAudioDeviceAPIResponse: boolean = false;
  private _isVideoDeviceAPIReponse: boolean = false;
  public audioOutputElm: any;
  public isAudioDeviceAccess: boolean = false;
  public isVideoDeviceAccess: boolean = false;

  private _soundMeter: any;
  public _sendAudioLevelIntervalId: any;
  public audioVisualizerListItem: any;
  public audioInputError: string = "";
  public videoInputError: string = "";
  private _audioDeviceRetry: number = 0;
  private _videoDeviceRetry: number = 0;
  private _browserInfo: any;
  public hideAudioOutput: boolean = false;
  private _reCallEnumeratedDeviceListAPI: boolean = false;
  public btnLabel: string = "Join Meeting";
  public deviceSettingForm: FormGroup;
  public audioMediaStreamAvailable: boolean = false;
  public videoMediStreamAvailable: boolean = false;
  public isLoggedIn: boolean = false;
  public deviceSettingPage: boolean = false;
  public audioAccessFirstTime: boolean = true;
  public videoAccessFirstTime: boolean = true;
  public audioPause: boolean = false;
  public clearTimeOutSession: any;

  constructor(
    private _deviceSettingService: DeviceSettingService,
    private _router: Router,
    private _logService: LogService,
    private _utilService: UtilService,
    public fb: FormBuilder
  ) {
    this.deviceSettingForm = this.fb.group(
      {
        audioInput: [],
        audioOutput: [''],
        videoInput: ['']
      }
    )
  }

  ngOnInit() {
    this._browserInfo = this._utilService.getBrowserInfo();
    let userInfo = this._utilService.getInfoFromStorage('session', 'participantInfo');
    this.videoPreviewElem = <HTMLSelectElement>document.getElementById('video');
    this.audioOutputTestVideoElm = <HTMLInputElement>document.querySelector('#audio-output');
    this.hideAudioOutput = this._browserInfo.name === 'Firefox' ? true : false;
    if (this.executeContext === undefined) {
      if (userInfo === null) {
        this._router.navigate(['/join-meeting']);
        return;
      }
      this._deviceSettingService.resetDeviceList();
    } else {
      this.btnLabel = "Continue";
      this.audioInputDeviceListArr = this._deviceSettingService.getDeviceList('audioInput');
      this.videoInputDeviceListArr = this._deviceSettingService.getDeviceList('videoInput');
      this.audioOutputDeviceListArr = this._deviceSettingService.getDeviceList('audioOutput');
      let outputDeviceId = this._deviceSettingService.getSelectedDeviceId('output');
      console.log('outputDeviceId on ngoninit -->', outputDeviceId)
      if (this.executeContext) {
        this._deviceSettingService.attachSinkId(outputDeviceId, this.audioOutputTestVideoElm);
        this.deviceSettingForm.controls['audioOutput'].setValue(outputDeviceId, { self: true });
      }
    }    
    try {
      window.AudioContext = window.AudioContext || window.webkitAudioContext;
      window.audioContext = new AudioContext();
      this._soundMeter = window.soundMeter = new SoundMeter(window.audioContext);
      this._logService.info('Conference --> AudioMeter --> Available');
    } catch (e) {
      this._logService.info('Conference --> AudioMeter --> Web Audio API not supported.');
    }

    this.audioVisualizerListItem = document.querySelectorAll('.audio-visualizer li');
    this.onUpdateDeviceListHandler();
    this.onAccessAudioDeviceHandler();
    this.onAccessVideoDeviceHandler();
    this._deviceSettingService.resetDeviceList();
    this._deviceSettingService.getEnumerateDevices();

    let userLoginDetails = localStorage.getItem('currentUser');
    if (userLoginDetails != undefined && userLoginDetails != null) {
      this.isLoggedIn = true;
    }

    if (this._router.url === '/device-settings') {
      this.deviceSettingPage = true;
    }
  }

  onUpdateDeviceListHandler() {
    this.onUpdateDeviceListSubs = this._deviceSettingService.onUpdateDeviceList().subscribe(
      (res: any) => {
        if (res.deviceListUpdated) {
          this.audioInputDeviceListArr = this._deviceSettingService.getDeviceList('audioInput');
          this.videoInputDeviceListArr = this._deviceSettingService.getDeviceList('videoInput');
          this.audioOutputDeviceListArr = this._deviceSettingService.getDeviceList('audioOutput');

          if (this._browserInfo.name === 'Firefox') {
            this.hideAudioOutput = true;
          } else {
            if (this.executeContext === undefined) {
              if (this.audioOutputDeviceListArr.length > 0) {
                this._deviceSettingService.updateSelectedDeviceId(this.audioOutputDeviceListArr[0].deviceId, 'output');
                this._deviceSettingService.attachSinkId(this.audioOutputDeviceListArr[0].deviceId, this.audioOutputTestVideoElm);
                this.deviceSettingForm.controls['audioOutput'].setValue(this.audioOutputDeviceListArr[0].deviceId, { self: true });
              }
            }
          }

          if (this.executeContext !== undefined || this._reCallEnumeratedDeviceListAPI === true) {
            if (this.executeContext !== undefined) {
              this.selectedAudioDeviceId = this._deviceSettingService.getSelectedDeviceId('audio');
              this.selectedVideoDeviceId = this._deviceSettingService.getSelectedDeviceId('video');
              this.selectedOutputDeviceId = this._deviceSettingService.getSelectedDeviceId('output');
              let videoMediaStream = this._deviceSettingService.getStoredStream('video');
              let audioMediaStream = this._deviceSettingService.getStoredStream('audio');
              this.audioLevelMeter(this._soundMeter, audioMediaStream);
              console.log('this.audioInputDeviceListArr ', this.audioInputDeviceListArr);
              let isAudioDeviceExists = this.checkDeviceIdExists(this.selectedAudioDeviceId, this.audioInputDeviceListArr);
              let isVideoDeviceExists = this.checkDeviceIdExists(this.selectedVideoDeviceId, this.videoInputDeviceListArr);
              let isOutputDeviceExists = this.checkDeviceIdExists(this.selectedOutputDeviceId, this.audioOutputDeviceListArr);
              // this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'audio');
              // this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'video');
              if (isAudioDeviceExists) {
                this.deviceSettingForm.controls['audioInput'].setValue(this.selectedAudioDeviceId, { self: true });
              } else {
                this.deviceSettingForm.controls['audioInput'].setValue("", { self: true });
              }

              if (isVideoDeviceExists) {
                this.deviceSettingForm.controls['videoInput'].setValue(this.selectedVideoDeviceId, { self: true });
              } else {
                this.deviceSettingForm.controls['videoInput'].setValue("", { self: true });
              }              
              
              this.videoPreviewElem.srcObject = videoMediaStream;
              if (this._browserInfo.name !== 'Firefox' && this.selectedOutputDeviceId.length > 1) {
                if (isOutputDeviceExists) {
                  this._deviceSettingService.attachSinkId(this.selectedOutputDeviceId, this.audioOutputTestVideoElm);
                  this.deviceSettingForm.controls['audioOutput'].setValue(this.selectedOutputDeviceId, { self: true });
                } else  {
                  let firstAvaialbleOutputDeviceId = this.audioOutputDeviceListArr[0].deviceId;
                  this._deviceSettingService.attachSinkId(firstAvaialbleOutputDeviceId, this.audioOutputTestVideoElm);
                  this.deviceSettingForm.controls['audioOutput'].setValue(firstAvaialbleOutputDeviceId, { self: true });
                }               
              }
            }
            return;
          }

          if (this.audioInputDeviceListArr.length > 0 && this.videoInputDeviceListArr.length > 0) {
            this.selectedAudioDeviceId = this.audioInputDeviceListArr[0].deviceId;
            this.selectedVideoDeviceId = this.videoInputDeviceListArr[0].deviceId;
            this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'audio');
            this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'video');
          } else {
            if (this.audioInputDeviceListArr.length > 0 && this.videoInputDeviceListArr.length === 0) {
              this.selectedAudioDeviceId = this.audioInputDeviceListArr[0].deviceId;
              this.videoInputError = this._deviceSettingService.getErrorMsg('NO_VIDEO_INPUT');
            } else if (this.audioInputDeviceListArr.length === 0 && this.videoInputDeviceListArr.length > 0) {
              this.selectedVideoDeviceId = this.videoInputDeviceListArr[0].deviceId;
              this.audioInputError = this._deviceSettingService.getErrorMsg('NO_AUDIO_INPUT');
            } else {
              console.log('No Device Found');
            }
          }
        }
      }
    );
  }

  checkDeviceIdExists(deviceId: any, allDeviceIdsList: any): boolean {
    let continueLoop: boolean = true;
    let deviceAvailable: boolean = false;
    allDeviceIdsList.map((device, idx)=> {
      if (device.deviceId !== undefined && device.deviceId === deviceId && continueLoop === true) {
        deviceAvailable = true;
        continueLoop = false;
      }
    });
    return deviceAvailable;
  }

  onAccessAudioDeviceHandler() {
    this._onAccessAudioDevice = this._deviceSettingService.onAccessAudioDevice().subscribe(
      (successResponse: any) => {
        if (successResponse.errorCode === null ||
          (successResponse.errorCode !== null && this._videoDeviceRetry === 2)
        ) {
          console.log('audio device acccess successfully ', successResponse, this.selectedAudioDeviceId);
          this._isAudioDeviceAPIResponse = true;
          this.isAudioDeviceAccess = successResponse.isDeviceAccessGranted;
          let audioMediaStream = this._deviceSettingService.getStoredStream('audio');
          this.audioLevelMeter(this._soundMeter, audioMediaStream);
          if (!successResponse.isDeviceAccessGranted) {
            this.audioInputError = successResponse.errorMsge !== undefined ? successResponse.errorMsge : this._deviceSettingService.getErrorMsg('AUDIO_INPUT_ACCESS_DENIED');
          } else {
            this.audioInputError = "";
          }
          this.deviceSettingForm.controls['audioInput'].setValue(successResponse.deviceId, { self: true });
        } else if (successResponse.errorCode !== null && successResponse.errorCode === 0) {
          ++this._audioDeviceRetry;
          this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'audio');
          this.deviceSettingForm.controls['audioInput'].setValue(successResponse.deviceId, { self: true });
        }
        this.audioMediaStreamAvailable = true;
        console.log('audion device id  --> ', successResponse.deviceId);
        // this.deviceSettingForm.controls.audioDeviceId.setValue(this.selectedAudioDeviceId);
      }, (errorResponse: any) => {
        this._isAudioDeviceAPIResponse = true;
        this.isAudioDeviceAccess = false;
        this.audioInputError = this._deviceSettingService.getErrorMsg('NO_AUDIO_INPUT');
        // this.deviceSettingForm.controls.audioDeviceId.setValue(this.selectedAudioDeviceId);
        this.audioMediaStreamAvailable = false;
      }
    );
  }

  onAccessVideoDeviceHandler() {
    this._onAccessVideoDevice = this._deviceSettingService.onAccessVideoDevice().subscribe(
      (successResponse: any) => {
        console.log('onAccessVideoDeviceHandler ', successResponse, this.selectedVideoDeviceId)
        if (successResponse.errorCode === null || (successResponse.errorCode !== null && this._videoDeviceRetry === 2)) {
          this._isVideoDeviceAPIReponse = true;
          this.isVideoDeviceAccess = successResponse.isDeviceAccessGranted;
          this.videoPreviewElem.srcObject = successResponse.videoStream;
          if (!successResponse.isDeviceAccessGranted) {
            this.videoInputError = successResponse.errorMsge !== undefined ? successResponse.errorMsge : this._deviceSettingService.getErrorMsg('VIDEO_INPUT_ACCESS_DENIED');
          } else {
            this.videoInputError = "";
          }
          this.deviceSettingForm.controls['videoInput'].setValue(successResponse.deviceId, { self: true });
        } else if (successResponse.errorCode !== null && successResponse.errorCode === 0) {
          ++this._videoDeviceRetry;
          this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'video');
        }

        console.log('videio device id  --> ', successResponse.deviceId);
        // check whether the api call first time only 
        if (
          (
            this.videoInputDeviceListArr[0].label !== undefined &&
            this.videoInputDeviceListArr[0].label.length === 0
          ) &&
          this._reCallEnumeratedDeviceListAPI === false
        ) {
          this._deviceSettingService.resetDeviceList();
          this._reCallEnumeratedDeviceListAPI = true;
          this._deviceSettingService.getEnumerateDevices();
        }
        //this.deviceSettingForm.controls.videoDeviceId.setValue(this.selectedVideoDeviceId);
        this.videoMediStreamAvailable = true;
      }, (errorResponse: any) => {
        this._isVideoDeviceAPIReponse = true;
        this.isVideoDeviceAccess = false;
        this.videoInputError = this._deviceSettingService.getErrorMsg('NO_VIDEO_INPUT');
        // this.deviceSettingForm.controls.videoDeviceId.setValue(this.videoDeviceId);
        this.videoMediStreamAvailable = false;
      }
    );
  }

  audioLevelMeter(soundMeterIntance: any, audioMediaStream: any) {
    if (soundMeterIntance && audioMediaStream) {
      soundMeterIntance.connectToSource(audioMediaStream, (error: any) => {
        if (error) {
          return this._logService.warn('Conference --> audioLevelSender --> error --> ', error);
        }
        clearInterval(this._sendAudioLevelIntervalId);
        this._sendAudioLevelIntervalId = setInterval(() => {
          const curAudioLevel = soundMeterIntance.instant.toFixed(2) * 100;
          this.showHideLevel(this.audioVisualizerListItem, curAudioLevel);
        }, 1000);
      });
    }
  }

  showHideLevel(listItems: any, audioLevel) {
    listItems.forEach((elem, idx) => {
      elem.classList.remove('active');
    });
    console.log('audioLevel  before ', audioLevel);
    audioLevel = audioLevel > 1? audioLevel * 3 : audioLevel;
    console.log('audioLevel  after ', audioLevel);
    audioLevel = audioLevel >= 26 ? 26 : audioLevel;
    for (let i = 0; i < audioLevel; i++) {
      if (listItems[i] !== undefined) {
        listItems[i].classList.add('active');
      }
    }
  }

  onChangeVideoInput(event: any) {
    console.log(' video chanage ', event.value, this.deviceSettingForm.controls.videoInput.value);
    this.selectedVideoDeviceId = this.deviceSettingForm.controls.videoInput.value;
    if (this.selectedVideoDeviceId && this.selectedVideoDeviceId.length > 1) {
      this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'video');
    } else {
      this.videoInputError = "No input device selected";
      this.videoMediStreamAvailable = false;
      if (this.executeContext) {
        this.videoPreviewElem.srcObject = null;
        this._deviceSettingService.stopTempStream('video');
        this._deviceSettingService.updateDeviceChangeStatus('video', false);
      } else {
        this._deviceSettingService.stopVideoStream();
      }
    }
  }

  onChangeAudioInput(event: any) {
    console.log(' audio input change ', event.value, this.deviceSettingForm.controls.audioInput.value);
    this.selectedAudioDeviceId = this.deviceSettingForm.controls.audioInput.value;
    if (this.selectedAudioDeviceId && this.selectedAudioDeviceId.length > 1) {
      this.initGetUserMediaDevice(this.selectedAudioDeviceId, this.selectedVideoDeviceId, 'audio');
    } else {
      this.audioInputError = 'No input device selected';
      this.audioMediaStreamAvailable = false;
      if (this.executeContext) {
        this._deviceSettingService.stopTempStream('audio');
        this._deviceSettingService.updateDeviceChangeStatus('audio', false);
      } else {
        this._deviceSettingService.stopAudioStream();
      }
    }
  }

  initGetUserMediaDevice(audioDeviceId: string, videoDeviceId: string, changeFor: string) {
    let isNotificationRequire = this.executeContext === undefined ? true : false;
    if (changeFor === 'audio') {
      this._deviceSettingService.getUserAudioMedia(audioDeviceId, {}, isNotificationRequire);
      // if (this.audioAccessFirstTime && this.executeContext) {
      //   this.audioAccessFirstTime = false;
      //   this._deviceSettingService.updateSelectedDeviceId(audioDeviceId, 'audio');
      // }
    } else {
      this._deviceSettingService.getUserVideoDevice(
        videoDeviceId, {
          frameRate: {
            min: 10,
            max: 30
          },
          width: {
            max: 720,
            min: 400,
          },
          height: {
            max: 500,
            min: 200
          }
        }, isNotificationRequire
      );
      // if (this.videoAccessFirstTime && this.executeContext) {
      //   this.videoAccessFirstTime = false;
      //   this._deviceSettingService.updateSelectedDeviceId(videoDeviceId, 'audio');
      // }
    }
    // this.selectedAudioDeviceId = audioDeviceId;
    // this.selectedVideoDeviceId = videoDeviceId;
    if (this.executeContext) {
      // no update require 
    } else {
      this._deviceSettingService.updateSelectedDeviceId(audioDeviceId, 'audio');
      this._deviceSettingService.updateSelectedDeviceId(videoDeviceId, 'video');
    }

  }

  continueToConference() {
    if (this.executeContext === undefined) {
      this._router.navigate(['/conference']);
    } else {
      this._deviceSettingService.updateAllSelectedDeviceId();
      this.deviceSettingModalClose.emit(true);
      //this.deviceSettingClose(null);
    }
  }

  // Attach audio output device to video element using device/sink ID.
  attachSinkIds(element, sinkId) {
    const audioOutputSelect = <HTMLSelectElement>document.querySelector('select#audioOutput');
    if (typeof element.sinkId !== 'undefined') {
      element.setSinkId(sinkId)
        .then(() => {
          console.log(`Success, audio output device attached: ${sinkId}`);
        })
        .catch(error => {
          let errorMessage = error;
          if (error.name === 'SecurityError') {
            errorMessage = `You need to use HTTPS for selecting audio output device: ${error}`;
          }
          console.error(errorMessage);
          // Jump back to first output device in the list as it's the default.
          audioOutputSelect.selectedIndex = 0;
        });
    } else {
      console.warn('Browser does not support output device selection.');
    }
  }


  onChangeAduioOutput(event: any) {
    let outputDeviceId = this.deviceSettingForm.controls.audioOutput.value;
    let outputDeviceList = this._deviceSettingService.getDeviceList('audioOutput');
    let isTempId = this.executeContext !== undefined ? true : false;
    if (outputDeviceId.length === 0) {
      outputDeviceId = outputDeviceList[0].deviceId;
    }
    if (outputDeviceId && outputDeviceId.length > 1) {
      if (this.executeContext) {
        // this._deviceSettingService.updateSelectedDeviceId(outputDeviceId, 'output');
        this._deviceSettingService.updateDeviceChangeStatus('output', true);
      }
      console.log('temp audio output  --> ', outputDeviceId);
      this.deviceSettingForm.controls['audioOutput'].setValue(outputDeviceId, { self: true });
      this._deviceSettingService.attachSinkId(outputDeviceId, this.audioOutputTestVideoElm, isTempId);
    }
  }

  playAudio() {
    if (this.audioOutputTestVideoElm) {
      this.audioOutputTestVideoElm.play();
    }
    if(this.audioPause == false){
      this.audioPause = true;
    }   

    clearTimeout(this.clearTimeOutSession);
    this.clearTimeOutSession = setTimeout(() => {
      this.audioPause = false;
    },100)
  }

  deviceSettingClose(event: any) {
    this._deviceSettingService.resetAllTempDeviceId();
    this._deviceSettingService.resetDeviceSettingChangeStatus();
    // this._deviceSettingService.stopTempStream('audio');
    // this._deviceSettingService.stopTempStream('video');
    this.deviceSettingModalClose.emit(false);
  }

  ngOnDestroy() {
    this._onAccessVideoDevice.unsubscribe();
    this._onAccessAudioDevice.unsubscribe();
    this.onUpdateDeviceListSubs.unsubscribe();
    clearInterval(this._sendAudioLevelIntervalId);

    // this timeout will handle to close the media if user move any other url other conference
    setTimeout(() => {
      if (window.location !== undefined && window.location.href.indexOf("conference") === -1) {
        this._deviceSettingService.stopAudioStream();
        this._deviceSettingService.stopVideoStream();
      }
    }, 1500);
  }
}
