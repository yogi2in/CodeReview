import { Injectable } from '@angular/core';
import { HttpService} from 'src/app/shared/services/http.service';
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PollService {
  public nextQueData = new Subject<{questionid: any, answerid: any, pollId: any}>();
  public startPollObs$ =  new Subject<{pollInfo: any}>();
  public pollAsnwerObs$ =  new Subject<{answerInfo: any}>();
  public sharePollObs$ =  new Subject<{sharePollInfo: any}>();


  constructor(private httpService: HttpService) { }

  getPollList(data) {
    const param = {
        url : environment.BASE_URI + 'poll-list?meetingId=' + data.meetingId
      };

   return this.httpService.get(param)
  }

  pollAnswer(data){
    const param = {
      url : environment.BASE_URI + 'poll-answer',
      body: {
        pollId: data.pollId,
        pollQuestionInfo: data.pollQuestionInfo
      }
    };
    return this.httpService.put(param)
  }

  sharePollListener() {
    return this.sharePollObs$.asObservable();
  }

  answerPollListener() {
    return this.pollAsnwerObs$.asObservable();
  }

  sharePollObs(pollInfo) {
    this.sharePollObs$.next({sharePollInfo: pollInfo})
  }

  answerPollObs(answerInfo) {
    this.pollAsnwerObs$.next({answerInfo: answerInfo})
  }

  // pollLaunch(data){
  //   //   const param = {
  //   //       url : environment.BASE_URI + 'poll-launch',
  //   //       body: {
  //   //         pollId: data.pollId,
  //   //         pollStatus: data.pollStatus,
  //   //         req: data.req,
  //   //         userId: data.userId
  //   //       }
  //   //     };
  //   //  return this.httpService.put(param)
  //   this.launchPollObserable.next({data: data});
  // }

  onStartPollListener() {
    return this.startPollObs$.asObservable();
  }

  startPollObs(pollInfo: any): void {
    this.startPollObs$.next({pollInfo: pollInfo})
  }

  deletePoll(data){
    const param = {
        url : environment.BASE_URI + 'poll-del?pollId=' + data.pollId
      };
   return this.httpService.delete(param)
  }

  pollRead(data){
    const param = {
        url : environment.BASE_URI + 'poll-read?pollId=' + data.pollId
      };

   return this.httpService.get(param)
  }

  /*
  * The below function post the poll data.
  */
  createPoll(obj) {
    const param = {
        url : environment.BASE_URI + 'poll-create',
        body: {
          creator_email: obj.creator_email,
          meetingId: obj.meetingId,
          pollTitle: obj.pollTitle,
          pollInfo: obj.pollInfo
        }
      };

    return this.httpService.post(param);
  }

  pollEnd(data) {
    const param = {
        url : environment.BASE_URI + 'poll-end',
        body: {
          pollId: data.pollId,
          pollSummary: data.pollSummary
        }
      };
    return this.httpService.put(param);
  }

  pollUpdate(data) {
    const param = {
        url : environment.BASE_URI + 'poll-update',
        body: {
          pollId: data.pollId,
          creator_email: data.creator_email,
          pollInfo: data.pollInfo
        }
      };

    return this.httpService.put(param)
  }

  locanJsonServer() {
    const param = {
        url : 'http://localhost:3004/pollInfo'
      };

   return this.httpService.get(param)
  }

  pollAnswerListener(){
    return this.nextQueData.asObservable();
  }

  pollAnswerSubmitData(obj) {
    this.nextQueData.next({
      questionid: obj.questionid,
      answerid: obj.answerid,
      pollId: obj.pollId
      });
  }

  getPollSummary(pollId: number) {
    if (pollId === undefined) {
      return;
    }
    const param = {
      url : environment.BASE_URI + 'poll-summary?pollId='+pollId
    };
    return this.httpService.get(param)
  }

}
