import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { RestApiService } from "src/app/_sharedService/restApi.service";

@Injectable({
    providedIn: 'root'
})
export class ReportsService {
    constructor(private rest: RestApiService){}

    /*
    * The below function get the Enterprise Name list from customer Api.
    */
    searchEnterpriseName(customerName) {
        const data = {
            "currentPage": 1,
            "numPerPage": 1000
        }
        return this.rest.sendRequest('Get', environment.BASE_URI+ 'customer?custName='+ customerName, data)
    }

    /*
    * The below function get the lincence report API details.
    */
    getLicenceReports(filter) {
        let licenceReportsAPI;
        if(filter.customerName != null && filter.customerName != undefined) {
            licenceReportsAPI = environment.BASE_URI+ 'reports/licence-report?customerName='+ filter.customerName + '&status=' + filter.status
        } else {
            licenceReportsAPI = environment.BASE_URI+ 'reports/licence-report?status=' + filter.status
        }
        const data = {
            "currentPage": filter.pageIndex,
            "numPerPage": environment.NUMBER_PER_PAGE
        }
        return this.rest.sendRequest('Get', licenceReportsAPI , data)
    }

    /*
    * The below function get the user Api data.
    */
   ownerNameDetails(params) {
        let roleType = params.roleType != undefined && params.roleType != null ? '&roleType=' + params.roleType : ''
        let roleName = params.roleName != undefined && params.roleName != null ? '&roleName=' + params.roleName : ''
        const data = {
            "currentPage": 1,
            "numPerPage": 1000
        }
        return this.rest.sendRequest('Get', environment.BASE_URI + 'user?fullName='+ params.ownerName + roleType + roleName, data);
    }

    /*
    * The below function get the sales report data.
    */
    getSalesReportData(params) {

        let reportAPIUrl;
        let roleType = params.roleType != undefined && params.roleType != null ? '&roleType=' + params.roleType : ''
        let roleName = params.roleName != undefined && params.roleName != null ? '&roleName=' + params.roleName : ''
        let ownerName = params.ownerName != undefined && params.ownerName != null ? '&roleCreator=' + params.ownerName : ''

        if(params.reportType === '0') {
            reportAPIUrl = params.ownerId != null && params.ownerId != undefined ? environment.BASE_URI+'reports/sales-report?ownerId=' + params.ownerId+'&' : environment.BASE_URI+'reports/sales-report?'
        } else {
            reportAPIUrl = params.ownerId != null && params.ownerId != undefined ? environment.BASE_URI+'reports/detailed-sales-report?ownerId=' + params.ownerId : environment.BASE_URI+'reports/detailed-sales-report?'
        }

        if(params.fromDate != null && params.fromDate != undefined && params.toDate != null && params.toDate != undefined) {
            let salesDate = 'fromDate=' + params.fromDate + '&toDate=' + params.toDate
            reportAPIUrl = reportAPIUrl + '&' + salesDate
        }

        const data = {
            "currentPage": params.pageIndex,
            "numPerPage": environment.NUMBER_PER_PAGE
        }
        return this.rest.sendRequest('Get', reportAPIUrl + roleType + roleName + ownerName, data)
    }

    /*
    * The below function get the licence-utilization-report data on licence page.
    */
    getUsedLicenceUserDetails(filter) {
        const data = {
            "currentPage": filter.pageIndex,
            "numPerPage": environment.NUMBER_PER_PAGE
        }
        return this.rest.sendRequest('Get', environment.BASE_URI + 'reports/licence-utilization-report?lotId=' + filter.lotId , data);
    }

    /*
    * The below function send mail on the basic of lotId.
    */
    postLicenceRenewalReminder(data) {
        return this.rest.sendRequest('Post', environment.BASE_URI + 'licence-renewal-reminder', data);
    }

    /*
    * The below function get the role Api data.
    */
    getRoleName() {
        const data = {
            "currentPage": 1,
            "numPerPage": 1000
        }
        return this.rest.sendRequest('Get', environment.BASE_URI + 'role/user', data);
    }

    /*
    * The below function get the Meeting Report Api data.
    */
    getMeetingReports(param) {
        return this.rest.sendRequest('Get', environment.REPORT_BASE_URI + 'actual_meeting', param);
      }
}
