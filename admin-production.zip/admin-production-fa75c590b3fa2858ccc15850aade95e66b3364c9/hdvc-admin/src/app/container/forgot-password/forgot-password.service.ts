import { Injectable } from '@angular/core';
import { RestApiService } from '../../_sharedService/restApi.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  constructor(private restService: RestApiService) { }

  setPassword(dataParams)
  {
    const data = {
        email:dataParams.email 
    }
    let urlsegment = 'password-forgot';
    if(dataParams["email-type"] != undefined){
      urlsegment = 'password-forgot?email-type='+'resend-set-password';
    }
    return this.restService.sendRequest('Post',environment.BASE_URI+urlsegment,data)
    
  }
}
