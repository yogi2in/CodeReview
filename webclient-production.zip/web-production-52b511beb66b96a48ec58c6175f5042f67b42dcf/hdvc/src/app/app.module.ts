import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app.route.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { ImageCropperModule } from 'ngx-image-cropper';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { NgxPaginationModule } from 'ngx-pagination';
import { CookieService } from 'ngx-cookie-service';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserMenuComponent } from './container/user-menu/user-menu.component';
import { LoginComponent } from './auth/login/login.component';
import { ScheduleMeetingComponent } from './container/schedule-meeting/schedule-meeting.component';
import { JoinMeetingComponent } from './container/join-meeting/join-meeting.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ConferenceComponent } from './container/conference/conference.component';
import { JwtInterceptor } from './mock-api/_helpers/jwt.interceptor';
import { ErrorInterceptor } from './mock-api/_helpers/error.interceptor';
import { MyProfileComponent } from './container/user/my-profile/my-profile.component';
import { MyMeetingsComponent } from './container/my-meetings/my-meetings.component';
import { MeetingDetailsComponent } from './container/my-meetings/meeting-details/meeting-details.component';
import { ForgotPasswordComponent } from './container/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './container/reset-password/reset-password.component';
import { ConfirmMeetingModalComponent } from './container/schedule-meeting/confirm-meeting-modal/confirm-meeting-modal.component';
import { AddProfilePicModalComponent } from './container/user/my-profile/add-profile-pic-modal/add-profile-pic-modal.component';
import { EditProfileComponent } from './container/user/edit-profile/edit-profile.component';
import { AlertPopupComponent } from './shared/components/alert-popup/alert-popup.component';
import { ScreenSharedLayoutHandlerDirective } from './container/conference/screen.shared.layout.handler.directive';
import { ShareScreenComponent } from './container/conference/share-screen/share-screen.component';
import { GlobalErrorHandlerService } from './shared/services/error.handler.service';
import { ServerRequestInterceptor } from './shared/services/serverRequest.interceptor';
import { SettingsComponent } from './container/settings/settings.component';
import { MeetingHistoryComponent } from './container/user/meeting-history/meeting-history.component';
import { UserComponent } from './container/user/user.component';
import { UserSidebarComponent } from './container/user/user-sidebar/user-sidebar.component';
import { GetStatsComponent } from './container/conference/get-stats/get-stats.component';
import { GlobalErrorHandlerComponent } from './shared/global-error-handler/global-error-handler.component';

import { SpeedTesterComponent } from './shared/components/speed-tester/speed-tester.component';
import { SplitPipe } from '../app/shared/custom-pipe/split';
import { RangePipe } from './shared/custom-pipe/range.pipe';
import { UnitConverterPipe } from './shared/custom-pipe/unit-converter.pipe';

import { MeetingEndComponent } from './container/meeting-end/meeting-end.component';
import { LicenceManagementComponent } from './container/licence-management/licence-management.component';
import { LicenceUserManagementComponent } from './container/licence-user-management/licence-user-management.component';
import { AppDeleteConfirmModalComponent } from './shared/app-delete-confirm-modal/app-delete-confirm-modal.component';
import { CreateCustomerUserComponent } from './container/licence-user-management/create-customer-user/create-customer-user.component';
import { ChangePasswordComponent } from './container/user/change-password/change-password.component';
import { TruncateDirective } from './shared/directive/truncate.directive';
import { TypeaheadModule } from 'ngx-bootstrap';
import { MostActiveUserDirective } from './container/conference/most-active-user/most-active-user.directive';
import { ActiveUsersPagingDirective } from './container/conference/active-users-paging/active-users-paging.directive';
import { LocalStorageModule } from 'angular-2-local-storage';
import { NotifierModule } from 'angular-notifier';
import { ConferenceDomUpdateHandlerDirective } from './container/conference/conference-dom-update-handler/conference-dom-update-handler.directive';

import { ReportsComponent } from './container/reports/reports.component';
import { LocalPeerConnectionStatsComponent } from './container/conference/local-peer-connection-stats/local-peer-connection-stats.component';
import { OpenDesktopAppPopupComponent } from './container/my-meetings/open-desktop-app-popup/open-desktop-app-popup.component';
import { DesktopAppDownloadComponent } from './container/desktop-app-download/desktop-app-download.component';
import { RemotePeerConnectionStatsComponent } from './container/conference/remote-peer-connection-stats/remote-peer-connection-stats.component';
import { SidebarComponent } from './container/sidebar/sidebar.component';
import { PollComponent } from './container/conference/poll/poll.component';
import { CreatePollComponent } from './container/conference/poll/create-poll/create-poll.component';
import { pollAnswerComponent } from './container/conference/poll/poll-answer/poll-answer.component';
import { LivePollComponent } from './container/conference/poll/live-poll/live-poll.component';
import { ParticipantMinutesPipe } from './shared/custom-pipe/participant-minutes.pipe';
import { FilterApiDataPipe } from './shared/custom-pipe/filter-api-data.pipe';
import { DeepLinkComponent } from './container/deep-link/deep-link.component';
import { ConfirmDialogComponent } from './shared/components/confirm-dialog/confirm-dialog.component';
import { DeviceSettingComponent } from './container/device-setting/device-setting.component';
import { DisconnectMeetingComponent } from './container/disconnect-meeting/disconnect-meeting.component';
import { H264UserHandlerComponent } from './container/conference/h264-user-handler/h264-user-handler.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    UserMenuComponent,
    LoginComponent,
    ScheduleMeetingComponent,
    JoinMeetingComponent,
    PageNotFoundComponent,
    ConferenceComponent,
    MyProfileComponent,
    MyMeetingsComponent,
    MeetingDetailsComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    ConfirmMeetingModalComponent,
    AddProfilePicModalComponent,
    EditProfileComponent,
    AlertPopupComponent,
    ScreenSharedLayoutHandlerDirective,
    ShareScreenComponent,
    SettingsComponent,
    MeetingHistoryComponent,
    UserComponent,
    UserSidebarComponent,
    GetStatsComponent,
    SplitPipe,
    RangePipe,
    MeetingEndComponent,
    LicenceManagementComponent,
    LicenceUserManagementComponent,
    AppDeleteConfirmModalComponent,
    CreateCustomerUserComponent,
    GlobalErrorHandlerComponent,
    SpeedTesterComponent,
    ChangePasswordComponent,
    TruncateDirective,
    MostActiveUserDirective,
    ActiveUsersPagingDirective,
    ConferenceDomUpdateHandlerDirective,
    ReportsComponent,
    LocalPeerConnectionStatsComponent,
    OpenDesktopAppPopupComponent,
    DesktopAppDownloadComponent,
    RemotePeerConnectionStatsComponent,
    SidebarComponent,
    UnitConverterPipe,
    PollComponent,
    CreatePollComponent,
    pollAnswerComponent,
    LivePollComponent,
    ParticipantMinutesPipe,
    FilterApiDataPipe,
    DeepLinkComponent,
    ConfirmDialogComponent,
    DeviceSettingComponent,
    DisconnectMeetingComponent,
    H264UserHandlerComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BsDatepickerModule.forRoot(),
    DeviceDetectorModule.forRoot(),
    ImageCropperModule,
    NgxPaginationModule,
    NgbModule,
    NotifierModule.withConfig({
      position: {
        horizontal: {
          position: 'right',
          distance: 12
        },
        vertical: {
          position: 'top',
          distance: 12,
          gap: 10
        }
      },
      theme: 'material',
      behaviour: {
        autoHide: 3000,
        onClick: false,
        onMouseover: 'pauseAutoHide',
        showDismissButton: true,
        stacking: 4
      },
      animations: {
        enabled: true,
        show: {
          preset: 'slide',
          speed: 300,
          easing: 'ease'
        },
        hide: {
          preset: 'fade',
          speed: 300,
          easing: 'ease',
          offset: 50
        },
        shift: {
          speed: 300,
          easing: 'ease'
        },
        overlap: 150
      }
    }),
    TypeaheadModule.forRoot(),
    LocalStorageModule.forRoot({
      prefix: 'customer_admin',
      storageType: 'localStorage'
    })
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ServerRequestInterceptor, multi: true },
    // { provide: ErrorHandler, useClass: GlobalErrorHandlerService }
    CookieService
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
