import { Component, OnInit } from '@angular/core';
import { CustomerService } from './customer.service';
import { Subscription } from 'rxjs';
import { Route, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { NewsResolver } from '../../_guards/auth.guard.service';
declare var $;
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  private customerListSubscription = new Subscription();
  private permissionListSubscription = new Subscription();
  customerList = []; // array list for customer info
  originalCustomerList = []; // used for store original copy 
  // customer table fields
  fields = [
    "Organization Name",
    "Used Licences",
    "Available Licences",
    "Status"
  ];
  // customer table status
  statusList = [{"label":"Active","value":"ACTIVE", "code":1},{"label":"Inactive","value":"INACTIVE", "code":2},{"label":"Delete", "value":"DELETE", "code":3}];
  statusFilterList = [{"label":"Active","value":"ACTIVE", "code":1},{"label":"Inactive","value":"INACTIVE", "code":2},{"label":"Delete", "value":"DELETE", "code":3}];
  pocStatusList = [{"label":"Active", "value":"ACTIVE", "code":1},{"label":"Inactive","value":"INACTIVE", "code":2},{"label":"Password Not Set","value":"PASSWORD NOT SET", "code":4}]
  licenceStatus = [{label:"NOT_STARTED",code:0 , value:"NOT STARTED"}, {label: "ACTIVE", code:1, value:"ACTIVE"},{label:"DELETED", code:2, value:"DELETED"},{label:"EXPIRED", code:3, value:"EXPIRED"}]; 
  filterValues;
  // paginator params
  currentPage = 1;
  currentPreviousPage:any;
  numPerPage = environment.NUMBER_PER_PAGE;
  totalItem;
  customerDetails;
  modalType = null;
  selectedId;
  selectedSearchStatus;
  searchString;
  custId;
  staticAlertClosed;
  message;
  permissions = {};
  selectedSearchString;
  constructor(private customerService: CustomerService, private router: Router, private newsResolver: NewsResolver) {}

  ngOnInit() {
    this.filterValues = this.statusList.filter(x => x.value != 'DELETE')
    // get permission listner
    this.permissionListSubscription = this.newsResolver.permissionProcessListener()
    .subscribe(
      (res) => {
        if(res.isSuccess && res.isSuperUser == false){
          this.permissions = res.permission;
          this.statusList = this.statusList.filter(x => {
            if(this.permissions['EDIT'] && this.permissions['DELETE'] == false){
                if(x.value != 'DELETE'){
                  return x;
                }  
              }else if(this.permissions['EDIT'] == false && this.permissions['DELETE'] == true){
                if(x.value == 'DELETE'){
                  return x;
                } 
              }else{
                return x;
              }
          })
        }else if(res.isSuperUser){
          this.permissions = {"ADD": true, "VIEW": true, "EDIT": true, "DELETE": true};
        }
    })
    // Subscribe the Observables after success and get customer list data
    this.customerListSubscription = this.customerService.customerListListner()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          this.customerList = res.data["list"]; // set customer list
          if(this.customerList != null && this.customerList.length == 0 && res.action == 'getCustomerList' && this.currentPage > 1){
            this.currentPage = 1;
            let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
            this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);      
          }
          this.assignCopy(); // store the original copy also
          // get all paginator data
          if(res.data["paginator"] != undefined && res.data["paginator"].totalItemCount != undefined){
              this.totalItem = res.data["paginator"].totalItemCount;
              this.currentPage = res.data["paginator"].currentPage;
            }else{
              this.totalItem = 0;  
          }
       }
      }
    );
    // call get customer list data on ng on init
    if(localStorage.getItem('currentPreviousPage')!==undefined && localStorage.getItem('currentPreviousPage')!==null)
    {
      this.currentPreviousPage=localStorage.getItem('currentPreviousPage');
      this.currentPage = this.currentPreviousPage;
      localStorage.removeItem("currentPreviousPage");
    }
    let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
    this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
  
  }

  // assign original copy
  assignCopy(){
    this.originalCustomerList = Object.assign([], this.customerList);
  }

  // method called on checkbox clicked
  checkAll(ev) {
    this.customerList.forEach(x => x.state = ev.target.checked)
  }

  // method check is all nested check box checked/unchecked status and change parent checkbox status
  isAllChecked() {
    if(this.customerList.length != 0)
    return this.customerList.every(_ => _.state);
  }

  // This method called for change selected customer status.
  executeStatusAction(status){
    let selectedCustomerIds = []; // selected customer id array

    this.customerList.filter(item => 
      {
        if(item.state == true){
          // get all checkbox selected customer and push id to array
          selectedCustomerIds.push(item.customerId)
        }
      }
      );
      // excute api for selected customer id with change status
      this.changeCustomerStatus(selectedCustomerIds,status.code)
  }

  changeCustomerStatus(selectedCustomerIds,code){
    if(selectedCustomerIds.length != 0 && this.permissions["EDIT"]){
      if(code == 3){
        this.modalType = 'bulkAction';
        this.selectedId = selectedCustomerIds;
        $("#delete-customer-modal").modal('show');
      }else{
        let data = {
          "ids":selectedCustomerIds,
          "status":code
        }
        this.customerService.changeCustomerstatus(data)
        .subscribe(
          (res) => {
            let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
            this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
          }
        );
      }
    }else if(this.permissions["EDIT"] == false){
      this.staticAlertClosed = false;
      this.message = "Permission Denied";
    }
    else{
      this.staticAlertClosed = false;
      this.message = "Please select at least one customer";
      this.FadeOutLink();
    }
  }

  // This method filter customer list based on status
  filterCustomer(event){
    this.customerList = Object.assign([], this.originalCustomerList);
    if(event.target.value){
      let searchStatus = this.statusFilterList.filter(item => item.label == event.target.value)[0].value;
      this.selectedSearchStatus = searchStatus;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
      this.customerService.getCustomerListBysearch(selectedData,1, this.numPerPage)
    }else{
      this.selectedSearchStatus = null;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
      this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
    }
  }

  //This method call delete customer api
  deleteCustomer(customerIds){
    let data = {"ids":[], "status":3};
    if(this.modalType == 'bulkAction'){
      customerIds = this.selectedId;      
    }
    data["ids"] = customerIds;
    this.customerService.changeCustomerstatus(data)
    .subscribe(
      (res) => {
        $('#delete-customer-modal').modal('hide');
        this.modalType = null;
        this.selectedId = null;
        let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
        this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
      }
    );
  }

  //This method search customer by organization name and call api 
  searchOrganization(searchString){
    if(searchString){
      this.selectedSearchString = searchString
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
      this.customerService.getCustomerListByOrganization(selectedData)
    }else{
      this.selectedSearchString = null;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
      this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
    }
  }

  // This method execute for clear search
  clearSearch(val){
    if(!val){
      this.selectedSearchString = null;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
      this.customerService.getCustomerList(this.currentPage, this.numPerPage, selectedData);
    }
  }

  // This method execute on click of edit customer button
  editCustomer(customerId){
    this.currentPreviousPage= this.currentPage;
    localStorage.setItem("currentPreviousPage",this.currentPreviousPage);
    console.log(this.currentPage);
    this.router.navigate(['edit-customer',customerId]);
  }

  // This method execute on click of pagination buttons and get next page data set according to page number
  getNextPageData(pageNumber){
    let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchStatus":this.selectedSearchStatus};
    this.customerService.getCustomerList(pageNumber, this.numPerPage, selectedData);
  }

  ViewCustomer(id){
    this.customerService.getCustomerById(id)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            this.customerDetails = res["result"];
            console.log("this.customerDetails",this.customerDetails)
            $('#view-customer-modal').modal('show');
          }
          
        })
  }

  getStatusLabel(status,field){
    if(status){
      if(field == "poc"){
        return this.pocStatusList.filter(x => x.code == status)[0].value;
      }else{
        return this.statusList.filter(x => x.code == status)[0].value;
      }
      
    }
  }

  getPagingOffset(){
    let pageLabel;
    let firstLabel = 1+this.numPerPage*(this.currentPage-1);
    let secondLabel = (1+this.numPerPage*(this.currentPage-1))+(this.customerList.length-1);
    if(firstLabel == secondLabel){
      return firstLabel;
    }else{
      let pageLabel = firstLabel +"-"+secondLabel;
      return pageLabel;
    }
  }

  getLicenceStatus(statusCode){
    let status = this.licenceStatus.filter(x => x.code == statusCode)[0].value;
    return status;
  }
  FadeOutLink() {
    setTimeout( () => {
          this.staticAlertClosed = true;
          this.message = null;
        }, 1000);
   }

  ngOnDestroy(){
    // prevent memory leak when component destroyed
    this.customerListSubscription.unsubscribe();
    this.permissionListSubscription.unsubscribe();
  }


  
}
