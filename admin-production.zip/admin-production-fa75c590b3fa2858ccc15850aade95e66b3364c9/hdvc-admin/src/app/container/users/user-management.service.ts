import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { RestApiService } from '../../_sharedService/restApi.service';
import { environment } from '../../../environments/environment';
import { AuthService } from '../../auth/auth.service';

@Injectable({
    providedIn: 'root'
})
export class UserManagementService {
   userProfileData = {};
   panasonicUserList = []; 
    private userProcess = new Subject<{data:{}, isSuccess: boolean, action:string}>();
    private userProfileProcess = new Subject<{userProfileData: {}}>();
    public errorMessage;

    constructor(private http: HttpClient, private rest :RestApiService, private auth :AuthService) { }

    userProcessListener() {
      return this.userProcess.asObservable();
    }

    userProfileListner() {
      return this.userProfileProcess.asObservable();
    }

    createPanasonicUser(fullName: string, countryCode: string, mobile: string, email:string, roleId, parentId) {
      const userData = {
        fullName: fullName,
        countryCode: countryCode,
        mobile:mobile,
        email:email,
        roleId: roleId,
        parentId: parentId 
      };
      this.rest.sendRequest('Post',environment.BASE_URI+'user',userData)
        .subscribe(
          (res) => {
            console.log(res)
            this.userProcess.next({data:{}, isSuccess: true,action:"createPanasonicUser"});
          },
          err => console.log(err)
        );
    }

    setPassword(password: string, emailToken:string){
      const data = {
        password: password,
        emailToken: emailToken
      };
      this.rest.sendRequest('Post',environment.BASE_URI+'password',data)
        .subscribe(
          (res) => {
            console.log(res)
            if(res.result != null){
              let roleName = res.result["roleName"]
              let roleResponse = this.auth.checkUserBasedOnRole(roleName)
              if(roleResponse){
                this.userProcess.next({data:{}, isSuccess: true, action:"SetPassword"});
              }else{
                window.location.href = environment.CUSTOMER_ADMIN_URI;
              }
            }
            
          },
          err => {
            console.log(err)
            this.errorMessage = err.message;
          }
        );
    }

    getUserProfile(){
      let data = {};
      this.rest.sendRequest('Get',environment.BASE_URI+'user/profile',data)
        .subscribe(
          (res) => {
            if(res["result"] != null){
              this.userProfileData = res["result"];      
            }
            this.userProfileProcess.next({userProfileData: this.userProfileData});
          },
          err => console.log(err)
        );
    }

    getAllPanasonicUser(currentPage,numPerPage,selectedData){
      let data = {"currentPage":currentPage,"numPerPage":numPerPage};
      if(selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null){
        data["userStatus"] = selectedData.selectedSearchStatus;
      }
      if(selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null){
        data[selectedData.selectedSearchFieldName] = selectedData.selectedSearchString;
      }
      this.rest.sendRequest('Get',environment.BASE_URI+'user',data)
        .subscribe(
          (res) => {
            console.log("res",res)
            if(res["result"] != null){
              this.panasonicUserList = res["result"];      
            }
            let action = "GetAll"
            if(numPerPage > 10){
              action = "GetAllParentUser"
            }
            this.userProcess.next({data:{"list":this.panasonicUserList,"paginator":res.pagination}, isSuccess: true, action:action});
          }
        );
    }

    getPanasonicUserById(userId){
      let data = {};
      return this.rest.sendRequest('Get',environment.BASE_URI+'user/'+userId, data)
    }

    updatePanasonicUserById(userId, fullName: string, countryCode: string, mobile: string, roleId, parentId){
      const userData = {
        fullName: fullName,
        countryCode: countryCode,
        mobile:mobile,
        roleId:roleId,
        parentId:parentId
      };
      this.rest.sendRequest('Put',environment.BASE_URI+'user/'+userId, userData)
      .subscribe(
        (res) => {
          console.log(res)
          this.userProcess.next({data:{}, isSuccess: true, action:"updatePanasonicUser"});
        },
        err => console.log(err)
      );
    }

    changePanasonicAdminUserStatus(data){
      return this.rest.sendRequest('Put',environment.BASE_URI+'user', data)
    }

    getPanasonicAdminByField(currentPage, numPerPage, selectedData){
      let data = {"currentPage":currentPage,"numPerPage":numPerPage};
      if(selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null){
        data["userStatus"] = selectedData.selectedSearchStatus;
      }
      if(selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null){
        data[selectedData.selectedSearchFieldName] = selectedData.selectedSearchString;
      }
      this.rest.sendRequest('Get',environment.BASE_URI+'user',data)
        .subscribe(
          (res) => {
            if(res["result"] != null){
              this.panasonicUserList = res["result"];      
            }
            this.userProcess.next({data:{"list":this.panasonicUserList,"paginator":res.pagination}, isSuccess: true, action:'getPanasonicAdminByField'});
          }
        );
    }

    changePassword(data){
      return this.rest.sendRequest('Put',environment.BASE_URI+'changepassword',data)
    }

    getAllParentActiveUser(){
      let params = {}
      return this.rest.sendRequest('Get',environment.BASE_URI+'user/getAllPanasonicUsers',params)
    }

    


    

}
