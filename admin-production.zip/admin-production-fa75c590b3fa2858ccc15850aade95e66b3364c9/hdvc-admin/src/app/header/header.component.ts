import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';
import { ProfileService } from '../container/user-profile/profile.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public isSideBarFlag = false;
  public isLoggedIn = false;
  public token = this.authService.getToken();
  private loggedInSubscription = new Subscription();
  @Output() valueChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  private userSubscription = new Subscription();
  public profileData: any;
  public currentTime: any;
  public userFullName: any;
  public profileImage: any;
  public profileFullName;
  constructor(private authService: AuthService, private router: Router, private profileService: ProfileService) { }

  ngOnInit() {
    this.loggedInSubscription = this.authService.authProcessListener()
      .subscribe(
        (res) => {
          if (res.isSuccess === true) {
            this.isLoggedIn = true;
            this.hideSidebar();
            this.profileService.getUserProfile();
          } else {
            this.isLoggedIn = false;
            this.isSideBarFlag = false;     // hide the sidebar when logout.
            this.hideSidebar();             // logout function.
          }
        },
        (error) => {
          // code to handel rejection.
        }
      );

    /* When page refresh, if authToken in localStorage then page should be in loggedIn state.
     *  */
    if (this.token && this.token != null && this.token != undefined && !window.location.href.includes('set-password')) {
      this.isLoggedIn = true;
    } else {
      this.isLoggedIn = false;
    }

    // call getUserProfile from profile service
    if (this.isLoggedIn) {
      this.profileService.getUserProfile();
    }
    /*
    * User Profile subscribe for get user name
    */
    this.userSubscription = this.profileService.userProfileListner()
      .subscribe(
        (res) => {
          if (res.isSuccess === true) {
            //this.profileData = res.userProfileData;
            this.profileFullName = res.userProfileData.fullName
            this.profileImage = res.userProfileData.profileImage + "?" + Math.random() * 100000000000000000000;;
          }
        }
      );

    /*
    * The below function get the current time.
    */
    setInterval(() => {
      let getCurrentTime = new Date();
      let hours = getCurrentTime.getHours() < 10 ? ("0" + getCurrentTime.getHours()) : getCurrentTime.getHours();
      let minuts = getCurrentTime.getMinutes() < 10 ? ("0" + getCurrentTime.getMinutes()) : getCurrentTime.getMinutes();
      let seconds = getCurrentTime.getSeconds() < 10 ? ("0" + getCurrentTime.getSeconds()) : getCurrentTime.getSeconds();

      return this.currentTime = hours + ":" + minuts + ":" + seconds;
    }, 500)

  }

  ngAfterContentInit(): void {
    //Called after ngOnInit when the component's or directive's content has been initialized.
    //Add 'implements AfterContentInit' to the class.
    let windowWidth = window.outerWidth;
    if (windowWidth < 992) {
      this.hideSidebar();
    }

  }

  /*
  * The Below function checking the sidebar show or hide.
  */
  hideSidebar() {
    if (this.isLoggedIn === true) {
      if (this.isSideBarFlag === true) {
        this.valueChange.emit(this.isSideBarFlag);
        this.isSideBarFlag = false;
      } else {
        this.valueChange.emit(this.isSideBarFlag);
        this.isSideBarFlag = true;
      }
    } else {
      this.isSideBarFlag = undefined;
      this.valueChange.emit(this.isSideBarFlag);
      this.isSideBarFlag = true;
    }
  }

  logout() {
    this.authService.logout();
    console.log("logout")
  }
  changePasswordOpen() {
    this.profileService.toggleChangePassword(true);
  }

  // Destory the subscription.
  ngOnDestroy(): void {
    this.loggedInSubscription.unsubscribe();
  }

}
