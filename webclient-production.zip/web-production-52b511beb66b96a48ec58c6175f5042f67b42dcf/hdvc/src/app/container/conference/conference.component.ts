import { Component, OnInit, OnDestroy, AfterViewInit, HostListener } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { JoinMeetignService } from '../join-meeting/join-meeting.service';
import { DOMHandlerService } from '../../shared/services/dom.handler.services';
import { environment } from '../../../environments/environment';
import { UtilService } from 'src/app/shared/services/utils.services';
import { SocketService } from 'src/app/shared/services/socket.service';
import { PagingInfo } from './paging-info';
import Swiper from 'swiper';
import { Howl, Howler } from 'howler';

// third party library
import * as kurentoUtils from 'kurento-utils';
import { ConferencePageService } from './conference-page-service.service';
import { UserInfo } from './_models/user-info';
import { NotifierService } from 'angular-notifier';
import { LogService } from 'src/app/shared/logger/log.service';
import { RFC_2822 } from 'moment';
import { HttpService } from 'src/app/shared/services/http.service';
import { PollService } from './poll/poll.service';
declare var Participant;
declare var window;
declare var $;
declare var SoundMeter;
import { Subject } from 'rxjs';
import { DeviceSettingService } from '../device-setting/device-setting.service';
import { parse } from 'url';
import { access } from 'fs';

@Component({
  selector: 'app-conference',
  templateUrl: './conference.component.html',
  styleUrls: ['./conference.component.css'],
  host: {
    '(window:resize)': 'onResize($event)'
  }
})

export class ConferenceComponent implements OnInit, OnDestroy {
  private _webSocket: any; // will store the websock instance
  public isSocketConnected = false;
  public participant: any;
  public participants: any = {};
  public remoteParticipant: any = [];
  public participantList = [];
  public totalParticipantCount: number = 1;
  public configureLayout: any = {};
  public userInfo: any;
  public meetingUrl: string;
  public isUserPresenter = false;
  public presenterUserId: string;
  public speakerName: string;
  public errorObsSubs: Subscription;
  public sendMsgObsSubs: Subscription;
  public isInternetOnSubs: Subscription;
  public rejoinTryCounter: number = 0;
  // public stopScreenSharedSubs: Subscription;
  public userId: string;
  public popUpMessage: string;
  public isScreenShareInited = false;
  public showScreenShareIndicator: boolean = false;
  public screenShareIndicatorInterval: any;
  public screenShareIndicatorTimeout: any;
  public screenSharePermissionDenied = false;
  private _userName: string;
  public muteAudio = false;
  public pauseVideo = false;
  public isAudShare: boolean = true;
  public isVidShare: boolean = true;
  public localVideoElement: any;
  public isVideoStreamAvailable = true;
  public sharedScreenUserId: string;
  public isPstrStartScreenShare = false;
  public shareScreenStreamStarted = false;
  public disabledMakePresenter = false;
  public screenShareUserId: string;
  private _layoutBeforeShareScreen: string;
  public ignoreAnswer = false;
  public mediaAccessStatus: string;
  public alertFor: boolean;
  public showAlert = false;
  public alertMsg: string;
  public alertTimeoutId: any;
  private _isUserStopScreenShared = false;
  private _browserInfo: any;
  public hidePanel = false;
  public statsParticipantId: string;
  public selectorId: string;
  public currentResolution: any;
  public heartBeatIntervalId: any;
  public leaveMeetingTimeoutId: any;
  public resizeEventTimeoutId: any;
  public mySwiper: Swiper;
  public carouselDirection = false;
  public carouselDireVal: any;
  public isMeetingOwner: any;
  public isMuteAll: boolean;
  public isPauseAll: boolean;
  private meetingOwnerUserId: any;
  public currentActiveUserId: string;
  public currentActiveUserName: string;
  public sideBarWidth: any;
  public groupCarousal: any;
  public ownerPausedVideo = false;
  public ownerMutedAudio = false;
  public showMainVideoLoader = false;
  public videoPreviewElement: any;
  public checkInternetSubs = new Subscription();
  public isInternetConnectedInterval: any;
  public prevBandwidthUnit: any;
  public prevBandwidthValue: any = "";
  public unstableBandwithCount = 0;
  public stableBandwidthCount = 0;
  public bandWidthCheckIntervalId: any = 0;
  public windowHeight: any;
  public presenterName: any = '';
  public conferenceNavigation: boolean = false;
  public mouseMoveTimeoutId: any;
  public statsInterval: any;
  public audioSent: any;
  public videoSent: any;
  public videoSentCodec: any = '';
  public audioSentCodec: any = '';
  public prevVideoSent = 0;
  public prevAudioSent = 0;
  public prevAudioSentTime: any;
  public prevVideoSentTime: any;
  public curActualResolution: any;
  public currentBandWidth: any = 256;
  public userSelectedBandWidth: any = 256;
  public prevResponsesReceived = 0;
  public RTCIceCandidatePairTimeoutId: any;
  public RTCIceCandidatePairResponseRecievedCounter = 0;
  public autoRedirectTimeoutId: any;
  public videoConstraints: any;
  public frameSentCount: any = 0;
  public prevframeSentCount: any = 0;
  public layoutTypeENUMS: any;
  public layoutType: string;
  private previousThumbnailCount = 0;
  private thumbnailCount: number = 4;
  public pagingInfo: PagingInfo = {
    curPageNo: 1,
    curActiveUsers: [],
    curPageSizeCount: 1,
    curParticipantCount: 1
  };
  //public layoutType: string = 'grind-layout';
  private fetchActiveParticipantsSubs = new Subscription();
  private vDetForRemoteUserJoinedTimeoutId: any;
  public listSidebarHeight: any = 0;
  public isOverConstraints: boolean = false;

  //whiteboard code
  public initWhiteBoard: boolean = false;
  public whiteBoardStreamStart: boolean = false;
  public isPollStarted: boolean = false;
  public tooltipPosition: string;
  public resetMostActiveUserTimeoutId: any;
  private _soundMeter: any;
  private _sendAudioLevelIntervalId: any;
  private _isPrevAudioLevelZero: boolean = false;
  private leaveMeetingSubs = new Subscription();
  private onPausedVideoListener = new Subscription();
  private readonly notifier: NotifierService;
  private isWindowActive: boolean = true;
  private currentBandwidthUsageSubs = new Subscription();
  public isAdaptiveViewEnable: boolean = environment['ADAPTIVE_VIEW'];
  public totalPagingCount = 1;
  public muteUnmuteTimeoutId: any;
  public stopVoiceLevelAPI: boolean = false;
  private startPollSubscription = new Subscription();
  private notifyToRetryIceCandidateSubs = new Subscription();
  private meetingValidationListenerSubs = new Subscription();
  private onMeetingValidationAPIFailed = new Subscription();
  private isUserAbleToAccessDevice: boolean = false;
  private currentPollInfo: any = null;
  private latestOfferSPDReq: any = {};
  private _turnsConfig: any = [];
  private curPageInfo: any;
  public isAdaptiveLayoutEnabled: boolean = false;
  public selectedUserIdToDisconnect: any = null;
  public uniqueClientId: string = "";
  public userType: string = "WEB";
  public meetingInfoForH264User: any = {};
  public initH264UserConnection: boolean = false;
  private _previousPageNumber: number = 0;

  /** DEVICE SETTINGS  */
  public audioDeviceId: any;
  public videoDeviceId: any;
  public outputDeviceId: any;
  public prevAudioDeviceId: any;
  public prevVideoDeviceId: any;
  private _audioMediaStream: any;
  private _videoMediaStream: any;
  private _onAccessAudioDevice: any = new Subscription();
  private _onAccessVideoDevice: any = new Subscription();
  private _isAudioDeviceAPIResponse: boolean = false;
  private isAudioDeviceAccess: boolean = false;
  private _isVideoDeviceAPIReponse: boolean = false;
  private isVideoDeviceAccess: boolean = false;
  public isDeviceSettingsEnable: boolean = false;
  private _isDeviceSettingModalOpen: boolean = false;
  public initDeviceSettingModalComponent: boolean = false;
  public isMostActiveUserForGridViewTypeEnable: boolean = false;
  public actualActiveUserDuringScreenShare: string;
  public resetScreenShareMostActiveUserTimeoutId: any;
  public delayFetchActiveParticipantTimeoutId: any;

  constructor(
    private _joinMeetingService: JoinMeetignService,
    private _router: Router,
    private _domHandler: DOMHandlerService,
    private _utilService: UtilService,
    private _socketService: SocketService,
    private _confPageService: ConferencePageService,
    notifierService: NotifierService,
    private _logService: LogService,
    private _httpService: HttpService,
    private pollService: PollService,
    private _deviceSettingService: DeviceSettingService
  ) {
    // Active
    window.addEventListener('focus', this.onFocus.bind(this));

    // Inactive
    window.addEventListener('blur', this.onBlur.bind(this));
    this.notifier = notifierService;
    this._logService.info('Conference Component Construction Called');
    this.layoutTypeENUMS = this._utilService.getEnvironmentValue('LAYOUT_TYPE_ENUMS');//environment.LAYOUT_TYPE_ENUMS;
    const defaultAudioConfig = this._joinMeetingService.getMeetingConfig('default_audio');
    const defaultVideoConfig = this._joinMeetingService.getMeetingConfig('default_video');
    this.isAudShare = defaultAudioConfig !== null && defaultAudioConfig === 0 ? false : true;
    this.isVidShare = defaultVideoConfig !== null && defaultVideoConfig === 0 ? false : true;

    this._logService.info('Conference --> defaultAudioConfig --> ', defaultAudioConfig);
    this._logService.info('Conference --> defaultVideoConfig --> ', defaultVideoConfig);

    // store the audio config in local storage
    this._utilService.setInfoInStorage('local', 'audioConfig', {
      echoCancellation: { exact: true },
      noiseSuppression: { exact: true },
      autoGainControl: { exact: true },
    });

    try {
      window.AudioContext = window.AudioContext || window.webkitAudioContext;
      window.audioContext = new AudioContext();
      this._soundMeter = window.soundMeter = new SoundMeter(window.audioContext);
      this._logService.info('Conference --> AudioMeter --> Available');
    } catch (e) {
      this._logService.info('Conference --> AudioMeter --> Web Audio API not supported.');
    }
  }


  ngOnInit() {
    //this.alerts.setDefaults('timeout', 3);
    this._logService.info('Conference --> ngOnInit Called -->');
    this.userInfo = this._utilService.getInfoFromStorage('session', 'participantInfo');

    if (this.userInfo === null) {
      this._router.navigate(['/join-meeting']);
      return;
    }
    window.isResendOfferInProgress = false;

    // device settings data start here 
    this._audioMediaStream = this._deviceSettingService.getStoredStream('audio');
    console.log('this._audioMediaStream ', this._audioMediaStream)
    this._videoMediaStream = this._deviceSettingService.getStoredStream('video');
    this.audioDeviceId = this._deviceSettingService.getSelectedDeviceId('audio');
    this.videoDeviceId = this._deviceSettingService.getSelectedDeviceId('video');
    this.isDeviceSettingsEnable = this._utilService.getEnvironmentValue('ENABLED_DEVICE_SETTINGS');
    this.outputDeviceId = this._deviceSettingService.getSelectedDeviceId('output');


    this.userType = this._utilService.getEnvironmentValue('USER_TYPE');
    this.uniqueClientId = this._utilService.generateRandomAlphaNumericString(32) + "-" + this.userType;
    this.isAdaptiveLayoutEnabled = this._utilService.getEnvironmentValue('ADAPTIVE_VIEW');//  environment['ADAPTIVE_VIEW'];
    this.configureLayout = this._joinMeetingService.getMeetingConfig('default_layout');
    this._turnsConfig = this._utilService.getTurnsConf(environment.ENVIRONMENT_TYPE);
    this.meetingUrl = environment['BASE_URL'] + "/join-meeting/" + this.userInfo.meetingId;
    const existUserInfo = this._joinMeetingService.getExistUserInfo();
    this.isMeetingOwner = this._utilService.getInfoFromStorage('localStorage', 'is_owner');
    this.isMuteAll = false;
    this.isPauseAll = false;

    this._browserInfo = this._utilService.getBrowserInfo();
    this.layoutType = this._confPageService.getLayoutType();
    this.thumbnailCount = this._confPageService.getThumbnailCount(this.layoutType);

    this.updateObject(this.pagingInfo, 'curPageNo', 1);
    this.updateObject(this.pagingInfo, 'curPageSizeCount', parseInt("" + this.thumbnailCount));
    this.videoConstraints = this._joinMeetingService.getMediaConstraints(this._browserInfo.name.toLowerCase())

    this._webSocket = this._socketService.getSocketInstance();
    if (this._webSocket && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }

    if (existUserInfo !== undefined) {
      this.getAcccessToDevices(existUserInfo, this._webSocket);
      // this.exisUserHandler(existUserInfo, this._webSocket);
      this._joinMeetingService.resetExistUserInfo();
    } else {
      if (this._joinMeetingService.isUserClickJoinButton) {
        this._webSocket.onopen = this.onSocketOpenHandler.bind(this);
        this._webSocket.onerror = this.onSockeErrorHandler.bind(this);
      } else {
        let userInfo = this._utilService.getInfoFromStorage('localStorage', 'currentUser');;
        let ownerEmailId = userInfo !== null ? userInfo.email : '';
        // this subscriber will handle when validation got failed or meeting expired 
        this.onMeetingValidationAPIFailed = this._joinMeetingService.onMeetingIDValidation().subscribe(
          (response: any) => {
            if (response !== undefined && response.status === false) {
              this._joinMeetingService.setConnectionLostMessage(response.msg);
              this._router.navigate(["\join-meeting"]);
            }
          }
        );

        // if meeting validation successfull then it will continue to join the conference
        this.meetingValidationListenerSubs = this._joinMeetingService.meetingValidationListenner().subscribe(
          (response: any) => {
            this._webSocket = this._socketService.getSocketInstance();
            if (this._webSocket && this._webSocket !== null && this._webSocket.readyState > 1) {
              this._webSocket = this._socketService.getSocketInstance();
            }
            this.onSocketOpenHandler();
          });
        if (this.userInfo !== null && this.userInfo.meetingId !== undefined) {
          this._joinMeetingService.validateMeeting(
            this.userInfo.meetingId,
            ownerEmailId,
            this.userInfo.userName,
            "",
            false
          );
        }
      }
    }

    this._webSocket.onmessage = this.onSocketMessageHandler.bind(this);
    window.addEventListener('message', this.messageEventListener.bind(this));
    this.setHeightVideoScreen();
    this.setToolTipOptions(this.layoutType);


    if (!this.isDeviceSettingsEnable) {
      navigator.mediaDevices.enumerateDevices().then(this.gotDevices).catch(this.handleError);
    }

    this.sendCurBandwidthUsageReport();

    this.fetchActiveParticipantsSubs = this._confPageService.fetchActiveParticipantsListener().subscribe(
      (res: any) => {
        this.layoutType = this._confPageService.getLayoutType();
        this.fetchActiveParticipantsList(res.pageNumber, res.layoutCount, true);
      }
    );

    this.leaveMeetingSubs = this._confPageService.redirectUserToJoinMeetingListener().subscribe(
      (response: any) => {
        let connectionLostMsge = this._joinMeetingService.getConnectionLostMessage();
        if (connectionLostMsge !== undefined && connectionLostMsge.length > 1) {
          // not need to assign
        } else {
          this._joinMeetingService.setConnectionLostMessage('Something went wrong. <br /> Please try again.');
        }
        this.onLeaveMeeting('leave');
      }
    );

    this.pollService.pollAnswerListener().subscribe(
      (res) => {
        const answerPayload = {
          meetingId: this.userInfo !== null ? this.userInfo.meetingId : "",
          pollId: res.pollId,
          userId: this.userId,
          questionId: res.questionid,
          answerId: res.answerid,
          req: "sharePollAnswer"
        }
        this.sendRquestToSocket(answerPayload, this._webSocket);
      }
    )

    this.startPollSubscription = this.pollService.onStartPollListener().subscribe(
      (res) => {
        const startPollPayload = res.pollInfo;
        if (res.pollInfo !== undefined) {
          this.sendRquestToSocket(startPollPayload, this._webSocket);
        }
      }
    )

    this.notifyToRetryIceCandidateSubs = this._confPageService.onNotifyToRetryIceCandidateListener().subscribe(() => {
      if (this.initDeviceSettingModalComponent) {
        return;
      }
      this.onUpdateBandwidth(256, true);
    });
  }

  sendCurBandwidthUsageReport() {
    this.currentBandwidthUsageSubs = this._confPageService.totalBandwidthUsageListener().subscribe(
      (bitrate: any) => {
        const bandwidthUsagePayLoad = {
          req: 'bitrate',
          userid: this.userId,
          meetingid: this.userInfo !== null && this.userInfo.meetingId !== undefined ? this.userInfo.meetingId : "",
          bitrate: {
            totalSent: bitrate.totalBitrateSent.toFixed(0),
            totalRecv: bitrate.totalBitrateRecv.toFixed(0),
            sentPerSec: bitrate.bitrateSentPerSec.toFixed(0),
            recvPerSec: bitrate.bitrateRecvPerSec.toFixed(0)
          },
          resolution: {
            min: bitrate.minResolution,
            max: bitrate.maxResolution
          },
          packetLost: bitrate.remotePacketLost,
          jitter: {
            max: bitrate.maxJitter,
            avg: bitrate.avgJitter
          }
        };

        const param = {
          url: environment.BASE_URI + "meeting/report/actual_meeting",
          body: bandwidthUsagePayLoad
        };

        this._logService.info('currentBandwidthUsageSubs ---> ', bandwidthUsagePayLoad);
        this._logService.debug('currentBandwidthUsageSubs ---> ', bandwidthUsagePayLoad);

        this._httpService.post(param).subscribe(
          response => {
            // console.log('report sent ');
          }
        )
      }
    )
  }

  showAlertMsge(conFlag: boolean, alertMsg: string) {
    this._logService.info('Conference --> showAlertMsge called --> ', alertMsg);
    clearTimeout(this.alertTimeoutId);
    const innerThis = this;
    this.showAlert = true;
    this.alertFor = conFlag;
    this.alertMsg = alertMsg;
    this.alertTimeoutId = setTimeout(() => {
      innerThis.showAlert = false;
    }, 5000);
  }

  /**
   * @description The below function will handle the joined the meeting as soon as the connection open.
   *  + ' (' + this.userInfo.orgName + ')'
   */
  onSocketOpenHandler() {
    this._logService.info('Conference --> onSocketOpenHandler Called -->')
    this.autoRedirectTimeoutId = setTimeout(() => {
      this._logService.warn('Conference --> Failed to Connect as server not response! retry again ', this.rejoinTryCounter);
      if (this.rejoinTryCounter >= 2) {
        this._logService.warn('onSocketOpenHandler --> failed to connect after 2 retry--> redirect to leave meeting!')
        let errorMsge = this._utilService.getNotificationMessage('JOIN_MEETING_VALID_API_FAILED');
        this._joinMeetingService.setConnectionLostMessage(errorMsge); //'Room join request goes timeout.<br /> Please try again'
        this.redirectToJoinMeeting(3000, false, 'JOIN_MEETING_VALID_API_FAILED');
        this.rejoinTryCounter = 0;
        clearTimeout(this.autoRedirectTimeoutId);
      } else {
        clearTimeout(this.autoRedirectTimeoutId);
        this.onSocketOpenHandler();
        ++this.rejoinTryCounter;
      }
    }, 10000);

    if (this.userInfo !== null) {
      const kip = this._utilService.getInfoFromStorage('localStorage', 'kip');
      const jip = this._utilService.getInfoFromStorage('localStorage', 'jip');
      this._joinMeetingService.curMeetingInfo.userName = this.userInfo.userName;
      const joinMeetingPayLoad = {
        req: 'joinMeetingRoom',
        user: this.userInfo.userName,
        roomID: this.userInfo.meetingId,
        is_owner: this.isMeetingOwner,
        clientId: this.uniqueClientId,
        user_type: this.userType,
        connection_mode: 'VP8',
        kip: kip,
        jip: jip
      };
      this.meetingInfoForH264User = joinMeetingPayLoad;
      this.sendRquestToSocket(joinMeetingPayLoad, this._webSocket);
    }
  }

  startExistUserHandler(parsedMsge, _webSocket, requestFor, grantedDevice) {
    switch (grantedDevice) {
      case 'audioDevice':
        // get audio device access granted / denied response 
        if (requestFor === 0) {
          //request was only for audio only then you can proceed to generate offer 
          this.exisUserHandler(parsedMsge, this._webSocket);
        } else {
          // check whether you get the video device access or not 
          if (this.isVideoDeviceAccess) {
            // if video device access already either granted/ denied 
            // can proceed to generate offer 
            // this.exisUserHandler(parsedMsge, this._webSocket);
            if (parsedMsge === null) {
              this.onMediaQualityChange(null)
            } else {
              this.exisUserHandler(parsedMsge, this._webSocket);
            }
          } else {

          }
        }
        break;
      case 'videoDevice':
        // get video device access permission/ denied response 
        if (requestFor === 1) {
          // request was only to access video device 
          this.exisUserHandler(parsedMsge, this._webSocket);
        } else {
          // check whether audio device access or not 
          if (this.isAudioDeviceAccess) {
            // if audio device access already either granted/ denied 
            // can proceed to generate offer 
            if (parsedMsge === null) {
              this.onMediaQualityChange(null)
            } else {
              this.exisUserHandler(parsedMsge, this._webSocket);
            }

          } else {

          }
        }
        // get video device access granted/ denied response 
        break;
    }

  }

  requestToAccessMediaDevices(parsedMsg, _webSocket, accessFor, mediaConstraints) {
    this._onAccessAudioDevice = this._deviceSettingService.onAccessAudioDevice().subscribe(
      (successResponse: any) => {
        if (successResponse.ignoreResponse) {
          return;
        }
        console.log('audio device acccess successfully ');
        this._isAudioDeviceAPIResponse = true;
        this.isAudioDeviceAccess = successResponse.isDeviceAccessGranted;
        this.startExistUserHandler(parsedMsg, _webSocket, accessFor, 'audioDevice');
        this._onAccessAudioDevice.unsubscribe();
      }, (errorResponse: any) => {
        if (errorResponse.ignoreResponse) {
          return;
        }
        this._isAudioDeviceAPIResponse = true;
        this.isAudioDeviceAccess = false;
        this.startExistUserHandler(parsedMsg, _webSocket, accessFor, 'audioDevice');
        this._onAccessAudioDevice.unsubscribe();
      }
    );

    this._onAccessVideoDevice = this._deviceSettingService.onAccessVideoDevice().subscribe(
      (successResponse: any) => {
        if (successResponse.ignoreResponse) {
          return;
        }
        this._isVideoDeviceAPIReponse = true;
        this.isVideoDeviceAccess = successResponse.isDeviceAccessGranted;
        this.startExistUserHandler(parsedMsg, _webSocket, accessFor, 'videoDevice');
        this._onAccessVideoDevice.unsubscribe();
      }, (errorResponse: any) => {
        if (errorResponse.ignoreResponse) {
          return;
        }
        this._isVideoDeviceAPIReponse = true;
        this.isVideoDeviceAccess = false;
        this.startExistUserHandler(parsedMsg, _webSocket, accessFor, 'videoDevice');
        this._onAccessVideoDevice.unsubscribe();
      }
    );

    switch (accessFor) {
      case 0:
        //only audio device 
        this._deviceSettingService.getUserAudioMedia(this.audioDeviceId, {}, true);
        break;
      case 1:
        //only video device 
        this._deviceSettingService.getUserAudioMedia(this.audioDeviceId, mediaConstraints, true);
        break;
      case 2:
        //both audio and video 
        console.log('this.videoDeviceId ', this.videoDeviceId);
        this._deviceSettingService.getUserAudioMedia(this.audioDeviceId, {}, true);
        this._deviceSettingService.getUserVideoDevice(this.videoDeviceId, mediaConstraints, true);
        break;
    }
  }

  getAcccessToDevices(parsedMsge: any, _webSocket: any) {
    // 0 - audio 
    // 1 - video 
    // 2 - both device 
    if (this._audioMediaStream || this._videoMediaStream) {
      // any of the stream avaialble 
      this.exisUserHandler(parsedMsge, this._webSocket);
    } else {
      // this block is execute when user refresh the page 
      // check any device already selected or not 
      if (this.audioDeviceId && this.videoDeviceId) {
        // both device id available 
        this.requestToAccessMediaDevices(parsedMsge, _webSocket, 2, {});
      } else {
        if (this.audioDeviceId) {
          // only audio available 
          this.requestToAccessMediaDevices(parsedMsge, _webSocket, 0, {});
        } else if (this.videoDeviceId) {
          // only video device id available 
          this.requestToAccessMediaDevices(parsedMsge, _webSocket, 1, {});
        } else {
          // if none of the id avaialble then redirect to join meeting page 
          this._router.navigate(['/join-meeting'])
        }
      }
    }
  }
  /**
   * @description The below function will handle to categories every response received from web socket.
   * @param socketMsg
   */
  onSocketMessageHandler(socketMsg: any) {
    const parsedMsge = JSON.parse(socketMsg.data);
    this._logService.debug("Response Received From Client <<<<< ", parsedMsge);
    this._logService.info('Conference --> onSocketMessageHandler --> rsponse from server ', parsedMsge);
    switch (parsedMsge.rsp) {
      case 'exisUsr':
        this.getAcccessToDevices(parsedMsge, this._webSocket);
        break;
      case 'joinMeetingRoom':
        this.joinMeetingRoomHandler(parsedMsge, this._webSocket);
        break;
      case 'iceCandidate':
        this.iceCandidateHandler(parsedMsge, this._webSocket);
        break;
      case 'answer':
        if (this.isScreenShareInited === true && this.ignoreAnswer === true) {
          return;
        }
        this.receiveVideoResponse(parsedMsge);
        break;
      case 'usrArr':
        this.onNewUserJoin(parsedMsge);
        if (this.configureLayout == 2 && this.isAdaptiveLayoutEnabled === true) {
          this.updateBitrate(256);
        }
        break;
      case 'usrleft':
        this.onParticipantLeft(parsedMsge);
        if (this.configureLayout == 2 && this.isAdaptiveLayoutEnabled === true) {
          this.updateBitrate(256);
        }
        break;
      case 'reqPresBall':
        this.updateNewPresenter(parsedMsge);
        break;
      case 'status_scr_share':
        this.onStartStopScreenShare(parsedMsge);
        break;
      case 'status_aud_share':
        let participantForAudioAction = this.participants[parsedMsge.userId];
        this.participantAudioAction(participantForAudioAction, parsedMsge.userId, parsedMsge.share_aud);        
        break;
      case 'status_vid_share':
        let participantForVideoAction = this.participants[parsedMsge.userId];
        this.participantVideoAction(participantForVideoAction, parsedMsge.userId, parsedMsge.share_vid);
        if (!this.initWhiteBoard && !this.shareScreenStreamStarted) {
          // this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
          clearTimeout(this.resetMostActiveUserTimeoutId);
          this.resetMostActiveUserTimeoutId = setTimeout(() => {
            this._confPageService.resetMostActiveUser = true;
            this._confPageService.notifyMostActiveUser(this.currentActiveUserId, 'null', this.layoutType);
          }, 100);
        }
        break;
      case 'mute_audio_all':
        this.toggleMuteAll(parsedMsge.share_aud, parsedMsge.owner_id);
        if (!this.initWhiteBoard && !this.shareScreenStreamStarted) {
          this._confPageService.resetMostActiveUser = true;
          this._confPageService.notifyMostActiveUser(this.currentActiveUserId, 'null', this.layoutType);
        }
        break;
      case 'mute_video_all':
        this.tooglePauseAll(parsedMsge.share_vid, parsedMsge.owner_id);
        if (!this.initWhiteBoard && !this.shareScreenStreamStarted) {
          this._confPageService.resetMostActiveUser = true;
          this._confPageService.notifyMostActiveUser(this.currentActiveUserId, 'null', this.layoutType);
        }
        break;
      case 'end_meeting':
        $('#device-settings-sidebar').modal('hide');
        $('#createPollModal').modal('hide');
        $('#leaveEndMeeitng').modal('hide');
        this.onLeaveMeeting('END');
        break;
      case 'clearSession':
        this._logService.debug('User Received Clear Session From Server --> ')
        this._joinMeetingService.setConnectionLostMessage('Connection lost due to poor network condition.');
        this.redirectToJoinMeeting(3000, true, 'CLEAR_SESSION');
        break;
      case 'activeUsr':
        this.mostActiveUserHandler(parsedMsge, this.curPageInfo);
        break;
      case 'vDet':
        this.curPageInfo = parsedMsge;
        this.layoutPagingHandler(parsedMsge);
        if (
          (
            this.shareScreenStreamStarted ||
            this.initWhiteBoard ||
            this.layoutType === this.layoutTypeENUMS[2]
          ) &&
          this.curPageInfo.pNo == 1 &&
          this.actualActiveUserDuringScreenShare !== undefined &&
          this.actualActiveUserDuringScreenShare.length > 1
        ) {
          let isUserExistInCurPage = this.isUserExistInCurrentPage(this.actualActiveUserDuringScreenShare, this.curPageInfo.pInfo);
          clearTimeout(this.resetScreenShareMostActiveUserTimeoutId);
          if (isUserExistInCurPage) {
            this.resetScreenShareMostActiveUserTimeoutId = setTimeout(() => {
              this._confPageService.mostActiveUserDuringScreenShare(this.actualActiveUserDuringScreenShare);
              this.actualActiveUserDuringScreenShare = "";
            }, 1500);
          }
        }
        break;
      case 'shareWhiteBoard':
        if (parsedMsge.userId === this.userId) {
          return;
        }
        this.initWhiteBoard = parsedMsge.share_wboard === 'true' || parsedMsge.share_wboard === true ? true : false;
        this._confPageService.isWhiteBoardStarted = this.initWhiteBoard;
        this.shareScreenStreamStarted = this.initWhiteBoard;
        this._confPageService.isWhiteBoardStarted = false;
        this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
        this.onStartWhiteBoard(parsedMsge.share_wboard, parsedMsge.white_board_data);
        break;
      case 'sharePollStatus':
        if (parsedMsge.pollStatus != undefined && this.isMeetingOwner === 0) {
          if (parsedMsge.pollId != undefined && parsedMsge.pollId != null) {
            if (parsedMsge.pollStatus === 'start') {
              $('#createPollModal').modal('show');
            }
            this.isPollStarted = parsedMsge.pollStatus === 'start' ? true : false;
            const pollInfo = {
              pollId: parsedMsge.pollId,
              pollStatus: parsedMsge.pollStatus
            }
            this.currentPollInfo = parsedMsge.pollStatus === 'start' ? pollInfo : null;
            this.pollService.sharePollObs(pollInfo);
          }
        }
        break;
      case 'sharePollAnswer':
        this.pollService.answerPollObs(parsedMsge);
        break;
      case 'resend_offer':
        if (window.isResendOfferInProgress !== undefined && window.isResendOfferInProgress === true) {
          return;
        }
        this.onUpdateBandwidth(this.currentBandWidth, true);
        break;
      case 'forced_disconnect':
        if (parsedMsge.userId === this.userId) {
          this.onUserClickLeaveMeeting('forced_disconnect');
        }
        break;
    }
  }

  /**
   * @description The below function will handle to check socket connection and sent a heartbeat to server
   *              to  notify that the client is connected to the server.
   */
  connectionHeartBeat() {
    this._logService.info('Conference --> connectionHeartBeat Called-->');
    this._logService.warn('Conference --> onSockeErrorHandler --> ');
    if (this.heartBeatIntervalId) {
      clearInterval(this.heartBeatIntervalId);
      clearTimeout(this.leaveMeetingTimeoutId);
    }

    this.heartBeatIntervalId = setInterval(() => {
      if (this._webSocket && this._webSocket !== null && this._webSocket.readyState !== 1) {
        clearInterval(this.heartBeatIntervalId);
        this._logService.warn('Conference --> connectionHeartBeat --> Socket State Changed to ' + this._webSocket.readyState);
        this._joinMeetingService.setConnectionLostMessage('Connection lost!<br /> Please try again.');
        this._confPageService.isSocketStateValid = false;
        return this.redirectToJoinMeeting(10000, true, 'SOCKET_STATE_CHANGE');
      } else {
        this.sendRquestToSocket({
          'req': 'hrtbeat'
        }, this._webSocket);
      }
    }, environment.HEARTBEAT_INTERVAL);
  }


  /**
   * @description The below function will handle to redirect the user to join meeting page.
   * @param timeoutTimmer
   */
  redirectToJoinMeeting(timeoutTimmer: any, retry: boolean, errorKey: string) {
    this._logService.warn('Conference --> redirectToJoinMeeting Called -->');
    if (retry) {
      this._logService.warn('notifyToShowReconnectLayoutObs --> Retry to joined --> ')
      const curMeetingInfo = this._joinMeetingService.curMeetingInfo;
      this._confPageService.notifyToShowReconnectLayoutObs(true, curMeetingInfo, timeoutTimmer, errorKey);
      this.onLeaveMeeting('leave');
    } else {
      this.leaveMeetingTimeoutId = setTimeout(() => {
        this._logService.warn('Conference --> redirectToJoinMeeting Called --> onLeaveMeeting called');
        this.onLeaveMeeting('leave');
        clearTimeout(this.leaveMeetingTimeoutId);
      }, timeoutTimmer);
    }

  }
  /**
  * @description The below function will handle whenever there is any error in websocket connection.
  */
  onSockeErrorHandler(error: any) {
    // this.consoleInfo('onSockeErrorHandler', ' Socket error messaage ', 'console' );
    this._logService.warn('Conference --> onSockeErrorHandler --> ', error);
    let errorMsge = this._utilService.getNotificationMessage('JOIN_MEETING_VALID_API_FAILED');
    this._joinMeetingService.setConnectionLostMessage(errorMsge);
    this.redirectToJoinMeeting(1000, false, 'JOIN_MEETING_VALID_API_FAILED');
  }


  /**
   * @description The below will handle to listen event triggered from participant file
   */
  messageEventListener(event: any) {
    this._logService.info('Conference --> messageEventListener called-->');
    if (
      this.isScreenShareInited === true &&
      this.isUserPresenter === true &&
      this.ignoreAnswer === true) {
      return;
    }
    if (event.data.type === undefined && typeof event.data === 'string' && event.data.length > 1) {
      if (event.data === 'ice-connected' || event.data == 'ice-failed') {
        // when ice failed dont wait, just throw the user in join meeting page
        if (event.data === 'ice-failed') {
          this._joinMeetingService.setConnectionLostMessage('Unable to connect using your browser. Please try desktop app instead or contact your network administrator.');
          this.redirectToJoinMeeting(1000, false, 'JOIN_MEETING_VALID_API_FAILED');
        }
        return;
      }
      const payLoad = JSON.parse(event.data);
      if (
        this.participants[payLoad.userId] === undefined ||
        payLoad.req === 'h264Offer' ||
        (payLoad.req === 'videoQualityChange' && payLoad.userId !== this.userId) ||
        (payLoad.req === 'mediaChangeOffer' && payLoad.userId !== this.userId)
      ) {
        return;
      }
      this.sendRquestToSocket(payLoad, this._webSocket);
    } else {
      this._logService.info('Conference --> messageEventListener called--> event data -->');
    }
  }

  /**
   * @description The below function will handle when user received answer from other participants
   * @param result
   */
  receiveVideoResponse(result: any): void {
    this._logService.info('Conference --> receiveVideoResponse called --> ', result);
    if (result !== undefined && this.participants[result.userId]) {
      this.participants[result.userId].rtcPeer.processAnswer(result.answer, function (error) {
        if (error) { return console.error(error); }
      });
    }
  }

  /**
   * @description The below function will handle to send request to Socket for every action like joined, sdp, ice, left etc
   * @param payLoad - json data
   * @param webSocket - socket connection
   */
  sendRquestToSocket(payLoad: any, webSocket: any): void {
    this._logService.info('Conference --> sendRquestToSocket called -->');
    if (payLoad !== undefined && webSocket !== null && webSocket.readyState > 1) {
      webSocket = this._socketService.getSocketInstance();
    }

    if (payLoad !== undefined && webSocket !== null && webSocket.readyState === 1) {
      payLoad = JSON.stringify(payLoad);
      this._logService.debug("Send Payload to Socket >>>>>> ", payLoad);
      this._logService.info('Conference --> sendRquestToSocket --> send to server -->', payLoad);
      webSocket.send(payLoad);
    }
  }

  /**
   * @description The below function will handle to initiate the webcame and audio input
   *              when ever the user joined the meeting.
   * @param msg - msge return from web socket for every new action
   * @param webSocket - Socket connections instance
   */
  exisUserHandler(responseFromSocket: any, webSocketInstance: any): void {
    this._logService.info('Conference --> exisUserHandler called --> ', responseFromSocket);
    this.connectionHeartBeat();
    const thisPointer = this;
    const audioConfig = this._utilService.getInfoFromStorage('local', 'audioConfig');
    this.showMainVideoLoader = true;
    this.userId = responseFromSocket.userId;
    this._userName = responseFromSocket.user;
    let constraints: any =
    {
      audio: {
        echoCancellation: { exact: true },
        noiseSuppression: { exact: true },
        autoGainControl: { exact: true }
      },
      video: this.getVideoConstraint(256, this.configureLayout, this.isAdaptiveLayoutEnabled)
    };
    let audioStream = this._deviceSettingService.getStoredStream('audio');
    let videoStream = this._deviceSettingService.getStoredStream('video');
    this.isUserPresenter = responseFromSocket.data === undefined || responseFromSocket.data.length === 0 ? true : false;
    this.presenterUserId = this.isUserPresenter === true ? this.userId : "";
    this.participant = new Participant(this.userId, this._userName, true, false);
    this.localVideoElement = this.participant.getVideoElement();
    this.localVideoElement.addEventListener('contextmenu', event => event.preventDefault());

    let options = {
      localVideo: this.localVideoElement,
      audioStream: audioStream,
      videoStream: videoStream,
      onicecandidate: this.participant.onIceCandidate.bind(this.participant),
      browserType: this._browserInfo.name,
      turnsConfig: this._turnsConfig,
      H264Codec: this._utilService.getEnvironmentValue('H264_ALL_PEER')  //environment['H264_ALL_PEER']
    };

    this.participants[this.userId] = this.participant;
    this.participantList.push({
      userId: this.userId,
      name: this._userName,
      pstr: this.isUserPresenter,
      share_video: true,
      share_audio: true,
      is_owner: this.isMeetingOwner
    });
    this._confPageService.updateUserInfo(
      this.userId,
      {
        isAudioShare: true,
        isVideoShare: true,
        isStreamAvailable: true,
        isUserPresenter: this.isUserPresenter,
        isUserMeetingOwner: this.isMeetingOwner
      }
    );

    this.updateObject(this.pagingInfo, 'curParticipantCount', responseFromSocket.data.length + 1);
    // this._joinMeetingService.notifyPagingInfo$(this.pagingInfo);


    //cancel the auto redirect timeout
    clearTimeout(this.autoRedirectTimeoutId);

    // // create SDP Offer
    this.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(options,
      thisPointer.sendRecvSDPOfferCallback.bind(thisPointer)
    );

    // this will add video for already joined paticipants
    this.handleAlreadyJoinedParticipant(responseFromSocket.data, this.userId);

    // this will add custom video control to mute/unmute call
    this.addVideoControl(this.userId);
    this.addVideoControlDropDown(this.userId);

    // add click listener for the custom create element to mute/unmute
    this.addVideoControlHandler(this.userId);
    const defaultVideo = this._joinMeetingService.getMeetingConfig('default_video');
    if (defaultVideo === 0) {
      const videoWrapper = document.getElementById(this.userId);
      if (videoWrapper !== null) {
        videoWrapper.classList.add('hide-video');
        setTimeout(() => {
          videoWrapper.classList.remove('hide-video');
        }, 1500);
      }
    }
  }


  /**
   * @description The below function will handle to check the whether applied constraint execute successfully or not.
   */
  sendRecvSDPOfferCallback(error: any) {
    this._logService.info('Conference --> sendRecvSDPOfferCallback called ');
    const thisPointer = this;
    if (error !== undefined && error !== null) {
      if (error.name !== undefined && error.name === 'NotReadableError') {
        // video source not available
        this._logService.warn('Conference --> sendRecvSDPOfferCallback --> video source not available');
      }
      else if (error.name !== undefined && error.name === 'OverconstrainedError') {
        this._logService.warn('Conference --> sendRecvSDPOfferCallback --> ', error.name);
        thisPointer.isOverConstraints = true;
        const options = {
          localVideo: thisPointer.localVideoElement,
          mediaConstraints: { audio: true, video: true },
          onicecandidate: thisPointer.participant.onIceCandidate.bind(thisPointer.participant),
          browserType: this._browserInfo.name,
          turnsConfig: this._turnsConfig,
          H264Codec: this._utilService.getEnvironmentValue('H264_ALL_PEER') //environment['H264_ALL_PEER'],
        };
        thisPointer.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(options,
          thisPointer.sendRecvSDPOfferCallback.bind(thisPointer)
        );
        return;
      }
      // else if (error.name !== undefined && error.name === 'NotReadableError' && this.isUserAbleToAccessDevice === true) {
      //   this._logService.warn('Conference --> sendRecvSDPOfferCallback --> ', error.name);
      //   thisPointer.isOverConstraints = true;
      //   const options = {
      //     localVideo: thisPointer.localVideoElement,
      //     mediaConstraints: { audio: true, video: false },
      //     onicecandidate: thisPointer.participant.onIceCandidate.bind(thisPointer.participant)
      //   };
      //   thisPointer.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(options,
      //     thisPointer.sendRecvSDPOfferCallback.bind(thisPointer)
      //   );
      //   return;
      // }
    }
    thisPointer.onAccessSuccessfullyInputDevice(error);
    this.isUserAbleToAccessDevice = true;
  }

  /**
   * @description Once the media devices access successfully then send the spd offer to
   */
  onAccessSuccessfullyInputDevice(error: any) {
    this._logService.info('Conference --> onAccessSuccessfullyInputDevice called -->');
    const thisPointer = this;
    const userInfo = thisPointer._confPageService.getUserInfo(thisPointer.userId);
    thisPointer.participants[thisPointer.userId] =
      thisPointer._confPageService.setLocalParticipant(thisPointer.participant);
    thisPointer._confPageService.updateParticipants(thisPointer.userId, thisPointer.participant);
    thisPointer.isVideoStreamStart();
    thisPointer.defualtVideoControlHandler(thisPointer.isAudShare, thisPointer.isVidShare, userInfo);
    thisPointer.audioLevelSender(thisPointer._soundMeter, window.localStream);
    if (error) {
      this._logService.info('Conference --> onAccessSuccessfullyInputDevice failed to get access -->', error);
      thisPointer.isVideoStreamAvailable = false;
      this._confPageService.updateUserInfo(thisPointer.userId, userInfo, 'isStreamAvailable', false);
      thisPointer.notifyNoVideoStream(thisPointer.userId);
      thisPointer.updateBitrate(thisPointer.currentBandWidth);
      return console.log(error);
    }
    thisPointer.localVideoElement.muted = true;
    thisPointer.participants[thisPointer.userId] = thisPointer.participant;
    thisPointer.participant.rtcPeer.generateOffer(thisPointer.participant.offerToReceiveVideo.bind(thisPointer.participant));
    this.initH264UserConnection = true;
  }

  autoUpdateQality() {
    let thisPointer = this;
    const options = {
      localVideo: this.localVideoElement,
      audioSteam: null,
      videoStream: window.localVideoStream,
      onicecandidate: this.participant.onIceCandidate.bind(this.participant),
      browserType: this._browserInfo.name,
      turnsConfig: this._turnsConfig,
      H264Codec: this._utilService.getEnvironmentValue('H264_ALL_PEER') //environment['H264_ALL_PEER'],
    };
    // if (this.localVideoElement.srcObject !== null) {
    //   this.localVideoElement.srcObject.getTracks().forEach(track => track.stop());
    // }

    if (thisPointer.currentActiveUserId === thisPointer.userId) {
      thisPointer.resetVideoSrcObject('full-video');
    }
    // thisPointer.resetVideoSrcObject('video-' + thisPointer.currentActiveUserId);

    thisPointer.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(
      options,
      function (error) {
        thisPointer.isVideoStreamStart();
        thisPointer._confPageService.resetMostActiveUser = true;
        thisPointer.audioLevelSender(thisPointer._soundMeter, window.localStream);
        if (error) {
          // thisPointer.isVideoStreamAvailable = false;
          // thisPointer.notifyNoVideoStream(thisPointer.userId);
          // if (thisPointer.currentBandWidth >= 512) {
          //   thisPointer.userSelectedBandWidth = 512;
          //   thisPointer.onUpdateBandwidth(384, false)
          // } else if (thisPointer.currentBandWidth >= 384) {
          //   thisPointer.userSelectedBandWidth = 384;
          //   thisPointer.onUpdateBandwidth(256, false);
          // }
          // // else if (thisPointer.currentBandWidth >= 256) {
          // //   thisPointer.userSelectedBandWidth = 256;
          // //   thisPointer.onUpdateBandwidth(128, false);
          // // }
          return console.log(error);
        }
        thisPointer.localVideoElement.muted = true;
        if (thisPointer.currentActiveUserId === thisPointer.userId) {
          thisPointer._confPageService.notifyMostActiveUser(thisPointer.currentActiveUserId, 'null', thisPointer.layoutType);
        }

        // // if user already muted before change resolution then make
        // if (audioMuteStatus === 0) {
        //   thisPointer.participant.rtcPeer.audioEnabled = false;
        // }
        // if (videoStopStatus === 0) {
        //   thisPointer.participant.rtcPeer.videoEnabled = false;
        // }
        thisPointer.participant.rtcPeer.generateOffer(thisPointer.participant.offerToChangeQualityVideo.bind(thisPointer.participant));
      }
    );
  }

  /**
   * @description The below function will handle whenever a new user join the conference
   */
  onNewUserJoin(parsedMsge: any) {
    this._logService.info('Conference --> onNewUserJoin called', parsedMsge);
    let isApiCallReq = true;
    this.removePlaceHolderElems();
    let isH264User = this.checkUserType(parsedMsge);
    if (
      this.isUserPresenter === true &&
      this.isScreenShareInited === true &&
      (parsedMsge.user === 'screen-shared-user' || parsedMsge.user === 'screen-shared-web-user')
    ) {
      this._logService.info('Conference --> onNewUserJoin --> Screen Shared User Joined');
      this.screenShareUserId = parsedMsge.userId;
      return this.ignoreAnswer = true;
    } else {
      if (isH264User === false) {
        this.ignoreAnswer = false;
      } else {
        // this is fake user for h264 connnection
      }
    }

    if (parsedMsge.user === 'screen-shared-user' || parsedMsge.user === 'screen-shared-web-user') {
      // isApiCallReq = true;
      this.isPstrStartScreenShare = true;
    } else {
      if (this.isWindowActive === true) {
        this.notifier.notify('success', parsedMsge.user + ' joined');
      }
      this.playSound("assets/images/join-conference.mp3");
      // ../../../assets/images/join-conference.mp3
    }
    if (parsedMsge.is_owner === 1) {
      this._confPageService.hostName = parsedMsge.user;
      this.meetingOwnerUserId = parsedMsge.userId;
    }
    this.receiveVideoHandler(parsedMsge, isApiCallReq);
  }

  checkUserType(parsedMsg: any): boolean {
    let userName = parsedMsg.user !== undefined ? parsedMsg.user : parsedMsg.name;
    let result = false;
    if (userName.indexOf('H264_USER') > -1 || userName.indexOf('newUser') > -1) {
      result = true;
    } else if (
      parsedMsg.connection_mode === 'H264' &&
      (
        parsedMsg.user_type === 'WEB' ||
        parsedMsg.user_type === 'ANDROID' ||
        parsedMsg.user_type === 'IOS'
      )
    ) {
      result = true;
    }
    return result;
  }

  onStartStopScreenShare(parsedMsge: any): void {
    this._logService.info('Conference --> onStartStopScreenShare called --> ', parsedMsge);
    this.disabledMakePresenter = parsedMsge.share_scr;
    if (this.isUserPresenter) {
      this.screenShareIndicatorHandler(parsedMsge.share_scr);
    }
    if (this.isUserPresenter === true && this.isScreenShareInited === true) {
      return;
    }
    this.screenShareUserId = parsedMsge.userId;
    this._confPageService.isScreenShareStarted = parsedMsge.share_scr;
    if (parsedMsge.share_scr) {
      this.previousThumbnailCount = this.thumbnailCount;
      this.speakerName = this.getParticipantNameByUserId(this.presenterUserId, this.participantList, true);
    } else {
      this.speakerName = "";
    }
    this.shareScreenStreamStarted = parsedMsge.share_scr;
    this.isPstrStartScreenShare = parsedMsge.share_scr;
    if (this.isPstrStartScreenShare) {
      this.showMainVideoLoader = false;
    } else {
      this.showMainVideoLoader = true;
    }
    this._confPageService.notifyMostActiveUser(parsedMsge.userId, 'screen-shared-user', this.layoutType);
    setTimeout(() => {
      const thumbCount = this._confPageService.getThumbnailCount(environment.LAYOUT_TYPE_ENUMS[1]);
      this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, thumbCount, true);
    }, 1000);

    // this._utilService.notifyScreenShared(parsedMsge);
  }

  mostActiveUserHandler(parsedMsge: any, curPageInfo: any) {
    let isUserExistInCurPage = true;
    if (curPageInfo && curPageInfo.pNo === 1 &&
      (this.initWhiteBoard === true || this.shareScreenStreamStarted)
    ) {
      this.mostActiveUserHandlerDuringScreenShare(parsedMsge, curPageInfo);
    }

    if (this.initWhiteBoard === true || parsedMsge.userId1 === undefined) {
      return;
    }

    if (this.shareScreenStreamStarted) {
      this.speakerName = this.getParticipantNameByUserId(this.presenterUserId, this.participantList, true);
      return;
    }

    let mostActiveUserId = this.userId;
    if (parsedMsge.userId2 !== undefined) {
      mostActiveUserId = parsedMsge.userId1 !== this.userId ? parsedMsge.userId1 : parsedMsge.userId2;
    }

    if (this.layoutType === this.layoutTypeENUMS[2] && curPageInfo && curPageInfo.pNo === 1) {
      isUserExistInCurPage = this.isUserExistInCurrentPage(mostActiveUserId, curPageInfo.pInfo);
      if (!isUserExistInCurPage) {
        this.actualActiveUserDuringScreenShare = mostActiveUserId;
        // console.log('user not exists call vDet with first page');
        this.fetchActiveParticipantsList(1, this.thumbnailCount, true);
        return;
      } else {
        // this.fetchActiveParticipantsList(1, this.thumbnailCount);
        // console.log(' its ok you can  continue ');
      }
    }

    this.speakerName = this.getParticipantNameByUserId(mostActiveUserId, this.participantList);
    this.currentActiveUserId = mostActiveUserId;

    if (this.layoutType === this.layoutTypeENUMS[2] && curPageInfo && curPageInfo.pNo === 1) {
      this._confPageService.mostActiveUserDuringScreenShare(mostActiveUserId);
    } else {
      this._confPageService.notifyMostActiveUser(mostActiveUserId, 'null', this.layoutType);
    }
  }

  mostActiveUserHandlerDuringScreenShare(parsedMsge: any, curPageInfo: any) {
    let mostActiveUserId = this.userId;
    let isUserExistInCurPage = true;
    if (parsedMsge.userId2 !== undefined) {
      mostActiveUserId = parsedMsge.userId1 !== this.userId ? parsedMsge.userId1 : parsedMsge.userId2;
    }
    this.actualActiveUserDuringScreenShare = mostActiveUserId;
    if (curPageInfo && curPageInfo.pNo === 1) {
      isUserExistInCurPage = this.isUserExistInCurrentPage(mostActiveUserId, curPageInfo.pInfo);
      if (!isUserExistInCurPage) {
        this.fetchActiveParticipantsList(1, this.thumbnailCount, true);
        return;
      } else {
        // this.fetchActiveParticipantsList(1, this.thumbnailCount);
      }
    }
    this._confPageService.mostActiveUserDuringScreenShare(mostActiveUserId);
    //this._confPageService.notifyMostActiveUser(mostActiveUserId, 'null', );

  }


  isUserExistInCurrentPage(mostActiveId: string, curPageUsersListObj: any): boolean {
    let userIdsListArr = this.getCurActiveUserIdsList(curPageUsersListObj);
    // console.log('--userIdsListArr ', userIdsListArr, mostActiveId)
    return userIdsListArr.indexOf(mostActiveId) > -1 ? true : false;
  }

  getCurActiveUserIdsList(curPageUsersList) {
    let userIdsArr = [];
    if (curPageUsersList !== undefined) {
      curPageUsersList.map((val, arrIdx) => {
        userIdsArr.push(val.userId);
      });
    }
    return userIdsArr;
  }

  layoutPagingHandler(parsedMsge: any): void {
    // if no participant return for any page other than first page, then make the vdet call
    // with previous page
    if (parsedMsge.pNo !== 1 && parsedMsge.pInfo !== undefined && parsedMsge.pInfo.length === 0) {
      const curPageNumber = this.pagingInfo.curPageNo - 1;
      const layoutNumber = this.pagingInfo.curPageSizeCount;
      return this.fetchActiveParticipantsList(curPageNumber, layoutNumber, true);
    }
    if (parsedMsge.pNo === 1) {
      parsedMsge.pInfo.unshift({ userId: this.userId });
    }
    this.updateObject(this.pagingInfo, 'curPageNo', parsedMsge.pNo);
    this.updateObject(this.pagingInfo, 'curActiveUsers', parsedMsge.pInfo);
    this._confPageService.notifyPagingInfo$(this.pagingInfo);
  }

  /**
   * @description This video will make sure video stream started
   */
  isVideoStreamStart(): void {
    let streamCheckCounter = 0;
    const streamCheckIntervalId = setInterval(() => {
      if (this.localVideoElement.videoHeight < 20) {
        if (streamCheckCounter > 15) {
          this._confPageService.initLocalPeerStatsObs(this.participant);
          //this.getSenderStats(this.participant);
          this._confPageService.notifyToShowReconnectLayoutObs(false, this._joinMeetingService.curMeetingInfo, 100, "");

          setTimeout(() => {
            this.isSocketConnected = true;
            // this.initDeviceSettingModalComponent = true;
          }, 2500);
          clearInterval(streamCheckIntervalId);
        }
      } else {
        if (this.localVideoElement.videoHeight > 20) {
          this.updateBitrate(this.currentBandWidth);
        } else {
          this._confPageService.initLocalPeerStatsObs(this.participant);
          //this.getSenderStats(this.participant);
        }
        this._confPageService.notifyToShowReconnectLayoutObs(false, this._joinMeetingService.curMeetingInfo, 100, "");
        setTimeout(() => {
          this.isSocketConnected = true;
          // this.initDeviceSettingModalComponent = true;
        }, 2500);
        clearInterval(streamCheckIntervalId);
      }
      ++streamCheckCounter;
    }, 250);
  }

  /**
   * @description The below function will handle to mute/ pause video by default if the value is 0
   */

  defualtVideoControlHandler(isAudShare: boolean, isVidShare: boolean, userInfo: UserInfo) {
    if (isAudShare === false) {
      //this.muteAudio = false;
      this.participantList[0].share_audio = isAudShare;
      this.toggleAudio(this.userId, isAudShare, true);
      this._confPageService.updateUserInfo(this.userId, userInfo, 'isAudioShare', false);
    }

    if (isVidShare === false) {
      this.pauseVideo = false;
      this.participantList[0].share_video = isVidShare;
      this.toggleVideo(this.userId, this.pauseVideo);
      this._confPageService.updateUserInfo(this.userId, userInfo, 'isVideoShare', false);
    }
  }

  /**
   * @description The below function will handle to add a class to indicate the participant dont have video stream.
   * @param userId
   */
  notifyNoVideoStream(userId: string) {
    const videoWrapper = document.getElementById(userId);
    if (videoWrapper !== null) {
      this.isVideoStreamAvailable = false;
      videoWrapper.classList.add('no-video-stream');
    }
  }

  /**
   * @description The below function will handle to check the participant/ thisPointer has video stream
   */
  checkVideoStreamAvailable(userId: string) {
    if (this._browserInfo.name === 'Chrome') {
      const videoWrapper: any = document.getElementById('video-' + userId);
      if (videoWrapper.webkitDecodedFrameCount !== undefined && videoWrapper.webkitDecodedFrameCount <= 1) {
        this.notifyNoVideoStream(userId);
      }
    }
  }

  /**
   * @description The below function will handle to add to show video for
   *              already joined participent when user joined the meeting first time.
   * @param existingParticipants : list of already joined participants
   */
  handleAlreadyJoinedParticipant(existingParticipants, selectorId: string) {
    if (existingParticipants === undefined || existingParticipants.length === 0) {
      this.isUserPresenter = true;
      this.presenterName = this._userName;
      this.speakerName = this._userName;
      this.fetchActiveParticipantsList(1, this.thumbnailCount, false);
      this.setSideHeaderHeight();
      this._confPageService.updatePresenterIconIndicatorObs(this.userId, true);
      return;
    }

    const totalParticipantCount = existingParticipants.length;
    existingParticipants.map(
      (participantInfo: any, arrIdx: number) => {
        // first check is the current participant is screen share user
        if (participantInfo.share_scr !== undefined && participantInfo.share_scr === true) {
          this.isPstrStartScreenShare = true;
          this.shareScreenStreamStarted = true;
          this._confPageService.isScreenShareStarted = true;
        }
        if (participantInfo.whiteboard_share !== undefined && participantInfo.whiteboard_share === true) {
          setTimeout(() => {
            this.initWhiteBoard = true;
            this._confPageService.isWhiteBoardStarted = true;
            this.onStartWhiteBoard("true", participantInfo.whiteboard_data);
            this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
          }, 3000);
        }

        if (participantInfo.is_owner === 1) {
          this._confPageService.hostName = participantInfo.name;
          this.meetingOwnerUserId = participantInfo.userId;
        }
        // if the user is last in the list then make sure it call page handler api
        const isPagingAPIRequire = arrIdx + 1 === totalParticipantCount ? true : false;

        this.receiveVideoHandler(participantInfo, isPagingAPIRequire);
        if (participantInfo.pstr === true) {
          this.presenterUserId = participantInfo.userId;
          this.presenterName = participantInfo.name;
          this.updatePresenterIconIndicator(participantInfo.userId, true);
        }

        //if this is the last user in the data array  and the presenter shared the screen
        if (isPagingAPIRequire === true && this.isPstrStartScreenShare === true) {
          this.speakerName = this.getParticipantNameByUserId(this.presenterUserId, this.participantList, true);
        }
      }
    );
  }

  /**
   * @description The below function will handle to remove the partcipent when another user left the meeting.
   * @param request
   */
  onParticipantLeft(request: any) {
    // the exact participant which was left from the meeting
    if (request.user === 'screen-shared-user' || request.user === 'screen-shared-web-user' || this.screenShareUserId === request.userId) {
      this.isPstrStartScreenShare = false;
      this.shareScreenStreamStarted = false;
      this.disabledMakePresenter = false;
    }
    const participant = this.participants[request.userId];
    this._confPageService.removeUserFromUserInfo(request.userId);
    if (request.userId === this.presenterUserId && this.initWhiteBoard === true) {
      this.initWhiteBoard = false;
      this.initWhiteBoard = false;
      this.shareScreenStreamStarted = false;
      this._confPageService.isWhiteBoardStarted = false;
    }

    // this block will check the user left is owner and the meeting is in progress
    if (this.isPollStarted && request.userId === this.meetingOwnerUserId) {
      if (this.currentPollInfo !== null) {
        this.currentPollInfo.pollStatus = "end";
        this.pollService.sharePollObs(this.currentPollInfo);
      }
    }

    // make sure the participant is exists
    if (participant !== undefined) {
      if (request.user === 'screen-shared-user' || request.user === 'screen-shared-web-user' || this.screenShareUserId === request.userId) {
        const fullVideoElement: any = document.getElementById('full-video');
        if (fullVideoElement !== null) {
          fullVideoElement.srcObject = null;
        }
        this.isPstrStartScreenShare = false;
        this.shareScreenStreamStarted = false;
        this._confPageService.isScreenShareStarted = false;
        this._confPageService.setLayoutType(this._layoutBeforeShareScreen);
        this._confPageService.resetMostActiveUser = true;
        this._confPageService.notifyMostActiveUser(this.presenterUserId, 'null', this.layoutType);
        if (this.presenterUserId === request.userId) {
          this.playSound("assets/images/leave-conference.mp3");
          //../../../assets/images/leave-conference.mp3
        }
        this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
        //this._confPageService.updateMeetingConfig('default_layout', 1)
      } else {
        if (this.isWindowActive === true) {
          this.notifier.notify('error', request.user + ' left');
        }
        //this.alerts.setMessage(request.user + ' left', 'warn');
        this.playSound("assets/images/leave-conference.mp3");
        this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, false);
      }
      this._confPageService.stopRemotePeerStatsObs(request.userId);
      participant.dispose();
      delete this.participants[request.userId];
      this.removeParticipantFromList(request.userId);
    }
  }

  /**
   * @description The below function will handle to ICE candidate after SPD offere success.
   * @param parsedMsg - response from socket
   * @param webSocket - socket instance
   */
  iceCandidateHandler(parsedMsg, webSocket) {
    if (this.participants[parsedMsg.userId] === undefined) {
      return;
    }
    // console.log('remote candidate ice details ---> ', parsedMsg.candidate);
    this.participants[parsedMsg.userId].rtcPeer.addIceCandidate(
      parsedMsg.candidate,
      function (error) {
        if (error) {
          console.log('Error adding candidate: ' + error);
          return;
        }
      }
    );
  }

  /**
   * @description The below function will handle crate new video element for each existing/newly joined
   *              particpant and peer connection.
   * @param sender - The participant name
   * @param senderId - unique participant id
   */
  receiveVideoHandler(remoteUserInfo: any, callPaingApi: boolean) {
    const thisPointer = this;
    let isUserH264Mode = this.checkUserType(remoteUserInfo);
    if (isUserH264Mode) {
      return;
    }
    let offerH264: boolean = false;
    const pagingInfo = thisPointer.pagingInfo;
    const participantName = remoteUserInfo.name !== undefined ? remoteUserInfo.name : remoteUserInfo.user;
    // the below condition will handle to hide any extra user joined more than the layoutsize count
    const hideVideoWrapper = pagingInfo.curParticipantCount % pagingInfo.curPageSizeCount == 0 ? true : false;
    const participant = new Participant(remoteUserInfo.userId, participantName, false, hideVideoWrapper);
    const videoElement = participant.getVideoElement();
    if (participantName !== 'screen-shared-user' && participantName !== 'screen-shared-web-user') {
      thisPointer.participantList.push({
        userId: remoteUserInfo.userId,
        name: participantName,
        pstr: remoteUserInfo.pstr,
        share_audio: remoteUserInfo.share_aud,
        share_video: remoteUserInfo.share_vid,
        is_owner: remoteUserInfo.is_owner
      });
      offerH264 = remoteUserInfo.user_type === 'CODEC' && remoteUserInfo.connection_mode === 'H264' ? true : this._utilService.getEnvironmentValue('H264_ALL_PEER');//environment['H264_ALL_PEER'];
    } else {
      let H264ConfigValue = this._utilService.getEnvironmentValue('H264_CODEC');
      if (H264ConfigValue !== undefined && H264ConfigValue === true) {
        offerH264 = participantName == 'screen-shared-web-user' || participantName === 'screen-shared-user' ? true : false;
      }
    }

    thisPointer._confPageService.updateUserInfo(
      remoteUserInfo.userId,
      {
        isAudioShare: remoteUserInfo.share_aud,
        isVideoShare: remoteUserInfo.share_vid,
        isStreamAvailable: true,
        isUserPresenter: remoteUserInfo.pstr,
        isUserMeetingOwner: remoteUserInfo.is_owner
      }
    );
    thisPointer.totalParticipantCount = thisPointer.participantList.length; //participantName === 'screen-shared-user' ? thisPointer.participantList.length - 1 : thisPointer.participantList.length;
    thisPointer.participants[remoteUserInfo.userId] = participant;
    videoElement.addEventListener('contextmenu', event => event.preventDefault());
    const options = {
      remoteVideo: videoElement,
      onicecandidate: participant.onIceCandidate.bind(participant),
      browserType: this._browserInfo.name,
      turnsConfig: this._turnsConfig,
      H264Codec: offerH264,
    };
    //return;
    participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerRecvonly(
      options,
      function (error) {
        //thisPointer.defualtVideoControlHandler(remoteUserInfo.share_aud, remoteUserInfo.share_vid);
        thisPointer.toggleVideoControl(remoteUserInfo.userId, remoteUserInfo.share_aud, 'audio');
        thisPointer.toggleVideoControl(remoteUserInfo.userId, remoteUserInfo.share_vid, 'video');

        // this will check whether paging handler api need to call or not
        if (callPaingApi) {
          thisPointer.updateObject(thisPointer.pagingInfo, 'curParticipantCount', thisPointer.participantList.length);
          //thisPointer.fetchActiveParticipantsList(thisPointer.pagingInfo.curPageNo, thisPointer.thumbnailCount);
          clearTimeout(this.vDetForRemoteUserJoinedTimeoutId);
          this.vDetForRemoteUserJoinedTimeoutId = setTimeout(() => {
            thisPointer.fetchActiveParticipantsList(thisPointer.pagingInfo.curPageNo, thisPointer.thumbnailCount, true);
          }, 2000);
        }

        // this will handle to show the screen share user stream as active participant
        if (participantName === 'screen-shared-user' || participantName === 'screen-shared-web-user' || remoteUserInfo.share_scr === true) {
          setTimeout(() => {
            thisPointer.screenShareUserId = remoteUserInfo.userId;
            thisPointer._confPageService.notifyMostActiveUser(
              remoteUserInfo.userId,
              'screen-shared-user',
              thisPointer.layoutTypeENUMS[2]
            );
          }, 1000);
        }
        thisPointer.setSideHeaderHeight();
        thisPointer.remoteParticipant.push(participant)
        setTimeout(() => {
          if (thisPointer._browserInfo.name !== 'Firefox') {
            thisPointer.outputDeviceId = thisPointer._deviceSettingService.getSelectedDeviceId('output')
            thisPointer._deviceSettingService.attachSinkId(thisPointer.outputDeviceId, videoElement);
          }
          thisPointer._confPageService.initRemotePeerConnectionsStatsObs(participant, remoteUserInfo.userId);
        }, 5000);
        if (error) {
          return console.log(error);
        }
        participant.rtcPeer.generateOffer(participant.offerToReceiveVideo.bind(participant));
      }
    );
    // console.log('participant.rtcPeer ---> ', thisPointer.participants[remoteUserInfo.userId]);
    // setTimeout(() => {
    //   alert(1);
    //   thisPointer._confPageService.initLocalPeerStatsObs(participant);
    // }, 5000);
    this.addVideoControl(remoteUserInfo.userId);
    this.addVideoControlDropDown(remoteUserInfo.userId);
    this.addVideoControlHandler(remoteUserInfo.userId);
    // this.updatePresenterIconIndicator(remoteUserInfo.userId, remoteUserInfo.isPresenter);
  }

  /**
   * @description The below function will handle any functionality when user joined the meeting.
   * @param parsedMsg - response from socket
   * @param webSocket - socket instance
   */
  joinMeetingRoomHandler(parsedMsg, webSocket) {
    if (this.isMeetingOwner == 1) {
      this.meetingOwnerUserId = parsedMsg.userId;
      const meetingConfig = this._utilService.getInfoFromStorage('session', 'meeting_config');
      if (meetingConfig.is_owner === 1) {
        this._confPageService.hostName = this.userInfo.userName;
      }
    }
  }

  /**
   * @description The below function will handle when user want to leave the meeting.
   */
  onLeaveMeeting(type: any) {
    // send a request to sockete indicating user want to left the meeting
    // depending on this request, all other participant will reeived a notification
    // that this user is left the meeting.
    // this.consoleInfo('onLeaveMeeting', ' leave meeting as user click or due to above problem ', 'console' );
    this._logService.info('Conference --> onLeaveMeeting called --> ', type);
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState === 1) {
      if (this.participantList.length === 1) {
        this.leaveMeetingForAll();
      }

      this.sendRquestToSocket(
        { 'req': 'leaveMeetingRoom' }, this._webSocket
      );
    }

    clearInterval(this.heartBeatIntervalId);
    // dispose all the participants
    const participantsKeys = Object.keys(this.participants);
    participantsKeys.map((val, key) => {
      if (this.participants[val] !== undefined) {
        this.participants[val].dispose();
      }
    });

    this.participants = {};
    if (this._webSocket !== null) {
      this._webSocket.close();
      this._webSocket = null;
    }
    this.initH264UserConnection = false;
    this._utilService.removeFromStorage('session', 'userAction');
    this._utilService.removeFromStorage('session', 'participantInfo');
    this._utilService.removeFromStorage('localStorage', 'is_owner');
    this._utilService.removeFromStorage('localStorage', 'socketUrl');
    this._utilService.removeFromStorage('localStorage', 'kip');
    this._utilService.removeFromStorage('localStorage', 'jip');
    this.routerHandlerAfterMeetingEnd(type, this.isMeetingOwner);
  }

  onUserClickLeaveMeeting(type: any): void {
    this._joinMeetingService.resetConnectionLostMessage();
    this.onLeaveMeeting(type);
  }

  /**
   * @description The below function will handle to redirect the user to previous / respective page when meeting end
   */
  routerHandlerAfterMeetingEnd(meetingEndType: string, isUserMeetingOwner: boolean): void {
    $('#leaveEndMeeitng').modal('hide');
    if (meetingEndType == 'END' && !isUserMeetingOwner) {
      this._router.navigate(['/meeting-ended']);
    } else if (meetingEndType === 'forced_disconnect') {
      this._router.navigate(['/meeting-disconnect']);
    } else {
      const curUserInfo = this._utilService.getInfoFromStorage('local', 'currentUser');
      if (curUserInfo !== null) {
        this._router.navigate(['/my-meetings']);
      } else {
        // console.log('routerHandlerAfterMeetingEnd --> ', curUserInfo)
        if (this.userInfo !== null && this.userInfo.meetingId !== undefined) {
          this._router.navigate(['/join-meeting', this.userInfo.meetingId]);
        } else {
          this._router.navigate(['/join-meeting']);
        }
      }
    }
  }

  /**
   * @description The below function will handle to make any participant presenter.
   * @param participantId
   */
  onMakePresenterIconClicked(evt: Event) {
    const participantId = this.getTargetUserId(evt, 'data-user-id');
    if (participantId === undefined) {
      return;
    }
    if (this.isScreenShareInited === true) {
      alert('To make presenter, please stop screen sharing!');
      return;
    }
    this.notifyServerForNewPresenter(participantId);
  }


  notifyServerForNewPresenter(participantId: string) {
    const reqPayload = {
      req: 'reqPresBall',
      userId: participantId
    };
    if (this.userId === participantId && this.initWhiteBoard) {
      this.initWhiteBoard = false;
    }
    this.participantList.map(
      (participant: any, arrIdx: number) => {
        if (participant.userId === this.userId) {
          participant.pstr = false;
        } else if (participant.userId === participantId) {
          participant.pstr = true;
        }
      }
    );
    this.sendRquestToSocket(reqPayload, this._webSocket);
    this.updatePresenterIconIndicator(participantId, true);
  }

  /**
   * @description The below function will handle to set the user presenter/ host
   * @param parsedMsg - Object
   */
  updateNewPresenter(parsedMsg: any) {
    if (parsedMsg === undefined) {
      return;
    }
    const prevPresenterUserInfo: UserInfo = this._confPageService.getUserInfo(this.presenterUserId);
    const curPresenterUserInfo: UserInfo = this._confPageService.getUserInfo(parsedMsg.userId);
    this._confPageService.updateUserInfo(this.presenterUserId, prevPresenterUserInfo, 'isUserPresenter', false);
    this._confPageService.updateUserInfo(parsedMsg.userId, curPresenterUserInfo, 'isUserPresenter', true);

    // when presenter change and the previous presenter was shared white board then stop art board shared
    if (this.presenterUserId === this.userId && this.initWhiteBoard) {
      this.initWhiteBoard = false;
      this.stopWhiteBoard();
    }

    this.participantList.map(
      (val, key) => {
        if (val.userId === parsedMsg.userId) {
          val.pstr = true;
          this.updatePresenterIconIndicator(val.userId, true);
        } else {
          val.pstr = false;
        }
      }
    );
    this.presenterUserId = parsedMsg.userId;
    if (parsedMsg.userId === this.userId) {
      this.isUserPresenter = true;
      const popUpMessage = 'Now, you are presenter!';
      this._utilService.sendAlertMessage(popUpMessage, '');
    } else {
      this.isUserPresenter = false;
      this.isScreenShareInited = false;
    }
    this.presenterName = this.getParticipantNameByUserId(this.presenterUserId, this.participantList);
  }

  /**
   * @description The below function will return the name of the presenter
   * @param userId
   * @param participantList
   */
  getParticipantNameByUserId(userId: string, participantList: any, nameForScreenShare?: boolean) {
    const curSpeakerUser = participantList.filter((participant, arrIdx) => {
      return participant.userId === userId;
    });
    if (curSpeakerUser.length === 1) {
      const speakerName = curSpeakerUser[0].name;
      if (nameForScreenShare !== undefined && nameForScreenShare === true) {
        return "You are viewing " + speakerName + "'s screen!";
      }
      return speakerName;
    } else {
      return '';
    }
  }




  /**
   * @description The below function will handle to remove participant which left from the meeting.
   *              This is internal use as the list need to display on UI. Its not related to any of the
   *              Kurento functionality.
   * @param userId
   */
  removeParticipantFromList(userId) {
    if (this.participantList.length > 1) {
      this.participantList = this.participantList.filter((val) => {
        return userId !== val.userId;
      });
      this.updateObject(this.pagingInfo, 'curParticipantCount', this.participantList.length);
      // this._confPageService.notifyPagingInfo$(this.pagingInfo);
      this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.pagingInfo.curPageSizeCount, true);
    }
    this.totalParticipantCount = this.participantList.length;
    this.updateObject(this.pagingInfo, 'curParticipantCount', this.totalParticipantCount);
    this._confPageService.notifyPagingInfo$(this.pagingInfo);
  }

  setSideHeaderHeight() {
    const confHeaderElem: any = document.querySelector('.conference-header');
    if (confHeaderElem !== null) {
      this.listSidebarHeight = window.innerHeight - confHeaderElem.offsetHeight + 'px';
    }
  }

  /**
   * @description The below function will handle to add click event listener
   */
  addVideoControlHandler(userId) {
    const controlWrapper = document.getElementById(userId);
    if (controlWrapper !== null) {
      const audioIcon = controlWrapper.querySelector('.audio-icon');
      const videoIcon = controlWrapper.querySelector('.video-icon');
      const makePresenterIcon = controlWrapper.querySelector('.make-presenter');
      controlWrapper.addEventListener('click', (evt) => {
        // evt.stopPropagation();
      });
      audioIcon.addEventListener('click', this.onVolumeIconClick.bind(this));
      videoIcon.addEventListener('click', this.onVideoIconClick.bind(this));
      makePresenterIcon.addEventListener('click', this.onMakePresenterIconClicked.bind(this));
    }
  }

  /**
   * @description The below function will handle to get particular attribute value
   *              from an element which triggered click event
   */
  getTargetUserId(evt: any, attrName: string): string {
    if (evt === undefined) {
      return null;
    }

    if (evt !== undefined && evt.target.attributes.getNamedItem(attrName) !== null) {
      return evt.target.attributes.getNamedItem(attrName).value;
    }
    return null;
  }


  /**
   * SCREEN SHARE CODE START HERE
  */
  onStartScreenShare() {
    if (this.screenSharePermissionDenied === true) {
      alert('It seems browser denied the screen share permision. Please allow and retry!');
      return;
    }
    this.isScreenShareInited = true;
    //this.showScreenShareIndicator = true;
    // this.screenShareIndicatorHandler(true);
    this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
  }

  /**
   * @description This method will handle to stop the screen share.
   */
  onStopScreenShare(eventMsg: any) {
    if (this.mediaAccessStatus !== undefined && this.mediaAccessStatus !== 'allowed') {
      switch (this.mediaAccessStatus) {
        case 'init':
          alert('Please close device access permission window!');
          // this.mediaAccessStatus = '';
          break;
        case 'denied':
          if (eventMsg !== undefined && eventMsg !== 'fromChild') { }
          alert('Oops! Your screen share permision is denied. Please allow the permission and refresh the page.');
          this.isScreenShareInited = false;
          this._isUserStopScreenShared = true;
          this.mediaAccessStatus = '';
          break;
      }
    }
    this.isScreenShareInited = false;
    this._isUserStopScreenShared = true;
    this.screenShareIndicatorHandler(false);
  }

  screenShareIndicatorHandler(screenShareIndicator: boolean) {
    this.showScreenShareIndicator = screenShareIndicator;
    if (screenShareIndicator === false) {
      clearInterval(this.screenShareIndicatorInterval);
      clearTimeout(this.screenShareIndicatorTimeout);
      return;
    }

    this.screenShareIndicatorInterval = setInterval(() => {
      this.showScreenShareIndicator = true;
      this.screenShareIndicatorTimeout = setTimeout(() => {
        this.showScreenShareIndicator = false;
      }, 2000);
    }, 3000);
  }

  userMediaAccessStatus(eventMsg: any) {
    this.mediaAccessStatus = eventMsg;
  }


  /**
   * SCREEN SHARE CODE END HERE
  */


  updatePresenterIconIndicator(participantId: string, pstrState: boolean) {
    this._confPageService.updatePresenterIconIndicatorObs(participantId, pstrState);
  }

  /**
   * @description Execute when user click on Mute/Unmute Icon
   */
  onVolumeIconClick(evt: Event) {
    const targetUser = this.getTargetUserId(evt, 'data-user-id');
    if (targetUser === null) {
      return;
    }
    if (targetUser !== this.userId && this.isMeetingOwner === 0) {
      return alert('You are not authorised!');
    }
    const muteState = this.getCurrentControlState(targetUser, this.participantList, 'share_audio');
    this.toggleAudio(targetUser, !muteState, true);
    evt.stopPropagation();
  }

  /**
   * @description Execute when user click on Play/Pause video
   */
  onVideoIconClick(evt: Event) {
    const targetUser = this.getTargetUserId(evt, 'data-user-id');
    if (targetUser === null) {
      return;
    }
    if (targetUser !== this.userId && this.isMeetingOwner === 0) {
      return alert('You are not authorised!');
    }
    const pausedState = this.getCurrentControlState(targetUser, this.participantList, 'share_video');
    this.toggleVideo(targetUser, !pausedState);
    evt.stopPropagation();
  }

  getCurrentControlState(userId: string, participantList: any, stateFor: string) {
    const participant = participantList.filter((participant, key) => {
      return participant.userId === userId;
    });
    return participant[0][stateFor];
  }

  toggleParticipantAudio(userId: string, muteAudio: boolean): void {
    if (userId !== this.userId && this.isMeetingOwner === 0) {
      return alert('You are not authorised to pause audio');
    }
    this.toggleAudio(userId, muteAudio, true)
  }

  toggleParticipantVideo(userId: string, pauseVideo: boolean): void {
    if (userId !== this.userId && this.isMeetingOwner === 0) {
      return alert('You are not authorised to pause video');
    }
    this.toggleVideo(userId, pauseVideo);
  }

  /**
   * @description Mute/unmute audio as per target element
   * @param userId
   */
  toggleAudio(userId: string, muteAudio: boolean, notifyServer: boolean): void {
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }
    const userInfo = this._confPageService.getUserInfo(userId);
    this._confPageService.updateUserInfo(userId, userInfo, 'isAudioShare', muteAudio);
    const audioLevelPayload = {
      req: 'voiceLvl',
      senderId: this.userId,
      voiceLevel: muteAudio === true ? 0 : -1
    };
    this.sendRquestToSocket(audioLevelPayload, this._webSocket);
    if (userId === this.userId) {
      this.stopVoiceLevelAPI = !muteAudio;
    }
    if (notifyServer) {
      clearTimeout(this.muteUnmuteTimeoutId);
      this.muteUnmuteTimeoutId = setTimeout(() => {
        const muteSingleParticipantPayLoad = {
          'req': 'muteAudioUser',
          'userId': userId,
          'share_aud': muteAudio
        };
        this.sendRquestToSocket(muteSingleParticipantPayLoad, this._webSocket);
      }, 500);
    }
  }

  /**
   * Mute umute the participan
   * @param participant
   */
  participantAudioAction(participant, userId, isAudShare: any): void {
    let curPageInfo = this.curPageInfo;
    let totalParticipantCount = this.participantList.length;
    if (participant !== undefined && participant.rtcPeer !== undefined && userId === this.userId) {
      this.isAudShare = isAudShare
      const default_audio = isAudShare === true ? 1 : 0;
      this._joinMeetingService.updateMeetingConfig('default_audio', default_audio);
      participant.rtcPeer.audioEnabled = isAudShare;
      this.updateParticipantList(userId, 'share_audio', isAudShare);
      this.toggleVideoControl(userId, isAudShare, 'audio');
      this.toggleAudio(userId, isAudShare, false);
    } else {
      clearTimeout(this.delayFetchActiveParticipantTimeoutId);
      this.delayFetchActiveParticipantTimeoutId = setTimeout(() => {            
        this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, false);    
      }, 1000);
      this.updateParticipantList(userId, 'share_audio', isAudShare);
      this.toggleVideoControl(userId, isAudShare, 'audio');
    }
  }

  /**
   * @description Play/Pause video as per target element
   * @param userId
   */
  toggleVideo(userId: string, pausedVideo: boolean): void {
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }
    const userInfo = this._confPageService.getUserInfo(userId);
    this._confPageService.updateUserInfo(userId, userInfo, 'isVideoShare', pausedVideo);
    if (userId === this.userId) {
      this._confPageService.isVideoPaused = !pausedVideo;
    }

    const muteSingleParticipantPayLoad = {
      'req': 'muteVideoUser',
      'userId': userId,
      'share_vid': pausedVideo
    };

    this.sendRquestToSocket(muteSingleParticipantPayLoad, this._webSocket);
  }

  /**
   * video on/off of the participant
   * @param participant
   */
  participantVideoAction(participant: any, userId: string, isVidShare: any): void {
    if (participant !== undefined && participant.rtcPeer !== undefined && userId === this.userId) {
      this.isVidShare = isVidShare;
      const default_video = isVidShare === true ? 1 : 0;
      this._joinMeetingService.updateMeetingConfig('default_video', default_video);
      participant.rtcPeer.videoEnabled = isVidShare;
      this.updateParticipantList(userId, 'share_video', isVidShare);
      this.toggleVideoControl(userId, isVidShare, 'video');
      //this.toggleVideo(userId, isVidShare);
    } else {
      this.updateParticipantList(userId, 'share_video', isVidShare);
      this.toggleVideoControl(userId, isVidShare, 'video');
    }
  }


  updateParticipantList(userId: string, keyName: string, keyValue: string): void {
    let test = [];
    this.participantList.map(
      (val, key) => {
        if (val.userId === userId) {
          if (keyName === 'share_audio') {
            val.share_audio = keyValue;
          } else if (keyName === 'share_video') {
            val.share_video = keyValue;
          }
        }
      }
    );
  }

  muteAll(muteStatus: boolean): void {
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }
    const muteAllParticipantAudioPayLoad = {
      'req': 'muteAudioAll',
      'share_aud': muteStatus
    };
    this.isMuteAll = !muteStatus;
    this.sendRquestToSocket(muteAllParticipantAudioPayLoad, this._webSocket);
  }

  pauseAll(pausedStatus: boolean): void {
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }
    const pauseAllParticipantVideoPayLoad = {
      'req': 'muteVideoAll',
      'share_vid': pausedStatus
    };
    this.isPauseAll = !pausedStatus;
    this.sendRquestToSocket(pauseAllParticipantVideoPayLoad, this._webSocket);
  }


  toggleMuteAll(mtueState: boolean, ownerId: string): void {
    const participantsKeys = Object.keys(this.participants);
    participantsKeys.map((userId, key) => {
      if (ownerId === userId || (this.isMeetingOwner === 1 && ownerId === userId)) {
        return;
      }
      if (this.participants[userId] !== undefined) {
        // this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, false);
        this.participantAudioAction(this.participants[userId], userId, mtueState);
        // if(this.participants[val].pstr !== true) {
        //   this.participantAudioAction(this.participants[val], val, muteStatus)
        // }
      }
    });
  }

  tooglePauseAll(pausedState: boolean, ownerId: string): void {
    const participantsKeys = Object.keys(this.participants);
    participantsKeys.map((userId, key) => {
      if (ownerId === userId || (this.isMeetingOwner === 1 && ownerId === userId)) {
        return;
      }
      if (this.participants[userId] !== undefined) {
        this.participantVideoAction(this.participants[userId], userId, pausedState)
      }
    });
  }
  /**
   * @description The below function will handle to add/remove class to change the video/audio icon
   * @param userId
   * @param toggleState
   * @param toggleFor
   */
  toggleVideoControl(userId: string, iconState: boolean, iconUpdateFor: string): void {
    const userInfo: UserInfo = this._confPageService.getUserInfo(userId);
    if (iconUpdateFor !== undefined) {
      switch (iconUpdateFor) {
        case 'audio':
          this._confPageService.updateAudioIconObs(userId, iconState);
          this._confPageService.updateUserInfo(userId, userInfo, 'isAudioShare', iconState);
          break;
        case 'video':
          this._confPageService.updateVideoIconObs(userId, iconState);
          this._confPageService.updateUserInfo(userId, userInfo, 'isVideoShare', iconState);
          break;
      }
    }
  }

  /**
   * @description The below function wiill handle to add all the video control
   */
  addVideoControl(userId: string): void {
    const videoWrapper = document.getElementById(userId);
    if (videoWrapper !== null) {
      const pstrIndicatorBtn = this._domHandler.createElement({
        nodeType: 'a',
        classArr: ['pstr-icon'],
        attrs: [{ attrName: 'href', attrVal: 'javascript:void(0);' }]
      }, videoWrapper);

      const pstrIndicatorIcon = this._domHandler.createElement({
        nodeType: 'i',
        classArr: [''],
        attrs: []
      }, pstrIndicatorBtn);

      const controlWrapper = this._domHandler.createElement(
        {
          nodeType: 'div',
          classArr: ['control_wrapper_' + userId, 'video-control', 'active-user'],
          attrs: [
            { attrName: 'aria-hidden', attrVal: 'true' },
            { attrName: 'data-user-id', attrVal: userId }
          ]
        }, videoWrapper
      );

      const audioIcon = this._domHandler.createElement({
        nodeType: 'div',
        classArr: ['audio-icon', 'unmute'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, controlWrapper);

      const videoIcon = this._domHandler.createElement({
        nodeType: 'div',
        classArr: ['video-icon', 'play'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, controlWrapper);

      const muteIcon = this._domHandler.createElement({
        nodeType: 'span',
        classArr: ['mute'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ],
      }, audioIcon);

      const unMuteIcon = this._domHandler.createElement({
        nodeType: 'span',
        classArr: ['unmute'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, audioIcon);

      const pauseVideo = this._domHandler.createElement({
        nodeType: 'span',
        classArr: ['pause'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, videoIcon);

      const playVideo = this._domHandler.createElement({
        nodeType: 'span',
        classArr: ['play'],
        attrs: [
          { attrName: 'aria-hidden', attrVal: 'true' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, videoIcon);
    }
  }

  addVideoControlDropDown(userId: string): void {
    const videoWrapper = document.getElementById(userId);
    if (videoWrapper !== null) {
      const dropDownWrapper = this._domHandler.createElement(
        {
          nodeType: 'div',
          classArr: ['dropdown', 'make-presenter-dot'],
          attrs: []
        }, videoWrapper
      );

      const dropDownButton = this._domHandler.createElement({
        nodeType: 'button',
        classArr: ['btn', 'dropdown-toggle'],
        attrs: [
          { attrName: 'type', attrVal: 'button' },
          { attrName: 'id', attrVal: userId },
          { attrName: 'data-toggle', attrVal: 'dropdown' },
          { attrName: 'aria-haspopup', attrVal: 'true' },
          { attrName: 'aria-expanded', attrVal: 'false' },
        ]
      }, dropDownWrapper);

      const dropDownMenu = this._domHandler.createElement({
        nodeType: 'div',
        classArr: ['dropdown-menu', 'dropdown-menu-right'],
        attrs: [
          { attrName: 'aria-labelledby', attrVal: userId },
        ]
      }, dropDownWrapper);

      const menuItem3 = this._domHandler.createElement({
        nodeType: 'button',
        classArr: ['dropdown-list-item', 'btn', 'make-presenter'],
        attrs: [
          { attrName: 'aria-labelledby', attrVal: 'dropdownMenu2' },
          { attrName: 'data-user-id', attrVal: userId }
        ]
      }, dropDownMenu);

      menuItem3.appendChild(document.createTextNode('Make Presenter'));
    }
  }

  public hideRightPanel() {
    if (this.hidePanel === true) {
      this.hidePanel = false;
    } else {
      this.hidePanel = true;
    }
  }

  onMediaQualityChange(videoConstraint: any): void {
    window.isResendOfferInProgress = true;
    const thisPointer = this;
    if (thisPointer.userId === thisPointer.currentActiveUserId) {
      const loaderIcon = document.querySelector('.screen-share-loader');
      if (loaderIcon !== null) {
        loaderIcon.classList.remove('d-none');
      }
      thisPointer.showMainVideoLoader = true;
    }
    // window.localStream.getTracks().forEach(track => {
    //   track.stop();
    // });
    let audioMuteStatus = this._joinMeetingService.getMeetingConfig('default_audio');
    let videoStopStatus = this._joinMeetingService.getMeetingConfig('default_video');
    // let audioConstraint = this._utilService.getInfoFromStorage('local', 'audioConfig');

    // audioConstraint = audioConstraint !== null ? audioConstraint : { echoCancellation: { exact: true }, noiseSuppression: { exact: true }, autoGainControl: { exact: true } };

    // let constraints = {
    //   audio: audioConstraint,
    //   video: videoConstraint
    // };    
    let audioStream = this._deviceSettingService.getStoredStream('audio');
    let videoStream = this._deviceSettingService.getStoredStream('video');

    const options = {
      localVideo: this.localVideoElement,
      audioStream: audioStream,
      videoStream: videoStream,
      // mediaConstraints: constraints,
      onicecandidate: this.participant.onIceCandidate.bind(this.participant),
      browserType: this._browserInfo.name,
      turnsConfig: this._turnsConfig,
      H264Codec: this._utilService.getEnvironmentValue('H264_ALL_PEER') //environment['H264_ALL_PEER']
    };

    // if (this.localVideoElement.srcObject !== null) {
    //   this.localVideoElement.srcObject.getTracks().forEach(track => track.stop());
    // }

    if (thisPointer.currentActiveUserId === thisPointer.userId) {
      thisPointer.resetVideoSrcObject('full-video');
    }
    // thisPointer.resetVideoSrcObject('video-' + thisPointer.currentActiveUserId);

    thisPointer.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(
      options,
      function (error) {
        thisPointer.isVideoStreamStart();
        thisPointer._confPageService.resetMostActiveUser = true;
        thisPointer.audioLevelSender(thisPointer._soundMeter, window.localStream);
        if (error) {
          thisPointer.isVideoStreamAvailable = false;
          thisPointer.notifyNoVideoStream(thisPointer.userId);
          if (thisPointer.currentBandWidth >= 512) {
            thisPointer.userSelectedBandWidth = 512;
            thisPointer.onUpdateBandwidth(384, false)
          } else if (thisPointer.currentBandWidth >= 384) {
            thisPointer.userSelectedBandWidth = 384;
            thisPointer.onUpdateBandwidth(256, false);
          }
          // else if (thisPointer.currentBandWidth >= 256) {
          //   thisPointer.userSelectedBandWidth = 256;
          //   thisPointer.onUpdateBandwidth(128, false);
          // }
          return console.log(error);
        }
        thisPointer.localVideoElement.muted = true;
        if (thisPointer.currentActiveUserId === thisPointer.userId) {
          thisPointer._confPageService.notifyMostActiveUser(thisPointer.currentActiveUserId, 'null', thisPointer.layoutType);
        }

        // if user already muted before change resolution then make
        if (audioMuteStatus === 0) {
          thisPointer.participant.rtcPeer.audioEnabled = false;
        }
        if (videoStopStatus === 0) {
          thisPointer.participant.rtcPeer.videoEnabled = false;
        }
        thisPointer.participant.rtcPeer.generateOffer(thisPointer.participant.offerToChangeQualityVideo.bind(thisPointer.participant));
      }
    );
  }

  onMediaQualityChangeOld(videoConstraint: any): void {
    window.isResendOfferInProgress = true;
    const thisPointer = this;
    if (thisPointer.userId === thisPointer.currentActiveUserId) {
      const loaderIcon = document.querySelector('.screen-share-loader');
      if (loaderIcon !== null) {
        loaderIcon.classList.remove('d-none');
      }
      thisPointer.showMainVideoLoader = true;
    }
    window.localStream.getTracks().forEach(track => {
      track.stop();
    });
    let audioMuteStatus = this._joinMeetingService.getMeetingConfig('default_audio');
    let videoStopStatus = this._joinMeetingService.getMeetingConfig('default_video');
    let audioConstraint = this._utilService.getInfoFromStorage('local', 'audioConfig');
    audioConstraint = audioConstraint !== null ? audioConstraint : { echoCancellation: { exact: true }, noiseSuppression: { exact: true }, autoGainControl: { exact: true } };

    let constraints = {
      audio: audioConstraint,
      video: videoConstraint
    };

    // if (this._browserInfo.name.toLowerCase() === 'chrome') {
    //   constraints.audio = {};
    //   constraints.audio = this.advaceAudioConfig;
    // }

    if (this.isOverConstraints) {
      constraints.audio = audioConstraint;
      constraints.video = true;
    }
    if (this.audioDeviceId !== undefined && this.audioDeviceId !== null) {
      if (constraints.audio["deviceId"] === undefined) {
        constraints.audio["deviceId"] = {};
      }
      constraints.audio["deviceId"] = { exact: this.audioDeviceId };

      // audioConstraint.deviceId = this.audioDeviceId;
    }

    if (this.videoDeviceId !== undefined && this.videoDeviceId !== null) {
      if (constraints.video["deviceId"] === undefined) {
        constraints.video["deviceId"] = {};
      }
      constraints.video["deviceId"] = { exact: this.videoDeviceId };
      // audioConstraint.deviceId = this.audioDeviceId;
    }

    const options = {
      localVideo: this.localVideoElement,
      mediaConstraints: constraints,
      onicecandidate: this.participant.onIceCandidate.bind(this.participant),
      browserType: this._browserInfo.name,
      turnsConfig: this._turnsConfig,
      H264Codec: this._utilService.getEnvironmentValue('H264_ALL_PEER') //environment['H264_ALL_PEER']
    };

    if (this.localVideoElement.srcObject !== null) {
      this.localVideoElement.srcObject.getTracks().forEach(track => track.stop());
    }

    if (thisPointer.currentActiveUserId === thisPointer.userId) {
      thisPointer.resetVideoSrcObject('full-video');
    }
    // thisPointer.resetVideoSrcObject('video-' + thisPointer.currentActiveUserId);

    thisPointer.participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendrecv(
      options,
      function (error) {
        thisPointer.isVideoStreamStart();
        thisPointer._confPageService.resetMostActiveUser = true;
        thisPointer.audioLevelSender(thisPointer._soundMeter, window.localStream);
        if (error) {
          thisPointer.isVideoStreamAvailable = false;
          thisPointer.notifyNoVideoStream(thisPointer.userId);
          if (thisPointer.currentBandWidth >= 512) {
            thisPointer.userSelectedBandWidth = 512;
            thisPointer.onUpdateBandwidth(384, false)
          } else if (thisPointer.currentBandWidth >= 384) {
            thisPointer.userSelectedBandWidth = 384;
            thisPointer.onUpdateBandwidth(256, false);
          }
          // else if (thisPointer.currentBandWidth >= 256) {
          //   thisPointer.userSelectedBandWidth = 256;
          //   thisPointer.onUpdateBandwidth(128, false);
          // }
          return console.log(error);
        }
        thisPointer.localVideoElement.muted = true;
        if (thisPointer.currentActiveUserId === thisPointer.userId) {
          thisPointer._confPageService.notifyMostActiveUser(thisPointer.currentActiveUserId, 'null', thisPointer.layoutType);
        }

        // if user already muted before change resolution then make
        if (audioMuteStatus === 0) {
          thisPointer.participant.rtcPeer.audioEnabled = false;
        }
        if (videoStopStatus === 0) {
          thisPointer.participant.rtcPeer.videoEnabled = false;
        }
        thisPointer.participant.rtcPeer.generateOffer(thisPointer.participant.offerToChangeQualityVideo.bind(thisPointer.participant));
      }
    );
  }

  /**
    As a meeting owner I can leave the meeting for all participants
   */
  leaveMeetingForAll(): void {
    if (this._webSocket !== undefined && this._webSocket !== null && this._webSocket.readyState > 1) {
      this._webSocket = this._socketService.getSocketInstance();
    }
    const leaveMeetingForAllPayLoad = {
      'req': 'endMeeting'
    };
    this.sendRquestToSocket(leaveMeetingForAllPayLoad, this._webSocket);
  }

  /*
  * When window resize the carousel vertical height calculate
  */
  onResize(evt: Event): void {
    clearTimeout(this.resizeEventTimeoutId);
    this.resizeEventTimeoutId = setTimeout(() => {
      this.setSideHeaderHeight();
      this.layoutType = this._confPageService.getLayoutType();
      if (this.layoutType === this.layoutTypeENUMS[1]) {
        this.thumbnailCount = this._confPageService.getThumbnailCount(this.layoutType);
        this.updateObject(this.pagingInfo, "curPageSizeCount", this.thumbnailCount);
      }

      if (this.pagingInfo.curPageNo !== undefined) {
        this.fetchActiveParticipantsList(1, this.pagingInfo.curPageSizeCount, true);
      }
      this.setHeightVideoScreen();
    }, 100);
  }


  resetVideoSrcObject(selectorId: string): void {
    this.videoPreviewElement = document.getElementById(selectorId);
    this.videoPreviewElement.srcObject = null;
  }

  setHeightVideoScreen(): void {
    if (document.getElementById('video-preview-wrapper') === null) {
      return;
    }
    const headerElem: any = document.querySelector('.conference-header');
    let headerHeight = headerElem.offsetHeight;
    this.windowHeight = window.innerHeight - 92;
    document.getElementById('video-preview-wrapper').style.height = this.windowHeight + 'px';
    document.getElementById('swiper-container').style.height = this.windowHeight + 'px';
  }

  calcRequireBirateToSet(totalParticipant) {
    let resultBitRate = 256;
    let averageBytesSentCheckValue = environment['AVERAGE_BYTES_SENT_CHECK'];
    if (totalParticipant !== undefined) {
      if (totalParticipant <= 2) {
        resultBitRate = 512;
      } else if (totalParticipant > 2 && totalParticipant <= 4) {
        resultBitRate = 256;
      } else if (totalParticipant > 4 && totalParticipant <= 8) {
        resultBitRate = 128;
      } else if (totalParticipant > 8) {
        resultBitRate = 64;
        averageBytesSentCheckValue = 45;
      }
    }
    this._confPageService.notifyAverageBytesSendRangeObs(averageBytesSentCheckValue);
    return resultBitRate;
  }

  updateBitrate(bandwidth: any): void {
    this._confPageService.initLocalPeerStatsObs(this.participant);
    if (this.configureLayout === 2 && this.isAdaptiveLayoutEnabled === true) {
      //check if the default layout set at the time meeting schedule is grid
      let totalParticipant = this.participantList.length;
      bandwidth = this.calcRequireBirateToSet(totalParticipant);
      // if (this.userSelectedBandWidth === bandwidth && this.userSelectedBandWidth !== 128) {
      //   // no action require if need to update the same bandwidth
      //   return;
      // }
    } else {
      this._confPageService.notifyBitrateChangeObs(bandwidth, this.layoutType);
    }

    // if (this.userSelectedBandWidth !== undefined && bandwidth < this.userSelectedBandWidth) {
    //   bandwidth = this.userSelectedBandWidth;
    //   this.userSelectedBandWidth = 0;
    //   this.currentBandWidth = bandwidth;
    // }
    // bandwidth = 256;
    //bandwidth = bandwidth - 30;
    if ('RTCRtpSender' in window) {
      const pc1 = this.participant.rtcPeer;
      const videoSender = pc1.getSenders()[1];
      pc1.getSenders().forEach(sender => {
        if (sender.track !== undefined) {
          if (sender.getParameters !== undefined) {
            const parameters = sender.getParameters();
            if (sender.track.kind === 'video') {
              if (!parameters.encodings) {
                parameters.encodings = [{}];
              }
              if (bandwidth === 'Unlimited') {
                delete parameters.encodings[0].maxBitrate;
              } else {
                if (bandwidth !== 64) {
                  parameters.encodings[0].maxBitrate = (bandwidth - 15) * 1000;
                } else {
                  parameters.encodings[0].maxBitrate = bandwidth * 1000;
                }

              }
              if (sender.setParameters !== undefined) {
                sender.setParameters(parameters)
                  .then(() => {
                    clearInterval(this.statsInterval);
                    this._confPageService.initLocalPeerStatsObs(this.participant);
                    // this._confPageService.notifyBitrateChangeObs(bandwidth, this.layoutType);
                    // this.getSenderStats(this.participant);
                  })
                  .catch(e => console.error(e));
              } else {
                console.log("sender ", sender);
              }

              return;
            }
            if (sender.track.kind === 'audio') {
              if (!parameters.encodings) {
                parameters.encodings = [{}];
              }
              if (bandwidth === 'Unlimited') {
                delete parameters.encodings[0].maxBitrate;
              } else {
                parameters.encodings[0].maxBitrate = 25 * 1000;
              }
              if (sender.setParameters !== undefined) {
                sender.setParameters(parameters)
                  .then(() => {
                    clearInterval(this.statsInterval);
                    this._confPageService.initLocalPeerStatsObs(this.participant);
                    //this.getSenderStats(this.participant);
                  })
                  .catch(e => console.error(e));
              } else {
                console.log("sender ", sender);
              }

              return;
            }
          } else {
            this._confPageService.initLocalPeerStatsObs(this.participant);
            this._confPageService.notifyBitrateChangeObs(bandwidth, this.layoutType);
          }

        } else {
          this._confPageService.initLocalPeerStatsObs(this.participant);
          this._confPageService.notifyBitrateChangeObs(bandwidth, this.layoutType);
        }
      });
    }
  }

  onUpdateBandwidth(bandwidth: any, forceToLoad: boolean) {
    if (bandwidth === this.currentBandWidth && forceToLoad === false) {
      return;
    }
    this.currentBandWidth = bandwidth;
    let videoConstraint = this.getVideoConstraint(bandwidth, this.configureLayout, this.isAdaptiveLayoutEnabled);
    if (bandwidth >= 512) {
      videoConstraint = { width: { max: 1280, min: 500 }, height: { max: 720, min: 400 } }
    }
    // if (this.videoDeviceId !== undefined) {
    //   videoConstraint.deviceId = this.videoDeviceId;
    // }
    // this.onMediaQualityChange(videoConstraint);
    console.log('videoConstraint ', videoConstraint);
    this.changeVideoResolution(videoConstraint)
  }

  changeVideoResolution(videoConstraint: any): void {
    this.isAudioDeviceAccess = false;
    this.isVideoDeviceAccess = false;
    this.requestToAccessMediaDevices(null, this._webSocket, 2, videoConstraint);
  }


  /**
   * @description The below function will handle to send the current audio level to server to notify
   *              the user is speaking or not.
   */
  audioLevelSender(soundMeterIntance: any, localVideoStream: any) {
    clearInterval(this._sendAudioLevelIntervalId);
    if (soundMeterIntance === undefined) {
      return this._logService.warn('Conference --> audioLevelSender --> no data found for sound meter');
    }
    let audioStream = this._deviceSettingService.getStoredStream('audio');
    soundMeterIntance.connectToSource(audioStream, (error: any) => {
      if (error) {
        return this._logService.warn('Conference --> audioLevelSender --> error --> ', error);
      }
      this._sendAudioLevelIntervalId = setInterval(() => {
        const curAudioLevel = soundMeterIntance.instant.toFixed(2);
        if (this.stopVoiceLevelAPI === false) {
          if (curAudioLevel != "0.00" || this._isPrevAudioLevelZero === false) {
            this._logService.debug('Conference --> audioLevelSender --> send audio level -->', curAudioLevel);
            const audioLevelPayload = {
              req: 'voiceLvl',
              senderId: this.userId,
              voiceLevel: curAudioLevel
            };
            this.sendRquestToSocket(audioLevelPayload, this._webSocket);
          } else {
            // this._logService.debug('Conference --> audioLevelSender --> dont send audio level -->', curAudioLevel);
          }

          if (curAudioLevel == "0.00") {
            this._isPrevAudioLevelZero = true;
          } else {
            this._isPrevAudioLevelZero = false;
          }
        }
      }, 1000);
    });
  }


  getVideoConstraint(bandwidth: any, layoutType: any, enableAdaptiveView: boolean): any {
    bandwidth = bandwidth.toString();
    let result = true;
    // if layout type is grid layout then return 640 * 460 (256)
    if (layoutType === 2 && enableAdaptiveView === true) {
      let resolutionFromStorage = this._utilService.getInfoFromStorage('session', '256Bitrate');
      if (resolutionFromStorage) {
        result = resolutionFromStorage;
      } else {
        result = this.videoConstraints['256_bitrate'];
      }
    } else {
      switch (bandwidth) {
        case '128':
          result = this.videoConstraints['128_bitrate'];
          break;
        case '256':
        case '384':
          result = this.videoConstraints['256_bitrate'];
          break;
        default:
          result = this.videoConstraints['512_bitrate'];
          break;
      }
    }
    return result;
  }

  /*
  * The below function work when hove on video screen
  */
  onMouseMove() {
    this.conferenceNavigation = true;
    if (this.mouseMoveTimeoutId) {
      clearTimeout(this.mouseMoveTimeoutId);
    }

    this.mouseMoveTimeoutId = setTimeout(() => {
      this.conferenceNavigation = false;
      clearTimeout(this.mouseMoveTimeoutId);
    }, 5000);

  }

  onMouseLeave() {
    this.conferenceNavigation = false;
  }


  updateObject(object: any, keyName: string, value: any) {
    if (object === undefined) {
      return;
    }
    object[keyName] = value;
  }

  /**
   * This method will handle to fetch active user per page
   */
  fetchActiveParticipantsList(pageNumber: number, layoutNumber: number, ignoreCountCheck: boolean) {
    if (
      pageNumber === undefined ||
      typeof (pageNumber) !== 'number' ||
      layoutNumber === undefined ||
      typeof layoutNumber !== 'number'
    ) {
      return;
    }
    this.layoutType = this._confPageService.getLayoutType();
    this.updateObject(this.pagingInfo, 'curPageNo', pageNumber);
    if (this._confPageService.isScreenShareStarted || this._confPageService.isWhiteBoardStarted || this.initWhiteBoard) {
      let windowHeight = window.innerHeight;
      let thumbnailCount = 4;
      thumbnailCount = windowHeight / 161;

      // from total of any thumbnail there is 5 more padding need to remove 77 + 40 (header + arrow icon height)
      thumbnailCount = (windowHeight - ((thumbnailCount - 1) * 5) - 117) / 161;
      layoutNumber = Math.floor(thumbnailCount);
    } else {
      if (this.layoutType === environment.LAYOUT_TYPE_ENUMS[2]) {
        if (this.isAdaptiveViewEnable === true) {
          let minGridView = this._utilService.getEnvironmentValue('MIN_GRID_VIEW');
          let maxGridView = this._utilService.getEnvironmentValue('MAX_GRID_VIEW');
          layoutNumber = this.totalParticipantCount <= minGridView ? minGridView : maxGridView;
        } else {
          layoutNumber = 4;
        }
      } else {
        let windowHeight = window.innerHeight;
        let thumbnailCount = 4;
        thumbnailCount = windowHeight / 161;

        // from total of any thumbnail there is 5 more padding need to remove 77 + 40 (header + arrow icon height)
        thumbnailCount = (windowHeight - ((thumbnailCount - 1) * 5) - 127) / 161;
        layoutNumber = Math.floor(thumbnailCount);
      }
    }


    this.updateObject(this.pagingInfo, 'curPageSizeCount', layoutNumber);
    this.totalPagingCount = Math.ceil(this.pagingInfo.curParticipantCount / this.pagingInfo.curPageSizeCount);
    pageNumber = pageNumber > 1 ? pageNumber : 1;
    layoutNumber = Math.floor(layoutNumber) >= 1 ? Math.floor(layoutNumber) : 4
    // // if total number of participant is less than the number of require participant
    // if (layoutNumber >= this.participantList.length && !ignoreCountCheck) {
    //   return;
    // }
    let isVdetRequire = this.checkVDetEligible(layoutNumber, pageNumber, this.participantList.length);
    if (isVdetRequire || ignoreCountCheck) {
      const vDetPayLoad = {
        req: "vDet",
        pNo: pageNumber,
        layout: layoutNumber
      };  
      this.sendRquestToSocket(vDetPayLoad, this._webSocket);      
    }    
  }

  checkVDetEligible(curMaxUserPerPage: number, curPageNumber: number, totalParticipantCount: number): boolean {
    let result = false; // curMaxUserPerPage && curPageNumber && 
    if (curPageNumber !== 0 && totalParticipantCount > 1) {
      if (curMaxUserPerPage * curPageNumber < totalParticipantCount) {
        result = true;
      } else {
        result = false;
      }
    }
    this._previousPageNumber = curPageNumber;
    return result;
  }
  /**
   *
   * @param audio path of the mp3 file
   * Please sound on join and leave conference
   */
  playSound(audio: string): void {
    var sound = new Howl({
      src: [audio]
    });

    sound.play();
  }

  removePlaceHolderElems(): void {
    const firstPlaceHolder: any = document.getElementById("place-holder-1");
    const secondPlaceHolder: any = document.getElementById("place-holder-2");
    const body: any = document.body;
    if (firstPlaceHolder !== null && secondPlaceHolder !== null) {
      firstPlaceHolder.parentNode.removeChild(firstPlaceHolder);
      secondPlaceHolder.parentNode.removeChild(secondPlaceHolder);
    }
  }

  /**
   * WHITE BOARD CODE START HERE
   */

  startWhiteBoard(): void {
    this.showMainVideoLoader = true;
    this.initWhiteBoard = true;
    let thisPointer = this;
    this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
    setTimeout(() => {
      const whiteBoardIframe: any = document.getElementById("white-board-iframe");
      const videoWrapper: any = document.getElementById("video-preview-wrapper");
      const iframeLoader: any = document.querySelector(".iframe-loader");
      const randomCode: any = Math.random().toString().split(".")[1];
      if (whiteBoardIframe !== null && videoWrapper !== null) {
        whiteBoardIframe.classList.remove('d-none');
        const frameHeight = videoWrapper.offsetHeight;
        const frameWidth = videoWrapper.offsetWidth;
        const iframeUrl = this._utilService.getEnvironmentValue('WHITEBOARD_IFRAME_URL');  //environment.WHITEBOARD_IFRAME_URL;
        const uniqueId = randomCode + this.userId;
        whiteBoardIframe.style.width = 960 + "px";
        whiteBoardIframe.style.height = 630 + "px";
        whiteBoardIframe.src = iframeUrl + "?userName=" + this._userName + "&presenter=true&roomId=" + uniqueId + "#" + uniqueId;
        whiteBoardIframe.onload = function () {
          // console.log('iframe has been loaded you can send data');
          const whiteBoardPlayLoad = {
            "req": "shareWhiteBoard",
            "userId": thisPointer.userId,
            "share_wboard": true,
            "white_board_data": {
              "url": iframeUrl + "?roomId=" + uniqueId + "#" + uniqueId,
              "width": 960, //frameWidth,
              "height": 630 //frameHeight
            }
          }
          thisPointer.sendRquestToSocket(whiteBoardPlayLoad, thisPointer._webSocket);
          if (iframeLoader !== null) {
            iframeLoader.classList.remove('d-none');
          }
          thisPointer.showMainVideoLoader = false;
        }
        // setTimeout(() => {

        // }, 3000)
      }
    }, 1000)

  }

  stopWhiteBoard(): void {
    this.initWhiteBoard = false;
    this.shareScreenStreamStarted = false;
    this._confPageService.isWhiteBoardStarted = false;
    const whiteBoardPlayLoad = {
      "req": "shareWhiteBoard",
      "userId": this.userId,
      "share_wboard": false,
      "white_board_data": {
        "url": environment.WHITEBOARD_IFRAME_URL + "#" + this.userId,
        "width": 600,
        "height": 500
      }
    }
    this.layoutType = this._confPageService.getLayoutType();
    this.sendRquestToSocket(whiteBoardPlayLoad, this._webSocket);
    this.fetchActiveParticipantsList(this.pagingInfo.curPageNo, this.thumbnailCount, true);
  }

  onStartWhiteBoard(whiteBoardShareState: any, whiteBoardData: any): void {
    if (whiteBoardShareState === "true" || whiteBoardShareState === true) {
      setTimeout(() => {
        const whiteBoardIframe: any = document.getElementById("white-board-iframe");
        const videoWrapper: any = document.getElementById("video-preview-wrapper");
        const iframeLoader: any = document.querySelector(".iframe-loader");
        // const randomCode: any = Math.random().toString().split(".")[1];
        if (whiteBoardIframe !== null && videoWrapper !== null) {
          whiteBoardIframe.classList.remove('d-none');
          // const frameHeight = videoWrapper.offsetHeight;
          // const frameWidth = videoWrapper.offsetWidth;
          let url = whiteBoardData.url.split("#");
          const iframeUrl = url[0] + "&userName=" + this._userName + "#" + url[1];
          whiteBoardIframe.style.width = 960 + "px"; // whiteBoardData.width + "px";
          whiteBoardIframe.style.height = 630 + "px"; // whiteBoardData.height + "px";
          whiteBoardIframe.src = iframeUrl;
        }
        this.showMainVideoLoader = false;
      }, 1500)
    }
  }
  /**
  * WHITE BOARD CODE END HERE
  */


  initForcedforcedDisconnectUser(userId: string): void {
    this.selectedUserIdToDisconnect = userId;
  }

  confirmForcedforcedDisconnectUser(userId: string) {
    if (userId) {
      const forceDisconnectPayload = {
        req: 'forced_disconnect',
        userId: userId
      };
      this.sendRquestToSocket(forceDisconnectPayload, this._webSocket);
    }
    this.selectedUserIdToDisconnect = null;
  }

  consoleInfo(callAt: string, msge: string, logType: string) {
    if (logType === undefined) {
      console.log(callAt + ': ' + msge);
    }
    const concatString = '<-----CONSOLE INFO------> ' + callAt + ' <-------------------- : ------------------> ' + msge;
    switch (logType) {
      case 'debug':
        console.debug(concatString);
        break;
      case 'info':
        console.info(concatString);
        break
      default:
        console.log(concatString);
        break;
    }
  }

  copyPath(elem: any) {
    elem.select();
    document.execCommand('copy');
  }

  setToolTipOptions(layoutType) {
    if (layoutType === 'GRID_VIEW') {
      $('[data-toggle="tooltip"]').attr('data-placement', 'right');
    } else {
      $('[data-toggle="tooltip"]').attr('data-placement', 'top');
    }
    $('[data-toggle="tooltip"]').tooltip({
      container: 'body'
    });
  }

  onFocus(evt) {
    this.isWindowActive = true;
  }

  onBlur(evt) {
    this.isWindowActive = false;
  }

  showPollModal() {
    $('#createPollModal').modal('show');
    this.hideRightPanel();
  }
  showPollModalOnMobile() {
    $('#createPollModal').modal('show');
    $('#hostSettingModal').modal('hide');
  }


  /**
   * @description The below function wil handle to show device list modal 
   */
  openDeviceSettings(): void {
    this.initDeviceSettingModalComponent = true;
    this._isDeviceSettingModalOpen = true;
  }

  /**
   * @description The below function will handle when device settings modal close 
   */
  onDeviceSettingModalClose(data): void {
    this._isDeviceSettingModalOpen = false;
    if (!data) {
      setTimeout(() => {
        this.initDeviceSettingModalComponent = false;
        this._deviceSettingService.resetDeviceSettingChangeStatus();
      }, 500);
      return;
    }
    let isAudioMediaChange = this._deviceSettingService.isDeviceSettingChange('audio');
    let isVideoMediaChange = this._deviceSettingService.isDeviceSettingChange('video');
    let isAudioOutputChange = this._deviceSettingService.isDeviceSettingChange('output');

    if (isAudioMediaChange || isVideoMediaChange) {
      let tempAudioStream;
      let tempVideoStream;
      if (isAudioMediaChange) {
        tempAudioStream = this._deviceSettingService.getTempMediaStream('audio');
        this._deviceSettingService.stopAudioStream();
        this._deviceSettingService.storeStreamTrack(tempAudioStream, 'audio');
        //this._deviceSettingService.stopTempStream('aduio');
      }

      if (isVideoMediaChange) {
        tempVideoStream = this._deviceSettingService.getTempMediaStream('video');
        this._deviceSettingService.stopVideoStream();
        this._deviceSettingService.storeStreamTrack(tempVideoStream, 'video');
        //this._deviceSettingService.stopTempStream('video');
      }
      this.onMediaQualityChange(null);
    }

    if (isAudioOutputChange && this.participantList.length > 1) {
      this.resetAudioOutputDeviceForAllRemote(this.participantList);
    }
    setTimeout(() => {
      this.initDeviceSettingModalComponent = false;
      this._deviceSettingService.resetDeviceSettingChangeStatus();
    }, 500);

  }

  resetAudioOutputDeviceForAllRemote(remoteParticipantList) {
    setTimeout(() => {
      if (remoteParticipantList.length >= 1) {
        remoteParticipantList.map((remoteUser, key) => {
          console.log('remoteUser')
          if (remoteUser.userId !== this.userId) {
            let remoteUserVideoElem = document.getElementById("video-" + remoteUser.userId);
            let outputDeviceId = this._deviceSettingService.getSelectedDeviceId('output');
            if (remoteUserVideoElem !== null) {
              this._deviceSettingService.attachSinkId(outputDeviceId, remoteUserVideoElem);
            }
          }
        })
      }
    }, 1000);

  }


  gotDevices(deviceInfos) {
    //const videoElement = document.querySelector('video');
    const audioInputSelect = <HTMLInputElement>document.querySelector('select#audioSource');
    const audioOutputSelect = <HTMLInputElement>document.querySelector('select#audioOutput');
    const videoSelect = <HTMLInputElement>document.querySelector('select#videoSource');
    const selectors = [audioInputSelect, audioOutputSelect, videoSelect];
    audioOutputSelect.disabled = !('sinkId' in HTMLMediaElement.prototype);

    // Handles being called several times to update labels. Preserve values.
    const values = selectors.map(select => select.value);
    selectors.forEach(select => {
      while (select.firstChild) {
        select.removeChild(select.firstChild);
      }
    });
    for (let i = 0; i !== deviceInfos.length; ++i) {
      const deviceInfo = deviceInfos[i];
      if (deviceInfo.deviceId != "default" && deviceInfo.deviceId != "communications") {
        const option = document.createElement('option');
        option.value = deviceInfo.deviceId;
        if (deviceInfo.kind === 'audioinput') {
          option.text = deviceInfo.label;
          audioInputSelect.appendChild(option);
        } else if (deviceInfo.kind === 'audiooutput') {
          option.text = deviceInfo.label;
          audioOutputSelect.appendChild(option);
        } else if (deviceInfo.kind === 'videoinput') {
          option.text = deviceInfo.label;
          videoSelect.appendChild(option);
        } else {
          console.log('Some other kind of source/device: ', deviceInfo);
        }
      }
    }
    selectors.forEach((select, selectorIndex) => {
      if (Array.prototype.slice.call(select.childNodes).some(n => n.value === values[selectorIndex])) {
        select.value = values[selectorIndex];
      }
    });
  }



  // Attach audio output device to video element using device/sink ID.
  attachSinkId(element, sinkId) {
    const audioOutputSelect = <HTMLSelectElement>document.querySelector('select#audioOutput');
    if (typeof element.sinkId !== 'undefined') {
      element.setSinkId(sinkId)
        .then(() => {
          console.log(`Success, audio output device attached: ${sinkId}`);
        })
        .catch(error => {
          let errorMessage = error;
          if (error.name === 'SecurityError') {
            errorMessage = `You need to use HTTPS for selecting audio output device: ${error}`;
          }
          console.error(errorMessage);
          // Jump back to first output device in the list as it's the default.
          audioOutputSelect.selectedIndex = 0;
        });
    } else {
      console.warn('Browser does not support output device selection.');
    }
  }

  changeAudioDestination() {
    const videoElement = document.querySelector('video');
    const audioOutputSelect = <HTMLInputElement>document.querySelector('select#audioOutput');
    const audioDestination = audioOutputSelect.value;
    videoElement.muted = true;
    this.attachSinkId(videoElement, audioDestination);
  }

  gotStream(stream) {
    const videoElement = document.querySelector('video');
    window.stream = stream; // make stream available to console
    videoElement.srcObject = stream;
    // Refresh button list in case labels have become available
    return navigator.mediaDevices.enumerateDevices();
  }

  start() {
    const audioInputSelect = <HTMLInputElement>document.querySelector('select#audioSource');
    const videoSelect = <HTMLInputElement>document.querySelector('select#videoSource');
    const audioSource = audioInputSelect.value;
    const videoSource = videoSelect.value;
    this.audioDeviceId = audioSource;
    this.videoDeviceId = videoSource;
    const constraints = {
      audio: false,
      video: { deviceId: videoSource ? { exact: videoSource } : undefined }
    };
    navigator.mediaDevices.getUserMedia(constraints).then(this.gotStream).then(this.gotDevices).catch(this.handleError);
  }

  // onDeviceSettingClose() {
  //   if (window.stream) {
  //     window.stream.getTracks().forEach(track => {
  //       track.stop();
  //     });
  //   }
  //   // the below code will force to reload the new camera/audio input settings
  //   if (
  //     (this.prevAudioDeviceId === undefined && this.audioDeviceId !== undefined)
  //     ||
  //     (this.prevVideoDeviceId === undefined && this.videoDeviceId !== undefined)
  //     ||
  //     (this.prevAudioDeviceId !== undefined && this.prevAudioDeviceId !== this.audioDeviceId)
  //     ||
  //     (this.prevVideoDeviceId !== undefined && this.prevVideoDeviceId !== this.videoDeviceId)
  //   ) {
  //     this.onUpdateBandwidth(this.currentBandWidth, true);
  //     this.prevAudioDeviceId = this.audioDeviceId;
  //     this.prevVideoDeviceId = this.videoDeviceId;
  //   }
  // }

  handleError(error) {
    console.log('navigator.MediaDevices.getUserMedia error: ', error.message, error.name);
  }
  /**
   *
   * @description The below function will execute when the conference component exit
   */
  ngOnDestroy() {
    clearInterval(this.bandWidthCheckIntervalId);
    clearInterval(this.heartBeatIntervalId);
    clearTimeout(this.leaveMeetingTimeoutId);
    clearTimeout(this.RTCIceCandidatePairTimeoutId);
    clearTimeout(this.muteUnmuteTimeoutId);
    clearInterval(this.statsInterval);
    clearInterval(this._sendAudioLevelIntervalId);
    this.leaveMeetingSubs.unsubscribe();
    this.onPausedVideoListener.unsubscribe();
    this._confPageService.removeUserFromUserInfo();
    this._utilService.removeFromStorage('local', 'audioConfig');
    this._utilService.removeFromStorage('local', 'layoutType');
    this._utilService.removeFromStorage('session', 'userAction');
    this._utilService.removeFromStorage('session', 'participantInfo');
    this._utilService.removeFromStorage('localStorage', 'is_owner');
    this._utilService.removeFromStorage('localStorage', 'socketUrl');
    this._utilService.removeFromStorage('localStorage', 'kip');
    this._utilService.removeFromStorage('localStorage', 'jip');
    this._utilService.removeFromStorage('session', 'meeting_config');
    this.leaveMeetingSubs.unsubscribe();
    this.notifyToRetryIceCandidateSubs.unsubscribe();
    this.currentBandwidthUsageSubs.unsubscribe();
    this._confPageService.isScreenShareStarted = false;
    this._confPageService.isWhiteBoardStarted = false;
    window.removeEventListener('focus', this.onFocus);
    window.removeEventListener('blur', this.onBlur);
    this.startPollSubscription.unsubscribe();
    this.meetingValidationListenerSubs.unsubscribe();
    this.onMeetingValidationAPIFailed.unsubscribe();
    this._joinMeetingService.isUserClickJoinButton = false;
    this.initH264UserConnection = false;
    this._onAccessAudioDevice.unsubscribe();
    this._onAccessVideoDevice.unsubscribe();
  }
}
