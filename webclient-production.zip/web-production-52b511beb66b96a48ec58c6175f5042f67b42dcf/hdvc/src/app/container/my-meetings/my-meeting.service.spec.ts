import { TestBed } from '@angular/core/testing';

import { MyMeetingService } from './my-meeting.service';

describe('MyMeetingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MyMeetingService = TestBed.get(MyMeetingService);
    expect(service).toBeTruthy();
  });
});
