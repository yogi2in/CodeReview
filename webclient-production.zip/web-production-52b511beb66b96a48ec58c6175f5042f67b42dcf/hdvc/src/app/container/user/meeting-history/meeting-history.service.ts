import { Injectable } from '@angular/core';
import { HttpService} from 'src/app/shared/services/http.service';
import { environment } from 'src/environments/environment';
import * as moment from 'moment';
import { getDate } from 'ngx-bootstrap/chronos/utils/date-getters';


@Injectable({
  providedIn: 'root'
})
export class MeetingHistoryService {
public date:Date;
public fromdate: any;
public todate: any;
 constructor(private httpService: HttpService) { }

  /**
   * @param payload will contains details to create the meeting
   */
  getMeetingHistoryDetails(filter) {

      if(filter.fromdate===null){
      this.date= new Date();
      this.date.setDate(this.date.getDate()-1);
      this.todate= moment(this.date).format("YYYY-MM-DD");
      this.fromdate='';
    }
    else
    {
      this.todate= moment(filter.fromdate).format("YYYY-MM-DD");
      this.fromdate= moment(filter.fromdate).format("YYYY-MM-DD");
    }

    const param = {
      url : environment.BASE_URI +"meeting?email_id=" + filter.emailId + "&page_index="+filter.pageIndex+"&page_size="+environment.PAGE_SIZE+"&to_date="+this.todate+"&from_date="+this.fromdate
    };
    return this.httpService.get(param);
  }
 
}
