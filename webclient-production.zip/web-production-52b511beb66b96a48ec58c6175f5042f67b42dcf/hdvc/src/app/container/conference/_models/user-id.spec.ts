import { UserId } from './user-id';

describe('UserId', () => {
  it('should create an instance', () => {
    expect(new UserId()).toBeTruthy();
  });
});
