import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LogPublisher } from './log-publisher';
import { LogConsole } from './log-console';
import { LogLocalStorage } from './log-local-storage';
import { LogWebApi } from './log-web-api';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LogPublishersService {

  constructor(private _http: HttpClient) {
    // Build publishers arrays
    this.buildPublishers();
  }

  // public properties
  publishers: LogPublisher[] = [];

  // public methods
  buildPublishers(): void {
    if (environment.LOG_TYPE.indexOf(0) > -1) {
      // create instance of LogConsole Class
      this.publishers.push(new LogConsole());
    }
    if(environment.LOG_TYPE.indexOf(1) > -1) {
      // Create instance of LogLocalStorage Class
      this.publishers.push(new LogLocalStorage());
    }
    if (environment.LOG_TYPE.indexOf(2) > -1) {
      // Create instance of LogWebApi Class
      this.publishers.push(new LogWebApi(this._http));
    }
  }
}
