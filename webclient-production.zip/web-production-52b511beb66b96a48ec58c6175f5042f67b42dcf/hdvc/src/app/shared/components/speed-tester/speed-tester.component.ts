import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-speed-tester',
  templateUrl: './speed-tester.component.html',
  styleUrls: ['./speed-tester.component.css']
})
export class SpeedTesterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
