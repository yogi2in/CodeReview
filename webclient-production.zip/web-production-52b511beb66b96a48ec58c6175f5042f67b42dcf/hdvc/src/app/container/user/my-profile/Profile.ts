export interface Profile {
    fullName?: String;
    email?: String;
    mobile?: Number;
    countryCode?: String;
    profileImage:any;
}

export interface EditProfile {
    fullName?: String;
    mobile?: Number;
    countryCode?: String;
}
export interface EditPassword {
    oldPassword?: string;
    newPassword?: string;
}