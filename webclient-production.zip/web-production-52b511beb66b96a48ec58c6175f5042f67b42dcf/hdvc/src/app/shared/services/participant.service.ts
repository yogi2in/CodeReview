import { Observable, Subject } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class ParticipantService {
  private userId: any;
  private name: any;
  private participantContainer: any;
  private container: any;
  private video: any;
  private span: any;
  private PARTICIPANT_MAIN_CLASS = 'participant main';
  private PARTICIPANT_CLASS = 'participant';
  public rtcPeer;

  public errorObs$ = new Subject<{errorFor: string, msg: string}>();
  public sendMsgObs$ = new Subject<{msgFor: string, data: any}>();

  constructor() {}

  init(userId, userName) {
    this.userId = userId;
    this.name = name;
    localStorage.setItem('userId', this.userId);
    localStorage.setItem('name', this.name);
    this.participantContainer = document.querySelector('#participants');

    this.container = document.createElement('div');
    this.span = document.createElement('span');
    // create video element to display video stream
    this.video = document.createElement('video');

    // set the class name of the container
    this.container.className = this.isPresentMainParticipant() ? this.PARTICIPANT_CLASS : this.PARTICIPANT_MAIN_CLASS;
    this.container.id = name;

    // append the newly created video and span in the DOM
    this.container.appendChild(this.video);
    this.container.appendChild(this.span);

    this.container.addEventListener('click', this.switchContainerClass.bind(this));

    // now append the video container
    this.participantContainer.appendChild(this.container);

    // add name in the span
    this.span.appendChild(document.createTextNode(userName));

    // set video element attribute
    this.video.id = 'video_' + userId;
    this.video.autoplay = true;
    this.video.controls = false;
  }

  isPresentMainParticipant() {
	  return ((document.getElementsByClassName(this.PARTICIPANT_MAIN_CLASS)).length !== 0);
  }

  switchContainerClass(event) {
    if (this.container.className === this.PARTICIPANT_CLASS) {
      const mainParticipantElem = document.getElementsByClassName(this.PARTICIPANT_MAIN_CLASS);
      const elements = Array.prototype.slice.call(mainParticipantElem);
      elements.forEach((item) => {
        item.className = this.PARTICIPANT_CLASS;
      });
      this.container.className = this.PARTICIPANT_MAIN_CLASS;
    } else {
      this.container.className = this.PARTICIPANT_CLASS;
    }
  }

  getElement() {
    return this.container;
  }

  getVideoElement() {
    return this.video;
  }

  offerToReceiveVideo(error, offerSdp, wp) {
    const self = this;
    const userId = localStorage.getItem('userId');
    const name = localStorage.getItem('name');
    if (error) {
      console.log('error ', error);
      // self.errorObs$.next({
      //   errorFor: 'sdp_error',
      //   msg: 'System face an error in SPD Offer!'
      // });
      return;
    }

    const msge = {
      req: "offer",
      userId: userId,
      offer: offerSdp
    };

    // "req":”offer",
    // "userId": "1234"
    // "offer": "<sdp offer String>"

    window.postMessage(JSON.stringify({
      msgFor: 'send_sdp',
      data: msge
    }), '*');
    //self.sendMsgObs$.next();
  }

  onIceCandidate(candidate, wp) {
    const self = this;
    const msge = {
      id: 'onIceCandidate',
      candidate: candidate,
      name: this.name
    };
    self.sendMsgObs$.next({
      msgFor: 'send_ice',
      data: msge
    });
  }

  dispose() {
    this.rtcPeer.dispose();
    this.container.parentNode.removeChild(this.container);
  }

  errorObsListener() {
    this.errorObs$.asObservable();
  }

  sendMsgObsListener() {
    this.sendMsgObs$.asObservable();
  }

}
