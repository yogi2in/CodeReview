import { Component, OnInit,  Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription, Observable } from 'rxjs';
import {debounceTime, map } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { UserManagementService } from '../user-management.service';
import { ProfileService } from '../../user-profile/profile.service';
import {CustomerService} from '../../../container/customer/customer.service';
import { AuthService } from '../../../auth/auth.service';
declare var $;


@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {
  createUserForm: FormGroup;
  ref:CreateUserComponent;
  profileData;
  private sub: any;
  modalId = "#add-user-modal"
  showGlobalError = true;
  countryList:any;
  CountryCodeList: {name: string, code: string}[] = [];
  @Input() panasonicUserid = null;
  @Input() routerName;
  @Input() editUserDataObj;
  @Input() roleList;
  @Input() userParentList;
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  private userSubscription = new Subscription();
  userObj :any;
  //private userSubscription = new Subscription();
  constructor(private userService: UserManagementService, private profileService: ProfileService, private router: Router, private route: ActivatedRoute, private customerService: CustomerService, private authService : AuthService) {
    
   }

  ngOnInit() {
    this.userObj= this.authService.getCurrentUserObj();
    this.createUserForm = new FormGroup({
      fullName: new FormControl(null, Validators.required),
      countryCode: new FormControl(null, Validators.required),
      mobile: new FormControl(null, Validators.required),
      email: new FormControl(null, [Validators.email]),
      selectedRole:new FormControl(null),
      selectedParent:new FormControl(null)
    });

    this.customerService.getCountryCode()
    .subscribe(
      (res) => {
        if(res.result != undefined && res.result != null && res.result.length != 0){
          this.countryList = res["result"];
          for(let countrycode in this.countryList ) { 
          this.CountryCodeList.push({name: this.countryList[countrycode].code,code: " "+this.countryList[countrycode].name})
          }
        }
      }
    );
      
    if(this.routerName == 'ADD-USER'){
      this.createUserForm.reset();
      this.createUserForm.controls['countryCode'].patchValue("+91")
      this.createUserForm.controls['selectedRole'].patchValue(this.roleList[0].roleId)
      console.log("this.userParentList[0]",this.userParentList[0]);
      this.createUserForm.controls['selectedParent'].patchValue(this.userObj.userId)
      this.createUserForm.controls['email'].setValidators([Validators.required, Validators.email]);
    }
    
    // Subscribe the Observables and change the router 
    this.userSubscription = this.userService.userProcessListener()
    .subscribe(
      (res) => {
        if(res.isSuccess == true && res.action == "updatePanasonicUser" || res.action == "createPanasonicUser"){
          if(this.panasonicUserid != null){
            $('#add-user-modal'+this.panasonicUserid).modal('hide')
            delete this.editUserDataObj[this.panasonicUserid];
          }else{
            this.createUserForm.reset()
            $('#add-user-modal').modal('hide')
          }
        }
      }
    );

    if(this.routerName == 'EDIT-USER'){
      this.createUserForm.setValue(this.editUserDataObj);
    } 
  }
  
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
        : this.CountryCodeList.filter(v => +v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
    
  formatter = (x: {name: string}) => {
    if(x.name != undefined){
      return x.name;
    }else{
      return x;
    }
  }

  createUser() {
    // When user click on form submit button without filling the fields then error will display.
    this.createUserForm.controls['fullName'].markAsTouched();
    this.createUserForm.controls['countryCode'].markAsTouched();
    this.createUserForm.controls['mobile'].markAsTouched();
    this.createUserForm.controls['email'].markAsTouched();
    if (this.createUserForm.valid) {
      if(this.routerName == 'ADD-USER'){
         this.userService.createPanasonicUser(
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode.name==undefined?this.createUserForm.value.countryCode:this.createUserForm.value.countryCode.name,
          this.createUserForm.value.mobile,
          this.createUserForm.value.email,
          this.createUserForm.value.selectedRole,
          this.createUserForm.value.selectedParent
        );
       
      }else if(this.routerName == 'EDIT-USER'){
        console.log("this.createUserForm.value",this.createUserForm.value)
        this.userService.updatePanasonicUserById(
          this.panasonicUserid,
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode.name==undefined?this.createUserForm.value.countryCode:this.createUserForm.value.countryCode.name,
          this.createUserForm.value.mobile,
          this.createUserForm.value.selectedRole,
          this.createUserForm.value.selectedParent
        );
      }
      /* else{
        this.profileService.updateUserProfile(
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode,
          this.createUserForm.value.mobile
        );
      } */
    } else {
      console.log('form invalid!');
    }

  }

  
  ngOnDestroy(){
      // prevent memory leak when component destroyed
      this.userSubscription.unsubscribe();
  }
  

  ngAfterViewInit() {
    $('#add-user-modal').on('hidden.bs.modal', () => {
      if(!this.panasonicUserid){
        this.createUserForm.reset();
        this.createUserForm.controls['selectedRole'].patchValue(this.roleList[0].roleId);
        this.createUserForm.controls['selectedParent'].patchValue(this.userObj.userId);
        this.createUserForm.patchValue({countryCode:'+91'});
      }
    });
    this.showGlobalError = true
  }

  selectRole(roleId){
    console.log("selectRole",roleId)
  }
}
