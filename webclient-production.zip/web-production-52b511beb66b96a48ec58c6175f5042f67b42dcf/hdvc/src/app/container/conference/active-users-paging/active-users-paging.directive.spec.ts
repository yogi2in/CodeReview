import { ActiveUsersPagingDirective } from './active-users-paging.directive';

describe('ActiveUsersPagingDirective', () => {
  it('should create an instance', () => {
    const directive = new ActiveUsersPagingDirective();
    expect(directive).toBeTruthy();
  });
});
