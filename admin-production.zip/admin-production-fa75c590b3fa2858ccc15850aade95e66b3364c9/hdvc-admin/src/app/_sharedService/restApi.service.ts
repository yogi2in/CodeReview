import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpRequest } from '@angular/common/http';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { catchError,tap} from 'rxjs/operators';
import { error } from '@angular/compiler/src/util';



@Injectable({
    providedIn: 'root'
})
export class RestApiService {
    private errorProcessor = new Subject<{isError:boolean,errorObj: {}, successMsg:string}>();

    errorProcessorListener() {
        return this.errorProcessor.asObservable();
    }
    constructor(private http: HttpClient) { }

    public sendRequest(method,dataUrl, data) : Observable<any>{
        let options = {body:data};
        if(method == 'Get'){
            options["params"] = data;
        }
        return this.http.request(method,dataUrl,options)
        .pipe(
            tap( 
                //data => this.errorProcessor.next({isError:false, errorObj: {}}),
                data => {
                    console.log("rest===",data)
                    if(data.message != undefined && data.message != null){
                        this.errorProcessor.next({isError:false, errorObj: {},successMsg:data.message})
                    }
                }, 
                error => this.errorProcessor.next({isError:true, errorObj: error, successMsg:""})
            )
          );
    }


       
    }
    

