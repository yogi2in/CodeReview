import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { IfStmt } from '@angular/compiler';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Subscription } from 'rxjs';
declare var IceServersHandler;
declare var window;
declare var Participant;

@Component({
  selector: 'app-get-stats',
  templateUrl: './get-stats.component.html',
  styleUrls: ['./get-stats.component.css']
})
export class GetStatsComponent implements OnInit {
  //////
  bandWidthSpeed: any;
  firstCheck = true;
  previousBandwidthValue: any;
  previousBandwidthUnit: any = 'Bytes';
  videoCodecs: any;
  audioCodecs: any;
  videoSent: any;
  videReceived: any;
  audioSent: any;
  audioReceived: any;
  videoStream: any;
  stopGetResult = false;
  offerer: any;
  answerer: any;
  offererToAnswerer: any;
  iceServers: any = {
    iceServers: IceServersHandler.getIceServers(),
    iceTransportPolicy: 'all',
    rtcpMuxPolicy: 'require',
    bundlePolicy: 'max-bundle'
  };
  checkInternetSubs = new Subscription();
  mediaConstraints = {
    OfferToReceiveAudio: true,
    OfferToReceiveVideo: true
  };
  stateCounter = 0;
  public currentFramerate: any = 15;
  participant: any;
  @Input() participantId: string;
  @Input() currentResolution: any;
  @Output() notifyModalClose = new EventEmitter();
  @Output() notifyBandwidthChange = new EventEmitter<{resolution: any}>()

  constructor(private _utilService: UtilService) { }

  ngOnInit() {
    this.participant = new Participant();
    this.getStats(this.participantId);
    this.showStatsValue('avialbleSpeed', 'Available Speed: ...');
  }

  getStats(elementeId: string) {
    this.checkInternetSubs = this._utilService.checkInternetSpeedListner().subscribe(
      (response: any) => {
        console.log('response ', response);
        //this.checkInternetSubs.unsubscribe();
        this.showStatsValue('avialbleSpeed', 'Available Speed: '+ response.currentSpeed);
        // let mbpsSpeed = response.speedMBps != undefined ? parseInt(response.speedMBps) : 0;

        // if (mbpsSpeed !== undefined && mbpsSpeed > 0) {
        //   this.showStatsValue('avialbleSpeed', 'Available Speed: '+ response.speedMBps);
        // } else {
        //   this.showStatsValue('avialbleSpeed', 'Available Speed: '+ response.speedKbps);
        // }
      }, (error: any) => {
        console.log('error ', error);
      }
    )

    //this._utilService.checkInternetSpeed();
    // make reference to component this
    const thisRef = this;

    // get the videoElement to calculate the bandwidth
    const videoElem: any = document.getElementById('video-' + elementeId);

    // if no video element found, do nothing
    if (videoElem === null || videoElem.srcObject === null) {
      return;
    }

    // get the video stream of the selected video element
    this.videoStream = videoElem.srcObject;

    // create a new connection
    this.offerer = new RTCPeerConnection(this.iceServers);
    this.offerer.idx = 1;
    this.videoStream.getTracks().forEach(function(track) {
      thisRef.offerer.addTrack(track, thisRef.videoStream);
    });

    let firedOnce = false;
    this.offerer.ontrack = function (event) {
      if (firedOnce) {
        return;
      }
      firedOnce = true;
      if (typeof window.InstallTrigger !== 'undefined') {
        thisRef.participant.innerGetStats(thisRef.offerer, event.streams[0].getTracks()[0], function(result) {
            thisRef.previewGetStatsResult(thisRef.offerer, result);
          }, 1000);
      } else {
        thisRef.participant.innerGetStats(thisRef.offerer, function(result) {
          thisRef.previewGetStatsResult(thisRef.offerer, result);
        }, 1000);
      }
    };

    this.offerer.onicecandidate = function (event) {
      if (!event || !event.candidate)  {
        return;
      }
      thisRef.addIceCandidate(thisRef.answerer, event.candidate);
    };

    thisRef.offerer.createOffer(thisRef.mediaConstraints).then(function (offer) {
      offer.sdp = thisRef.preferSelectedCodec(offer.sdp);
      thisRef.offerer.setLocalDescription(offer).then(function() {
        thisRef.answererPeer(offer, thisRef.videoStream);
      });
    });
  }

  /**
   * @description The below answer will handle to answer the video stream offer
   * @param offer
   * @param video_stream
   */
  answererPeer(offer, video_stream) {
    // make reference to component this
    const thisRef = this;

    thisRef.answerer = new RTCPeerConnection(thisRef.iceServers);
    thisRef.answerer.idx = 2;

    video_stream.getTracks().forEach(function(track) {
      thisRef.answerer.addTrack(track, video_stream);
    });

    thisRef.answerer.setRemoteDescription(offer).then(function() {
      thisRef.answerer.createAnswer(thisRef.mediaConstraints).then(function (answer) {
          answer.sdp = thisRef.preferSelectedCodec(answer.sdp);
          thisRef.answerer.setLocalDescription(answer).then(function() {
            thisRef.offerer.setRemoteDescription(answer);
          });
      });
    });
  }


  previewGetStatsResult(peer, result) {
    // console.log("result.bandwidth", result.bandwidth);
    ++this.stateCounter;
    const thisRef = this;
    if (thisRef.stopGetResult === true) {
      this.stateCounter = 0;
      result.nomore();
    }
    // console.log('result ----> ', JSON.stringify(result));
    // console.log('thisRef.currentResolution ', result.video.bytesReceived, result.audio.bytesReceived);
    if (thisRef.currentResolution === null) {
      if(this.stateCounter < 10) { return console.log('dont check');}
      else {
        // console.log('continue check');
      }
     // console.log(result.bandwidth);
      thisRef.isUserBandwidthEnough(this.bytesToSize(result.bandwidth.availableSendBandwidth));
      return; // console.log('bandwidth speed', this.bytesToSize(result.bandwidth.availableSendBandwidth));
    }
    //console.log('resolution ', result);
    this.showStatsValue('bSpeed', 'Speed: ' + this.bytesToKiloBitsSize(result.bandwidth.speed, 'cm'));
    // this.showStatsValue('avialbleSpeed', 'Available Speed: '+ this.bytesToSize(result.bandwidth.availableSendBandwidth, 'cm'));
    this.showStatsValue('vSent', 'Sent: ' + this.bytesToSize(result.video.bytesSent));
    this.showStatsValue('vReceived', 'Received: ' + this.bytesToSize(result.video.bytesReceived));
    this.showStatsValue('vCodecs', 'Codecs: ' + result.video.send.codecs[0]);
    this.showStatsValue('aSent', 'Sent: ' + this.bytesToSize(result.audio.bytesSent));
    this.showStatsValue('aReceived', 'Received: ' + this.bytesToSize(result.audio.bytesReceived));
    this.showStatsValue('aCodec', 'Codecs: ' + result.audio.send.codecs[0]);
    this.currentResolution = {
      width: result.resolutions.send.width,
      height: result.resolutions.send.height
    }
    this.updateFrameRateValue(result.results);
  }

  updateFrameRateValue(results) {
    results.forEach((arrVal, arrKey) => {
      if (arrVal.googFrameRateOutput !== undefined) {
        this.currentFramerate = arrVal.googFrameRateOutput;
        // console.log('this.currentFramerate ', this.currentFramerate)
      }
    })
  }

  isUserBandwidthEnough(bandWidthInfo: string) {
    if (bandWidthInfo === undefined || this.firstCheck == true) {
      this.firstCheck = false;
      return;
    }

    // console.log('bandWidthInfo ', bandWidthInfo)
    if(bandWidthInfo !== undefined && bandWidthInfo.indexOf('MB') > - 1) {
      if(this.previousBandwidthUnit === 'MB') {
        return;
      }
      const splitBandwidth = bandWidthInfo.split(" ");
      this.previousBandwidthValue = splitBandwidth[0];
      this.previousBandwidthUnit = splitBandwidth[1];
      this.notifyBandwidthChange.emit({resolution: {width: 720, height: 480, frameRate: 30}});
      return;
    }

    if(bandWidthInfo !== undefined && bandWidthInfo.indexOf('KB') > -1) {
      if(this.previousBandwidthUnit === 'KBps') {
        return;
      }
      const splitBandwidth = bandWidthInfo.split(" ");
      const curretnBandWidth = +splitBandwidth[0];
      if (curretnBandWidth >=256 && curretnBandWidth < 999) {
        this.notifyBandwidthChange.emit({resolution: {width: 176, height: 144, frameRate: 15}});
      } else if(curretnBandWidth <256) {
        this.notifyBandwidthChange.emit({resolution: {width: 0, height: 0, frameRate: 0}});
      }
      this.previousBandwidthValue = splitBandwidth[0];
      this.previousBandwidthUnit = splitBandwidth[1];
    }
  }

  showStatsValue(id: string, value: string) {
    const element = document.getElementById(id);
    if (element !== null) {
      value = value.indexOf('undefined') === -1 ? value : '';
      element.innerHTML = value;
    }
  }

  getInfo(mainObj: any, keyNames: any, siblings?: boolean) {
    if (mainObj === undefined || mainObj === null || keyNames === undefined) {
      return null;
    }

    let result: any;
    if (siblings === undefined || siblings === false) {
      const keys =  keyNames.length > 1 ? keyNames.join('.') : keyNames[0];
      result = keyNames.join(' ') + ':' + mainObj[keys];
    }
    return result;
  }

  bytesToKiloBitsSize(bytes, unit?: string) {
    const k = 1000;
    let result;
    const sizes = unit !== undefined? ['kbps', 'kbps', 'kbps', 'GB', 'TB']: ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes <= 0) {
        return '0 Bytes';
    }
    let i: any = Math.floor(Math.log(bytes) / Math.log(k));

    if (!sizes[i]) {
      return '0 Bytes';
    }
    const unitType = sizes[i];
    result = (bytes / Math.pow(k, i)).toPrecision(3);
    //comment if required
    // if (i === 0) {
    //   result = result * 0.008;
    // } else if (i === 1) {
    //   // console.log('result ', result)
    //   result = result * 8;
    // } else if (i === 2) {
    //   result = result * 8000;
    // }
    //end
    result = parseInt(result)+ ' ' + unitType;
    return result;
  }

  bytesToSize(bytes, unit?: string) {
    const k = 1000;
    const sizes = unit !== undefined? ['Bytes', 'kbps', 'MBps', 'GB', 'TB']: ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes <= 0) {
        return '0 Bytes';
    }
    let i: any = Math.floor(Math.log(bytes) / Math.log(k));

    if (!sizes[i]) {
      return '0 Bytes';
    }
    const unitType = sizes[i];
    return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + unitType;
  }

  addIceCandidate(peer, candidate): void {
    peer.addIceCandidate(candidate);
  }

  preferSelectedCodec(sdp): any {
    return sdp;
  }


  onModalClose(): void {
    this.stopGetResult = true;
    this.videoStream.getTracks().forEach(function(track) {
      track.stop();
    });
    this.notifyModalClose.emit();
  }

  ngOnDestroy(): void {
    this.stopGetResult = true;
  }
}
