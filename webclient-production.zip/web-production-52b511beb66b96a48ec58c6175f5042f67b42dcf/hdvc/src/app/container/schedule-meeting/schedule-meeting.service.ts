import { Injectable } from '@angular/core';
import { HttpService} from 'src/app/shared/services/http.service';
import { environment } from 'src/environments/environment';

@Injectable({providedIn: 'root'})

export class ScheduleMeetingService {

  constructor(private httpService: HttpService) { }

  /**
   * @param payload will contains details to create the meeting
   */
  scheduleMeeting(payload) {
    const param = {
      // method: "post",
      url : environment.BASE_URI + 'meeting',
      body: payload
    };

    return this.httpService.post(param);
  }

  updateMeeting(payload) {
    console.log("payload", payload)
    const param = {
      // method: "post",
      url : environment.BASE_URI + 'meeting',
      body: payload
    };

    return this.httpService.put(param);
  }

  getEditMeetingDetails(meetingId, isRecurringSingle) {
     let postFixurl = isRecurringSingle === true ? 'meeting?meeting_id=' + meetingId : 'meeting?meeting_refid=' + meetingId;
   // let postFixurl =  'meeting?meeting_refid=' + meetingId;
    const param = {
      url: environment.BASE_URI + postFixurl
    }
    return this.httpService.get(param);
  }


}
