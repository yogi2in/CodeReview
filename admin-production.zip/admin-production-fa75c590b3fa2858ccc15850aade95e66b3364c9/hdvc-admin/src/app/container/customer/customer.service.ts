/* This service is used for call customer related API */
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient, HttpParams  } from '@angular/common/http';
import { RestApiService } from '../../_sharedService/restApi.service';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customerListData:any = [];

  private customerListProcess = new Subject<{isSuccess :boolean, data:{}, statusChanged :boolean, action:string}>();
  
  customerListListner() {
    return this.customerListProcess.asObservable();
  }
  
  constructor(private http: HttpClient, private restService :RestApiService) { }

  /* This method is execute for get customer list */
  getCustomerList(currentPage,numPerPage,selectedData){
    let params = {"currentPage":currentPage,"numPerPage":numPerPage};
    if(selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null){
      params["status"] = selectedData.selectedSearchStatus;
    }
    if(selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null){
      params["custName"] = selectedData.selectedSearchString;
    }
    this.restService.sendRequest('Get',environment.BASE_URI+'customer',params)
      .subscribe(
        (res) => {
          // after success process request for pass data in component
          this.customerListData = res.result;
          this.customerListProcess.next({isSuccess: true, data:{"list":this.customerListData,"paginator":res.pagination}, statusChanged:false, action:'getCustomerList'});
        }
      );
  }

  /* This method is execute for create customer */
  addCustomer(data){
    this.restService.sendRequest('Post',environment.BASE_URI+'customer ',data)
      .subscribe(
        (res) => {
          this.customerListProcess.next({isSuccess: true, data:{"list":this.customerListData,"paginator":res.pagination}, statusChanged:false, action:'addCustomer'});
        }
      );
  }
  
  /* This method is execute for get customer by status */
  getCustomerListBysearch(selectedData, currentPage, numPerPage){
    let params = {"currentPage":currentPage,"numPerPage":numPerPage};
      if(selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null){
        params["status"] = selectedData.selectedSearchStatus;
      }
      if(selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null){
        params["custName"] = selectedData.selectedSearchString;
      } 
      this.restService.sendRequest('Get',environment.BASE_URI+'customer', params)
      .subscribe(
        (res) => {
          // after success process request for pass data in component
          this.customerListData = res.result;
          this.customerListProcess.next({isSuccess: true, data:{"list":this.customerListData,"paginator":res.pagination}, statusChanged:false, action:'getCustomerListBysearch'});
        }
      );
  }

  /* This method is execute for get customer by organization name */
  getCustomerListByOrganization(selectedData){
    let params = {};
    if(selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null){
      params["status"] = selectedData.selectedSearchStatus;
    }
    if(selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null){
      params["custName"] = selectedData.selectedSearchString;
    }
    this.restService.sendRequest('Get',environment.BASE_URI+'customer', params)
     .subscribe(
       (res) => {
         // after success process request for pass data in component
         this.customerListData = res.result;
         this.customerListProcess.next({isSuccess: true, data:{"list":this.customerListData,"paginator":res.pagination}, statusChanged:false, action:'getCustomerListByOrganization'});
       }
     );
  }

  /* This method is execute for change customer status (active, inactive, delete) */
  changeCustomerstatus(data){
    return this.restService.sendRequest('Put',environment.BASE_URI+'customer', data)
  }

  /* This method is execute for get customer by id */
  getCustomerById(id){
    let params = {};
    return this.restService.sendRequest('Get',environment.BASE_URI+'customer/'+id, params)
  }

  /* This method is execute for update customer details */
  updateCustomerById(id, data){
    this.restService.sendRequest('put',environment.BASE_URI+'customer/'+id, data)
    .subscribe(
      (res) => {
        this.customerListProcess.next({isSuccess: true, data:{"list":this.customerListData,"paginator":res.pagination}, statusChanged:false, action: 'updateCustomerById'});
      }
    );
  }

  getCountryCode(){
    let data = {};
    return this.restService.sendRequest('get',environment.BASE_URI+'country-codes',data)
  }

}
