import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalPeerConnectionStatsComponent } from './local-peer-connection-stats.component';

describe('LocalPeerConnectionStatsComponent', () => {
  let component: LocalPeerConnectionStatsComponent;
  let fixture: ComponentFixture<LocalPeerConnectionStatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocalPeerConnectionStatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalPeerConnectionStatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
