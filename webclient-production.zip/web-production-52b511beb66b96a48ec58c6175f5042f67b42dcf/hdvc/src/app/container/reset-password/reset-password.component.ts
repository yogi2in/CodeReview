import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators} from '@angular/forms';
import { Subscription } from 'rxjs';
import { Route, Router, ActivatedRoute} from '@angular/router';
import {AuthService} from '../../auth/auth.service';
import {CustomValidators} from '../../shared/custom-validation/customValidators';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class ResetPasswordComponent implements OnInit {
  createPasswordForm: FormGroup;
  private userSubscription = new Subscription();
  emailToken: string;
  private sub: any;
  public errorMessage;
  public successMessage;
  private clearSetTimeOut;


  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.createPasswordForm = this.fb.group({
      'password': [null, [Validators.required, CustomValidators.strongpassword]],
      'confirmPassword' : [null, Validators.required ]
    }, {
      validator: passwordMatcher // your validation method
    });

    this.sub = this.route.params.subscribe(params => {
      this.emailToken = params['emailToken'];
    });

    // Subscribe the Observables and change the router after password save
    this.userSubscription = this.authService.setPasswordProcessListener()
    .subscribe(
      (res) => {
        this.errorMessage = null;
        this.successMessage = null;
        if (res.isSuccess === true) {
          this.successMessage = "Password Saved Successfully"
          let self = this
          clearTimeout(this.clearSetTimeOut);
          this.clearSetTimeOut = setTimeout(function() {
            self.authService.signOut();
            self.router.navigate(['/login']);
          },1000)
        }else{
          this.errorMessage = res.data;
        }
      },
      (error) => {
        // code to handel rejection.
        console.log("error",error);
      }
    );


  }

  savePassword(){
     // When user click on form submit button without filling the fields then error will display.
     this.errorMessage = null;
     this.createPasswordForm.controls['password'].markAsTouched();
     this.createPasswordForm.controls['confirmPassword'].markAsTouched();
     if(this.createPasswordForm.controls['password'].hasError('Strong')){
      this.createPasswordForm.controls['password'].setErrors(null);
    }
     if (this.createPasswordForm.valid) {
        this.authService.setPassword(
        this.createPasswordForm.value.password,
        this.emailToken
        );
     } else {
       console.log('form invalid!');
     }
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
    this.userSubscription.unsubscribe();
    clearTimeout(this.clearSetTimeOut);
  }
}

export const passwordMatcher = (control: AbstractControl): {[key: string]: boolean} => {
  if (control.get('password') && control.get('confirmPassword')) {
    const password = control.get('password').value; // to get value in input tag
    const confirmPassword = control.get('confirmPassword').value; // to get value in input tag
    if (password !== confirmPassword) {
      control.get('confirmPassword').setErrors( {matchPassword: true});
    } else {
      return null;
    }
  }
  return null;
};

// import { Component, OnInit } from '@angular/core';
// import { AbstractControl } from '@angular/forms';
// import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';

// @Component({
//   selector: 'app-reset-password',
//   templateUrl: './reset-password.component.html',
//   styleUrls: ['./reset-password.component.css']
// })
// export class ResetPasswordComponent implements OnInit {
//   resetPasswordForm: FormGroup;
//   submitted = false;
//   constructor(private fb: FormBuilder) {
//     this.buildForm();
//   }

//   ngOnInit() {
//   }

//   public buildForm() {
//     // use FormBuilder to create a form group
//     this.resetPasswordForm = this.fb.group({
//       'password': [null, Validators.required ],
//       'confirmPassword' : [null, Validators.required ]
//     }, {
//       validator: passwordMatcher // your validation method
//     });
//   }

//   public saveResetPassword(){
//     this.submitted = true;
//     if (this.resetPasswordForm.invalid) {
//       return;
//     } else {
//       this.submitted = false;
//       console.log(this.resetPasswordForm.controls['password'].value);
//       console.log(this.resetPasswordForm.controls['confirmPassword'].value);
//     }

//   }


// }


// export const passwordMatcher = (control: AbstractControl): {[key: string]: boolean} => {
//   if (control.get('password') && control.get('confirmPassword')) {
//     const password = control.get('password').value; // to get value in input tag
//     const confirmPassword = control.get('confirmPassword').value; // to get value in input tag
//     if (password !== confirmPassword) {
//       console.log('false');
//       control.get('confirmPassword').setErrors( {matchPassword: true});
//     } else {
//       console.log('true');
//       return null;
//     }
//   }
//   return null;
// };

