import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-user-sidebar',
  templateUrl: './user-sidebar.component.html',
  styleUrls: ['./user-sidebar.component.css']
})

export class UserSidebarComponent implements OnInit {
  // @Input() profilePic: string;
  constructor(private authService: AuthService) {
  }

  ngOnInit() {

  }

  // signOut() {
  //   this.authService.signOut();
  // }
}
