import { ParticipantMinutesPipe } from './participant-minutes.pipe';

describe('ParticipantMinutesPipe', () => {
  it('create an instance', () => {
    const pipe = new ParticipantMinutesPipe();
    expect(pipe).toBeTruthy();
  });
});
