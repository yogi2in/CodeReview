/**
 * ProfileService contains all user profile related methods
 */
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { RestApiService } from '../../_sharedService/restApi.service';
import { environment } from '../../../environments/environment';
import { EventEmitter, Output } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  userProfileData: any;
  isOpenChangePwd = false;
  @Output() change: EventEmitter<boolean> = new EventEmitter();
  private userProfileProcess = new Subject<{isSuccess: boolean, userProfileData: any, action: string}>();

  userProfileListner() {
    return this.userProfileProcess.asObservable();
  }

  constructor(private http: HttpClient, private rest: RestApiService) { }

  /* This method executed for get user profile */
  getUserProfile(){
    let params = {};
    this.rest.sendRequest('Get',environment.BASE_URI+'user/profile',params)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            this.userProfileData = res["result"];
          }
          // after success process request for pass data in component
          this.userProfileProcess.next({isSuccess: true, userProfileData: this.userProfileData,action:'get'});
        }
      );
  }

   /* This method executed for update user profile */
  updateUserProfile(fullName: string, countryCode: string, mobile: string){
    const userData = {
      fullName: fullName,
      countryCode: countryCode,
      mobile:mobile
    };
    return this.rest.sendRequest('Put',environment.BASE_URI+'user/profile',userData)
  }

  processReqForUpdateUserProfile(userProfileData){
    // after success process request for pass updated data in component
    this.userProfileProcess.next({isSuccess: true, userProfileData: userProfileData, action:'update'});
  }

  uploadProfileImage(file){
   let formdata = new FormData();
   formdata.append("file", file);
    this.rest.sendRequest('Post',environment.BASE_URI+'user/upload-image',formdata)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            this.userProfileData = res["result"];
          }
          // after success process request for pass updated data in component
          this.userProfileProcess.next({isSuccess: true, userProfileData: this.userProfileData, action:'upload'});
        }
      );
  }

  toggleChangePassword(isChangePassword) {
    console.log("toggleChangePassword",isChangePassword)
    this.isOpenChangePwd = isChangePassword
    this.change.emit(this.isOpenChangePwd);
  }
}
