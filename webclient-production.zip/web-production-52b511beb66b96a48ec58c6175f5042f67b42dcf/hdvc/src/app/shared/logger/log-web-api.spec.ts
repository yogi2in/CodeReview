import { LogWebApi } from './log-web-api';

describe('LogWebApi', () => {
  it('should create an instance', () => {
    expect(new LogWebApi()).toBeTruthy();
  });
});
