import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'roleType'
})
export class RoleTypePipe implements PipeTransform {

  transform(items: any[], field: any, value: any): any[] {
    if (!items) return [];
    if (value !== 1 && value !== 0) {
      return items;
    }
    return items.filter(
      items => items[field] == value
    );
  }

}
