import { Component, OnInit, OnDestroy, EventEmitter, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { UtilService } from '../shared/services/utils.services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit, OnDestroy {
  public isLoggedIn: boolean = false;
  public isCustomerAdmin: boolean = false;
  public localStTokenVal: void;
  private headerSubscription = new Subscription();
  private signOutSubsctiption = new Subscription();
  public showScheduleMeeting: boolean = false;
  //public isSideBarFlag = false;
  @Output() valueChange:EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private authService: AuthService,
    private _utilService: UtilService,
    private router: Router
  ) {}

  ngOnInit(): void{
    this.headerSubscription = this.authService.showHeaderForLoginUserListner()
    .subscribe(
      (res) => {
        this.checkAuthToken();
      })

      //called on page load
      this.checkAuthToken();

    /*
    *  The below code will execute when user singOut form porfile page.
    */
      this.signOutSubsctiption = this.authService.isSignOutPage()
      .subscribe(
        (res) => {
          this.isLoggedIn = res.isLoggedIn;
        },
        (err) => {
          console.log("Header component page error", err);
        }
      )
      //this.hideSidebar();

    }

    checkAuthToken(){
      if (this.authService.userExists()) { //method checking token and token expiry time
        this.isLoggedIn=true;
        const currentUser = this._utilService.getInfoFromStorage('local', 'currentUser'); // localStorage.getItem('currentUser');
        if (currentUser === null) {
          return;
        }
        this.isCustomerAdmin = currentUser["roleName"] == 'CUSTOMER_ADMIN' ? true :false;
        this.showScheduleMeeting = currentUser["isValidLicence"];
      } else {
        this.isLoggedIn = false;
        this.isCustomerAdmin = false;
      }
    }

    /* The below function call when user signout. In this false flag will pass.
    * */
    childDataFlag($event) {
      console.log("childDataFlag",$event)
      this.isLoggedIn = $event;
    }


    /*
    * The Below function checking the sidebar show or hide.
    */
    // hideSidebar() {
    //   if (this.isLoggedIn === true) {
    //     if (this.isSideBarFlag === true) {
    //       this.valueChange.emit(this.isSideBarFlag);
    //       this.isSideBarFlag = false;
    //     } else {
    //       this.valueChange.emit(this.isSideBarFlag);
    //       this.isSideBarFlag = true;
    //     }
    //   } else {
    //     this.isSideBarFlag = undefined;
    //     this.valueChange.emit(this.isSideBarFlag);
    //     this.isSideBarFlag = true;
    //   }
    // }

    // Destory the subscription.
    ngOnDestroy(): void {
      this.headerSubscription.unsubscribe();
      this.signOutSubsctiption.unsubscribe();
    }

}
