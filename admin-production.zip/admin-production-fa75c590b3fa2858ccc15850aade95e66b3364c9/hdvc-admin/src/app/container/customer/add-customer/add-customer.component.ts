import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CustomerService } from '../customer.service';
import { UserManagementService } from '../../users/user-management.service';
import { AuthService } from '../../../auth/auth.service';
import { Subscription } from 'rxjs';
import { Route, Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { LicenceService } from '../licence-management/licence.service';
declare var $

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {
  private addCustomerSubscription = new Subscription();
  private customerListSubscription = new Subscription();
  private userSubscription = new Subscription();
  addCustomerForm: FormGroup;
  forSubmitted = false;
  routerName = null;
  customerid;
  private sub: any;
  countryList = [];
  showGlobalError = false;
  permissions = {};

  configForOrganizationForm = [
    {
      type: 'input',
      label: 'Organization Name',
      name: 'custName',
      required: true

    },
    {
      type: 'textarea',
      label: 'Address',
      name: 'address',
      required: false
    },
    {
      type: 'inputGroup',
      label: 'Contact Number',
      name: ['contactNoCountryCode', 'contactNo'],
      required: true
    },
    {
      type: 'inputGroup',
      label: 'Alternate Number',
      name: ['alternateNumberCountryCode', 'alternatePhoneNumber'],
      required: false
    },
    {
      type: 'select',
      label: 'Enterprise Owner',
      name: 'owner',
      required: false
    },
    /* {
      type: 'input',
      label: 'Alternate Phone Number',
      name: 'alternatePhoneNumber',
      required:false
    },   */
    {
      type: 'checkbox',
      label: 'Status',
      name: 'status',
      required: false
    }
  ];

  configForContactInfoForm = [
    {
      type: 'input',
      label: 'Name',
      name: 'pointOfContactName',
      required: true

    },
    {
      type: 'input',
      label: 'Email',
      name: 'pointOfContactEmail',
      required: true
    },

    {
      type: 'inputGroup',
      label: 'Contact Number',
      name: ['pointOfContactCountryCode', 'pointOfContactMobile'],
      required: true
    },
    /* {
      type: 'input',
      label: 'Point Of Contact Number',
      name: 'pointOfContactMobile',
      required:true
    }, */
    {
      type: 'label',
      label: 'POC Status',
      name: 'pointOfContactStatus'
    }
  ];

  configForLicenceManagement = [
    /* {
      type: 'input',
      label: 'Licence Lot ID',
      name: 'licenceLotId'
    }, */
    {
      type: 'input',
      label: 'Number of Licence',
      name: 'numberOfUsers',
      required: true
    },
    {
      type: 'date',
      label: 'Start Date',
      name: 'licenceStartDate',
      required: true
    },
    {
      type: 'date',
      label: 'Expiry Date',
      name: 'licenceEndDate',
      required: true
    }
  ]
  formTitle = "Add Enterprise";
  buttonName = "Add Enterprise";
  licences = [];
  customerDataById;
  customerOwnerList = [];
  constructor(private fb: FormBuilder, private customerService: CustomerService, private router: Router, private route: ActivatedRoute, private licenceService: LicenceService, private userService: UserManagementService, private authService: AuthService) {
    if (this.router.url.includes("/edit-customer")) {
      this.routerName = 'EDIT-CUSTOMER';
      this.formTitle = 'Edit Enterprise';
      this.buttonName = "Save";
    }
  }

  ngOnInit() {
    this.addCustomerForm = this.fb.group({});
    // Subscribe the Observables after success and set profile data
    this.addCustomerSubscription = this.customerService.customerListListner()
      .subscribe(
        (res) => {
          if (res.isSuccess === true) {
            this.router.navigate(['customer']);
          }
        }
      );

    this.sub = this.route.params.subscribe(params => {
      this.customerid = +params['id'];
    });

    if (this.routerName == 'EDIT-CUSTOMER') {
      this.getCustomerById();

      this.authService.getLoggedInUserPrivilege()
        .subscribe(
          (res) => {
            if (res.result != null && res.result.length != 0) {
              let permissionData = res.result;
              permissionData.resourceActionsPairs.forEach(value => {
                this.permissions[value.resourceName] = value.actions;
              })
            }
          })
    }

    this.customerService.getCountryCode()
      .subscribe(
        (res) => {
          if (res.result != undefined && res.result != null && res.result.length != 0) {
            this.countryList = res["result"];
          }
        }
      );

    this.customerListSubscription = this.customerService.customerListListner()
      .subscribe(
        (res) => {
          this.showGlobalError = false;
        }
      )
    let userObj: any = this.authService.getCurrentUserObj();
    //console.log("userObj",JSON.parse(userObj))
    //userObj = JSON.parse(userObj)
    // call getAllParentActiveUser from userService  
    this.userService.getAllParentActiveUser()
      .subscribe(
        (res) => {
          if (res["result"] != null && res["result"].length != 0) {
            this.customerOwnerList = res["result"];
            this.customerOwnerList = this.customerOwnerList.filter(x => x.userId != userObj.userId)
            this.customerOwnerList.unshift({ "userId": userObj.userId, "roleName": userObj.roleName, "fullName": userObj.fullName })
          }
        })
  }

  getCustomerById() {
    this.customerService.getCustomerById(this.customerid)
      .subscribe(
        (res) => {
          if (res["result"] != null) {
            this.customerDataById = res["result"];
            this.licences = this.customerDataById.licences != undefined && this.customerDataById.licences != null ? this.customerDataById.licences : [];
          }
        }
      );

  }

  setEditCustomerData() {
    let dataParams = {
      "custName": this.customerDataById.custName,
      "contactNo": this.customerDataById.contactNo,
      "address": this.customerDataById.address,
      "owner": this.customerDataById.ownerId,
      "status": this.customerDataById.status == null || this.customerDataById.status == 2 ? 0 : Number(this.customerDataById.status),
      "alternatePhoneNumber": this.customerDataById.alternatePhoneNumber,
      "contactNoCountryCode": this.customerDataById.contactNoCountryCode,
      "alternateNumberCountryCode": this.customerDataById.alternateNumberCountryCode,
      "pointOfContactName": this.customerDataById.pointOfContactName,
      "pointOfContactEmail": this.customerDataById.pointOfContactEmail,
      "pointOfContactMobile": this.customerDataById.pointOfContactMobile,
      "pointOfContactCountryCode": this.customerDataById.pointOfContactCountryCode,
      "pointOfContactStatus": this.customerDataById.pointOfContactStatus
    }
    this.addCustomerForm.patchValue(dataParams);
  }



  addCustomer(value) {
    this.forSubmitted = true;
    this.showGlobalError = true;
    if (this.showGlobalError) { // page scroll bottom to top
      window.scrollTo(0, 0)
    }
    // if in edit customer previous saved date(for licenceStartDate) is past date forcefully set errors null to submit form
    /* if( this.addCustomerForm.get('licenceStartDate').errors != null && this.addCustomerForm.get('licenceStartDate').errors.bsDate != null && this.routerName == 'EDIT-CUSTOMER'){
        this.addCustomerForm.get('licenceStartDate').setErrors(null);
    } */
    if (this.addCustomerForm.invalid) {
      return;
    } else {
      this.forSubmitted = false;
      console.log("value", value)
      let dataParams = {
        "custName": value.custName,
        "contactNo": value.contactNo,
        "address": value.address,
        "ownerId": value.owner,
        "status": value.status == null || Number(value.status) == 0 ? 2 : Number(value.status),
        //"numberOfLicence": value.numberOfUsers,                 
        //"licenceStartDate":moment(value.licenceStartDate).valueOf(),    
        //"licenceEndDate": moment(value.licenceEndDate).valueOf(),     
        "alternatePhoneNumber": value.alternatePhoneNumber,
        "contactNoCountryCode": value.contactNoCountryCode != null && value.contactNoCountryCode.name != undefined ? value.contactNoCountryCode.name : value.contactNoCountryCode,
        "alternateNumberCountryCode": value.alternateNumberCountryCode != null && value.alternateNumberCountryCode.name != undefined ? value.alternateNumberCountryCode.name : value.alternateNumberCountryCode,
        "pointOfContactName": value.pointOfContactName,
        "pointOfContactEmail": value.pointOfContactEmail,
        "pointOfContactMobile": value.pointOfContactMobile,
        "pointOfContactCountryCode": value.pointOfContactCountryCode.name != undefined ? value.pointOfContactCountryCode.name : value.pointOfContactCountryCode,
        "pointOfContactStatus": value.pointOfContactStatus == null || value.pointOfContactStatus == undefined ? 1 : Number(value.pointOfContactStatus)
      }
      if (this.routerName != 'EDIT-CUSTOMER') {
        dataParams["numberOfLicence"] = value.numberOfUsers;
        dataParams["licenceStartDate"] = moment(value.licenceStartDate).valueOf();
        dataParams["licenceEndDate"] = moment(value.licenceEndDate).valueOf();
        dataParams["status"] = 1;
        this.customerService.addCustomer(dataParams);
      } else {
        this.customerService.updateCustomerById(this.customerid, dataParams);
      }
    }
  }

  ngOnDestroy() {
    // prevent memory leak when component destroyed
    this.addCustomerSubscription.unsubscribe();
    this.customerListSubscription.unsubscribe();
    this.userSubscription.unsubscribe();
  }

}
