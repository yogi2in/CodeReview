import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemotePeerConnectionStatsComponent } from './remote-peer-connection-stats.component';

describe('RemotePeerConnectionStatsComponent', () => {
  let component: RemotePeerConnectionStatsComponent;
  let fixture: ComponentFixture<RemotePeerConnectionStatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemotePeerConnectionStatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemotePeerConnectionStatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
