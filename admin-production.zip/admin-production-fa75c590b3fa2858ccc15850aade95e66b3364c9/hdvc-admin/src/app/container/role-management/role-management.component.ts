import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { RoleManagementService } from './role-management.service';
import { environment } from '../../../environments/environment';
import { Route, Router, ActivatedRoute} from '@angular/router';
import { LocalStorageService } from 'angular-2-local-storage';
declare var $;

@Component({
  selector: 'app-role-management',
  templateUrl: './role-management.component.html',
  styleUrls: ['./role-management.component.css']
})
export class RoleManagementComponent implements OnInit {
  private roleSubscription = new Subscription();
  roleList = [];
  fields = [
    "Role Name",
    "Role Description",
    "Created By",
    "Action"
  ]
  // paginator params
  currentPage = 1;
  numPerPage = environment.NUMBER_PER_PAGE;
  totalItem;
  roleDetails;
  permissions = {"User Management":"PANASONIC_ADMIN", "Enterprise Management": "CUSTOMER", "Licence Management": "LICENCE"};
  actions = {"Create":"ADD", "View":"VIEW", "Edit/Renew":"EDIT", "Delete":"DELETE"};
  rolePermission = {"PANASONIC_ADMIN":{}, "CUSTOMER":{}, "LICENCE":{}};
  showGlobalError = false;
  public selectedRoleId;

  constructor(
    private roleService : RoleManagementService, 
    private router: Router, 
    private localStorageService: LocalStorageService,
    private activeRouter: ActivatedRoute) { 
      
    }

  ngOnInit() {
    this.roleSubscription = this.roleService.roleProcessListener()
    .subscribe(
      (res) => {
        if (res.isSuccess === true){
            this.roleList = res.data["list"];
            if(res.data["paginator"] != undefined && res.data["paginator"].totalItemCount){
              this.totalItem = res.data["paginator"].totalItemCount;
              this.currentPage = res.data["paginator"].currentPage;
            }
        }
      },
      (error) => {
        this.showGlobalError = true;
      }
    );

    // The below code check the user is coming form edit-role page or not, 
    //if user coming other page then remove the pageNumber from localstorage 

    let previouslySavedPagenumber;
    this.activeRouter.queryParams.subscribe(
      (res) => {
        console.log(res.roleEdit)
        if(res.roleEdit === 'true') {
          previouslySavedPagenumber = this.localStorageService.get('pageNumber');
          return
        } else {
          this.localStorageService.remove('pageNumber');
        }
      }
    )

    if(previouslySavedPagenumber != null && previouslySavedPagenumber != undefined){
      this.roleService.getAllRoles(previouslySavedPagenumber,this.numPerPage);
    } else {
      this.roleService.getAllRoles(this.currentPage,this.numPerPage);
    }
    
  }

  isAllChecked(){
    return false;
  }

  checkAll($event){

  }

  getNextPageData(pageNumber){
    this.roleService.getAllRoles(pageNumber,this.numPerPage);
  }

  editRole(roleId){
    this.localStorageService.set('pageNumber', this.currentPage);
    this.router.navigate(['edit-role',roleId])
  }

  deleteRole(roleId){
    this.showGlobalError = true;
    this.roleService.deleteRole(roleId)
    .subscribe(
      (res) => {
        $('#delete-role-modal').modal('hide');
        this.roleService.getAllRoles(this.currentPage,this.numPerPage);
      },
      err => {
        $('#delete-role-modal').modal('hide');
      }
    );
  }

  ViewRole(id){
    this.showGlobalError = true;
    this.roleService.getRoleById(id)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            this.roleDetails = res["result"];
            if(this.roleDetails.isSuperUser){
              Object.entries(this.roleDetails.resourceActionsPairs).forEach(([key, value]) => {
                let response: any = value;
                this.rolePermission[response.resourceName]["ADD"] =true;
                this.rolePermission[response.resourceName]["VIEW"] =true;
                this.rolePermission[response.resourceName]["DELETE"] =true;
                this.rolePermission[response.resourceName]["EDIT"] =true;
              })
            }else{
              Object.entries(this.roleDetails.resourceActionsPairs).forEach(([key, value]) => {
                let response: any = value;
                Object.entries(response.actions).forEach(y =>
                  {
                    this.rolePermission[response.resourceName][y[0]] = y[1]
                  })
              });
            }
            $('#view-role-modal').modal('show');
          }

        })
  }

  getPagingOffset(){
    let pageLabel;
    let firstLabel = 1+this.numPerPage*(this.currentPage-1);
    let secondLabel = (1+this.numPerPage*(this.currentPage-1))+(this.roleList.length-1);
    if(firstLabel == secondLabel){
      return firstLabel;
    }else{
      let pageLabel = firstLabel +"-"+secondLabel;
      return pageLabel;
    }
  }

  ngOnDestroy(){
    // prevent memory leak when component destroyed
    this.roleSubscription.unsubscribe();
  }

}
