import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
//import * as moment from 'moment';
import * as moment from 'moment-timezone';
import { CustomValidators } from '../../shared/custom-validation/customValidators';
import { SocketService } from '../../shared/services/socket.service';
import { Router, ActivatedRoute } from '@angular/router';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { environment } from 'src/environments/environment';
import { ScheduleMeetingService } from './schedule-meeting.service';
import { UtilService } from '../../shared/services/utils.services';
import { type } from 'os';
declare var $;


@Component({
  selector: 'app-schedule-meeting',
  templateUrl: './schedule-meeting.component.html',
  styleUrls: ['./schedule-meeting.component.css']
})

export class ScheduleMeetingComponent implements OnInit {
  // assigning some initial values
  // formname is FormGroup oject
  scheduleMeetingForm: FormGroup;
  // initial value of form submitt true
  submitted = false;
  // error object
  error = {};
  // meeting time day of week
  daysList = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  // used in create dynamic form control
  dynamicControl;
  // add Participant submitted by default false
  addParticipantSubmitted = false;
  // initializing some data type for store data
  participantList: any;
  participantObj: any;
  socketUrl: any;

  meetingId: any;
  hostOrigin = environment.HOST;
  meetingUrl: string;
  startHours: number;
  startMinutes: number;
  isUserAlreadyAdded: boolean;
  isHowManyParticipantError: boolean;
  defaultParticipant: any;
  maximumParticipant: any;
  isBackTimeError: boolean;
  emailId: string;
  isDurationError: boolean;
  txtSchedule: string;
  public isRecurringAll: boolean = false;
  public isRecurringSingle: boolean = false;
  public isDaysError: boolean = false;
  public minDate = moment().toDate();
  public isDailyMeetingDurationError: boolean = false;
  public isWeeklyMeetingDurationError: boolean = false;
  public isMonthlyMeetingDurationError: boolean = false;
  private editMeetingId: any;
  public getMeetingDetails: any;
  public zone: string = moment.tz(moment.tz.guess()).zoneAbbr();
  public recurringSelected: any;
  public reScheduleMeeting;
  public reScheduleMeetingMessage: any;
  public disableBtn: boolean = false;
  public audioBtnInfo = 'ON';
  public videoBtnInfo = 'ON';
  public maxParticipants: any;
  private userInfo: any;
  public showPollModel: boolean = false;
  private dateNotAvailable: boolean = true;
  public effectiveDateStart;
  private clearSetTimeOut;
  /**
   * constructor function for dependencies injection
   * */
  constructor(
    public _bsDatePickerConfig: BsDatepickerConfig,
    private _scheduleMeetingService: ScheduleMeetingService,
    private router: Router,
    private utils: UtilService,
    private activeRouter: ActivatedRoute) {
    this.participantList = [];

    this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
    this._bsDatePickerConfig.showWeekNumbers = false;
    this.maximumParticipant = new Array(environment.MAX_PARTICIPANTS + 1).fill(1, 0, environment.MAX_PARTICIPANTS + 1).map((x, i) => i);
    this.defaultParticipant = environment.DAFAULT_MAX_PARTICIPANTS;
    this.userInfo = this.getUserInfo();
    this.emailId = this.userInfo.email;
  }

  /**
    ngOnInit function
  */
  ngOnInit() {
    this.txtSchedule = "Schedule";
    this.buildForm(); // creating form for form control and added validatons
    moment.tz.setDefault(moment.tz.guess()); //set the default time zone

    this.activeRouter.params.subscribe(
      (res) => {
        this.editMeetingId = res.meetingId;
        console.log(res);
      }
    )
    this.activeRouter.queryParams.subscribe(
      (res) => {
        this.isRecurringAll = res.recurringAll === "yes" ? true : false;
        this.isRecurringSingle = res.recurringSingle === "yes" ? true : false;
      }
    )
    
  }

  ngAfterContentInit() {
    if (this.editMeetingId != null && this.editMeetingId != undefined) {
      this.getEditMeeting();
    }    
  }


  /*
  * The below function call when edit a meeting.
  */
  getEditMeeting() {
    this._scheduleMeetingService.getEditMeetingDetails(this.editMeetingId, this.isRecurringSingle).subscribe(
      (res) => {
        // document.getElementById('collapseMeetingSettings').classList.add('show');
        // document.getElementById('meetingSettings').classList.remove('collapsed');
        this.getMeetingDetails = res;
        this.txtSchedule = "Update";

        let meetingDetailsData = this.getMeetingDetails.body.data[0];
        let start_date = meetingDetailsData.start_date + meetingDetailsData.start_time;
        let end_date = meetingDetailsData.end_date + meetingDetailsData.start_time;
        let start_time_value = this.convertUTCDateToLocalTime(start_date);
        let start_date_value = moment(this.convertUTCDateToLocalDate(start_date)).format("YYYY-MM-DD");
        let end_date_value = moment(this.convertUTCDateToLocalDate(end_date)).format("YYYY-MM-DD");
        let default_layout = meetingDetailsData.default_layout != undefined && typeof meetingDetailsData.default_layout === 'number' ? meetingDetailsData.default_layout.toString() : meetingDetailsData.default_layout;
        this.audioBtnInfo = meetingDetailsData.default_audio != undefined && meetingDetailsData.default_audio === 1 ? "ON" : "OFF";
        this.videoBtnInfo = meetingDetailsData.default_video != undefined && meetingDetailsData.default_video === 1 ? "ON" : "OFF";
        let set_duration = (meetingDetailsData.duration).split(':');
        let emailId = meetingDetailsData.email_id !== undefined && typeof meetingDetailsData.email_id === 'string' ? meetingDetailsData.email_id.split(',') : [];
        let recurrence_type = meetingDetailsData.recurrence_type !== undefined && typeof meetingDetailsData.recurrence_type === 'number' ? meetingDetailsData.recurrence_type.toString() : meetingDetailsData.recurrence_type;
        start_date_value = start_date_value.split("-").reverse().join("-");
        end_date_value = end_date_value.split("-").reverse().join("-");
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          document.getElementById("addedParticipants").innerHTML = emailId.length;
        }, 1000);

        let default_audio;
        let default_video;
        let weekSelect;
        let recurrence_week;

        if (meetingDetailsData.default_audio === 1) {
          default_audio = true;
        } else {
          default_audio = false;
        }
        if (meetingDetailsData.default_video === 1) {
          default_video = true;
        } else {
          default_video = false;
        }

        if (this.isRecurringAll) {
          let recurrence_day_Split = meetingDetailsData.recurrence_day.split(',').map((val, key) => { return val !== undefined && val === 'true' ? true : null });

          weekSelect = meetingDetailsData.recurrence_day !== undefined && typeof meetingDetailsData.recurrence_day === 'string' ? recurrence_day_Split : [];
          recurrence_week = meetingDetailsData.recurrence_week !== undefined && meetingDetailsData.recurrence_week !== null ? meetingDetailsData.recurrence_week : [];

          if (meetingDetailsData.recurring_meeting === 1) {
            this.recurringSelected = true;
          } else {
            this.recurringSelected = false;
          }
        } else {
          this.recurringSelected = false;
        }

        if (emailId !== undefined && emailId.length >= 1) {
          emailId.map((email, key) => {
            this.participantList.unshift(email);
          })
        }

        this.scheduleMeetingForm.patchValue({
          title: meetingDetailsData.title,
          description: meetingDetailsData.description,
          participant_number: meetingDetailsData.participant_number,
          start_date: start_date_value,
          meetingStartTime: {
            meetingStartHour: start_time_value.newHr,
            meetingStartHourFormat: start_time_value.newMin
          },
          end_date: end_date_value,
          meetingEndTime: {
            meetingEndHour: +set_duration[0],
            meetingEndHourFormat: +set_duration[1]
          },
          participantName: [],
          default_layout: default_layout,
          default_audio: default_audio,
          default_video: default_video
        })

        if (this.recurringSelected) {
          this.scheduleMeetingForm.patchValue({
            recurring: {
              recurring_meeting: this.recurringSelected,
              recurrence_type: recurrence_type,
              recurrence_day: weekSelect,
              recurrence_week: recurrence_week,
            },
          });
          clearTimeout(this.clearSetTimeOut);
          this.clearSetTimeOut = setTimeout(() => {
            this.autoTriggerToSelectDay(weekSelect);
          }, 500);

        }

      }
    )
  }

  autoTriggerToSelectDay(days: any): void {
    if (days !== undefined) {
      days.map((dayChecked, idx) => {
        if (dayChecked === true) {
          console.log('---- ', $('.day_item_'+idx));
          $('.day_item_'+idx).trigger("click");
        }
      })
    }
  }

  /*
  * The Below function convert UTC Date to local date.
  */
  convertUTCDateToLocalDate(date) {
    let newDate = new Date(date)
    return newDate;
  }

  /*
  * The Below function convert UTC Time to local time.
  */
  convertUTCDateToLocalTime(date) {
    let newHr = new Date(date).getHours();
    let newMin = new Date(date).getMinutes();
    let newTime = { newHr, newMin };
    return newTime;
  }

  /**
    This function creating the form control and added validation on each form control
   */
  public buildForm() {
    this.setDefaultMeetingTime();
    // creating dynamic form control used in form array for week list checkboxes
    const dynamicControl = this.daysList.map(c => new FormControl(false));
    this.maximumParticipant.shift();
    this.maximumParticipant.shift();
    // initializing FormGroup and setting each form control value and validation(default) and custom validation
    this.scheduleMeetingForm = new FormGroup({
      title: new FormControl(null, [Validators.required, Validators.maxLength(100), this.removeSpaceKey]),
      description: new FormControl(null, [Validators.maxLength(200)]),
      participant_number: new FormControl(this.defaultParticipant),
      start_date: new FormControl(new Date(), Validators.required),
      meetingStartTime: new FormGroup({
        meetingStartHour: new FormControl(this.startHours),//this.startTime),
        meetingStartHourFormat: new FormControl(this.startMinutes)//this.startMeridiem)
      }),

      //end_date: new FormControl(new Date(), {validators: [Validators.required, CustomValidators.compareDate]}),
      end_date: new FormControl(new Date(), { validators: [Validators.required] }),
      meetingEndTime: new FormGroup({
        meetingEndHour: new FormControl(0),
        meetingEndHourFormat: new FormControl(15)
      }),

      recurring: new FormGroup({
        recurring_meeting: new FormControl(),//{value: false, disabled: true}
        recurrence_type: new FormControl('1'),
        recurrence_day: new FormArray(dynamicControl),
        recurrence_week: new FormControl(1),
      }),
      participantName: new FormControl(null, [Validators.email]),
      default_layout: new FormControl('2'),
      default_audio: new FormControl(true),
      default_video: new FormControl(true)
    });

    //document.getElementById('addedParticipants').innerHTML = '0';
    //document.getElementById('maxParticipants').innerHTML = environment.DAFAULT_MAX_PARTICIPANTS.toString();
    this.maxParticipants = environment.DAFAULT_MAX_PARTICIPANTS.toString();
  }

  /*
  * The below function call when audio or video btn clicked.
  */
  changeValueOnOffBtn() {
      clearTimeout(this.clearSetTimeOut);
      this.clearSetTimeOut = setTimeout(() => {
      this.audioBtnInfo = this.scheduleMeetingForm.value.default_audio != undefined && this.scheduleMeetingForm.value.default_audio === true ? 'ON' : 'OFF';
      this.videoBtnInfo = this.scheduleMeetingForm.value.default_video != undefined && this.scheduleMeetingForm.value.default_video === true ? 'ON' : 'OFF';
    }, 20)
  }

  getUserInfo(): any {
    return this.utils.getInfoFromStorage('localStorage', 'currentUser');
  }

  recurringMeeting(e) {
    this.isRecurringAll = e.target.checked;
    this.setMeetingEndDate("D");
  }

  setMeetingEndDate(meetingFreqyency) {
    switch (meetingFreqyency) {
      case "D":
        this.scheduleMeetingForm.controls.end_date.setValue(moment().add(7, 'd').toDate());
        break
      case "W":
        this.scheduleMeetingForm.controls.end_date.setValue(moment().add(1, 'M').format("DD-MM-YYYY"));
        break
      case "M":
        this.scheduleMeetingForm.controls.end_date.setValue(moment().add(6, 'M').format("DD-MM-YYYY"));
        break
    }
  }

  /**
    This function used to check the back time
   */
  checkMeetingTime() {
    this.isBackTimeError = false;
    let meetingTime = this.scheduleMeetingForm.controls.meetingStartTime.get("meetingStartHour").value + ":" + this.scheduleMeetingForm.controls.meetingStartTime.get("meetingStartHourFormat").value;
    let currentTime = moment.duration(moment().format("HH:mm"), "HH:mm");
    let meetingStartTime = moment.duration(meetingTime, "HH:mm");
    let difference = meetingStartTime.subtract(currentTime);
    let minutesDiff = difference.minutes();
    let startDate = moment.tz(this.scheduleMeetingForm.controls.start_date.value, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    let currentDate = moment.tz(this.minDate, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    let start = moment(startDate);
    let end = moment(currentDate);
    let duration = moment.duration(start.diff(end));
    let durationDays = duration.asDays();
    if (durationDays <= 0 && minutesDiff < 0) {
      this.isBackTimeError = true;
      return;
    }
    return this.isBackTimeError;
  }

  /**
   * check the meeting duration
   */
  checkMeetingDuration() {
    this.isDurationError = false;
    let hour = this.scheduleMeetingForm.controls.meetingEndTime.get("meetingEndHour").value;
    let min = this.scheduleMeetingForm.controls.meetingEndTime.get("meetingEndHourFormat").value;
    if (hour == 0 && min == 0) {
      this.isDurationError = true;
    }
    return this.isDurationError;
  }

  /**
   * check the meeting days are selected
   */
  isDaysSelected(recurring) {
    if (recurring.recurring_meeting && recurring.recurrence_type != "1") {
      if (recurring.recurrence_day.indexOf(true) > -1) {
        this.isDaysError = false;
      } else {
        this.isDaysError = true;
      }
      // this.isDaysError = !recurring.recurrence_day.indexOf(true);
      console.log("Date Error");
    }
    return this.isDaysError;
  }

  updateRecuringDataForMonthly(recurring) {
    if (recurring.recurrence_type !== "3") {
      return recurring;
    }
    let newMonthlyDay = [null, null, null, null, null, null, null];
    let continueLooping: boolean = true;
    recurring.recurrence_day = recurring.recurrence_day.map((dayNumber: any, idx: any) => {
      if (continueLooping === true) {
        if (dayNumber !== null) {
          if (typeof dayNumber === 'boolean') {
            newMonthlyDay.splice(idx, 1, true); // return true;
            continueLooping = false;
          } else {
            newMonthlyDay.splice(dayNumber, 1, true);
            continueLooping = false;
          }

        }
      }

    }) ;
    recurring.recurrence_day =  newMonthlyDay;
    //console.log("6+6+6+6+6+6+6", recurring)
    //     this.isDaysError = !newMonthlyDay.includes(true);
    // if (recurring.recurring_meeting && recurring.recurrence_type != "1") {
    //   if (recurring.recurrence_type === 2) {
    //     this.isDaysError = !recurring.recurrence_day.includes(true);
    //   } else {

    //   }

    //   console.log("Date Error");
    // }
    // return this.isDaysError;
    return recurring;
  }

  canRecurringMeetingHappen(recurring) {
    this.scheduleMeetingForm.value;
    this.isDailyMeetingDurationError = false;
    this.isWeeklyMeetingDurationError = false;
    this.isMonthlyMeetingDurationError = false;
    let startDate;

    if (this.scheduleMeetingForm.controls.start_date.value.length == 10) {
      let startDateVal = this.scheduleMeetingForm.controls.start_date.value.split("-").reverse().join("-");
      startDate = moment.tz(startDateVal, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    }
    else {
      let startDateVal = moment.tz(this.scheduleMeetingForm.controls.start_date.value, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");;//moment.tz(this.scheduleMeetingForm.controls.end_date.value, "fulldate", moment().tz()).format("YYYY-MM-DD");
      startDate = moment.tz(startDateVal, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    }

    let endDate;
    if (this.scheduleMeetingForm.controls.end_date.value.length == 10) {
      let endDateVal = this.scheduleMeetingForm.controls.end_date.value.split("-").reverse().join("-");
      endDate = moment.tz(endDateVal, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    }
    else {
      let endDateVal = moment.tz(this.scheduleMeetingForm.controls.end_date.value, "fulldate", moment().tz()).format("YYYY-MM-DD");
      endDate = moment.tz(endDateVal, "YYYY-MM-DD", moment().tz()).format("YYYY-MM-DD");
    }
    var start = moment(startDate);
    var end = moment(endDate);
    var duration = moment.duration(end.diff(start));
    if (recurring.recurring_meeting) {
      let days = duration.asDays();
      days = days + 1;
      switch (recurring.recurrence_type) {
        case "1":
          if (days < 2) {
            this.isDailyMeetingDurationError = true;
          }
          break;
        case "2":
          if (days < 15) {
            this.isWeeklyMeetingDurationError = true;
          }
          break;
        case "3":
          if (days < 60) {
            this.isMonthlyMeetingDurationError = true;
          }
      }
    }
  }

  /**
   default funtion returning the all controls used on html for validation and error msgs
   */
  get f() {
    return this.scheduleMeetingForm.controls;
  }

  /* This functionis checking validation on dates(start and end) on form submit */
  setValidatorOnSubmit() {
    const meetingEndDate = this.scheduleMeetingForm.controls.end_date;
    //on form submitt again checking the date
    meetingEndDate.setValidators([Validators.required, CustomValidators.compareDate]);
    //update validator and value
  }

  /**
   This function called on form submitt for scheduling meeting
    */
  schedule() {
    this.submitted = true;
    //this.setValidatorOnSubmit();
    this.addParticipantSubmitted = false;
    let data = this.scheduleMeetingForm.value;
    data.recurring = this.updateRecuringDataForMonthly(data.recurring);

    this.canRecurringMeetingHappen(data.recurring);
    if (this.scheduleMeetingForm.invalid
      || this.participantList.length == 0
      || this.isHowManyParticipantError
      || this.checkMeetingTime()
      || this.checkMeetingDuration()
      || (data !== undefined && this.isDaysSelected(data.recurring))
      || this.isDailyMeetingDurationError
      || this.isWeeklyMeetingDurationError
      || this.isMonthlyMeetingDurationError || this.isBackTimeError
    ) {
      return;
    } else {
      this.txtSchedule = "Processing...";
      this.disableBtn = true;
      let startDateVal = this.scheduleMeetingForm.controls.start_date.value;



      if (startDateVal.length == 10) {
        startDateVal = startDateVal.split("-").reverse().join("-");
      }
      else {
        startDateVal = moment.tz(startDateVal, "fulldate", moment().tz()).format("YYYY-MM-DD");
      }

      let data = this.scheduleMeetingForm.value;
      data.description = data.description == null ? '' : data.description;//.replace(/(?:\r\n|\r|\n|\↵)/g, '<br>');
      let startDate = moment(startDateVal).format("YYYY-MM-DD") + " " + data.meetingStartTime.meetingStartHour + ":" + data.meetingStartTime.meetingStartHourFormat;

      data.start_date = moment.tz(startDate, "YYYY-MM-DD HH:mm", moment().tz()).utc().format();
      data["start_time"] = "T" + data.start_date.split("T")[1];
      data.start_date = data.start_date.split("T")[0];



      if (data.recurring.recurring_meeting == true) {
        if (data.end_date.length == 10) {
          let endDateVal = data.end_date.split("-").reverse().join("-");
          data.end_date = endDateVal;
        }
        else {
          let endDateVal = moment.tz(data.end_date, "fulldate", moment().tz()).format("YYYY-MM-DD");
          data.end_date = endDateVal;
        }
      }
      else {
        data.recurring.recurring_meeting = false;
        data.end_date = null;
        data.recurring.recurrence_type = 0;
        data.recurring.recurrence_week = null;
        data.recurring.recurrence_day = null;
      }
      let durationMinutes = data.meetingEndTime.meetingEndHourFormat;
      durationMinutes = moment(data.meetingEndTime.meetingEndHour + ":" + durationMinutes + ":" + "00: AM", 'hh:mm:ss: A').format("mm");
      let durationHour = data.meetingEndTime.meetingEndHour < 10 ? "0" + data.meetingEndTime.meetingEndHour : data.meetingEndTime.meetingEndHour;
      data["duration"] = durationHour  + ":" + durationMinutes;
      data["creator_meeting_emailid"] = this.emailId;
      data["email_id"] = this.participantList;
      //delete data.recurring;
      //delete data.participantName;
      //delete data.meetingEndTime;
      //delete data.meetingStartTime;

      data["default_audio"] = data["default_audio"] == false ? 0 : 1;
      data["default_video"] = data["default_video"] == false ? 0 : 1;
      data["customer_id"] = this.userInfo.customerId;
      data["customer_name"] = this.userInfo.customerName;
      
      if (!this.editMeetingId) {
        this._scheduleMeetingService.scheduleMeeting(data)
          .subscribe(
            (result: any) => {
              if (result.meeting_refid !== undefined) {
                this.meetingUrl = this.hostOrigin + '/join-meeting/' + result.meeting_refid;
              }
            },
            error => {
              console.log("Error", error);
            });
      } else {

        if (this.isRecurringSingle) {
          data["meeting_id"] = this.editMeetingId;
        } else {
          data["meeting_refid"] = this.editMeetingId;
        }

        this._scheduleMeetingService.updateMeeting(data)
          .subscribe(
            (result: any) => {
              this.reScheduleMeeting = true;
              this.reScheduleMeetingMessage = "Meeting updated Successfully!"
            },
            error => {
              console.log("Error", error);
            });
      }

    }
  }

  /**
    This function called for get meeting id
  */
  getMeetingId(url) {
    if (url !== undefined && typeof url === 'string') {
      const splitUrl = url.split('/');
      if (typeof splitUrl === 'object' && Array.isArray(splitUrl) === true) {
        return splitUrl[3];
      }
    }
  }

  /**
    This function is used to navigate the user to join meeting route
  */
  joinMeeting(meetingId) {
    if (meetingId !== undefined) {
      this.router.navigate(['/join-meeting', this.meetingId]);
    }
  }

  /**
    This function is used to get the selected days if the meeting
  */
  getSelectedWeekDays(weeklyRecurrenceDay) {
    let selectedWeekDaysForMeeting = weeklyRecurrenceDay.map((isSelected, i) => isSelected ? i + 1 : null)
      .filter(v => v !== null);
    return selectedWeekDaysForMeeting;
  }

  /**
    This function is execute on click of add participate button
  */
 
  addParticipant(event) {
    this.addParticipantSubmitted = true;
    this.isUserAlreadyAdded = false;
    if (this.scheduleMeetingForm.controls.participant_number.value == this.participantList.length) {
      return;
    }

    if (this.scheduleMeetingForm.controls.participantName.value != null && this.scheduleMeetingForm.controls.participantName.value != "" && this.scheduleMeetingForm.controls.participantName.valid) {
      let participantName = this.scheduleMeetingForm.controls.participantName.value.toLowerCase();
      if (this.participantList.length === 0 || this.participantList.indexOf(participantName) === -1) {
        this.participantList.unshift(participantName);

        this.scheduleMeetingForm.controls.participantName.patchValue(null);
        this.addParticipantSubmitted = false;
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          document.getElementById("addedParticipants").innerHTML = this.participantList.length;
        }, 100);
      }
      else {
        this.isUserAlreadyAdded = true;
      }
    }

    event.preventDefault();
  }

  /**
   This function execute for remove participant
   * */
  removeParticipant(index) {
    this.participantList.splice(index, 1);
    document.getElementById("addedParticipants").innerHTML = this.participantList.length > 0 ? this.participantList.length : "";
  }

  /**
   * When user close the modal, reset the form and meeting url
   */
  onCloseModal() {
    this.submitted = false;
    this.scheduleMeetingForm.reset();
    delete this.meetingUrl;
    this.router.navigate(['/my-meetings']);
  }

  /**
   * set the maximum participants
   */
  onParticipantChange() {
    this.isHowManyParticipantError = false;

    if (this.scheduleMeetingForm.controls.participant_number.errors) {
      return;
    }

    const participantNumber = this.scheduleMeetingForm.controls.participant_number.value;
    if (participantNumber < this.participantList.length) {
      this.isHowManyParticipantError = true;
    } else {
      document.getElementById("maxParticipants").innerHTML = participantNumber;
    }
  }

  /**
    set the default meeting time
  */
  setDefaultMeetingTime() {
    let currentTime = moment().add('m', 30).format("HH:mm");
    this.startHours = parseInt(currentTime.split(":")[0]);
    this.startMinutes = parseInt(currentTime.split(":")[1]);
  }

  /**
    clear the selected days
  */
  clearSelectedDays(frequency) {
    const days = this.scheduleMeetingForm.controls.recurring.get("recurrence_day");
    days.reset();
    this.isDaysError = false;
    this.setMeetingEndDate(frequency);
  }

  /**
   * change varible values
   */
  changeValue() {
    this.addParticipantSubmitted = false;
    this.isUserAlreadyAdded = false;
  }

  /**
   * The below function work on select monthly recurring meeting, calculate occurrence(s) meeting count, 
   * and schedule the effective start date.
   */
  effectiveDate() {

      clearTimeout(this.clearSetTimeOut);
      this.clearSetTimeOut = setTimeout(() => {
      let dayNum;
      //let monthArr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      let data = this.scheduleMeetingForm.value;
      let recurring = this.updateRecuringDataForMonthly(data.recurring);
      let recurrence_week = data.recurring.recurrence_week;
      recurring.recurrence_day.forEach((val, idx) => {
        if (val === true) {
          dayNum = idx;
        }
      });

      if (dayNum != null && dayNum != undefined) {
        // continue
      } else {
        return;
      }

      let isDaySelect = this.daysList[dayNum];
      let currentDate = new Date();//new Date(2019, 11, 25);
      let currentActualDate = moment(currentDate).format('DD-MM-YYYY');
      let currentMonthNumber = currentDate.getMonth();
      let currentYear = currentDate.getFullYear();
      let currentMonthNumOf = currentMonthNumber + 1;
    
      let nextMonthNumber = currentMonthNumOf + 1;
      if (nextMonthNumber == 12 || nextMonthNumber > 12) {
        nextMonthNumber = 0
      }

      let getSelectCurrentMonthDate = moment(this.getMonthlyWeekday(recurrence_week, isDaySelect, currentMonthNumOf, currentYear)).format('DD-MM-YYYY');


      let setStartMonthDate;
      let getSelectNextMonthDate
      const generatedDateFormat = this.getDateOfSchedule(nextMonthNumber, currentYear, currentDate, getSelectCurrentMonthDate, recurrence_week, isDaySelect, currentMonthNumOf);

      let isDateExceptable = this.checkDate(generatedDateFormat, currentActualDate);
      if (isDateExceptable && this.dateNotAvailable == true) {
        setStartMonthDate = generatedDateFormat;
        console.log("Greater", setStartMonthDate)
      } else {
        getSelectNextMonthDate = moment(this.getMonthlyWeekday(recurrence_week, isDaySelect, nextMonthNumber, currentYear)).format('DD-MM-YYYY');

        getSelectNextMonthDate = this.getDateOfSchedule(nextMonthNumber, currentYear, currentDate, getSelectNextMonthDate, recurrence_week, isDaySelect, currentMonthNumOf);

        setStartMonthDate = getSelectNextMonthDate;

      }

      this.scheduleMeetingForm.patchValue({
        start_date: setStartMonthDate
      })
      this.effectiveDateStart = setStartMonthDate;

    }, 500);

  }


  getDateOfSchedule(nextMonthNumber, currentYear, currentDate, getSelectCurrentMonthDate, recurrence_week, isDaySelect, currentMonthNumOf){
    if (this.dateNotAvailable == false) {
        if (nextMonthNumber == 12) {
          nextMonthNumber = 0
          currentYear = currentDate.getFullYear() + 1;
          getSelectCurrentMonthDate = moment(this.getMonthlyWeekday(recurrence_week, isDaySelect, nextMonthNumber, currentYear)).format('DD-MM-YYYY');
          return;
        }         
        
        if (getSelectCurrentMonthDate == 'Invalid date' || getSelectCurrentMonthDate == 'undefined') {
          if(recurrence_week == 5){
            getSelectCurrentMonthDate = moment(this.getMonthlyWeekday(4, isDaySelect, currentMonthNumOf, currentYear)).format('DD-MM-YYYY');
          } else {
            getSelectCurrentMonthDate = moment(this.getMonthlyWeekday(recurrence_week, isDaySelect, nextMonthNumber, currentYear)).format('DD-MM-YYYY');
            if(getSelectCurrentMonthDate == 'Invalid date'){
              getSelectCurrentMonthDate = moment(this.getMonthlyWeekday(4, isDaySelect, nextMonthNumber, currentYear)).format('DD-MM-YYYY');
            }
          }
        }
        this.dateNotAvailable = true;
      }
      return getSelectCurrentMonthDate
  }

  /*
  * The below function compare the two date generated date is greater then to currnet date.
  */
  checkDate(generatedDateFormat, currentActualDate) {
    let result = false;
    let splitDate1 = generatedDateFormat.split("-");
    let splitDate2 = currentActualDate.split("-");
    let date1, date2;
    if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
      date1 = new Date(splitDate1[2], splitDate1[1], splitDate1[0]);
      date2 = new Date(splitDate2[2], splitDate2[1], splitDate2[0]);
    }else {
      date1 = new Date(splitDate1[1]+" "+ splitDate1[0] + " " + splitDate1[2]);
      date2 = new Date(splitDate2[1]+" "+ splitDate2[0] + " " + splitDate2[2]);
    }

    if (date1.getTime() >= date2.getTime()) {
      result = true;
    }
    return result;
  }

  /*
  * The below function return actula date of the selected day like (24, 28, 31), 
  * pass argument is (week_number, selected_day, currentMonth, currentYear);
  */
  getMonthlyWeekday(n, d, m, y) {
    let daysInMonth = moment(y - m, 'YYYY-MM').daysInMonth();
    let targetDay, curDay = 0, 
        i = 0, 
        seekDay
    let week_num = parseInt(n, 10)

    if (d == "Sun") {
      seekDay = 0;
    }
    if (d == "Mon") {
      seekDay = 1;
    }
    if (d == "Tue") {
      seekDay = 2;
    }
    if (d == "Wed") {
      seekDay = 3;
    }
    if (d == "Thu") {
      seekDay = 4;
    }
    if (d == "Fri") {
      seekDay = 5;
    }
    if (d == "Sat") {
      seekDay = 6;
    }

  if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0){
    m = m - 1;
  }

    while (curDay < week_num && i <= daysInMonth) {
      if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0 && week_num == 5 ){
        targetDay = new Date(y,m,i++);   
      } else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
        targetDay = new Date(y,m,++i);    
      } else {
        targetDay = new Date(m + " " + ++i + " " + y) //new Date(y,m,i++);  
      }  

      if (targetDay.getDay() == seekDay) curDay++;
    }

    if(curDay == week_num){      
      this.dateNotAvailable = true;
      return targetDay;
    } else {
      this.dateNotAvailable = false;
      return false;
    }
  }

  /*
   * The below function control the space key when no any text enter in input box// control the whitespace.
  */
  removeSpaceKey(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    if (control && control.value && !control.value.replace(/\s/g, '').length){
      control.setValue('');
    }
    return isValid ? null : { 'whitespace': true };
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }

}