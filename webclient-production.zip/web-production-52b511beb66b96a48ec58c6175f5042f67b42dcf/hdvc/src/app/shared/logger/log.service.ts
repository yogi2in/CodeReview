import { Injectable } from '@angular/core';
import { LogPublishersService } from './log-publishers.service';
import { LogPublisher } from './log-publisher';
import { LogLevel } from './log.level.enums';
import { LogEntry } from './log.entry.class';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  // Public Properties
  publishers: LogPublisher[];
  level: any = environment.LOG_LEVEL;
  logWithDate: boolean = true;

  constructor(private _publisherService: LogPublishersService) {
    // set Publishers
    this.publishers = this._publisherService.publishers;
    this.shouldLog(LogLevel.All);
  }

  // Public methods

  debug(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, LogLevel.Debug, optionalParams);
  }

  info(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, LogLevel.Info, optionalParams);
  }

  warn(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, LogLevel.Warn, optionalParams);
  }

  fatal(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, LogLevel.Fatal, optionalParams);
  }

  log(msg: string, ...optionalParams: any[]) {
    this.writeToLog(msg, LogLevel.All, optionalParams);
  }

  clear(): void {
    for (let logger of this.publishers) {
      logger.clear()
        .subscribe( response => console.log(response));
    }
  }

  // *************************
  // Private methods
  // *************************
  private shouldLog(level: LogLevel): boolean {
    let ret: boolean = false;
    if (
      (this.level.indexOf(level) > -1) && level !== LogLevel.Off
    ) {
      ret = true;
    }

    return ret;
  }

  private writeToLog(msg: string, level: LogLevel, params: any[]) {
    if (this.shouldLog(level)) {
      let entry: LogEntry = new LogEntry();

      // Build Log Entry
      entry.message = msg;
      entry.level = level;
      entry.extraInfo = params;
      entry.logWithDate = this.logWithDate;

      for (let logger of this.publishers) {
        if (this.level.indexOf(entry.level) > -1) {
          logger.log(entry)
          .subscribe(
            (response: any) => {
                // console.log(response)
              }
            );
        }

      }
    }
  }
}
