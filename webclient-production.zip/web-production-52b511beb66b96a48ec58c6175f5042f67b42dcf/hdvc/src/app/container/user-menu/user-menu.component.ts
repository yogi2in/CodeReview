import { Component, OnInit, Output, EventEmitter, Input , OnDestroy} from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { UserService } from '../user/user.service';
import { Subscription } from 'rxjs';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.css']
})

export class UserMenuComponent implements OnInit, OnDestroy {

  @Output() public authSignOut = new EventEmitter();
  @Input() isCustomerAdmin;
  public profilePicSubscription = new Subscription();
  public profileImage;
  public userName;
  private clearSetTimeOut;
  
  constructor(
    private authService: AuthService, 
    private _userService: UserService,  
    private _utilService: UtilService,
    private router: Router
    ) { }

  ngOnInit() {
    let userData = this._utilService.getInfoFromStorage('localStorage', 'currentUser');
    this.profileImage = userData.profileImage;
    this.userName = userData.fullName;
    
    this.profilePicSubscription = this._userService.profilePicListener().subscribe(
      (res) => {
        this.profileImage = res.profilePic;
      }
    )
  }

  refreshProfilePicture(){
    this._userService.onCloseModal();
      clearTimeout(this.clearSetTimeOut);
      this.clearSetTimeOut = setTimeout(() => {
      this.router.navigate(['/user/my-profile']);
    }, 100)
    
  }

  signOut() {
    this.authService.signOut();
    this.authSignOut.emit(false);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.profilePicSubscription.unsubscribe();
    clearTimeout(this.clearSetTimeOut);
  }

}
