import { Injectable } from '@angular/core';
import { DOMModel } from '../model/dom.model';

@Injectable({providedIn: 'root'})

export class DOMHandlerService {
  constructor() {

  }

  /**
   * @description The following function will handle to create new element
   * */
  createElement(nodeInfo: DOMModel, parentNode: any): any {
    let newElement: any = null;
    if (nodeInfo === undefined || nodeInfo === null || typeof nodeInfo !== 'object' || parentNode === undefined || parentNode === null) {
      return null;
    }
    if (nodeInfo !== undefined && nodeInfo.nodeType !== undefined) {
      newElement = document.createElement(nodeInfo.nodeType);
      if (nodeInfo.classArr !== undefined && Array.isArray(nodeInfo.classArr) && nodeInfo.classArr.length > 0) {
        this.addClass(newElement, nodeInfo.classArr);
      }

      if (nodeInfo.attrs !== undefined && Array.isArray(nodeInfo.attrs) && nodeInfo.attrs.length > 0) {
        this.addAttribute(newElement, nodeInfo.attrs);
      }
      return parentNode.appendChild(newElement);
    }
  }

  /**
   * @description The below function will handle to add class to any element
   * @param element - HTML element on which class need to add
   * @param classList - list of class in array
   */
  addClass(element, classList) {
    if (element !== null && classList !== undefined) {
      classList.forEach((val, key) => {
        if (val.length > 1){
          element.classList.add(val);
        }
      });
    }
  }

  /**
   * @description The below function will handle to remove class to any element
   * @param element - HTML element on which class need to add
   * @param classList - list of class in array
   */
  removeClass(element, classList) {
    if (element !== null && classList !== undefined && Array.isArray(classList)) {
      classList.forEach((val, key) => {
        if (val.length > 1) {
          element.classList.remove(val);
        }
      });
    }
  }

  /**
   * @description The below function will handle to create
   * @param element
   * @param attrs
   */
  addAttribute(element: any, attrs: any) {
    if (element !== null && element !== undefined && Array.isArray(attrs)) {
      attrs.forEach((val, key) => {
        if (val.attrName !== undefined && val.attrVal !== undefined) {
          element.setAttribute(val.attrName, val.attrVal);
        }
      });
    }
  }
}
