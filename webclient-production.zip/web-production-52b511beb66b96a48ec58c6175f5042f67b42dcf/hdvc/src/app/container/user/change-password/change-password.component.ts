import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/shared/custom-validation/customValidators';
import { MyProfileService } from '../my-profile/my-profile.service';
import { AuthService } from 'src/app/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  // creates instance of FormGroup called ChangePasswordForm
  ChangePasswordForm: FormGroup;
  submittedPasswordForm = false;
  Errormsg:string;
  passMessage: any;
  private clearSetTimeOut;
  constructor(
    private fb: FormBuilder, 
    private myProfileService: MyProfileService, 
    private _objAuthService: AuthService,
    private router: Router) { }

  ngOnInit() {

    this.ChangePasswordForm = this.fb.group({
      'passwordGroup': this.fb.group({
       oldpassword: ['', [Validators.required]],
       newpassword: ['', [Validators.required,
       //Validators.pattern('^(?=.*[A-Z])(?=.*[!@#$&*\^%\*\.])(?=.*[0-9])(?=.*[a-z]).{8,}$')
       CustomValidators.strongpassword
       ]],
       confirmpassword: ['', [Validators.required]]
     }, {
       validator: CustomValidators.passwordMatcher // your validation method
     }),
   });




  }

  /* This function is called for save new password */
  public saveResetPassword() {
    if(this.ChangePasswordForm.controls.passwordGroup.get('newpassword').hasError('Strong')){
    this.ChangePasswordForm.controls.passwordGroup.get('newpassword').setErrors(null);
    }
    this.submittedPasswordForm = true;
    if (this.ChangePasswordForm.invalid) {
      return;
    } else {
      const resetpass = {
        oldPassword :this.ChangePasswordForm.controls['passwordGroup'].get('oldpassword').value,//"test@123",// need to ask for this
        newPassword: this.ChangePasswordForm.value.passwordGroup.newpassword
      };

      this.myProfileService.updateuserpassword(resetpass)
      .subscribe((response:any) => {
        this.submittedPasswordForm = false;
        this.passMessage = response.message;
        clearTimeout(this.clearSetTimeOut);
        this.clearSetTimeOut = setTimeout(() => {
          this.passMessage = false;
          this._objAuthService.signOut();
          this.router.navigate(['']); 
        }, 2000);
      },
      error => {
        this.Errormsg = error.message == "Validation Error" ? error.message.result[0].message : error.message;
        console.log('error', error);
      });
    }
  }

  hashPassword(password: string) {
    return '*'.repeat(password.length);
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }


}
