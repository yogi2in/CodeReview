/**
 * @description The below directive will handle to make the shared video layout whenever presenter shared
 *              his/her screen to any user.
 */
import { Directive, OnInit, OnDestroy, Renderer2, ElementRef, ViewChild } from '@angular/core';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[appScreenSharedLayoutHandler]'
})
export class ScreenSharedLayoutHandlerDirective implements OnInit, OnDestroy {
  private clsName = 'screen-shared-by';                 // cls to show shared participant video full width
  @ViewChild('participantWrapper') participantWrapper;  // get the reference to all template
  private screenSharedListenerSubs = new Subscription();

  constructor(
    private utilService: UtilService,
    private elemRef: ElementRef,
    private render: Renderer2) {}

  ngOnInit() {
    this.screenSharedListenerSubs = this.utilService.notifyScreenSharedListener().subscribe(
      (message: any) => {

        // setTimeout(() => {
        //   const sharedUserdWrapper = document.getElementById(message.message.userId);
        //   const layoutWrapper = document.querySelector('.left-sidebar.position-relative');
        //   if (message.message.share_scr === true) {
        //     this.render.addClass(this.elemRef.nativeElement, 'screen-shared-started');
        //     this.toggleClass(sharedUserdWrapper, this.clsName, true);
        //     this.toggleClass(layoutWrapper, 'layout-2', true);
        //   } else {
        //     this.render.removeClass(this.elemRef.nativeElement, 'screen-shared-started');
        //     this.toggleClass(sharedUserdWrapper, this.clsName, false);
        //     this.toggleClass(layoutWrapper, 'layout-2', false);
        //   }
        // });
      }
    );
  }

  toggleClass(element: any, clsName: string, toggleState: boolean) {
    if (element !== null) {
      if (toggleState === true) {
        this.render.addClass(element, clsName);
      } else  {
        this.render.removeClass(element, clsName);
      }
    }
  }


  ngOnDestroy() {
    this.screenSharedListenerSubs.unsubscribe();
  }
}
