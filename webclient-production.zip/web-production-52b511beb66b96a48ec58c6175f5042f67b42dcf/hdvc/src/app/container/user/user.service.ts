import { Injectable } from '@angular/core';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public userInfo: any;
  public profilePicUrl: string;
  public updateProfilePicUrl = new Subject<{profilePic: any}>();

  constructor(private _utilService: UtilService) {
    this.onCloseModal();
  }

  profilePicListener(){
    return this.updateProfilePicUrl.asObservable();
  }

  onCloseModal() {
    this.userInfo = this._utilService.getInfoFromStorage('localStorage', 'currentUser');
    this.profilePicUrl = this.userInfo.profileImage  + "?" + Math.random()* 100000000000000000000;
    this.updateProfilePicUrl.next({profilePic: this.profilePicUrl});
    return this.profilePicUrl;
  }






}
