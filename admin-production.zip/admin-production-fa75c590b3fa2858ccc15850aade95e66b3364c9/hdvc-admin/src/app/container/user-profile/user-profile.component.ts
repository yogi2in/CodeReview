import { Component, OnInit, Input } from '@angular/core';
import { ProfileService } from './profile.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  private userSubscription = new Subscription();
  public profileData: any;
  public profilePicUrl: string;
  loadEditProfile = false;
  showGlobalError = true;
  constructor(private profileService: ProfileService) { }

  ngOnInit() {
    // Subscribe the Observables after success and set profile data
    this.userSubscription = this.profileService.userProfileListner()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          this.profileData = res.userProfileData;
          this.profilePicUrl = res.userProfileData.profileImage + "?" + Math.random()* 100000000000000000000;
        }
      }
    );

    // call getUserProfile from profile service
     this.profileService.getUserProfile();

     this.profileService.change.subscribe(isOpenChangePwd => {
      this.showGlobalError = !isOpenChangePwd;
    });
  }

  onCloseModal() {
    // after modal close callback
    // call getUserProfile from profile service
    this.profileData = this.profileService.getUserProfile();
    this.profilePicUrl = this.profileData.profileImage + "?" + Math.random()* 100000000000000000000;;
   // this.cdRef.detectChanges();
  }

  toggleProfile(){
    this.loadEditProfile = !this.loadEditProfile
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.userSubscription.unsubscribe();
  }

}
