import { Injectable } from "@angular/core";
import { HttpService } from "src/app/shared/services/http.service";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class ReportsService {
    private fetchUrl;
    constructor(private http: HttpService){}

    /*
    * The below function get the lincence report API details.
    */
    getLicenceReports(filter) {
        if(filter.status) {
            this.fetchUrl = environment.BASE_URI_AUTH + 'reports/licence-report?customerName='+ filter.customerName +'&numPerPage=' + environment.PAGE_SIZE + '&currentPage='+ filter.pageIndex + '&status=' + filter.status
        } else {
            this.fetchUrl = environment.BASE_URI_AUTH + 'reports/licence-report?customerName='+ filter.customerName +'&numPerPage=' + environment.PAGE_SIZE + '&currentPage='+ filter.pageIndex
        }

        const params = {
            url: this.fetchUrl
        }
        return this.http.get(params)
    }

    /*
    * The below function get the Customer LotId.
    */
    getCustomerLotId(customerId) {
        const params = {
            url: environment.BASE_URI_AUTH + 'customer/' + customerId
        }
        return this.http.get(params);
    }

    /*
    * The below function get the Utilization Report API details.
    */
    getUtilizationReport(filter) {
        let utilApi;
        if(filter.pageIndex != undefined && filter.pageIndex != null) {
            utilApi = filter.lotId +'&numPerPage=' + environment.PAGE_SIZE + '&currentPage='+ filter.pageIndex
        } else {
            utilApi = filter.lotId
        }
        const params = {
            url: environment.BASE_URI_AUTH + 'reports/licence-utilization-report?lotId=' + utilApi
        }
        return this.http.get(params);
    }

    /*
    * The below function send mail on the basic of lotId.
    */
    postLicenceRenewalReminder(data) {
        const params = {
            url: environment.BASE_URI_AUTH + 'licence-renewal-reminder',
            body: data
        }
        return this.http.post(params);
    }

    /*
    * The below function get the meeting reports data.
    */
    getMeetingReports(data) {
        const params = {
            url: environment.BASE_URI + 'meeting/report/actual_meeting?customerId=' + data.customerId + '&page_index=' + data.pageIndex + '&from_date=' + data.from_date + '&to_date=' + data.to_date
        }
        return this.http.get(params);
    }

}