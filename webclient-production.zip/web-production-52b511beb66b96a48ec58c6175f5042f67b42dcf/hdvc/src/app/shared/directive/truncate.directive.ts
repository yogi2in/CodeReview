import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appTruncate]'
})
export class TruncateDirective {
  @Input() afterTruncateNumber: any;
  @Input() name: any;
  private clearSetTimeOut;

  constructor(private elem: ElementRef) { }
  
  ngOnInit(): void {
    clearTimeout(this.clearSetTimeOut);
    this.clearSetTimeOut = setTimeout(() => {
      this.elem.nativeElement.innerText = this.truncateText(this.name);
    }, 500);

    let windowWidth = window.innerWidth;
    if(windowWidth < 375) {
      this.afterTruncateNumber = 10;
    }
  }

  
  /*
  * Truncate text pass name and truncate value from directive initialization time.
  */
  public truncateText(name) {
    let textLength = name.length;
    if (textLength > this.afterTruncateNumber) {
      return name.substring(0, this.afterTruncateNumber) + "...";
    } else {
      return name;
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }

}
