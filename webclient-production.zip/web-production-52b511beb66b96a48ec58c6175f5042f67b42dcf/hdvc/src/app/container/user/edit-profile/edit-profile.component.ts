import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { MyProfileService } from '../my-profile/my-profile.service';
import { Profile, EditProfile } from '../my-profile/Profile';
import { Subscription, Observable } from 'rxjs';
import {debounceTime, map } from 'rxjs/operators';
import { UtilService } from 'src/app/shared/services/utils.services';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  // creates instance of FormGroup called myProfile
  myProfile: FormGroup;
  submitted = false;
  routerName;
  userProfile: any;
  editProfile: EditProfile
  saveError: string;
  countryList:any;
  CountryCodeList: {name: string, code: string}[] = [];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private myProfileService: MyProfileService,
    private _utilsService: UtilService) {
    this.buildForm();
  }

  public buildForm() {
    // use FormBuilder to create a form group
    this.myProfile = this.fb.group({
      'name': [null, Validators.required ],
      'email': [null, [Validators.required, Validators.email]],
      'mobile' : [null, Validators.required ],
      'countryCode' : [null, Validators.required ]
    });
  }

  /* default function get returning all form controls */
  get getFormControl() {
    return this.myProfile.controls;
  }

  /* This function called for save profile form */
  saveProfile() {
    this.submitted = true;
    if (this.myProfile.invalid) {
      return;
    } else {
      var userEditProfile: EditProfile = {};
      userEditProfile.countryCode = this.userProfile.countryCode.name == undefined ? this.userProfile.countryCode: this.userProfile.countryCode.name;
      userEditProfile.fullName  = this.userProfile.fullName;
      userEditProfile.mobile = this.userProfile.mobile;
      this.myProfileService.putuserProfile(userEditProfile)
      .subscribe((response: any) => {
        let currentUser = this._utilsService.getInfoFromStorage('localStorage', 'currentUser');
        currentUser["fullName"] = this.userProfile.fullName;
        this._utilsService.setInfoInStorage('localStorage', 'currentUser', currentUser);
        this.router.navigate(['user/my-profile']);
      },
      error => {
        this.saveError = error.message;
        console.log('error', error);
      });
    }
  }
  ngOnInit() {
    this.getuserProfileDetails();
    this.myProfileService.getCountryCode()
    .subscribe(
      (res) => {
        if(res["result"] != undefined && res["result"] != null && res["result"].length != 0){
          this.countryList = res["result"];
          for(let countrycode in this.countryList ) {
          this.CountryCodeList.push({name: this.countryList[countrycode].code,code: " "+this.countryList[countrycode].name})
          }
          console.log('list', this.CountryCodeList);
        }
      }
    );

   }
   search = (text$: Observable<string>) =>
   text$.pipe(
     debounceTime(200),
     map(term => term === '' ? []
       : this.CountryCodeList.filter(v => +v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
   )

 formatter = (x: {name: string}) => {
   if(x.name != undefined){
     return x.name;
   }else{
     return x;
   }
 }
   getuserProfileDetails() {
     this.myProfileService.getuserProfile()
     .subscribe((response:any) => {
     this.userProfile= response.result;
         console.log("user profile",this.userProfile);
     },
     error => {
       console.log('error', error);
     });
   }
}
