import { Component, OnInit } from '@angular/core';
import { ReportsService } from '../report.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { environment, Enums } from 'src/environments/environment';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators'

@Component({
  selector: 'app-licence-reports',
  templateUrl: './licence-reports.component.html',
  styleUrls: ['./licence-reports.component.css']
})
export class LicenceReportsComponent implements OnInit {
  public upComingRecordsNo;
  public customerName;
  public licenceStatus;
  public reports
  public totalrecords
  public startItemNumber
  public lastItemNumber
  public xlsDownloadUrl
  public pdfDownloadUrl
  public noRecordFound: boolean = true;
  public default_page_size = environment.NUMBER_PER_PAGE;
  public enum = Enums;
  public enumStatusKeys: any;
  public fields = [
    'Lot Id',
    'Start Date',
    'Expiry Date',
    'Total Licence',
    'Used Licence',
    'Available Licence',
    'Status'
  ];
  public searchCustName
  public hideList: boolean = false;
  //public results: any[] = [];
  public enterpriseName: FormControl = new FormControl();
  private _isQueryChange: boolean = true;
  public custStatus
  public showLoader: boolean = false;
  public customerNameAvilable: boolean = false;
  private customerFieldData: any;
  public hideBtn: boolean = false;
  public utilizationReportData;
  public utilizationFields = [
    'Licence Number',
    'Assigned to User',
    'Email',
    'Start Date',
  ];
  public licenceLotId;
  public renewalReminderMsg: any;
  public utiTotalItemCount: any;
  public utilCurrentPage: any;
  public usedLicenceFirstItemNumber: any;
  public usedLicenceLastItemNumber: any
  public usedLicenceTotalItemCount: any;
  public showLoaderOnUsedLicence: boolean = false;


  constructor(private _report: ReportsService) { }

  ngOnInit() {
    this.onPageLoadGetLotId();
    this.enumStatusKeys = Object.keys(this.enum);

    /*
    * The below code fetching the customer list when entring any value in input box.
    */
    this.enterpriseName.valueChanges.pipe(
      debounceTime(500),    // it's taking 0.5s
      distinctUntilChanged()
    )
      .subscribe(
        enterpriseName => {
          this.customerFieldData = this.enterpriseName.value;
          if (this.customerFieldData.length < 3) {
            this.custStatus = ''
          }
          if (this._isQueryChange === false || this.customerFieldData.length < 3) {
            this.hideList = false;
            return;
          }
          this._report.searchEnterpriseName(enterpriseName)
            .subscribe(
              (res) => {
                if (res.result.length > 0) {
                  this.hideList = true;
                  this.searchCustName = res.result;
                }

              }
            )
        }
      )
  }

  /*
  * The below function hide the dropdown when normal input focus work.
  */
  onFocus(): void {
    this._isQueryChange = true;
  }

  /*
  * The below function hide the dropdown when click on outside.
  */
  onBlur() {
    setTimeout(() => {
      this.hideList = false;
    }, 500);
  }

  /*
  * The below function start the loader and call licence report function.
  */
  getLicenceReportData() {
    this.showLoader = true;
    this.reports = [];
    this.totalrecords = 0;
    this.noRecordFound = false;
    this.getLicenceReports(1);
  }

  /*
  * The below function getting the status value and set list text on click list into input box.
  */
  getListData(event) {
    let currentEle = event.target.innerText
    let custStatus = event.target.getAttribute('custStatusValue');
    this.custStatus = custStatus != undefined && custStatus != null && +custStatus === 1 ? 'Active' : 'Inactive'
    this.enterpriseName.setValue(currentEle);     // Set list text into input box.
    this._isQueryChange = false;
    this.hideList = false;
  }

  /*
  * The below function fetching the licence report data and argument is pageIndex, customerName, status.
  */
  getLicenceReports(page) {
    this.upComingRecordsNo = page;
    const filter = {
      pageIndex: page == undefined ? 1 : page,
      customerName: this.customerFieldData,
      status: this.licenceStatus
    }
    this._report.getLicenceReports(filter).subscribe(
      (res) => {
        if (res.result != undefined && res.result != null && res.result.data != undefined && res.result.data != null) {
          this.showLoader = false;
          this.reports = res.result.data;
          this.totalrecords = res.pagination.totalItemCount;
          this.startItemNumber = res.pagination.firstItemNumber;
          this.lastItemNumber = res.pagination.lastItemNumber;
          this.xlsDownloadUrl = res.result.downloadAsXls;
          this.pdfDownloadUrl = res.result.downloadAsPdf;
          this.hideBtn = true;

          if (filter.customerName != null && filter.customerName != undefined) {
            this.customerNameAvilable = false;     // if user filled the customer name, hide the customer column
          } else {
            this.customerNameAvilable = true;     // if user not filled the customer name, show the customer column
          }

          if (this.reports.length > 0) {     // if record 0 show noRecordFound field.
            this.noRecordFound = false;
            this.hideBtn = true;
          } else {
            this.noRecordFound = true;
            this.hideBtn = false;
          }

        } else {
          return;
        }
      },
      (error) => {
        console.log(error);
      }
    )
  }

  /*
  * The below function download the PDF file.
  */
  downloadPdf(pdfFileurl: string) {
    if (pdfFileurl === undefined || typeof pdfFileurl !== 'string') {
      return;
    }
    window.open(this.pdfDownloadUrl, '_blank');
  }

  /*
  * The below function download the Excel file.
  */
  downloadXls(xlsFileUrl: string) {
    if (xlsFileUrl === undefined || typeof xlsFileUrl !== 'string') {
      return;
    }
    window.location.href = xlsFileUrl;
  }

  /*
  * The below function work when change the status.
  */
  onChangeStatus(event) {
    this.licenceStatus = event.target.value;
  }

  /*
  * The below function get the select box selected value on page load.
  */
  onPageLoadGetLotId() {
    let selectLotId: any = document.getElementById('selectStatus');
    this.licenceStatus = selectLotId.value
    console.log(selectLotId.value, typeof selectLotId.value)
  }

  /*
  * The below function reset the form fields.
  */
  resetFields() {
    let resetFormFields: any = document.getElementById('resetForm');
    resetFormFields.reset();
    this.custStatus = false;
    this.reports = [];
    this.totalrecords = 0;
    this.noRecordFound = true;
    this.customerNameAvilable = false;
    this.customerFieldData = null;
    this.licenceStatus = '';
    this.hideBtn = false;
  }

  /*
  * The below function get the UsedLicenceUserDetails if licence number is > 0.
  */
  getUsedLicenceUserDetails(lotId, page) {
    this.utilCurrentPage = page;
    //this.utilizationReportData = []
    this.licenceLotId = lotId;
    const filter = {
      pageIndex: page == undefined ? 1 : page,
      lotId: lotId
    }
    this._report.getUsedLicenceUserDetails(filter).subscribe(
      (res) => {
        this.utilizationReportData = res.result.data;
        this.utiTotalItemCount = res.pagination.totalItemCount;
        this.usedLicenceFirstItemNumber = res.pagination.firstItemNumber;
        this.usedLicenceLastItemNumber = res.pagination.lastItemNumber;
        this.usedLicenceTotalItemCount = res.pagination.totalItemCount;
      },
      (error) => {
        console.log("Post Licence Renewal Reminder", error);
      }
    )
  }

  /*
  * The below function send the mail when status is Expiring Soon on click the mail icon.
  */
  postLicenceRenewalReminder(lotId) {
    const data = {
      "lotId": lotId
    }
    this._report.postLicenceRenewalReminder(data).subscribe(
      (res) => {
        this.renewalReminderMsg = res.message;
        setTimeout(() => {
          this.renewalReminderMsg = false;
        }, 1000);
      }
    )
  }

}
