import { Component, OnInit, Renderer2, Output } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { UtilService } from './shared/services/utils.services';
import { Subscription } from 'rxjs';
import { AuthService } from './auth/auth.service';
import { ConferencePageService } from './container/conference/conference-page-service.service';
import { environment } from 'src/environments/environment';
declare var $;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  public isMeetingValid = false;
  public isLoginPage: boolean = false;
  private loginSubsctiption = new Subscription();
  private signOutSubsctiption = new Subscription();
  private startStopReconnectSubs = new Subscription();
  public isLoggedIn: boolean = false;
  public bodyElem = document.getElementsByTagName('body')[0];
  //public sideNavWidth: any = 0;
  public enableReconnectLayout: boolean = false;
  public reJoinNotifyTimeoutId: any;
  public hideConnectionLayoutTimeoutId: any;
  public notificationMsge: string = "";
  //@Output() public collapseMenu = true;

  constructor(
    private _router: Router,
    private _utilService: UtilService,
    private authService: AuthService,
    private render: Renderer2,
    private _confPageService: ConferencePageService) {
  }

  ngOnInit(): void {
    this._utilService.setInfoInStorage('session', 'environment', environment);
    this._utilService.setInfoInStorage('session', 'screenShareResolution', {
      chromeMediaSource: 'desktop',
      minWidth: 800,
      maxWidth: 1280,
      minHeight: 600,
      maxHeight: 720,
      minFrameRate: 5,
      maxFrameRate: 20
    });
    this._utilService.setInfoInStorage('session', 'optionalScreenConstraint', [{
      googScreencastMinBitrate: 512
    }, {
      googHighBitrate: true
    }, {
      googVeryHighBitrate: true
    }, {
      googLeakyBucket: true
    }
    ])

    this._utilService.setInfoInStorage('session', '256Bitrate', {
      // mandatory: {
      //   "minWidth": 300,
      //   "maxWidth": 720,
      //   "minHeight": 200,
      //   "maxHeight": 502,
      //   "minFrameRate": 25
      // }
      "frameRate": {
        "min": 25,
        "max": 35
      },
      "width": {
        "min": 300,
        "max": 720
      },
      "height": {
        "min": 200,
        "max": 500
      }
    });
    this._utilService.initBrowserInfo();
    let userInfo = localStorage.getItem('currentUser');
    if (userInfo != undefined && userInfo != null) {
      this.isLoggedIn = true;
    }

    this._router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(
      (res: any) => {
        if (res.urlAfterRedirects === '/conference') {
          this.isMeetingValid = true;
        } else {
          this.isMeetingValid = false;
        }
      }
    );

    /*
    *  The below code will execute when user singOut form porfile page.
    */
    this.loginSubsctiption = this.authService.authProcessListener()
      .subscribe(
        (res) => {
          this.isLoggedIn = res.isSuccess;
          console.log("Header component this.isLoggedIn this.isLoggedIn", res.isSuccess);
        },
        (err) => {
          console.log("Header component page error", err);
        }
      )

    /*
    *  The below code will execute when user singOut form porfile page.
    */
    this.signOutSubsctiption = this.authService.isSignOutPage()
      .subscribe(
        (res) => {
          this.isLoggedIn = res.isLoggedIn;
        },
        (err) => {
          console.log("Header component page error", err);
        }
      );

    this.startStopReconnectSubs = this._confPageService.onShowReconnectListener().subscribe(
      (sResponse: any) => {
        console.log('this.startStopReconnectSubs --> ')
        $('.modal').modal('hide');
        // need to reconnect
        this.enableReconnectLayout = sResponse.showReconnect;
        clearTimeout(this.hideConnectionLayoutTimeoutId);
        clearTimeout(this.reJoinNotifyTimeoutId);
        let timeoutTimmer = sResponse.delay !== undefined && sResponse.delay < 1500 ? 1500 : sResponse.delay;
        if (this.enableReconnectLayout) {
          this.notificationMsge = this._utilService.getNotificationMessage(sResponse.errorKey);
          this.reJoinNotifyTimeoutId = setTimeout(() => {
            console.log('execute under timeout ---> ', this.enableReconnectLayout, sResponse.meetingInfo)
            this._confPageService.notifyToStartReJoinObs(this.enableReconnectLayout, sResponse.meetingInfo);
            this.hideConnectionLayoutTimeoutId = setTimeout(() => {
              this.enableReconnectLayout = false;
            }, timeoutTimmer + 500);
          }, timeoutTimmer);
        }

      }, (eResponse: any) => {

      }
    )

  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.loginSubsctiption.unsubscribe();
    this.signOutSubsctiption.unsubscribe();
    this.startStopReconnectSubs.unsubscribe();
    clearTimeout(this.hideConnectionLayoutTimeoutId);
    clearTimeout(this.reJoinNotifyTimeoutId);
  }


}
