import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import * as moment from 'moment';
import { FormGroup, FormBuilder } from '@angular/forms';
import {LicenceService} from '../licence-management/licence.service';
import { CustomValidators } from '../../../shared/custom-validation/customValidators'
declare var $;

@Component({
  selector: 'app-licence-management',
  templateUrl: './licence-management.component.html',
  styleUrls: ['./licence-management.component.css']
})
export class LicenceManagementComponent implements OnInit {
  addLicenceForm:FormGroup;
  forSubmitted = false;
  licenceStatus = [{label:"NOT_STARTED",code:0 , value:"NOT STARTED"}, {label: "ACTIVE", code:1, value:"ACTIVE"},{label:"DELETED", code:2, value:"DELETED"},{label:"EXPIRED", code:3, value:"EXPIRED"}];
  addLicenceField = [
    /* {
      type: 'input',
      label: 'Licence Lot ID',
      name: 'licenceLotId'
    }, */
    {
      type: 'input',
      label: 'Number of Licence',
      name: 'numberOfUsers',
      required:true
    },
    {
      type: 'date',
      label: 'Start Date',
      name: 'licenceStartDate',
      required:true
    },
    {
      type: 'date',
      label: 'Expiry Date',
      name: 'licenceEndDate',
      required:true
    }
  ]
  ff = [
    "lotId",
    "Available Licences",
    "Used Licences",
    "Total Licences",
    "Start Date",
    "Expiry Date",
    "Status"
  ];
  deleteLotId;
  @Input() licences;
  @Input() customerId;
  @Input() groupName;
  @Input() permissions;
  @Output() fetchLicencelistEvent: EventEmitter<any> = new EventEmitter();


  selectedLicenceLotId;
  isRenewRequest;
  sectionName = "Add Licence";
  showLicenceError = false;
  constructor(private fb: FormBuilder, private licenceService : LicenceService) { }

  ngOnInit() {
    $('#add-licence-modal').on('hidden.bs.modal', () => {
      // notify users component to reset the form
      this.forSubmitted = false;
      this.sectionName = 'Add Licence';
      this.addLicenceForm.patchValue({
        'numberOfUsers': null,
        'licenceStartDate': new Date(),
        'licenceEndDate': null
      });
    });
    this.addLicenceForm = this.fb.group({});
  }

  saveLicence(){
    // on edit licence allow the past date of licenceStartDate
    console.log("this.addLicenceForm",this.addLicenceForm)
    this.addLicenceForm.controls['numberOfUsers'].markAsTouched();
    this.addLicenceForm.controls['licenceEndDate'].markAsTouched();
    if(this.addLicenceForm.get('licenceStartDate').hasError('bsDate')){
      this.addLicenceForm.get('licenceStartDate').setErrors(null);
    }
    this.forSubmitted = true;
    if (this.addLicenceForm.invalid) {
      return;
    } else {
      this.forSubmitted = false;
      let dataParams = {
        "customerId":this.customerId,
        "numberOfLicence":this.addLicenceForm.value.numberOfUsers,
        "licenceStartDate":moment(this.addLicenceForm.controls["licenceStartDate"].value).valueOf(),
        "licenceEndDate":moment(this.addLicenceForm.controls["licenceEndDate"].value).valueOf(),
      }
      //debugger;
      if(!this.selectedLicenceLotId){
        this.licenceService.addLicenceToCustomer(dataParams)
        .subscribe(
          (res) => {
            $('#add-licence-modal').modal('hide');
            this.fetchLicencelistEvent.emit();
          }
        );
      }else{
        dataParams["isRenewRequest"] = this.isRenewRequest;
        dataParams["lotId"] = this.selectedLicenceLotId;
        this.licenceService.updateLicence(dataParams)
        .subscribe(
          (res) => {
            $('#add-licence-modal').modal('hide');
            this.fetchLicencelistEvent.emit();
          }
        );

      }

    }
  }

  getLicenceStatus(statusCode){
    let status = this.licenceStatus.filter(x => x.code == statusCode)[0].value;
    return status;
  }

  deleteLicence(lotId){
    this.showLicenceError = true;
    if(lotId != null){
      let dataParams = {
        "customerId":this.customerId,
        "lotId":lotId
      }
      this.licenceService.deleteLicence(dataParams)
      .subscribe(
        (res) => {
          $('#delete-licence-modal').modal('hide');
          this.fetchLicencelistEvent.emit();
        }
      );
    }

  }

  closeModal(){
    this.selectedLicenceLotId = null;
  }

  openModal(lotId, isRenewRequest){
    this.showLicenceError = false;
    if(lotId != undefined){
      this.selectedLicenceLotId = lotId;
      this.sectionName = isRenewRequest ? 'Renew Licence':'Edit Licence';
      this.isRenewRequest = isRenewRequest;
      //this.minDateExpiry.setDate(this.minDate.getDate() + 1);
      this.licenceService.getLicenceByLotId(lotId,this.customerId)
      .subscribe(
        (res) => {
          if(res.result != null){
            let getLicenceData = res.result;
            this.selectedLicenceLotId = getLicenceData.lotId;
            this.addLicenceForm.patchValue({
              'numberOfUsers': getLicenceData.totalLicences,
              'licenceStartDate': isRenewRequest ? this.setRenewLicenceStartDate(getLicenceData.licenceStatus, getLicenceData.endDate):new Date(getLicenceData.startDate),
              'licenceEndDate': isRenewRequest ? this.setRenewLicenceExpiryDate(getLicenceData.licenceStatus,getLicenceData.startDate, getLicenceData.endDate) :new Date(getLicenceData.endDate)
            });
            let licenceStartDateCtrl = this.addLicenceForm.get('licenceStartDate');
            //HDVC-718
            if(getLicenceData.licenceStatus == 1 && !isRenewRequest){
              licenceStartDateCtrl.disable();
            }else if(isRenewRequest){
              licenceStartDateCtrl.enable();
            }

          }
        }
      );
      $('#add-licence-modal').modal('show');
    }
  }

 setRenewLicenceStartDate(licenceStatus, licenceEndDate){
  if(licenceStatus == 1 || licenceStatus == 0){
    var expiryPlusOneDay = moment(licenceEndDate).add('days', 1);
    let expiryPlusOneDayIso = expiryPlusOneDay.toISOString();
    return new Date(expiryPlusOneDayIso);
  }else if(licenceStatus == 3){
    return new Date();
  }
}

  setRenewLicenceExpiryDate(licenceStatus, startDateInMilli, endDateInMilli){
    let startDate = moment(startDateInMilli);
    let endDate = moment(endDateInMilli);
    //End date should not be less than start date
    let duration = moment.duration(endDate.diff(startDate));
    let days = duration.asDays();
    if(licenceStatus == 1 || licenceStatus == 0){
      var endDatePlusDuration = moment(endDateInMilli).add('days', days);
    }else if(licenceStatus == 3){
      var endDatePlusDuration = moment().add('days', days);
    }
    let endDatePlusDurationIso = endDatePlusDuration.toISOString();
    return new Date(endDatePlusDurationIso);

  }

}
