export const environment = {
  production: false,
  BASE_URI: "https://hdvcserver.impressicocrm.com/api/",
  CUSTOMER_ADMIN_URI: "https://hdvc.impressicocrm.com",
  NUMBER_PER_PAGE: 10,
  REPORT_BASE_URI: "https://17qkmcsa0c.execute-api.ap-south-1.amazonaws.com/Panasonic-UAT/meeting/report/"
};

export enum Enums {
  ACTIVE = "Active",
  NOT_STARTED = "Not Started",
  EXPIRED = "Expired",
  EXPIRING_SOON = "Expiring Soon",
  DELETED = "Deleted",
}


