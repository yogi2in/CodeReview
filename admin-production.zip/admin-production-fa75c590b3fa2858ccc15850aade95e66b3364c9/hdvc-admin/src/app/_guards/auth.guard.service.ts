import { Injectable, ɵConsole } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { LocalStorageService } from 'angular-2-local-storage';
import { AuthService } from '../auth/auth.service';
import {map} from 'rxjs/operators';
import * as moment from 'moment';
import { HttpClient } from '@angular/common/http';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { catchError} from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

    private roleProcess = new Subject<{data:{}, isSuccess: boolean, action:string}>();
    constructor(private router: Router, private cookieService: CookieService, private authService: AuthService, private localStorageService: LocalStorageService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        let nextActivateRoute = route.routeConfig.path;
        if (this.localStorageService.get('authToken')) {
            let isAfter = this.checkTokenExpiryTime(this.localStorageService.get('tokenExpirationTime'))
            if(isAfter == true){
                // token expired , call logout api
                this.authService.logout(); 
                return true; 
                /* if(!nextActivateRoute){
                    return true;
                }else{
                    this.router.navigate(['']);
                    return false;  
                } */
            }else{
                // logged in so return true
                if(!nextActivateRoute){
                    this.router.navigate(['customer']);
                    return false;
                }
                return true;
            }
        }
        // not logged in so redirect to login page with the return url
        console.log("auth guard outside",nextActivateRoute);
        if(!nextActivateRoute){
            return true;
        }else{
            this.router.navigate(['']);
            return false;
        }
        
    }
    checkTokenExpiryTime(time){
       let timeExp = Number(time);
        let tokenExpiryTime = moment(timeExp).format();
        let today = moment().format();
        let isAfter = moment(today).isAfter(tokenExpiryTime);
        return isAfter;
    }

    
}

// this guard will move 
@Injectable({ providedIn: 'root' })
export class NewsResolver implements Resolve<any> {

    private permissionProcess = new Subject<{isSuccess : boolean, isSuperUser:boolean, permission: {}, section:string}>();  
    constructor(private router: Router, private cookieService: CookieService, private authService: AuthService) { }
    permissionProcessListener() {
        return this.permissionProcess.asObservable();
      }
    
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    let nextActivateRoute = route.routeConfig.path;
    this.checkUserPermission(nextActivateRoute)
    .subscribe(
        (res) => {
            if(res.result != null && res.result.length != 0){
                console.log("checkUserPermissionresponse",res.result)
                let permissionData = res.result;
                if(permissionData.isSuperUser == false){
                    let permissionObj = this.checkSpecificSectionPermission(nextActivateRoute,permissionData.resourceActionsPairs)
                    console.log("permissionObj---",permissionObj)
                    let isPermissionDenied = this.checkCurrentRoutePermission(nextActivateRoute, permissionObj)
                    this.permissionProcess.next({isSuccess: true,isSuperUser:permissionData.isSuperUser, permission: permissionObj, section:nextActivateRoute});
                    console.log("isPermissionDenied---",isPermissionDenied)
                    if(isPermissionDenied == false){
                        this.router.navigate(['/permission-denied']);
                    }
                    return isPermissionDenied;
                }else{
                    this.permissionProcess.next({isSuccess: true,isSuperUser:permissionData.isSuperUser,permission: {}, section:nextActivateRoute});
                    return true;
                }
                
            }
        },
        (error) => {
            console.log(error);
        }
    );
}

  checkUserPermission(nextRoute){
    console.log("nextRoute",nextRoute)
    return this.authService.getLoggedInUserPrivilege()
    
}

checkSpecificSectionPermission(nextRoute,permissionArray){
    console.log(permissionArray)
    let returnVal = {};
    permissionArray.forEach(value => {
        console.log(value)
        if(value.resourceName == 'CUSTOMER'){
            let actions = value.actions;
            if(nextRoute == 'add-customer' || nextRoute == 'customer'
                || nextRoute == 'edit-customer/:id'){
                console.log("inside", nextRoute)
                returnVal["ADD"] = actions["ADD"];
                returnVal["VIEW"] = actions["VIEW"];
                returnVal["EDIT"] = actions["EDIT"];
                returnVal["DELETE"] = actions["DELETE"];
            }
        }

        if(value.resourceName == 'LICENCE' ){
            //
        }

        if(value.resourceName == 'PANASONIC_ADMIN' ){
            let actions = value.actions;
            if(nextRoute == 'create-user' || nextRoute == 'users'
                || nextRoute == 'edit-user/:id'){
                console.log("inside", nextRoute)
                returnVal["ADD"] = actions["ADD"];
                returnVal["VIEW"] = actions["VIEW"];
                returnVal["EDIT"] = actions["EDIT"];
                returnVal["DELETE"] = actions["DELETE"];
            }
        }
    })
    return returnVal;
}

checkCurrentRoutePermission(nextRoute,permissionObj){
    if(nextRoute == 'customer' || nextRoute == 'users'){
        return permissionObj["VIEW"];
    }else if(nextRoute == 'add-customer' || nextRoute == 'create-user'){
        return permissionObj["ADD"];
    }else if(nextRoute == 'edit-customer/:id' || nextRoute == 'edit-user/:id'){
        return permissionObj["EDIT"];
    }
}

}