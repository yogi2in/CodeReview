import { MostActiveUserDirective } from './most-active-user.directive';

describe('MostActiveUserDirective', () => {
  it('should create an instance', () => {
    const directive = new MostActiveUserDirective();
    expect(directive).toBeTruthy();
  });
});
