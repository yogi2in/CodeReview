import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'range'
})
export class RangePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!value || isNaN(value)) return [];
    return new Array(value).fill(0).map((v, i) => i);
  }
}
