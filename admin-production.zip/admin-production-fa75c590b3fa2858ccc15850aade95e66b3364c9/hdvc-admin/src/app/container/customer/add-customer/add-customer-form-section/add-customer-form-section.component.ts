import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Observable } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';
import { ForgotPasswordService } from '../../../forgot-password/forgot-password.service';

@Component({
  selector: 'app-add-customer-form-section',
  templateUrl: './add-customer-form-section.component.html',
  styleUrls: ['../add-customer.component.css', './add-customer-form-section.component.css']
})

export class AddCustomerFormSectionComponent implements OnInit {
  @Input() config: any[] = []
  @Input() sectionName: string;
  @Input() groupName: FormGroup
  @Input() forSubmitted
  @Input() customerId;
  @Input() countryList;
  @Input() routerName;
  @Input() customerOwnerList;
  @Output() getCustomerById: EventEmitter<any> = new EventEmitter();
  CountryCodeList: { name: string, code: string }[] = [];
  addCustomerFormInnerGroup: FormGroup;
  minDate = new Date();
  minDateExpiry = new Date();
  public compareDateTimeOutId: any;

  pocStatusList = [{ "label": "Active", "value": "ACTIVE", "code": 1 }, { "label": "Inactive", "value": "INACTIVE", "code": 2 }, { "label": "Deleted", "value": "DELETED", "code": 3 }, { "label": "Password Not Set", "value": "PASSWORD NOT SET", "code": 4 }]
  pocStatus;
  resetMessage;
  constructor(private fb: FormBuilder, public _bsDatePickerConfig: BsDatepickerConfig, private _objForgotPasswordService: ForgotPasswordService) {
    //this.minDateExpiry.setDate(this.minDate.getDate() + 1);
    this._bsDatePickerConfig.minDate = moment().toDate();
    this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
    this._bsDatePickerConfig.showWeekNumbers = false;


  }

  ngOnInit() {
    let countrycode;
    for (countrycode in this.countryList) {
      this.CountryCodeList.push({ name: this.countryList[countrycode].code, code: " " + this.countryList[countrycode].name })
    }
    this.addCustomerFormInnerGroup = this.buildAddCustomerForm();
    this.addControlName();
    if (this.routerName == 'EDIT-CUSTOMER') {
      this.getCustomerById.emit();
    }
  }
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
        : this.CountryCodeList.filter(v => +v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )


  formatter = (x: { name: string }) => {
    if (x.name != undefined) {
      return x.name;
    } else {
      return x;
    }

  }

  getMinDate(optionName) {
    let licenceStartDate = this.addCustomerFormInnerGroup.value.licenceStartDate;
    //console.log("licenceStartDate",licenceStartDate)

    if (optionName == "licenceStartDate") {
      return this.minDate;
    } else {
      return this.minDateExpiry;
    }
  }

  compareTwoDates(optionName) {
    clearTimeout(this.compareDateTimeOutId);
    this.compareDateTimeOutId = setTimeout(() => {
      let startDate = this.addCustomerFormInnerGroup.value.licenceStartDate;
      let endDate = this.addCustomerFormInnerGroup.value.licenceEndDate;
      // let startDateMilleSec = moment(startDate).format("DD-MM-YYYY");
      // let endDateMilleSec = moment(endDate).format("DD-MM-YYYY");

      // if (optionName == "licenceEndDate") {
      if (endDate >= startDate) {
        this.addCustomerFormInnerGroup.controls.licenceEndDate.setErrors(null);
      } else {
        this.addCustomerFormInnerGroup.controls.licenceEndDate.setErrors({ 'invalid': true });
      }
      // }

    }, 100);

  }

  getPOCstatus() {
    let pocStatus = this.addCustomerFormInnerGroup.value.pointOfContactStatus;
    if (pocStatus) {
      return this.pocStatus = this.pocStatusList.filter(x => x.code == pocStatus)[0].value;
    }
  }

  public resendEmail() {
    let pointOfContactEmail = this.addCustomerFormInnerGroup.value.pointOfContactEmail;
    if (pointOfContactEmail) {
      this.resetMessage = null;
      this._objForgotPasswordService.setPassword({ "email": pointOfContactEmail, "email-type": "resend-set-password" })
        .subscribe((response: any) => {
          this.resetMessage = response.message;
        })
    }
  }


  /* This function create form group for change pwd form */
  public buildAddCustomerForm() {
    // use FormBuilder to create a form group
    this.config.forEach(control => {
      if (control.type != 'inputGroup') {
        this.groupName.addControl(control.name, this.fb.control(this.addDefaultValueForDynamicControl(control), this.addValidatorForDynamicControl(control)))
      }
    })

    return this.groupName;
  }
  public addControlName() {
    this.config.forEach(control => {
      if (control.type == 'inputGroup') {
        if (control.name[0] == 'alternateNumberCountryCode' && control.name[1] == 'alternatePhoneNumber') {
          this.addCustomerFormInnerGroup.addControl(control.name[0], new FormControl(''));
          this.addCustomerFormInnerGroup.addControl(control.name[1], new FormControl(''));
        } else {
          this.addCustomerFormInnerGroup.addControl(control.name[0], new FormControl('+91', Validators.required));
          this.addCustomerFormInnerGroup.addControl(control.name[1], new FormControl('', Validators.required));
        }

      }
    })
  }

  public addValidatorForDynamicControl(control) {
    if (control.type != 'checkbox' && control.name != 'address' && control.name != 'alternateNumberCountryCode' && control.name != 'alternatePhoneNumber' && control.name != 'pointOfContactEmail' && control.name != 'pointOfContactStatus' && control.name != 'numberOfUsers') {
      return Validators.required;
    } else if (control.name == 'pointOfContactEmail') {
      return [Validators.required, Validators.email];
    } else if (control.name == 'numberOfUsers') {
      return [Validators.required, Validators.pattern(/^-?(1|[1-9]\d*)?$/)];
    }

  }

  public addDefaultValueForDynamicControl(control) {
    if (this.customerId == null || this.customerId == 'NaN') {
      if (control.type == 'checkbox') {
        let val = { value: 1, disabled: true }
        return val;
      } else if (control.name == 'licenceStartDate') {
        return new Date();
      } else if (control.name == 'licenceEndDate') {
        return new Date(new Date().getFullYear() + 1, new Date().getMonth(), new Date().getDate(), new Date().getHours(), new Date().getMinutes(), new Date().getSeconds());
      } else if (control.name == 'owner') {
        return this.customerOwnerList[0].userId;
      }
      else {
        return null;
      }
    } else if (this.sectionName == 'Add Licence' && control.name == 'licenceStartDate') {
      return new Date();
    }
  }

}
