/****
  * COMPONENT: Use this component to manage desktop application download & install according to -
      1. Operating System.
      2. Browser SKIP feture.
      3. Already install or not.
      4. Lounching desktop app, if installed.
      5. etc...
  * DATE: March 04, 2019.
  * @author: Impressico(fb/gshukla67).
*/
import { Component, OnInit, OnDestroy, Input, ViewChild, ElementRef } from '@angular/core';
import { toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';
import { Router, ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
// import { timeInterval } from 'rxjs/operators';

import { UtilService } from '../../shared/services/utils.services';
import { JoinMeetignService } from '../join-meeting/join-meeting.service';
import { Observable, Subscription } from 'rxjs';
import { type } from 'os';
import { createOfflineCompileUrlResolver } from '@angular/compiler';

declare var $;

@Component({
  selector: 'app-desktop-app-download',
  templateUrl: './desktop-app-download.component.html',
  styleUrls: ['./desktop-app-download.component.css']
})
export class DesktopAppDownloadComponent implements OnInit, OnDestroy {

  public token: any;
  public filePath: any;
  public browserName: any;
  public operatingSystem: any;
  public timeoutLouncher: any;
  public timeoutNavigation: any;
  public safarideeplink: any;
  public safarideeplinkshow: boolean;
  private _isDeviceSettingsEnable: boolean;

  @Input() userName: any;
  @Input() meetingId: any;
  @Input() sectionFrom: any;
  @Input() meetingOwnerEmailId: any;
  @ViewChild('openApp') openApp: ElementRef;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _utilService: UtilService,
    protected _sanitizer: DomSanitizer,
    private _joinMeetingService: JoinMeetignService
  ) {
    this.token = this._sanitizer.bypassSecurityTrustUrl("hdvc://p?t="+ this._utilService.getInfoFromStorage('localStorage', 'customer_admin.authToken'));
    /* FIREFOX ISSUE.
    this.token = "web+hdvc://p?t="+ this._utilService.getInfoFromStorage('localStorage', 'customer_admin.authToken');
    window.navigator['registerProtocolHandler']('web+hdvc','http://localhost:4200/download-meeting-app=%s','HDVC Wave')
    console.log("Token: ", this.token);
    */
  }

  /****
    * FUNCTION: Use this defined function to manage @params, device info, app path etc.
    * DATE: March 05, 2019
  */
  ngOnInit() {
    this._isDeviceSettingsEnable = this._utilService.getEnvironmentValue('ENABLED_DEVICE_SETTINGS');
    this._route.params.subscribe(val => {
      if (/^[0-9]+$/.test(this._route.snapshot.paramMap.get('mid'))) {
        if (this.meetingId == undefined) {
          this.meetingId = this._route.snapshot.paramMap.get('mid')
        }
      }
      if (this._route.snapshot.paramMap.get('section')) {
        if (this.sectionFrom == undefined) {
          this.sectionFrom = this._route.snapshot.paramMap.get('section')
        }
      }
      if (this._route.snapshot.paramMap.get('name')) {
        if (this.userName == undefined) {
          this.userName = this._route.snapshot.paramMap.get('name')
        }
      }
      if (this.meetingOwnerEmailId == undefined) {
        this.meetingOwnerEmailId = this.userName //'ankit.kumar@impressico.com'
      }
    });

    let deviceInfo = this._utilService.getDeviceDetection();
    if (deviceInfo != null && deviceInfo != undefined) {
      this.browserName = deviceInfo.browser
      this.operatingSystem = deviceInfo.os
    }
    this.getDeskAppPath();
    if (deviceInfo.os !== "Linux") {
      // this.lounchingDesktopApplication();
    }
    this.safarideeplinkshow = false;
    this.safarideeplink = this._sanitizer.bypassSecurityTrustResourceUrl("hdvc://p?t="+ this._utilService.getInfoFromStorage('localStorage', 'customer_admin.authToken'));
  }

  /****
    * FUNCTION: Use this function to get the downloadable/installer file full path according to os.
    * DATE: March 04, 2019.
  */
  getDeskAppPath = () => {
    this.filePath = this._utilService.getDeskTopAppUrlBasedOnOS()
  }

  /****
    * FUNCTION: Use this function to manage hdvc app access if installed.
    * DATE: March 19, 2019.
  */
  lounchingDesktopApplication = () => {
    if(this.browserName == 'Safari' || (this.operatingSystem == 'Linux' && this.browserName == 'Firefox'))
    {
     this.safarideeplinkshow = true;
    }else{
    let el: HTMLElement = this.openApp.nativeElement as HTMLElement
    this.timeoutLouncher = setTimeout(() => {
      if (typeof this._utilService.getInfoFromStorage('localStorage', 'installApplication') === 'object') {
        el.click()
      }
    }, 50)
    }
  }

  /****
    * FUNCTION: Use this function to download the installer file according to os.
    * DATE: March 04, 2019.
  */
  open = () => {
    window.open(this.filePath)

    this.timeoutNavigation = setTimeout(() => {
      if (this.sectionFrom === 'MEETING-DETAILS') {
        return this._router.navigate(['/my-meetings'])
      } else {
        return this._router.navigate(['/join-meeting'])
      }
    }, 3000)
  }

  /****
    * FUNCTION: Use this function to manage skip feature according to browser.
    * DATE: March 05, 2019.
  */
  continueWithBrowser = (meetingId: number) => {
    if (!meetingId) return;

    let date = new Date()
    clearTimeout(this.timeoutLouncher)
    let currentUserObj = this._utilService.getInfoFromStorage('localStorage', 'currentUser')
    let downloadApplicationObj = {
      "type": "skip-download",
      "browser": this.browserName,
      "meetingId": Number(meetingId),
      "userId": (currentUserObj != null) ? currentUserObj.userId : null,
      "storageTime": date.valueOf()
    }
    this._utilService.setInfoInStorage('session', 'downloadApplication', downloadApplicationObj)
    if (this._isDeviceSettingsEnable) {
      this._router.navigate(['/device-settings']);
    } else {
      this._router.navigate(['/conference']);
    }
    
    // this._router.navigate(['/conference'])
    // this.onJoinMeetingBtnClick(meetingId)
  }

  /****
    * FUNCTION: Use this function to start conferencing like - video/audio/app sharing etc.
    * DATE: March 04, 2019.
    * UPDATE: Outdated at May 18, 2019.
  */
  onJoinMeetingBtnClick = (meetingId: number) => {
    let name: any, email: any;
    const curUserInfo = this._utilService.getInfoFromStorage('local', 'currentUser')
    if (meetingId === undefined || typeof meetingId !== 'string') {
      return;
    }

    // if user info not available then redirect to join-meeting page.
    if (curUserInfo === null) {
      if (this.userName == undefined) {
        return this._router.navigate(['/join-meeting', meetingId])
      }
      else {
        name = this.userName
        email = this.meetingOwnerEmailId
      }
    }
    else {
      name = curUserInfo.fullName
      email = curUserInfo.email
    }
    this._joinMeetingService.isUserClickJoinButton = true;
    this._joinMeetingService.validateMeeting(
      meetingId,
      email,
      name,
      ""
    )
  }

  /****
   * FUNCTION: Use this interface to distroy all existing service for this screen.
   * DATE: April 22, 2019
  */
  ngOnDestroy() {
    clearTimeout(this.timeoutLouncher)
  }
}
