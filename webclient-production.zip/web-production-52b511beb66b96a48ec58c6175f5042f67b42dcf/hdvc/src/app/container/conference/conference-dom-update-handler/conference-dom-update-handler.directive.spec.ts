import { ConferenceDomUpdateHandlerDirective } from './conference-dom-update-handler.directive';

describe('ConferenceDomUpdateHandlerDirective', () => {
  it('should create an instance', () => {
    const directive = new ConferenceDomUpdateHandlerDirective();
    expect(directive).toBeTruthy();
  });
});
