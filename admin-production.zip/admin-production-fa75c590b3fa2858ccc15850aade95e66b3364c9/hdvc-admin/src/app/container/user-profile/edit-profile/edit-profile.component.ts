import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { UserManagementService } from '../../users/user-management.service';
import { ProfileService } from '../../user-profile/profile.service';
import { CustomerService } from '../../customer/customer.service';
import { Subscription, Observable } from 'rxjs';
import {debounceTime, map } from 'rxjs/operators';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  createUserForm: FormGroup;
  @Input() profileData;
  @Input() loadEditProfile;
  @Output() toggleProfile: EventEmitter<any> = new EventEmitter();
  countryList:any;
  searchmodel: any;
  countryCode:string;
  CountryCodeList: {name: string, code: string}[] = [];
  constructor(private userService : UserManagementService, private profileService: ProfileService, private router: Router, private route: ActivatedRoute, private customerService: CustomerService ) { }

  ngOnInit() {
    this.createUserForm = new FormGroup({
      fullName: new FormControl(this.profileData.fullName, Validators.required),
      countryCode: new FormControl(this.profileData.countryCode, Validators.required),
      mobile: new FormControl(this.profileData.mobile, Validators.required),
      email: new FormControl(this.profileData.email, [Validators.email])
    });
   
    console.log(this.profileData);
    this.customerService.getCountryCode()
    .subscribe(
      (res) => {
        if(res.result != undefined && res.result != null && res.result.length != 0){
          this.countryList = res["result"];
          for(let countrycode in this.countryList ) { 
          this.CountryCodeList.push({name: this.countryList[countrycode].code,code: " "+this.countryList[countrycode].name})
          }
        }
      }
    );
  }
  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
        : this.CountryCodeList.filter(v => +v.name.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )
    
  formatter = (x: {name: string}) => {
    if(x.name != undefined){
      return x.name;
    }else{
      return x;
    }
  }

  editProfile(){
    this.createUserForm.controls['fullName'].markAsTouched();
    this.createUserForm.controls['countryCode'].markAsTouched();
    this.createUserForm.controls['mobile'].markAsTouched();
    if (this.createUserForm.valid) {
      this.profileService.updateUserProfile(
          this.createUserForm.value.fullName,
          this.createUserForm.value.countryCode.name==undefined?this.createUserForm.value.countryCode:this.createUserForm.value.countryCode.name,
          this.createUserForm.value.mobile
        ).subscribe(
          (res) => {
            if(res["result"] != null){
              let userProfileData = res["result"]; 
              this.profileService.processReqForUpdateUserProfile(userProfileData); 
              this.loadEditProfile = false;
              this.toggleProfile.emit();    
            }
          }
        );
        
      }
      else {
      console.log('form invalid!');
      }
  }

  closeEditProfile() {
    this.loadEditProfile = false;
    this.toggleProfile.emit(this.loadEditProfile);    
  }
getProfile()
{
  this.toggleProfile.emit();
}
  
}
