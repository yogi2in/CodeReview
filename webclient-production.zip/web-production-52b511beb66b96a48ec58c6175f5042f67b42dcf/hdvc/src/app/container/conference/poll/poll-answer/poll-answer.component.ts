import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { PollService } from '../poll.service';
import { ConferencePageService } from '../../conference-page-service.service';
declare var $;

@Component({
  selector: 'app-poll-answer',
  templateUrl: './poll-answer.component.html',
  styleUrls: ['./poll-answer.component.css']
})

export class pollAnswerComponent implements OnInit {

  launchInfo = {
    //pollTitle: "",
    pollQuestionInfo: [
      {
        pollQuestion: {
          id: "",
          ques: ""
        },
        pollOptions: [
          {
            id: "",
            option: "",
          }
        ]
      }
    ]
  }

  pollAnswer: FormGroup;
  public pollLaunchTitle;
  public launchPollId;
  @Input() pollLaunchData;
  @Input() pollId;
  @Output() showCreateModal = new EventEmitter();
  @Output() launchPollModal = new EventEmitter();
  @Output() pollSubmit = new EventEmitter();
  private selectedQuesOptionIndex;
  public cunterIndex: number = 1;
  public pollQuestionLength: number;
  public submitpollAnsBtn: boolean= false;
  public thankyouPage: boolean = false;
  public hostName: string = "";

  constructor(
    private formBuilder: FormBuilder,
    private pollService: PollService,
    private _confPageService: ConferencePageService) { }

  ngOnInit() {
    this.pollAnswer = this.formBuilder.group({
      pollTitle: [''],
      pollQuestionInfo: this.formBuilder.array([])
    })
    this.setEditFormFields();
    this.getPollRead(this.pollId);
    this.hostName = this._confPageService.hostName;
  }

  /*
   * The below function get the poll details.
  */
  getPollRead(pollId) {
    const data = {
      pollId: pollId
    }
    this.pollService.pollRead(data).subscribe(
      (res: any) => {
        console.log("launch poll get data = > ", res.result);
        this.pollLaunchData = res.result;
         this.pollQuestionLength = res.result.pollQuestionInfo.length
      },
      (err) => {
        console.log("", err);
      }
    )
  }

  /*
   * The below function set the form fields.
  */
  setEditFormFields() {
    let control = <FormArray>this.pollAnswer.controls.pollQuestionInfo;
    this.launchInfo.pollQuestionInfo.forEach(x => {
      control.push(this.formBuilder.group({
        pollQuestion: this.formBuilder.group({
          id: [],
          ques: [x.pollQuestion.ques]
        }),
        pollOptions: this.setEditPollOptions(x)
      }))
    })
  }

  /*
   * The below function set the form option fields.
  */
  setEditPollOptions(x) {
    let arr = new FormArray([])
    x.pollOptions.forEach(y => {
      arr.push(this.formBuilder.group({
        option: [y.option]
      }))
    })
    return arr;
  }

  /*
   * The below function get id of selected option when click on option.
  */
  getSelectedId(eve){
    this.selectedQuesOptionIndex = eve.target.id;
  }

   /*
   * The below function send the questionId and answerId to socket in conference.component click on next/submit btn .
  */
  pollAnswerSubmit(endPoll) {
    let getActiveCalss = document.querySelector('.slide-item.active .q-number');
    let questionid = getActiveCalss.getAttribute('id');
    let answerid = this.selectedQuesOptionIndex
    
    let obj = {
      pollId: this.pollId,
      questionid: questionid,
      answerid: answerid
    }
    
    if (answerid !== undefined) {
      this.pollService.pollAnswerSubmitData(obj);
    }

    this.increaseCounterIndex();

    if(endPoll == 'endPoll'){
      this.pollSubmit.emit();
    }
  }

  /*
   * The below function increase the counter index.
  */
  increaseCounterIndex() {
    if(this.pollQuestionLength !=undefined && this.pollQuestionLength != null && this.cunterIndex != undefined && this.cunterIndex != null) {
      if(this.pollQuestionLength > this.cunterIndex){
        this.cunterIndex++
      } else {
        this.submitpollAnsBtn = true;
      }
    } else {
      return;
    }

  }

  /*
   * The below function close the modal.
  */
  closeModal(){;
    this.showCreateModal.emit(false);
    this.launchPollModal.emit(false);
    $('#createPollModal').modal('hide');
  }
  
}
