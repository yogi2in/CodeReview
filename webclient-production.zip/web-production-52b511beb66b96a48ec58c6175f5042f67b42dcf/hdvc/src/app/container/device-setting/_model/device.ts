export class device {
  deviceId: string;
  groupId: string;
  kind: string;
  label: string;
}
