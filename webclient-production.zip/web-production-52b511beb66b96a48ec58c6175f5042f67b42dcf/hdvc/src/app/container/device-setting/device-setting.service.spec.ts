import { TestBed } from '@angular/core/testing';

import { DeviceSettingService } from './device-setting.service';

describe('DeviceSettingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DeviceSettingService = TestBed.get(DeviceSettingService);
    expect(service).toBeTruthy();
  });
});
