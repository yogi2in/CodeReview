import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RoleManagementService } from '../role-management.service';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService } from 'angular-2-local-storage';
declare var $;

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {
  addRoleForm: FormGroup;
  permissions = {"User Management":"PANASONIC_ADMIN", "Enterprise Management": "CUSTOMER", "Licence Management": "LICENCE"};
  actions = {"Create":"ADD", "View":"VIEW", "Edit/Renew":"EDIT", "Delete":"DELETE"};
  rolePermission = {"PANASONIC_ADMIN":{}, "CUSTOMER":{}, "LICENCE":{}}
  //actionObj = {};
  routerName;
  sub;
  roleId;
  title = "Add Role";
  cancelPath = '../roles'
  isAnyChecked = false;
  showError = false;
  constructor(private roleService : RoleManagementService, private router: Router, private route: ActivatedRoute, private localStorageService: LocalStorageService) {
      if (this.router.url.includes("/edit-role")) {
        this.routerName = 'EDIT-ROLE';
      }else{
        this.localStorageService.remove('pageNumber');
      }    
   }

  ngOnInit() {
    //this.permissions.forEach(x => this.rolePermission[x] = {})
    Object.entries(this.permissions).forEach(([key, value]) => {
      this.rolePermission[value] = {};
    });
    this.addRoleForm = new FormGroup({
      roleName: new FormControl(null, Validators.required),
      roledesc: new FormControl(null),
      roleType: new FormControl('0'),
      isSuperAdmin: new FormControl(false)
    });

    this.sub = this.route.params.subscribe(params => {
      this.roleId = +params['id']; 
      
    });
    if(this.routerName == 'EDIT-ROLE'){
      this.title = "Edit Role"
      this.cancelPath = '../../roles'
      this.roleService.getRoleById(this.roleId)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            let roleData = res["result"];
            this.addRoleForm.setValue({
              "roleName":roleData.roleName,
              "roledesc":roleData.roleDescription,
              "isSuperAdmin":roleData.isSuperUser,
              "roleType": roleData.roleType !== null ? roleData.roleType.toString() : ""
            });
            if(roleData.isSuperUser){
              this.checkAll(true)
            }else{
              Object.entries(roleData.resourceActionsPairs).forEach(([key, value]) => {
                let response: any = value;
                Object.entries(response.actions).forEach(y => 
                  {
                    this.rolePermission[response.resourceName][y[0]] = y[1]
                    //this.isChecked(value.resourceName,y[0])
                  })
              });
            }     
          }
        },
        err => console.log(err)
      );
    } 

  }

  changePermission(role,action,$event){
    let actionObj = {}
    
    if(action == 'ADD'){
     actionObj["VIEW"] = $event.target.checked ? $event.target.checked:this.rolePermission[role]["VIEW"]
     actionObj["DELETE"] = this.rolePermission[role]["DELETE"];
     actionObj["EDIT"] = this.rolePermission[role]["EDIT"];
    }
    if(action == 'VIEW'){
      actionObj["ADD"] = ($event.target.checked == false) ? false : this.rolePermission[role]["ADD"];
      actionObj["DELETE"] = ($event.target.checked == false) ? false : this.rolePermission[role]["DELETE"] ;
      actionObj["EDIT"] = ($event.target.checked == false) ? false : this.rolePermission[role]["EDIT"] ;
     }
    else if(action == 'DELETE' ||  action == "EDIT"){
      actionObj["VIEW"] = ($event.target.checked == true) ? $event.target.checked :(this.rolePermission[role]["DELETE"] || this.rolePermission[role]["EDIT"] || this.rolePermission[role]["ADD"])? true:false;
      actionObj["ADD"] = this.rolePermission[role]["ADD"];
      actionObj["DELETE"] = action == 'DELETE' ? $event.target.checked : this.rolePermission[role]["DELETE"];
      actionObj["EDIT"] = action == 'EDIT' ? $event.target.checked : this.rolePermission[role]["EDIT"];
    }
    if(!$event.target.checked){
      this.addRoleForm.patchValue({
        "isSuperAdmin":$event.target.checked
      })
    }else{
      this.isAnyChecked = true;
    }
    actionObj[action] = $event.target.checked;
    this.rolePermission[role] = actionObj;
    let otherPermission = role == 'CUSTOMER' ? 'LICENCE' : (role == 'LICENCE' ? 'CUSTOMER' : null);
    if(otherPermission != null){
      let newObj = {};
      if(action == 'ADD'){
        newObj["ADD"] = this.rolePermission[role]["ADD"];
        newObj["VIEW"] = this.rolePermission[role]["VIEW"];
        newObj["DELETE"] = this.rolePermission[otherPermission]["DELETE"];
        newObj["EDIT"] = this.rolePermission[otherPermission]["EDIT"];
      }
      if(action == 'EDIT'){
        newObj["ADD"] = this.rolePermission[role]["ADD"];
        newObj["DELETE"] = role == 'CUSTOMER' && this.rolePermission[role]["EDIT"] == false ? false : role == 'LICENCE' ? this.rolePermission[otherPermission]["DELETE"]:this.rolePermission[role]["DELETE"];
        newObj["EDIT"] = role == 'LICENCE' && this.rolePermission[role]["EDIT"] ? true : (role == 'LICENCE' && this.rolePermission[role]["EDIT"] == false) ? this.rolePermission[otherPermission]["EDIT"] : role == 'CUSTOMER' && this.rolePermission[role]["EDIT"] ? this.rolePermission[otherPermission]["EDIT"] :this.rolePermission[role]["EDIT"];
        newObj["VIEW"] = newObj["EDIT"];
      }
      if(action == 'DELETE' && role == 'CUSTOMER'){
        newObj["ADD"] = this.rolePermission[otherPermission]["ADD"];
        newObj["VIEW"] = this.rolePermission[otherPermission]["VIEW"];
        newObj["DELETE"] = this.rolePermission[otherPermission]["DELETE"];
        newObj["EDIT"] = this.rolePermission[otherPermission]["EDIT"];
      }
      if(action == 'VIEW' && role == 'LICENCE' ){
        newObj["ADD"] = this.rolePermission[role]["ADD"];
        newObj["VIEW"] = this.rolePermission[otherPermission]["VIEW"];
        newObj["DELETE"] = this.rolePermission[role]["DELETE"];
        newObj["EDIT"] = this.rolePermission[otherPermission]["EDIT"];
      }
      if(action == 'DELETE' && role == 'LICENCE' ){
        newObj["ADD"] = this.rolePermission[role]["ADD"];
        newObj["VIEW"] = this.rolePermission[role]["VIEW"];
        newObj["DELETE"] = this.rolePermission[otherPermission]["DELETE"];
        newObj["EDIT"] = this.rolePermission[role]["DELETE"];
      }
      this.rolePermission[otherPermission] = newObj;
    
      
    }
    /* if(role == 'CUSTOMER' && actionObj["EDIT"] == true || actionObj["EDIT"] == false){
      this.rolePermission['LICENCE'] = actionObj;
    } */
    this.addRoleForm.patchValue({
      "isSuperAdmin":this.isAllselected()
    })
    
  }

  isChecked(role,action){
    if(this.rolePermission[role][action] != undefined){
      return this.rolePermission[role][action]
    }else{
      return false;
    }
  }

  checkAll(ev) {
    //this.rolePermission.forEach(x => x.state = ev.target.checked)
    /* this.permissions.forEach(x => 
      this.actions.forEach(y => 
        this.rolePermission[x][y] = ev.target.checked
      )
    ) */
    Object.entries(this.permissions).forEach(([key, value]) => {
      Object.entries(this.actions).forEach(y => 
        this.rolePermission[value][y[1]] = ev == true ? true : ev.target.checked
     )
    });
  }

  isAllselected(){
    let isAllChecked = [];
    Object.entries(this.permissions).forEach(([key, value]) => {
      let permissionName: any  = value;
      if( this.rolePermission[permissionName] != undefined && (this.rolePermission[permissionName]["ADD"] != true || this.rolePermission[permissionName]["EDIT"] != true || this.rolePermission[permissionName]["VIEW"] != true || this.rolePermission[permissionName]["DELETE"] != true)){
        isAllChecked.push(false)
      }else{
        isAllChecked.push(true)
      }
    });
    return !isAllChecked.includes(false);
  }

  validateIsAnyPermissionChecked(){
    console.log("this.rolePermission",this.rolePermission)
    this.isAnyChecked = false;
    this.showError = true;
    Object.entries(this.rolePermission).forEach(([key, value]) => {
      if(value["ADD"] || value["EDIT"] || value["VIEW"] || value["DELETE"]){
        this.isAnyChecked = true;
        this.showError = false;
      }
    })
    return this.isAnyChecked;
  }

  saveRole(){
    this.addRoleForm.controls['roleName'].markAsTouched();
    let isAnyChecked = this.validateIsAnyPermissionChecked()
    if (this.addRoleForm.valid && isAnyChecked) {
      let permissionObj = {};
      let resourceActionPairs = [];
      for (let prop in this.rolePermission) {
        console.log(prop);
        let permissionObj = {};
        let actions = [];
        if(this.rolePermission[prop]["ADD"] != undefined && this.rolePermission[prop]["ADD"] != false){
          permissionObj["resourceName"] = prop
          actions.push("ADD")          
        }
        if(this.rolePermission[prop]["VIEW"] != undefined && this.rolePermission[prop]["VIEW"] != false){
          permissionObj["resourceName"] = prop
          actions.push("VIEW")          
        }
        if(this.rolePermission[prop]["DELETE"] != undefined && this.rolePermission[prop]["DELETE"] != false){
          permissionObj["resourceName"] = prop
          actions.push("DELETE")          
        }
        if(this.rolePermission[prop]["EDIT"] != undefined && this.rolePermission[prop]["EDIT"] != false){
          permissionObj["resourceName"] = prop
          actions.push("EDIT")          
        }
        if(actions.length != 0){
          permissionObj["actions"] = actions;
        }
        if(!$.isEmptyObject(permissionObj)){
          resourceActionPairs.push(permissionObj);
        }
      }
      let dataParams = {
        "roleName": this.addRoleForm.value["roleName"],
        "roleDescription": this.addRoleForm.value["roledesc"],
        "isSuperUser":this.addRoleForm.value["isSuperAdmin"],
        "resourceActionPairs":resourceActionPairs ,
        "roleType": +this.addRoleForm.controls['roleType'].value
      }
      if(this.routerName != 'EDIT-ROLE'){
        this.roleService.addRole(dataParams)
        .subscribe(
          (res) => {
            this.router.navigate(['roles'], { queryParams: { 'roleEdit':'true'}});
          },
          err => console.log(err)
        );
      }else{
        this.roleService.updateRole(this.roleId, dataParams)
        .subscribe(
          (res) => {
            this.router.navigate(['roles'], { queryParams: { 'roleEdit':'true'}});
          },
          err => console.log(err)
        );
      } 
      
    }else{

    }
  }

}
