import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { UtilService } from '../../../shared/services/utils.services';
import { environment } from '../../../../environments/environment';
import { LicenceUserManagementComponent } from '../../licence-user-management/licence-user-management.component';
declare var $;

@Component({
  selector: 'app-open-desktop-app-popup',
  templateUrl: './open-desktop-app-popup.component.html',
  styleUrls: ['./open-desktop-app-popup.component.css']
})
export class OpenDesktopAppPopupComponent implements OnInit {

  public filePath;
  public browserName;
  @Input() meetingId;
  @Input() sectionFrom
  @Input() meetingOwnerEmailId;
  @Input() userName;
  @Output() onJoinMeetingBtnClick: EventEmitter<any> = new EventEmitter();

  constructor(private utilService: UtilService) { }

  ngOnInit() {
    let deviceInfo = this.utilService.getDeviceDetection();
    if (deviceInfo != null && deviceInfo != undefined) {
      this.browserName = deviceInfo.browser;
    }
    this.getDeskAppPath();
  }

  getDeskAppPath() {
    this.filePath = this.utilService.getDeskTopAppUrlBasedOnOS();
  }
  open() {
    // console.log("FinalPath >>", this.filePath);
    window.open(this.filePath);
  }

  continueWithBrowser(meetingId) {
    if (!meetingId) return;
    if (this.sectionFrom != 'JOIN-MEETING') {
      this.onJoinMeetingBtnClick.emit(meetingId)
    } else {
      this.onJoinMeetingBtnClick.emit({ "meetingId": this.meetingId, "ownerEmail": this.meetingOwnerEmailId, "userName": this.userName })
    }
  }

  ngAfterViewInit() {
    $('#download-deskTop-app').on('hidden.bs.modal', () => {
      //this.onJoinMeetingBtnClick.emit();
    });
  }

}
