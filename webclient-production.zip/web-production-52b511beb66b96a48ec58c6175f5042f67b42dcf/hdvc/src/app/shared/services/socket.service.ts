import { Injectable } from '@angular/core';
import { UtilService } from 'src/app/shared/services/utils.services';
import { Router } from '@angular/router';

@Injectable({providedIn: 'root'})
export class SocketService {
  private socketInstance: any = null;
  private isWithMeetingId: boolean;
  constructor(private utilService: UtilService, private router: Router){

  }
  getSocketInstance() {
    const socketURL = this.getSocketUrl();
    if (socketURL === null) {
      const userInfo = this.utilService.getInfoFromStorage('session', 'participantInfo');
      if (userInfo !== null) {
        return this.router.navigate(['/join-meeting', userInfo.meetingId]);
      } else {
        return this.router.navigate(['/join-meeting']);
      }
    }

    if (this.socketInstance === null || this.socketInstance.readyState > 1 ) {
      this.socketInstance =  new WebSocket(socketURL);
    }
    return this.socketInstance;
  }

  resetSocketInstance() {
    this.socketInstance = null;
  }

  isMeetingIdExist(){
   return this.isWithMeetingId;
  }

  getSocketUrl(): any {
    return this.utilService.getInfoFromStorage('localStorage', 'socketUrl');
  }
}
