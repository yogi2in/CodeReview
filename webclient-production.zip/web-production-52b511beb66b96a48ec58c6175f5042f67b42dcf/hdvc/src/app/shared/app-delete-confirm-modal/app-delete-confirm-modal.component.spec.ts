import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppDeleteConfirmModalComponent } from './app-delete-confirm-modal.component';

describe('AppDeleteConfirmModalComponent', () => {
  let component: AppDeleteConfirmModalComponent;
  let fixture: ComponentFixture<AppDeleteConfirmModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDeleteConfirmModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDeleteConfirmModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
