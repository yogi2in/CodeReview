import { Directive, OnInit, Renderer2, OnDestroy, ViewChild, AfterViewInit, ElementRef, Input } from '@angular/core';
import { JoinMeetignService } from '../../join-meeting/join-meeting.service';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ConferencePageService } from '../conference-page-service.service';

@Directive({
  selector: '[appMostActiveUser]'
})
export class MostActiveUserDirective implements OnInit, OnDestroy, AfterViewInit {

  @ViewChild('conferencePage') confPageDOM;
  @Input('selfUserId') selfUserId;

  private _mostActiveVideoElem: any;        // this will store the full video element
  private _allParticipantsVideoElem: any;   // this will store all the participants videos element
  private _screenLoaderElem: any;           // this will store screen loader element
  private prevActiveUserId: string;         // this will store the previous active user id
  private _layoutTypeENUMS: any;

  private sameActiveUserCounter = 0;
  // timeout id/ interval id
  private checkSrcObjectIntervalId: any;

  // OBSERVABLE
  private _mostActiveUserSubs = new Subscription();
  private _mostActiveUserDuringScreenShareSubs = new Subscription();

  constructor(
    private _renderer: Renderer2,
    private element: ElementRef,
    private _joinMeetingService: JoinMeetignService,
    private _confPageService: ConferencePageService
  ) {
    this._layoutTypeENUMS = environment.LAYOUT_TYPE_ENUMS;
  }

  ngOnInit() {
    this._mostActiveUserSubs = this._confPageService.mostActiveUserListener().subscribe(
      (response) => {
        // console.log('response most active user ', response);
        // if the same user in active for 15 seconds the just check to load new user
        let resetMostActiveUser = this._confPageService.resetMostActiveUser;
        if (this.sameActiveUserCounter >= 3) {
          var mostActiveUserVideo: any = document.getElementById("video-"+response.userId);
          if (mostActiveUserVideo !== null && mostActiveUserVideo.videoHeight !== undefined && mostActiveUserVideo.videoHeight < 10) {
            resetMostActiveUser = true;
          }
          this.sameActiveUserCounter = 0;
        }
        const curPageMostActiveUsers = this._confPageService.getCurPageMostActiveUsersInfo();
        this.updateMostActiveUser(
          response.userId,
          response.userName,
          response.layoutType,
          resetMostActiveUser,
          curPageMostActiveUsers);
      }
    )
    this._mostActiveUserDuringScreenShareSubs = this._confPageService.mostActiveUserDuringScreenShareListener().subscribe(
      (response: any) => {
        if (response.userId !== undefined) {
          this.updateForGridLayout(response.userId);
        }
      }
    )
  }

  ngAfterViewInit() {
    if (this.element.nativeElement !== undefined) {
      this._mostActiveVideoElem = this.selectElementFromDOM(
        this.element,
        '#full-video'
      )
      this._allParticipantsVideoElem = this.selectElementFromDOM(
        this.element,
        '.participant.participant-user',
        'all'
      )
      this._screenLoaderElem = this.selectElementFromDOM(this.element, '.screen-share-loader', 'all')
    }

  }

  /**
   * @description The below function will handle show most active user depending on layout type.
   * @param curActiveUserId - most active user id
   * @param layoutType - layout type - grind/ non-grind
   */
  updateMostActiveUser(
    curActiveUserId: string,
    curActiveUserName: string,
    layoutType: string,
    resetMostActive: boolean,
    curPageMostActiveUsers: any
  ) {
    if (
        (
          curActiveUserId === undefined ||
          layoutType === undefined ||
          (
            curActiveUserId === this.prevActiveUserId &&
            (
              curActiveUserName === '' || curActiveUserName === 'null'
            )
          )
        ) && resetMostActive === false
    ) {
      ++this.sameActiveUserCounter;
      return;
    }

    this.sameActiveUserCounter = 0;

    // if user change the media quality change
    if (resetMostActive === true) {
      this._confPageService.resetMostActiveUser = false;
    }


    if (layoutType === this._layoutTypeENUMS[1] || curActiveUserName === 'screen-shared-user' || curActiveUserName === 'screen-shared-web-user') {
      // for non grind layout
      // console.log('layoutType ', layoutType, curActiveUserName);
      const curPageMostActiveUsers = this._confPageService.getCurPageMostActiveUsersInfo();
      this.updateForNonGridLayout(curActiveUserId, curActiveUserName, curPageMostActiveUsers);
      this.prevActiveUserId = curActiveUserId;
    } else {
      const curPageMostActiveUsers = this._confPageService.getCurPageMostActiveUsersInfo();
      // for grid layout
      if (
        curPageMostActiveUsers !== null &&
        curPageMostActiveUsers.curActiveUsers.length >= 1 &&
        this.isActiveUserInCurActiveUsers(curActiveUserId, curPageMostActiveUsers.curActiveUsers)
      ) {
        this.updateForGridLayout(curActiveUserId);
      }
      this.prevActiveUserId = curActiveUserId;
    }
    // store the current userid as previous for next operation

  }

  isActiveUserInCurActiveUsers(userId: string, activeUsers: any) {
    let result = activeUsers.some((activeUser, key) => {
      return activeUser.userId === userId;
    });
    return result;
  }

  updateForNonGridLayout(selectorId: string, userName: string, activeUsersInfoArr: any) {
    if (selectorId === undefined) {
      return;
    }
    // cancel if any interval exists
    clearInterval(this.checkSrcObjectIntervalId);
    let checkCounter = 0;
    const userInfo = this._confPageService.getUserInfo(selectorId);
    const videoPreviewWrapper: any = this.selectElementFromDOM(this.element, "#video-preview-wrapper");
    const fullViewVideoElem = this.selectElementFromDOM(this.element, '#full-video');
    const activeUserVideoElementWrapper = this.selectElementFromDOM(this.element, '#' + selectorId);
    const activeUserVideoElement = this.selectElementFromDOM(this.element, '#video-' + selectorId);
    const allParticipantsVideoElem: any = this.selectElementFromDOM(this.element, '.participant.participant-user', 'all');

    if (userName === 'screen-shared-user' || userName === 'screen-shared-web-user') {
      this.toggleClassElement(fullViewVideoElem, 'no-transform', 'add');
    } else {
      this.toggleClassElement(fullViewVideoElem, 'no-transform', 'remove');
    }

    if (videoPreviewWrapper !== null) {
      this.toggleClassElement(videoPreviewWrapper, 'user-stop-video', 'remove');
      this.toggleClassElement(videoPreviewWrapper, 'show-no-video', 'remove');
      if (userInfo !== undefined && userInfo.isVideoShare !== undefined && userInfo.isVideoShare === false) {
        this.toggleClassElement(videoPreviewWrapper, 'user-stop-video', 'add');
      } else if(userInfo !== undefined && userInfo.isStreamAvailable !== undefined && userInfo.isStreamAvailable === false) {
        this.toggleClassElement(videoPreviewWrapper, 'show-no-video', 'add');
      }
    }

    // this will handle to show the video if it was hide due to most active user
    if ( activeUsersInfoArr !== undefined && activeUsersInfoArr !== null && activeUsersInfoArr.curActiveUsers !== null) {
      activeUsersInfoArr.curActiveUsers.forEach((activeUser, arrIdx) => {
        let activeUserElem = this.selectElementFromDOM(this.element, '#'+activeUser.userId);
        this.toggleClassElement(activeUserElem, 'd-none', 'remove');
      });
    }

    if (fullViewVideoElem !== null && activeUserVideoElement !== null) {
      if (activeUsersInfoArr !== null && activeUsersInfoArr.curActiveUsers !== null && activeUsersInfoArr.curActiveUsers.length === 1) {
        //this.toggleClassElement(activeUserVideoElementWrapper, 'd-none', 'add');
      }

      this.checkSrcObjectIntervalId = setInterval(() => {
        if (activeUserVideoElement.srcObject !== null) {
          fullViewVideoElem.srcObject = activeUserVideoElement.srcObject;
          if (this.selfUserId === selectorId) {
            fullViewVideoElem.muted = true;
          } else {
            fullViewVideoElem.muted = false;
          }
          this.toggleScreenLoaderIcon(this._screenLoaderElem, false);
          clearInterval(this.checkSrcObjectIntervalId);
        } else {
          if (checkCounter >= 20) {
            clearInterval(this.checkSrcObjectIntervalId);
            this.toggleScreenLoaderIcon(this._screenLoaderElem, false);
          }
        }
        ++checkCounter;
      }, 100);
    }
  }

  /**
   * @description The below function will handle to show currently active user in the grid view
   * @param slectorId
   */
  updateForGridLayout(slectorId: string) {
    if (slectorId === undefined) {
      return;
    }

    const activeUserVideoElement = this.selectElementFromDOM(this.element, '#' + slectorId);
    const allParticipantsVideoElem: any = this.selectElementFromDOM(this.element, '.participant.participant-user', 'all');

    if (activeUserVideoElement !== null) {
      this.toggleClassElement(allParticipantsVideoElem, 'current-active-user', 'remove');
      this.toggleClassElement(activeUserVideoElement, 'd-none', 'remove');
      this.toggleClassElement(activeUserVideoElement, 'current-active-user', 'add');
    }
  }



  toggleScreenLoaderIcon(loaderElem: any, loaderState: boolean) {
    if (loaderElem === undefined || loaderElem === null) {
      return;
    }
    let optType = loaderState !== undefined === true ? 'add' : 'remove';
    this.toggleClassElement(loaderElem, 'd-none', optType);
  }


  /**
   * @description The below function will handle to return the element as per selector passed
   * @param selector
   */
  selectElementFromDOM(selectorDOM: any, selector: string, selectorType?: string) {
    let selectedDOM = null;
    if (selectorDOM === undefined || selectorDOM === null) {
      return selectedDOM;
    }

    switch(selectorType) {
      case 'all':
        selectedDOM = selectorDOM.nativeElement.querySelectorAll(selector);
        break;
      default:
        if (selector.indexOf("#") > -1) {
          selector = selector.slice(1);
          selectedDOM = document.getElementById(selector);
        } else {
          selectedDOM = selectorDOM.nativeElement.querySelector(selector);
        }
        break;
    }
    return selectedDOM;
  }

  toggleClassElement(listOfElements: any, clsName: string, optType: string) {
    if (
        listOfElements === undefined ||
        listOfElements === null ||
        clsName === undefined ||
        typeof clsName !== 'string'
      ) {
      return;
    }

    if (listOfElements.length > 0) {
      listOfElements.forEach((element, key) => {
        if (optType === 'add') {
          this._renderer.addClass(element, clsName);
        } else {
          this._renderer.removeClass(element, clsName);
        }
      });
    } else {
      if (optType === 'add') {
        this._renderer.addClass(listOfElements, clsName);
      } else {
        this._renderer.removeClass(listOfElements, clsName);
      }
    }
  }

  ngOnDestroy() {
    this._mostActiveUserSubs.unsubscribe();
    this._mostActiveUserDuringScreenShareSubs.unsubscribe();
  }
}
