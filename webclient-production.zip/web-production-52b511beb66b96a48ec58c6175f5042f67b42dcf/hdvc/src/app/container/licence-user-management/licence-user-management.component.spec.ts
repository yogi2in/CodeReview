import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenceUserManagementComponent } from './licence-user-management.component';

describe('LicenceUserManagementComponent', () => {
  let component: LicenceUserManagementComponent;
  let fixture: ComponentFixture<LicenceUserManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LicenceUserManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenceUserManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
