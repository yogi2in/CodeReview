import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import {ImageCroppedEvent} from 'ngx-image-cropper/src/image-cropper.component';
import { ProfileService } from '../profile.service';
declare var $;

@Component({
  selector: 'app-add-profile-pic-modal',
  templateUrl: './add-profile-pic-modal.component.html',
  styleUrls: ['./add-profile-pic-modal.component.css']
})
export class AddProfilePicModalComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  cropperReady = false;
  imageUploaded = false;  // default imageUploaded false
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  @Input() profilePicUrl;
  constructor(private profileService: ProfileService) { }

  ngOnInit() {
    $('#changeProfile').on('hidden.bs.modal', () => {
      this.closeModal.emit();
    });
  }

   /* This function execute on image selection */
   fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
    this.imageUploaded = true; // after image selection imageUploaded true
    console.log(this.imageChangedEvent);
  }

  /* This function execute for get seleced cropped image  */
  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }

  /* This function execute when image is loaded */
  imageLoaded() {
    this.cropperReady = true;
  }
  /* This function execute when selected image loading failed */
  loadImageFailed () {
    console.log('Load failed');
  }

  /* This function execute for ressting all values */
   resetImageContainer () {
    this.imageChangedEvent = '';
    this.croppedImage = '';
    this.cropperReady = false;
    this.imageUploaded = false;
  }

  /* This function execute after image selection and upload image to server*/
  saveImage () {
    if (this.imageUploaded && this.croppedImage) {
      /* converting to blob object */
      const blob = this.dataURItoBlob(this.croppedImage);
      console.log('blob object created', blob);
      // add validation
      /* if (blob.size > maxAllowedImageSize) {
        return false;
      } */
      this.profileService.uploadProfileImage(blob);
      this.resetImageContainer(); // reset all values
      $('#changeProfile').modal('hide');
    }
  }

  /* This function convert base64 image to blob object*/
  dataURItoBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    let byteString, mimeString, ia;

    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
        byteString = atob(dataURI.split(',')[1]);
    } else {
        byteString = unescape(dataURI.split(',')[1]);
    }

   // separate out the mime component
    mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    ia = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia], {
        type: mimeString
    });
}


}
