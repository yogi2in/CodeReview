import { LogLocalStorage } from './log-local-storage';

describe('LogLocalStorage', () => {
  it('should create an instance', () => {
    expect(new LogLocalStorage()).toBeTruthy();
  });
});
