const createWindowsInstaller = require('electron-winstaller').createWindowsInstaller
const path = require('path')

getInstallerConfig()
  .then(createWindowsInstaller)
  .catch(() => {
    console.log("Hdvc installers has been successfully created on ../release-builds/windows-installer/HDVC.exe!!!");
  }, (error) => {
    console.error(error.message || error)
    process.exit(1)
  })

function getInstallerConfig() {
  console.log('Creating Windows Installer...')
  const rootPath = path.join('./')
  const outPath = path.join(rootPath, 'release-builds')

  return Promise.resolve({
    appDirectory: path.join(outPath, 'Panasonic-win32-ia32/'),
    authors: 'Panasonic',
    exe: 'Panasonic.exe',
    iconUrl: 'https://hdvc.in.panasonic.com/../../assets/icons/win/logo.ico',
    loadingGif: path.join(rootPath, 'assets', 'images', 'loading.gif'),
    noMsi: true,
    outputDirectory: path.join(outPath, 'windows-installer'),
    setupExe: 'panasonic.exe',
    setupIcon: path.join(rootPath, 'assets', 'icons', 'win', 'logo.ico')
  })
}