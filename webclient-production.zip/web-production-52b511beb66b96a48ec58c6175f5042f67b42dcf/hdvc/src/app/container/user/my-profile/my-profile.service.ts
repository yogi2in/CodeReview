import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { HttpService } from '../../../shared/services/http.service';
import { Profile } from './Profile';
import { Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class MyProfileService {
  myProfile : Profile;
  userProfileData = {};

  private userProfileProcess = new Subject<{isSuccess :boolean, userProfileData: {},action:string}>();

  userProfileListner() {
    return this.userProfileProcess.asObservable();
  }
   
  constructor(private httpService: HttpService) { 
    }
    
    getuserProfile() {
        const param = {
          url : environment.BASE_URI_AUTH + 'user/profile',
          body: ""
        };
        return this.httpService.get(param);
      }

    putuserProfile(payload){
      const param = {
        url : environment.BASE_URI_AUTH + 'user/profile',
        body: payload
      };
      return this.httpService.put(param);
    }    

    updateuserpassword(payload){
      const param = {
        url : environment.BASE_URI_AUTH + 'changepassword',
        body: payload
      };
      return this.httpService.put(param);
    } 

    getCountryCode(){
      const param = {
        url : environment.BASE_URI_AUTH + 'country-codes',
        body: ""
      };
      return this.httpService.get(param)
    }
    processReqForUpdateUserProfile(userProfileData){
      // after success process request for pass updated data in component
      this.userProfileProcess.next({isSuccess: true, userProfileData:userProfileData, action:'update'});
    }

    uploadProfileImage(file){
      let formdata = new FormData();
      formdata.append("file", file);
      const param = {
        url : environment.BASE_URI_AUTH+'user/upload-image',
        body: formdata
      };
      this.httpService.post(param)
         .subscribe(
           (res) => {
             if(res["result"] != null){
               this.userProfileData = res["result"];      
             }
             // after success process request for pass updated data in component
             this.userProfileProcess.next({isSuccess: true, userProfileData:this.userProfileData,action:'upload'});
           }
         );
     }
}
