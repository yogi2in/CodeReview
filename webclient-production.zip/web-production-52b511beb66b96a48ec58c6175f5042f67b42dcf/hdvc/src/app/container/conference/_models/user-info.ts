export class UserInfo {
  isAudioShare: boolean = true;
  isVideoShare: boolean = true;
  isStreamAvailable: boolean;
  isUserPresenter: boolean = false;
  isUserMeetingOwner: boolean = false;
}
