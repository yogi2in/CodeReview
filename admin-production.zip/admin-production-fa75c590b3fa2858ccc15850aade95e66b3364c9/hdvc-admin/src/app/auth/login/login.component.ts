import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { LocalStorageService } from 'angular-2-local-storage';
import { AuthService } from '../auth.service';
import { Subscription } from 'rxjs';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm: FormGroup;
  
  private authSubscription = new Subscription();
  constructor(
      private authService: AuthService,
      private router: Router, 
      private cookieService: CookieService,
      private localStorageService: LocalStorageService ) { }

  ngOnInit() {
    
   this.loginForm = new FormGroup({
      email: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required),
      remindMe: new FormControl(null)
    });

    // Subscribe the Observables and change the router after login success
    this.authSubscription = this.authService.authProcessListener()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          this.router.navigate(['home']);
        }
      }
    );

    
  }

  onSignIn() {
    // When user click on form submit button without filling the fields then error will display.
    this.loginForm.controls['email'].markAsTouched();
    this.loginForm.controls['password'].markAsTouched();
    this.loginForm.controls['remindMe'].markAsTouched();
    let remindMe = this.loginForm.value.remindMe == null ? false : this.loginForm.value.remindMe;
    if (this.loginForm.valid) {
      this.authService.login(
        this.loginForm.value.email,
        this.loginForm.value.password,
        remindMe
      );
      // if remember me true set data in cookies
      if(this.loginForm.value.remindMe){
        this.localStorageService.set('remember',this.loginForm.value.remindMe);
      }else{
        this.localStorageService.remove('remember');
      }
      
    } else {
      console.log('form invalid!');
    }
  }

  

  // Destory the subscription.
  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
  }

}

