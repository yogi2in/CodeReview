import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LicenceManagementService } from  '../licence-management/licence-management.service';

@Component({
  selector: 'app-licence-management',
  templateUrl: './licence-management.component.html',
  styleUrls: ['./licence-management.component.css']
})
export class LicenceManagementComponent implements OnInit {
  private licenceListSubscription = new Subscription();
  licenceStatus = [{label:"NOT_STARTED",code:0 , value:"NOT STARTED"}, {label: "ACTIVE", code:1, value:"ACTIVE"},{label:"DELETED", code:2, value:"DELETED"},{label:"EXPIRED", code:3, value:"EXPIRED"}];
  fields = [
    "lotId",
    "Available Licences",
    "Used Licences",
    "Total Licences",
    "Start Date",
    "Expiry Date",
    "Status"
  ];
  constructor(private licence : LicenceManagementService) { }
  licenceData = [];
  ngOnInit() {

    this.licenceListSubscription = this.licence.licenceListListner()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          if(res.action == 'customerListAndLicence'){
            console.log("customerListAndLicence",res.data["list"])
            this.licenceData = res.data["list"];
          }
       }
      }
    );

    let currentUser = localStorage.getItem('currentUser');
      currentUser = JSON.parse(currentUser)
      if(currentUser["customerId"] != null){
        this.licence.getCustomerById(currentUser["customerId"])
      }
  }
  getLicenceStatus(statusCode){
    let status = this.licenceStatus.filter(x => x.code == statusCode)[0].value;
    return status;
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.licenceListSubscription.unsubscribe();
  }
}
