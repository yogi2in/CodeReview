import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';
import { UtilService } from '../shared/services/utils.services';
import { HttpService } from '../shared/services/http.service';
import { environment } from 'src/environments/environment';
import { CookieService } from 'ngx-cookie-service';
import * as moment from 'moment';
import { LocalStorageService } from 'angular-2-local-storage';

@Injectable({
    providedIn: 'root'
})

export class AuthService {
    public isLoggedIn: boolean;
    private authProcess = new Subject<{isSuccess: boolean, data: any}>();
    private signOutAuthentication = new Subject<{isLoggedIn: boolean}>();
    private authPermissionError = new Subject<{isError: boolean, errorObj: {}}>();
    public authTokenVal: void;
    public setPasswordProcess = new Subject<{data:{}, isSuccess: boolean, action:string}>();
    public showHeaderProcessForLoginUser = new Subject<{isSuccess: boolean, action:string}>();
    private domain =  window.location.hostname;
    private url = window.location.href;

    constructor(
      private _httpService: HttpService,
      private router: Router,
      private utils: UtilService,
      private cookieService: CookieService,
      private localStorageService: LocalStorageService
    ) { }

    authProcessListener() {
      return this.authProcess.asObservable();
    }

    setPasswordProcessListener() {
      return this.setPasswordProcess.asObservable();
    }

    showHeaderForLoginUserListner() {
      return this.showHeaderProcessForLoginUser.asObservable();
    }

    authPermissionErrorListener() {
      return this.authPermissionError.asObservable();
    }

    // Make Auto Login Feture. - Ankit Shukla.
    autoLogin(meetingId:any, token?:any) {
      const param = {
        url : environment.BASE_URI_AUTH +'user/me',
      };
      this._httpService.get(param).subscribe((res:any) => {
        if (res.result != null && (res.result.user.roleName == "CUSTOMER_ADMIN") || res.result.user.roleName == "USER") {
          this.clearStorage();
          this.isLoggedIn = true;
          this.setToken(res.result);
          this.authTokenVal = res.result.token;
          this.authProcess.next({ isSuccess: true, data: res['result']});
          // return this.router.navigate(['/join-meeting', meetingId]);
        }
        else {
          // for other role login show error msg(permission denied)
          let errorObj = {status: 403, message: "Permission denied"}
          this.authPermissionError.next({isError:true, errorObj: errorObj})
        }
      }),
      (error: any) => {
        this.authProcess.next({ isSuccess: false, data: error});
      }
    }

    login(emailid: string, password: string, remindMe) {
      const param = {
        url : environment.BASE_URI_AUTH +'login',
        body: {email: emailid, password: password, isRememberMe:remindMe} //isRememberMe:remindMe
      };
      this._httpService.post(param)
        .subscribe(
          (data: any) => {
            if (data.result != null && (data.result.user.roleName == "CUSTOMER_ADMIN") || data.result.user.roleName == "USER") {
              this.clearStorage();
              this.isLoggedIn = true;
              this.setToken(data.result);
              this.authTokenVal = data.result.token;
              this.authProcess.next({ isSuccess: true, data: data['result']});
            }
            else{
              // for other role login show error msg(permission denied)
              let errorObj = {status: 403, message: "Permission denied"}
              this.authPermissionError.next({isError:true, errorObj: errorObj})
            }

          },
          (error: any) => {
            // Error handeling
            this.authProcess.next({ isSuccess: false, data: error});
          }
        );
    }

    public callHeaderProcessAfterLogin(){
      this.showHeaderProcessForLoginUser.next({ isSuccess: true, action: 'setHeaderForLoginUser'});
    }

    public setToken(result): void {
      this.utils.setInfoInStorage('localStorage', 'currentUser', result.user);
      this.localStorageService.set('authToken', result.token);
      this.localStorageService.set('tokenExpirationTime', result.tokenExpirationTime);
    }

    public clearStorage(){
      console.log("clearStorage",this.domain)
      this.utils.removeFromStorage('localStorage', 'currentUser');
      this.utils.removeFromStorage('localStorage', 'socketUrl');
      this.utils.removeFromStorage('localStorage', 'is_owner');
      this.utils.removeFromStorage('localStorage', 'loginInfo');
      this.localStorageService.remove('authToken');
      this.localStorageService.remove('tokenExpirationTime');
    }

    public isSignOutPage() {
      return this.signOutAuthentication.asObservable();
    }

    public signOut() {
      console.log("signOut",this.domain)
      this.isLoggedIn = false;
      this.clearStorage();
      this.localStorageService.clearAll();
      this.signOutAuthentication.next({isLoggedIn: false});
      if(!(this.url.indexOf('join-meeting') > -1)){
        this.router.navigate(['/login']);
      }
    }

    setPassword(password: string, emailToken:string){
      const param = {
        url : environment.BASE_URI_AUTH +'password',
        body: {password: password, emailToken: emailToken}
      };
      this._httpService.post(param)
      .subscribe(
          (res) => {
            console.log(res)
            if(res["result"] != null){
             this.setPasswordProcess.next(
                {
                  data:{},
                  isSuccess: true,
                  action: "SetPassword"
                });
            }
          },
          err => {
            console.log(err);
            this.setPasswordProcess.next(
              {
                data: err.message,
                isSuccess: false,
                action: "SetPassword"
              });
          }
        );
    }

    public userExists() {
      if (this.localStorageService.get('authToken')) {
        let isAfter = this.checkTokenExpiryTime(this.localStorageService.get('tokenExpirationTime'));
        if(isAfter){
          // token expired
          this.signOut();
          console.log("token has expired")
          return false;
        }else{
           // token not expired
          return true;
        }
      } else {
        //not logged auth token didn't in cookie
        return false;
      }
    }

    checkTokenExpiryTime(time){
      let timeExp = Number(time);
       let tokenExpiryTime = moment(timeExp).format();
       let today = moment().format();
       let isAfter = moment(today).isAfter(tokenExpiryTime);
       return isAfter;
   }

   public getUserInfo(field){
    return this.utils.getInfoFromStorage('localStorage', field);
  }

  checkUserBasedOnRole(roleName){
    if(roleName == 'CUSTOMER_ADMIN'){
      return true;
    }else{
      return false;
    }
  }

  updateLocalStorageForLicenceUser(isValidLicence){
    let currentUser = this.getUserInfo("currentUser")
    if(currentUser != null && currentUser!= undefined){
      currentUser["isValidLicence"] = isValidLicence;
      this.utils.removeFromStorage('localStorage', 'currentUser');
      this.utils.setInfoInStorage('localStorage', 'currentUser', currentUser);
      this.callHeaderProcessAfterLogin()
    }
  }
}
