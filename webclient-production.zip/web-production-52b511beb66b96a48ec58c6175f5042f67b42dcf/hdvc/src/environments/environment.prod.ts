export const environment = {
  ENVIRONMENT_TYPE: 'PROD',
  production: true,
  SOCKET_URL: "wss://hdvc.in.panasonic.com:5501/groupcall", //This will not be used in stage
  BASE_URL: "https://hdvc.in.panasonic.com",
  BASE_URI: "https://17qkmcsa0c.execute-api.ap-south-1.amazonaws.com/Panasonic-UAT/",//"https://i7fjji4cm6.execute-api.ap-south-1.amazonaws.com/pucc-hdvc/",
  BASE_URI_AUTH: "https://hdvc.in.panasonic.com/api/",
  DAFAULT_MAX_PARTICIPANTS: 200,
  MAX_PARTICIPANTS: 199,
  HOST: "https://hdvc.in.panasonic.com",
  PAGE_SIZE: 10,
  HEARTBEAT_INTERVAL: 5000,
  LAYOUT_TYPE_ENUMS: {
    "1": "SPEAKER_VIEW",
    "2": "GRID_VIEW"
  },
  DESKTOP_ENABLED: true,
  WIN_DESKTOP_APP_PATH: "https://hdvc.in.panasonic.com/windows/panasonic.exe",
  LIN_DESKTOP_APP_PATH: "https://hdvc.in.panasonic.com/linux/panasonic",
  MAC_DESKTOP_APP_PATH: "https://hdvc.in.panasonic.com/mac/panasonic.dmg",
  CONFERENNCE_USER_GUID: "https://drive.google.com/file/d/1hXRDIVj79399DK-jxM2ynKzDvjg8GOWj/view?usp=sharing",
  CUSTOMER_USER_GUIDE: "https://drive.google.com/file/d/1KUWY6_4IQOMyoOeZWRIiR2kF0PYhyjOn/view?usp=sharing",
  LOG_LEVEL: [1, 3], // All = 0,   Debug = 1,  Info = 2,  Warn = 3,  Error = 4,  Fatal = 5,  Off = 6
  LOG_TYPE: [0], // 0 - console, 1 - localstorage , 2 - send to api
  WHITEBOARD_IFRAME_URL: "https://hdvc.in.panasonic.com/whiteboard",
  ADAPTIVE_VIEW: true,
  MIN_GRID_VIEW: 9,
  MAX_GRID_VIEW: 16,
  CURRENT_BANDWIDTH_USAGE_API_INTERVAL: 30000,
  LOCAL_STATS_CHECK_LOOP_COUNTER: 5,
  AVERAGE_BYTES_SENT_CHECK: 80,
  AVERAGE_BANDWIDTH_CHECK_COUNTER: 10,
  H264_CODEC: true,
  H264_ALL_PEER: false,
  USE_EXTENSION_FOR_SCREEN_SHARE: true,
  CONFIG_FROM_SESSION_STORAGE: true,
  USER_TYPE: 'WEB',
  ENABLED_DEVICE_SETTINGS: true
};


export enum Enums {
  ACTIVE = "Active",
  NOT_STARTED = "Not Started",
  EXPIRED = "Expired",
  EXPIRING_SOON = "Expiring Soon",
  DELETED = "Deleted",
}
