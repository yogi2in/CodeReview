import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserManagementService } from '../users/user-management.service';
import { Route, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../../auth/auth.service';
import { RoleManagementService } from '../role-management/role-management.service';
import { environment } from '../../../environments/environment';
import { NewsResolver } from '../../_guards/auth.guard.service';
import { ForgotPasswordService } from '../forgot-password/forgot-password.service';
declare var $;


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  private userSubscription = new Subscription();
  private permissionListSubscription = new Subscription();
  permissions = {};
  panasonicUserList;
  
  fields = [
    "Name",
    "Contact Number",
    "Email Address",
    "Status",
    "User Role"
  ];
  searchFields = ["fullName","mobile","email"];
  currentUserId;
  statusList = [{"label":"Active","value":"ACTIVE", "code":1},{"label":"Inactive","value":"INACTIVE", "code":2}, {"label":"Delete", "value":"DELETE", "code":3}];
  userStatus = [{"label":"Active", "value":"ACTIVE", "code":1},{"label":"Inactive","value":"INACTIVE", "code":2},{"label":"Delete", "value":"DELETE", "code":3},{"label":"Password Not Set","value":"PASSWORD NOT SET", "code":4}]
  filterValues;
  // paginator params
  currentPage = 1;
  numPerPage = environment.NUMBER_PER_PAGE;
  totalItem;
  routerName;
  editUserId;
  deleteUserId;
  staticAlertClosed;
  message;
  editUserDataObj;
  showGlobalError = false;
  private roleSubscription = new Subscription();
  roleList;
  selectedFilterStatus;
  selectedSearchString;
  selectedSearchFieldName;
  userParentList;
  partialError = null;
  resetMessage = null;
  constructor(private userService: UserManagementService, private authService: AuthService, private router: Router, private roleService:RoleManagementService, private newsResolver:NewsResolver, private _objForgotPasswordService: ForgotPasswordService) { }

  ngOnInit() {
      this.filterValues = this.userStatus.filter(x => x.value != 'DELETE')
      let userObj = this.authService.getCurrentUserObj();
      this.currentUserId = userObj["userId"];
      // get permission listner
      this.permissionListSubscription = this.newsResolver.permissionProcessListener()
      .subscribe(
      (res) => {
        if(res.isSuccess && res.isSuperUser == false){
          this.permissions = res.permission;
          
          this.statusList = this.statusList.filter(x => {
            if(this.permissions['EDIT'] && this.permissions['DELETE'] == false){
                if(x.value != 'DELETE'){
                  return x;
                }  
              }else if(this.permissions['EDIT'] == false && this.permissions['DELETE'] == true){
                if(x.value == 'DELETE'){
                  return x;
                } 
              }else{
                return x;
              }
          })

    

        }else if(res.isSuperUser){
          this.permissions = {"ADD": true, "VIEW": true, "EDIT": true, "DELETE": true};
        }
        // get all user role list if user has ADD or EDIT permissions
        if(this.permissions["ADD"] || this.permissions["EDIT"]){
          this.roleService.getAllRoles(1,1000);
        }
    })

      
     // Subscribe the Observables and change the router 
     let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
     this.userSubscription = this.userService.userProcessListener()
     .subscribe(
       (res) => {
          
          if (res.isSuccess === true && res.action != "updatePanasonicUser" && res.action != "createPanasonicUser" && res.action != 'GetAllParentUser') {
            this.panasonicUserList = res.data["list"];
            // when last page complete data is delete get previous page data
            if(this.panasonicUserList.length == 0 && this.currentPage > 1){
              this.currentPage = this.currentPage - 1
              this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData);
            }
            if(res.data["paginator"] != undefined && res.data["paginator"].totalItemCount){
              this.totalItem = res.data["paginator"].totalItemCount;
              this.currentPage = res.data["paginator"].currentPage;
            }
         }else if(res.action == "updatePanasonicUser" || res.action == "createPanasonicUser"){
              this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData)
         }
         /* else if(res.action == 'GetAllParentUser'){
          if (res.isSuccess === true) {
            this.userParentList = res.data["list"];
            this.userParentList = this.userParentList.filter(x => x.userId != userObj.userId)
            this.userParentList.unshift({"userId":userObj.userId, "roleName":userObj.roleName,"fullName":userObj.fullName})
            setTimeout(()=>{  
              $("#add-user-modal").modal('show');
            }, 1000);
          }
         } */
       },
       (error) => {
        this.showGlobalError = true;
       }
     );
    // call getAllPanasonicUser from userService  
    this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData)
    

    this.roleSubscription = this.roleService.roleProcessListener()
    .subscribe(
      (res) => {
        if (res.isSuccess === true){
            this.roleList = res.data["list"];
        }
      });
  }
  checkAll(ev) {
    if(this.panasonicUserList == undefined)return;
    this.panasonicUserList.forEach(x =>{
      if(this.currentUserId == x.userId){
        return x.state = true;
      }else{
        return x.state = ev.target.checked;
      }
    })
  }

  isAllChecked() {
    if(this.panasonicUserList == undefined || this.panasonicUserList.length == 0)return;
    return this.panasonicUserList.every(x => {
      if(this.currentUserId == x.userId){
        return true;
      }else{
        return x.state;
      }
    });
  }
   unCheckAll(){
    if(this.panasonicUserList == undefined || this.panasonicUserList.length == 0)return;
    this.panasonicUserList.forEach(x =>{
        return x.state = false;
    })
   }

  executeStatusAction(status){
    let selectedUserIds = [];
    this.partialError = null;
    this.panasonicUserList.filter(item => 
      {
        if(item.state == true && this.currentUserId != item.userId){
          selectedUserIds.push(item.userId)
        }
      }
      );
      if(selectedUserIds.length != 0){
        //let status = this.statusList.filter(item => item.label == event.target.value)[0].code;
        if(status.code == 3){
          this.deleteUserId = selectedUserIds;
          $("#delete-modal").modal('show');
        }else{
          let data = {
            "ids":selectedUserIds,
            "status":status.code
          }
          this.showGlobalError = true;
          this.userService.changePanasonicAdminUserStatus(data)
          .subscribe(
            (res) => {
              if(res.message != null && res.message != "" && res.name == "ValidationError"){
                this.partialError = res.message;
              }
              let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
              this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage,selectedData);
            },(error) => {
              console.log("error",error)
            },
            () => {
              this.unCheckAll();
              console.log("Finally clause");
            }
          );
        }
      }else{
        this.staticAlertClosed = false;
        this.message = "Please select at least one customer";
        this.FadeOutLink();
      }
  }

  editUser(id){
    this.router.navigate(['edit-user',id]);
  }

  deleteUser($event){
    this.showGlobalError = true;
    this.partialError = null;
    if($event.id != undefined && $event.id != null){
      let data = {"ids":[], "status":3};
      let str_array = $event.id[0].split(',');
      let array = JSON.parse("[" + str_array + "]");
      data["ids"] = array
      this.userService.changePanasonicAdminUserStatus(data)
      .subscribe(
        (res) => {
          $('#delete-modal').modal('hide');
          if(res.message != null && res.message != "" && res.name == "ValidationError"){
            this.partialError = res.message;
          }
          this.deleteUserId = null;
          let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
          this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData);
        },
        (error) => {
          console.log("error",error);
          $('#delete-modal').modal('hide');
        }
      );
    }
    
  }

  search(val, field){
    if(!val && field == 'userStatus'){
      this.selectedFilterStatus = null;
    }
    if(val){
      if(field == 'userStatus'){
        val = this.filterValues.filter(item => item.label == val)[0].code;
        this.selectedFilterStatus = val;
      }else{
        this.selectedSearchString = val;
        this.selectedSearchFieldName = field;
      }
       
      //always send current page 1 to status filter
      this.currentPage = 1;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
      this.userService.getPanasonicAdminByField(this.currentPage,this.numPerPage, selectedData)
    }else{
      this.selectedSearchString = field == 'userStatus' ? this.selectedSearchString :null;
      this.selectedSearchFieldName = this.selectedSearchString != null ? this.selectedSearchFieldName :null;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
      this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage,selectedData);
    }
  }

  clearSearch(val){
    if(!val){
      this.selectedSearchString = null;
      let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
      this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData);
    }
  }

  getNextPageData(pageNumber){
    let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
    this.userService.getAllPanasonicUser(pageNumber,this.numPerPage,selectedData);
  }

  getCustomerStatus(userStatus){
     return status = this.userStatus.filter(item => item.code == userStatus)[0].label;
  }

  onCloseModal(event) {
    let selectedData = {"selectedSearchString":this.selectedSearchString, "selectedSearchFieldName":this.selectedSearchFieldName, "selectedSearchStatus":this.selectedFilterStatus};
    this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage, selectedData)
  }

  openModal(id){
    this.showGlobalError = false;
    this.editUserDataObj = {};
    delete this.editUserDataObj[id];
    this.userService.getPanasonicUserById(id)
      .subscribe(
        (res) => {
          if(res["result"] != null){
            /* let filterValues = this.roleList.filter(x => x.roleId == res["result"].roleId)
            console.log("filterValues",filterValues)
            if(filterValues.length == 0 ){
              
              let obj = {"roleName":res["result"].roleName, "roleId": res["result"].roleId}
              this.roleList.unshift(obj);
            } */
            this.getParentUserList({"id":id,"editUserInstance":res["result"]});
            this.editUserDataObj[id] = {
              fullName: res["result"].fullName, 
              countryCode: res["result"].countryCode,
              mobile:res["result"].mobile, 
              email:null,
              selectedRole:res["result"].roleId,
              selectedParent:res["result"].parentId //res["result"].parentId
            }

              /* setTimeout(()=>{  
                $("#add-user-modal"+id).modal('show');
              }, 1000); */
          }
          
        }
      );
  }

  getPagingOffset(){
    let pageLabel;
    let firstLabel = 1+this.numPerPage*(this.currentPage-1);
    let secondLabel = (1+this.numPerPage*(this.currentPage-1))+(this.panasonicUserList.length-1);
    if(firstLabel == secondLabel){
      return firstLabel;
    }else{
      let pageLabel = firstLabel +"-"+secondLabel;
      return pageLabel;
    }
  }

  getParentUserList(objectRes){
    // call getAllParentActiveUser from userService
    let userObj:any = this.authService.getCurrentUserObj();
    this.userService.getAllParentActiveUser() 
      .subscribe(
        (res) => {
          if (res["result"] != null && res["result"].length != 0 ) {
            this.userParentList = res["result"];
              setTimeout(()=>{  
                if(objectRes.id != undefined && objectRes.id != null){
                  let filterValuesForUserParent = this.userParentList.filter(x => x.userId == objectRes.editUserInstance.parentId)
                  console.log("filterValuesForUserParent",filterValuesForUserParent)
                  if(filterValuesForUserParent.length == 0 ){
                    let obj = {"fullName":objectRes.editUserInstance.parentName, "roleId": objectRes.editUserInstance.parentId, "roleName": objectRes.editUserInstance.parentRole};
                    this.userParentList.unshift(obj);
                  }
                  $("#add-user-modal"+objectRes.id).modal('show');
                }else{
                  //this.userParentList = this.userParentList.filter(x => x.userId != userObj.userId)
                  //this.userParentList.unshift({"userId":userObj.userId, "roleName":userObj.roleName,"fullName":userObj.fullName});
                  $("#add-user-modal").modal('show');
                } 
              }, 1000); 
            
         }
      })
  }

  public resendEmail(email) {
    this.resetMessage = null;
    this._objForgotPasswordService.setPassword({"email":email,"email-type":"resend-set-password"})
    .subscribe((response:any) => {
      this.resetMessage = response.message;
    })
  }

  FadeOutLink() {
    setTimeout( () => {
          this.staticAlertClosed = true;
          this.message = null;
        }, 1000);
   }

  ngOnDestroy(){
    // prevent memory leak when component destroyed
    this.permissionListSubscription.unsubscribe();
    this.userSubscription.unsubscribe();
    this.roleSubscription.unsubscribe(); 
  }
}
