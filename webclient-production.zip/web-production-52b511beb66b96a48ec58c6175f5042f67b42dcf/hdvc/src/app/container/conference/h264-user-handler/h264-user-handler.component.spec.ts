import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { H264UserHandlerComponent } from './h264-user-handler.component';

describe('H264UserHandlerComponent', () => {
  let component: H264UserHandlerComponent;
  let fixture: ComponentFixture<H264UserHandlerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ H264UserHandlerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(H264UserHandlerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
