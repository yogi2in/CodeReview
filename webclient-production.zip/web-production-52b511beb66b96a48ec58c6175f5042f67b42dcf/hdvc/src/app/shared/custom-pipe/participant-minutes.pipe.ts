import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment-timezone';

@Pipe({
  name: 'participantMinutes'
})
export class ParticipantMinutesPipe implements PipeTransform {
  public minDate = moment().toDate();
  public zone: string = moment.tz(moment.tz.guess()).zoneAbbr();

  transform(value: any, args?: any): any {
    let result:any = 0;
    value.map((user)=> {
      result = result + this.getDifference(user.participantjointime, user.participantleavetime);
    })
    result = moment.utc(result).format("HH:mm:ss");
    return result;
  }

  getDifference(participantjointime, participantleavetime){
    let diffInSeconds;
    if(participantleavetime === undefined || participantleavetime === null) {
      let currentTime = moment().format();
      diffInSeconds = moment(currentTime).diff(moment(participantjointime), 'milliseconds');
    } else {
      diffInSeconds = moment(participantleavetime).diff(moment(participantjointime), 'milliseconds');
    }
    
    return diffInSeconds;
  }

}
