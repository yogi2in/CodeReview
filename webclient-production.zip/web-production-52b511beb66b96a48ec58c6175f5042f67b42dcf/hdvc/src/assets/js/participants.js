/*
 * (C) Copyright 2014 Kurento (http://kurento.org/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

const PARTICIPANT_MAIN_CLASS = "participant main participant-user";
const PARTICIPANT_CLASS = "participant participant-user";

/**
 * Creates a video element for a new participant
 *
 * @param {String} name - the name of the new participant, to be used as tag
 *                        name of the video element.
 *                        The tag of the new element will be 'video<name>'
 * @return
 */
function Participant(userId, name, isPresenter, hideUserLayout) {
  if (userId === undefined) {
    this.innerGetStats = window.getStats;
    return;
  }
  this.isPresenter = isPresenter;
  this.name = name;
  var container = document.createElement("div");
  container.setAttribute("data-user-name", name);
  container.className = isPresentMainParticipant()
    ? PARTICIPANT_CLASS + " " + name
    : PARTICIPANT_MAIN_CLASS + " " + name;
  //hide the new user layout
  if (hideUserLayout !== undefined && hideUserLayout === true) {
    container.classList.add("d-none");
  }

  if (this.name.length === 0) {
    container.classList.add("no-hover");
  }

  if (this.isPresenter === true) {
    container.classList.add("self");
  } else {
    container.classList.add("d-none");
  }
  //  else if ( this.isPresenter !== undefined && this.isPresenter === true) {
  //   container.classList.add('presenter');
  // }

  container.id = userId;
  var span = document.createElement("span");
  var noVideoSpan = document.createElement("span");
  var video = document.createElement("video");
  var hoverColor = document.createElement("div");
  var nameTextNode = document.createTextNode(name);
  var noVideoText = document.createTextNode("No Video Available");
  var noVideoWrapper = document.createElement("div");
  var videoStopByUserWrapper = document.createElement("div");
  var innerWrapperForVideoStop = document.createElement("div");

  var hostNameForVideoStop = document.createTextNode("Host");
  var userNameForVideoStop = document.createTextNode(name);
  var textNodeForVideoStop = document.createTextNode("Video Sharing Stopped");

  var hostSpanForVideoStop = document.createElement("span");
  var nameSpanForVideoStop = document.createElement("span");
  var msgeSpanForVideoStop = document.createElement("span");
  var rtcPeer;

  // video.style.height = 'auto';
  // video.style.width = 'auto';
  container.appendChild(video);
  container.appendChild(hoverColor);
  span.appendChild(nameTextNode);
  noVideoSpan.appendChild(noVideoText);
  container.appendChild(span);
  noVideoWrapper.appendChild(noVideoSpan);
  container.appendChild(noVideoWrapper);

  // hostSpanForVideoStop.classList.add('host-name');
  // hostSpanForVideoStop.appendChild(hostNameForVideoStop);

  // nameSpanForVideoStop.classList.add('non-host-name');
  // nameSpanForVideoStop.appendChild(userNameForVideoStop);

  msgeSpanForVideoStop.appendChild(textNodeForVideoStop);

  // innerWrapperForVideoStop.appendChild(hostSpanForVideoStop);
  // innerWrapperForVideoStop.appendChild(nameSpanForVideoStop);
  innerWrapperForVideoStop.appendChild(msgeSpanForVideoStop);

  videoStopByUserWrapper.appendChild(innerWrapperForVideoStop);
  container.append(videoStopByUserWrapper);

  // container.onclick = switchContainerClass;
  document.getElementById("participants").appendChild(container);

  video.id = "video-" + userId;
  video.setAttribute("data-user-name", name);
  video.classList.add("embed-responsive-item");
  video.autoplay = true;
  video.controls = false;
  hoverColor.classList.add("hover-color");
  noVideoWrapper.classList.add("no-video-wrapper");
  videoStopByUserWrapper.classList.add("video-stop-wrapper");
  // videoStopByUserWrapper.classList.add('d-none');
  this.getElement = function() {
    return container;
  };

  this.getVideoElement = function() {
    return video;
  };

  function switchContainerClass() {
    if (container.className === PARTICIPANT_CLASS) {
      var elements = Array.prototype.slice.call(
        document.getElementsByClassName(PARTICIPANT_MAIN_CLASS)
      );
      elements.forEach(function(item) {
        item.className = PARTICIPANT_CLASS;
      });
      container.className = PARTICIPANT_MAIN_CLASS;
    } else {
      container.className = PARTICIPANT_CLASS;
    }
  }

  function isPresentMainParticipant() {
    return document.getElementsByClassName(PARTICIPANT_MAIN_CLASS).length != 0;
  }

  this.offerToReceiveScreen = function(error, offerSdp, wp) {
    if (error) {
      return console.error("sdp offer error");
    }

    var msg = {
      req: "mediaChangeOffer",
      userId: userId,
      offer: offerSdp,
      share_scr: true
    };

    window.postMessage(JSON.stringify(msg), "*");
  };

  this.offerToStopScreen = function(error, offerSdp, wp) {
    if (error) {
      return console.error("sdp offer error");
    }
    var msg = {
      req: "mediaChangeOffer",
      userId: userId,
      offer: offerSdp,
      share_scr: false
    };
    window.postMessage(JSON.stringify(msg), "*");
  };

  this.offerToReceiveVideo = function(error, offerSdp, wp) {
    const sdpOffer = {
      req: "offer",
      userId: userId,
      offer: offerSdp
    };
    // console.log('this.offerToReceiveVideo --> ', sdpOffer);
    window.postMessage(JSON.stringify(sdpOffer), "*");
  };


  this.offerToReceiveVideoCopy = function(error, offerSdp, wp) {
    const sdpOffer = {
      req: "offer",
      userId: userId,
      offer: offerSdp
    };
    // console.log('this.offerToReceiveVideo --> ', sdpOffer);
    // window.postMessage(JSON.stringify(sdpOffer), "*");
  };

  this.offerToSendH264Video = function(error, offerSdp, wp) {
    const sdpOffer = {
      req: "h264Offer",
      userId: userId,
      offer: offerSdp
    };
    // console.log('this.offerToReceiveVideo --> ', sdpOffer);
    window.postMessage(JSON.stringify(sdpOffer), "*");
  };

  this.offerToChangeQualityVideo = function(error, offerSdp, wp) {
    const sdpOffer = {
      req: "videoQualityChange",
      userId: userId,
      offer: offerSdp
    };
    // console.log('this.offerToReceiveVideo --> ', sdpOffer);
    window.postMessage(JSON.stringify(sdpOffer), "*");
  };

  this.onIceCandidate = function(candidate, wp) {
    var message = {
      req: "onIceCandidate",
      candidate: candidate,
      userId: userId
    };
    window.postMessage(JSON.stringify(message), "*");
  };

  Object.defineProperty(this, "rtcPeer", { writable: true });

  this.dispose = function() {
    if (container.parentNode !== null) {
      container.parentNode.removeChild(container);
    }
    if (this.rtcPeer === undefined) {
      return;
    }
    this.rtcPeer.dispose();
  };
}
