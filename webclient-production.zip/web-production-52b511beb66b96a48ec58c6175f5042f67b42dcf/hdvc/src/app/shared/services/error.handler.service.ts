import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';


@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {
  constructor(private injector: Injector) {}
  handleError(error: any) {
    const router = this.injector.get(Router);
    console.log('URL: ' + router.url, error);
    if (error instanceof HttpErrorResponse) {
      // backend returns unccessful
      console.error('Backend returned status code: ', error.status);
      console.error('Response body: ', error);
    } else {
      // client side or network error
      // console.error('An error occured: ', error);
    }

    // const loggerService = this.injector.get(LoggerService);
    // console.log(loggerService);
    // loggerService.log(error);

  }
}
