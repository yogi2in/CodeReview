import { LogConsole } from './log-console';

describe('LogConsole', () => {
  it('should create an instance', () => {
    expect(new LogConsole()).toBeTruthy();
  });
});
