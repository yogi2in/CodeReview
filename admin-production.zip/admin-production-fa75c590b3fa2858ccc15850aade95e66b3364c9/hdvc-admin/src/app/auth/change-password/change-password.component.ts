import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import { UserManagementService } from '../../container/users/user-management.service';
import { AbstractControl } from '@angular/forms';
import {AuthService} from '../auth.service';
import { Route, Router } from '@angular/router';
import {CustomValidators} from '../../../app/shared/custom-validation/customValidators'
import { TrustedHtmlString } from '@angular/core/src/sanitization/bypass';
import { ProfileService } from '../../container/user-profile/profile.service';
declare var $;

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  showPasswordError:boolean;
  constructor(private UserManagement: UserManagementService, private auth:AuthService, private fb: FormBuilder, private router: Router, private profileService: ProfileService ) {
    
   }

  ngOnInit() {
    
    $('#change-password').on('hidden.bs.modal', () => {
      this.profileService.toggleChangePassword(false);
      this.changePasswordForm.reset();
    }); 
    
    this.changePasswordForm = this.fb.group({
      'oldPassword': ['', Validators.required ],
      'password' : ['', [ Validators.required,CustomValidators.strongpassword]],
      'confirmPassword' : ['', Validators.required ]
    },{
      validator: passwordMatcher // your validation method
    });

  }

  savePassword(){
    // When user click on form submit button without filling the fields then error will display.
    this.changePasswordForm.controls['oldPassword'].markAsTouched();
    this.changePasswordForm.controls['password'].markAsTouched();
    this.changePasswordForm.controls['confirmPassword'].markAsTouched();
    if(this.changePasswordForm.controls['password'].hasError('Strong')){
      this.changePasswordForm.controls['password'].setErrors(null);
    }
  
    if (this.changePasswordForm.valid) {
      let data = {
        "oldPassword":this.changePasswordForm.value.oldPassword,
        "newPassword": this.changePasswordForm.value.password
      }
      this.UserManagement.changePassword(data)
      .subscribe(
        (res) => {
          if(res["name"] == 'PasswordUpdateSuccess'){
            setTimeout(() => {
              this.changePasswordForm.reset('');
              $('#change-password').modal('hide') 
              this.auth.logout();
              this.router.navigate(['']);  
            }, 3000);
            
          }
        // },
        // error => {
        //   this.showPasswordError = true;
        });
     
    } else {
      console.log('form invalid!');
    }
 }
 ngAfterViewInit() {
  this.showPasswordError = true
}

}

export const passwordMatcher = (control: AbstractControl): {[key: string]: boolean} => {
  if (control.get('password') && control.get('confirmPassword')) {
    const password = control.get('password').value; // to get value in input tag
    const confirmPassword = control.get('confirmPassword').value; // to get value in input tag
    if (password !== confirmPassword && password && confirmPassword) {
      control.get('confirmPassword').setErrors( {matchPassword: true});
    } else if(!confirmPassword) {
      control.get('confirmPassword').setErrors( {required: true});
      return null;
    }else {
      control.get('confirmPassword').setErrors(null);
      return null;
    }
  }
  return null;
};
