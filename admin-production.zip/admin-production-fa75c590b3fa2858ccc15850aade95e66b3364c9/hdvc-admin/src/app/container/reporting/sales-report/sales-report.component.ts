import { Component, OnInit } from '@angular/core';
import { ReportsService } from '../report.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators'
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';

@Component({
  selector: 'app-sales-report',
  templateUrl: './sales-report.component.html',
  styleUrls: ['./sales-report.component.css']
})
export class SalesReportComponent implements OnInit {
  public upComingRecordsNo;
  public reports;
  public totalrecords;
  public startItemNumber;
  public lastItemNumber;
  public xlsDownloadUrl;
  public pdfDownloadUrl;
  public noRecordFound :boolean = true;
  public default_page_size = environment.NUMBER_PER_PAGE;
  public fields = [
    'Owner Name',
    'Enterprise Name',
    'Total Licences Sold',
    'Total Licences expiring in 2 months'
  ];
  public searchCustName;
  public hideList: boolean = false;
  public searchOwnerName: FormControl = new FormControl();
  public roleSearchField: FormControl = new FormControl();
  private _isQueryChange: boolean = true;
  public custStatus;
  public ownerId;
  public salesReportForm: FormGroup;
  public fromDateMillSec;
  public toDateMillSec;
  public dateSelectionError: boolean = false;
  public showLoader: boolean = false;
  public hideBtn:boolean = false;
  public roleTypeFilter;
  public searchRoleName;
  public selectedReportType: string = '0';
  public userStatus = [
    {"label":"Not Started","value":"NOT STARTED", "code":0},
    {"label":"Active", "value":"ACTIVE", "code":1},
    {"label":"Deleted","value":"DELETED", "code":2},
    {"label":"Expired", "value":"EXPIRED", "code":3},
    {"label":"Expiring Soon","value":"EXPIRING_SOON", "code":4},
  ]
  public hideFilterpanel:boolean = true;
  constructor(
    private _report: ReportsService,
    public _bsDatePickerConfig: BsDatepickerConfig
    ) { 
      this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
      }

  ngOnInit() {
    /*
    * The below code get the form data.
    */
    this.salesReportForm = new FormGroup({
      fromDate: new FormControl(null, Validators.required),
      toDate: new FormControl(null, Validators.required),
      roleType: new FormControl('2'),
      roleName: new FormControl(null),
      reportType: new FormControl('0')
    })

    /*
    * The below function get the role Api data.
    */
    this._report.getRoleName()
    .subscribe(
      (res) => {
        if(res.result.length > 0) {
          this.searchRoleName = res.result;
        }
      }
    )

    /*
    * The below code fetching the customer list when entring any value in input box.
    */
    this.searchOwnerName.valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()
    )
    .subscribe(
      searchOwnerName =>
      {
        const queryString = this.searchOwnerName.value;
        if(queryString.length < 3) {
          this.custStatus = ''
        }
        if (this._isQueryChange === false || queryString.length < 3) {
          this.hideList  = false;
          return;
        }
        
        let obj = this.enterpriseFilterDetails();

        const data = {
          ownerName: searchOwnerName,
          roleType: obj.roleType,
          roleName: obj.roleName
        }
        this._report.ownerNameDetails(data)
        .subscribe(
          (res) => {
            this.searchCustName = res.result;
            if(res.result.length > 0) {
              this.hideList  = true;
              this.searchCustName = res.result;
            }
          }
        )
      }
    ) 
    
  }

  /*
  * The below function take the roleType and roleName.
  */
  enterpriseFilterDetails() {
    let roleType;
    let roleName = this.salesReportForm.controls['roleName'].value;
    let reportType = this.salesReportForm.controls['reportType'].value;

    if(roleName != undefined && roleName != null && roleName != ''){
      roleName = roleName
    } else {
      roleName = null
    }

    if(reportType != undefined && reportType != null && reportType != ''){
      reportType = reportType
    } else {
      reportType = null
    }

    // The below code give the roleType value DIRECT/CHANNELED, 
    //this.roleTypeFilter value is coming when change the role type. 
    if(this.roleTypeFilter != undefined && this.roleTypeFilter != null){
      if(this.roleTypeFilter === 0) {
        roleType = 'DIRECT'
      } else if (this.roleTypeFilter === 1) {
        roleType = 'CHANNELED'
      } else {
        roleType = null
      }
    } else {
      roleType = null
    }

    let obj = {
      roleType: roleType,
      roleName: roleName,
      reportType: reportType
    }
    return obj
  }

  /*
  * The below function hide the dropdown when normal input focus work.
  */
  onFocus(): void {
    this._isQueryChange = true;
  }

  /*
  * The below function hide the dropdown when click on outside.
  */
  onBlur() {
    setTimeout(() => {
      this.hideList  = false;
    }, 500);
  }

  /*
  * The below function checking form date value ,convert date, show loader .
  */
  salesReport() {
    this.reports = []
    this.totalrecords = 0;
    this.hideBtn = false;
    this.fromDateMillSec = null;
    this.toDateMillSec = null;
    let fromDateVal = this.salesReportForm.controls.fromDate.value;
    let toDateVal = this.salesReportForm.controls.toDate.value;
    this.selectedReportType = this.salesReportForm.controls['reportType'].value;
    
    if(fromDateVal != null && fromDateVal != undefined && fromDateVal != null && fromDateVal != undefined ) {
      this.convertDateInToMillSec(fromDateVal, toDateVal);
    }

    if(this.toDateMillSec >= this.fromDateMillSec){
      this.dateSelectionError = false;
      this.showLoader = true;
      this.noRecordFound = false;
      this.getSalesReportData(1);
    } else {
      this.dateSelectionError = true;
    }
  }

  /*
  * The below function converting date into millisecond.
  */
  convertDateInToMillSec(fromDate, toDate) {
    this.fromDateMillSec = moment(fromDate).valueOf();
    this.toDateMillSec = moment(toDate).valueOf();
  }

  /*
  * The below function getting the status value and custOwnerId and set list text on click list into input box.
  */
  getListData(event) {  
    let currentEle = event.target.innerText
    let custStatus = event.target.getAttribute('custStatusValue');
    this.ownerId = event.target.getAttribute('custOwnerId');
    this.custStatus = custStatus != undefined && custStatus != null && +custStatus === 1 ? 'Active' : 'Inactive'
    this.searchOwnerName.setValue(currentEle);
    this._isQueryChange = false;
    this.hideList  = false;
  }

  /*
  * The below function fetching the sales report data and argument is pageIndex, ownerId, fromDate, toDate.
  */
  getSalesReportData(page) {
    let obj = this.enterpriseFilterDetails();
    let ownerName = this.searchOwnerName.value;

    this.upComingRecordsNo = page;  
    const data = {
      pageIndex: page == undefined ? 1 : page,
      ownerId: this.ownerId,
      fromDate: this.fromDateMillSec,
      toDate: this.toDateMillSec,
      ownerName: ownerName,
      roleName: obj.roleName,
      roleType: obj.roleType,
      reportType: obj.reportType
    }
    this._report.getSalesReportData(data).subscribe(
      (res) => {
        if(res.result != undefined && res.result != null && res.result.data != undefined && res.result.data != null) {
          this.showLoader = false;
          this.reports = res.result.data;
          this.totalrecords = res.pagination.totalItemCount;
          this.startItemNumber = res.pagination.firstItemNumber;
          this.lastItemNumber = res.pagination.lastItemNumber;
          this.xlsDownloadUrl  = res.result.downloadAsXls;
          this.pdfDownloadUrl  = res.result.downloadAsPdf;
          this.hideBtn = true;
          this.hideMobilepanel();

          if(this.reports.length > 0) {     // if record 0 show noRecordFound field.
            this.noRecordFound = false;
          } else {
            this.noRecordFound = true;
            this.hideBtn = false;
          }
          
        } else {
          return;
        }
      },
      (error) => {
        console.log(error);
      }
    )
  }

  /*
  * The below function download the PDF file.
  */
  downloadPdf(pdfFileurl: string) {
    if (pdfFileurl === undefined || typeof pdfFileurl !== 'string') {
      return;
    }
    window.open(this.pdfDownloadUrl,'_blank');
  }

  /*
  * The below function download the Excel file.
  */
  downloadXls(xlsFileUrl: string) {
    if(xlsFileUrl === undefined || typeof xlsFileUrl !== 'string') {
      return;
    }
    window.location.href = xlsFileUrl; 
  }

  /*
  * The below function reset the form fields.
  */
  resetFields() {
    this.salesReportForm.reset();
    this.custStatus = false;
    this.ownerId = null
    this.reports = []
    this.noRecordFound = true;
    this.totalrecords = 0;
    this.dateSelectionError = false;
    this.hideBtn = false;
    this.selectedReportType = '0';
    setTimeout(() => {
      this.salesReportForm.patchValue({   // Reset the roles when change the Role type.
        roleType: '2',
        reportType: '0'
      })
    }, 10);
  }

  /*
  * The below function filter the role field on the basic of role type.
  */
  filterRoleField() {
    
    // Reset the roles when change the Role type.
    this.salesReportForm.patchValue({  
      roleName: ''
    })

    // Get the values when change the Role type.
    this.salesReportForm.controls.roleType.valueChanges.subscribe(
      (res) => {
        if(res === '0') {                   // if role type is Direct
          this.roleTypeFilter = 0;
        } else if (res === '1') {           // if role type is Channeled
          this.roleTypeFilter = 1;
        } else if (res === '2') {           // if role type is All
          this.roleTypeFilter = 2;
        }
      }
    )
  }

  getCustomerStatus(userStatus){
    return status = this.userStatus.filter(item => item.code == userStatus)[0].label;
 }

 hideMobilepanel(){
   let windowWidth = window.innerWidth;
   if(windowWidth < 768) {
    if(this.hideFilterpanel){
      this.hideFilterpanel = false;
      console.log(this.hideFilterpanel)
     } else {
      this.hideFilterpanel = true;
      console.log(this.hideFilterpanel)
     }
   }
   
   
 }

}
