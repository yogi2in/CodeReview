import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesktopAppDownloadComponent } from './desktop-app-download.component';

describe('DesktopAppDownloadComponent', () => {
  let component: DesktopAppDownloadComponent;
  let fixture: ComponentFixture<DesktopAppDownloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesktopAppDownloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesktopAppDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
