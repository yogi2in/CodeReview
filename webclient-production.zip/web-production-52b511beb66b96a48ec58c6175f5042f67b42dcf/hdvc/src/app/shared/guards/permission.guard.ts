import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PermissionGuard implements CanActivate {

  constructor(private router: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    let nextActivateRoute = next.routeConfig.path;
    // console.log("nextActivateRoute",nextActivateRoute)
    if (nextActivateRoute == 'schedule-meeting') {
      let currentUser = localStorage.getItem('currentUser');
      currentUser = JSON.parse(currentUser)
      if(currentUser != undefined && currentUser["isValidLicence"]) {
        return true;
      }
      else {
        this.router.navigate(['/my-meetings']);
        return false;
      }
      /*
      if(currentUser != undefined && currentUser["isValidLicence"]) {
        this.router.navigate(['/my-meetings']);
      }
      return true;
      */
    }
    else {
      return true;
    }
  }
}
