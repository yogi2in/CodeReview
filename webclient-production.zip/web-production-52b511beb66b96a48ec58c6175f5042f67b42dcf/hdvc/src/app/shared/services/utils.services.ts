import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import * as uaParserJS from 'ua-parser-js';
import { HttpService } from './http.service';
import { environment } from 'src/environments/environment';
import { DeviceDetectorService } from 'ngx-device-detector';

@Injectable({ providedIn: 'root' })
export class UtilService {
  private _browserInfo: any;
  startTime: any;
  endTime: any;
  downloadSize = 1933312;
  private checkInternetSpeedObs$ = new Subject<{ currentSpeed: any }>();
  private alertMessageObs$ = new Subject<{ message: string, msgLevel: string }>();
  private notifyScreenSharedObs$ = new Subject<{ message: any }>();
  private onInternetCheckObs$ = new Subject<{ message: any }>();
  private notificationMessage: any = {
    "SOCKET_STATE_CHANGE": "Connectivity lost. Trying to reconnect...",
    "SOCKET_CHANGE_VALIDATION_FAILED": "Unable to reconnect. Please try later.",
    "ICE_FAILED": "Unable to connect using your browser. Please try desktop app instead or contact your network administrator.",
    "JOIN_MEETING_VALID_API_FAILED": "Unable to contact server at this time. Please check internet connectivity & try again.",
    "CLEAR_SESSION": "Server stopped receiving response from you. Trying to reconnect..."
  }

  private turnsConfigurations = {
    PROD: [
      {
        urls: "turns:testturn.truringsoftek.co.in:5349?transport=udp",
        credential: "hdvc123t321hdvc",
        username: "kurento"
      }, {
        urls: "turns:testturn.truringsoftek.co.in:5349?transport=tcp",
        credential: "hdvc123t321hdvc",
        username: "kurento"
      }
    ],
    STAGING: [
      {
        'urls': 'turns:dev-kurento1.impressicocrm.com:5349?transport=tcp',
        'username': 'kurento',
        'credential': 'pass!@#$'
      }
    ],
    DEV: [
      {
        'urls': 'turns:dev-kurento.impressicocrm.com:5349?transport=tcp',
        'username': 'kurento',
        'credential': 'pass!@#$'
      }
    ]
  }

  // private notifyToStopScreenSharedObs$ = new Subject<{message: boolean}>();
  public deviceInfo;
  constructor(
    private httpService: HttpService,
    private deviceService: DeviceDetectorService) {

  }

  public initBrowserInfo() {
    const ua = window && window.navigator ? window.navigator.userAgent : '';
    const parser = new uaParserJS(ua);
    this._browserInfo = parser.getBrowser();
  }

  public getBrowserInfo() {
    return this._browserInfo;
  }
  public alertMesssageListener() {
    return this.alertMessageObs$.asObservable();
  }

  public sendAlertMessage(message: string, msgLevel) {
    this.alertMessageObs$.next({ message: message, msgLevel: msgLevel });
  }

  public notifyScreenShared(message: any) {
    return this.notifyScreenSharedObs$.next({ message: message });
  }

  public notifyScreenSharedListener() {
    return this.notifyScreenSharedObs$.asObservable();
  }

  // public notifyToStopScreenShared(status: boolean) {
  //   return this.notifyToStopScreenSharedObs$.next({
  //     message: status
  //   });
  // }

  // public notifyToStopScreenSharedListener() {
  //   return this.notifyToStopScreenSharedObs$.asObservable();
  // }



  setInfoInStorage(type: string, keyName: string, value: any) {
    if (value === undefined) {
      return;
    }
    // Store the details in session/local storage
    const storage = type === 'session' ? sessionStorage : localStorage;
    if (storage.getItem(keyName) !== null) {
      storage.removeItem(keyName);
    }
    storage.setItem(keyName, JSON.stringify(value));
  }

  getInfoFromStorage(type: string, keyName: string) {
    const storage = type === 'session' ? sessionStorage : localStorage;
    if (storage.getItem(keyName) === null || storage.getItem(keyName) === undefined) {
      return null;
    }

    return JSON.parse(storage.getItem(keyName));
  }

  removeFromStorage(type: string, keyName: string) {
    const storage = type === 'session' ? sessionStorage : localStorage;
    storage.removeItem(keyName);
  }

  onInternetCheckListener() {
    return this.onInternetCheckObs$.asObservable();
  }

  isInternetConnected(url: string) {
    const param = {
      url: environment.BASE_URI + "meeting/validate_meeting",
      body: {}
    };
    this.httpService.post(param).subscribe(
      (response) => {
        this.onInternetCheckObs$.next({ message: 1 });
      },
      (error) => {
        this.onInternetCheckObs$.next({ message: 0 });
      }
    )
  }


  checkInternetSpeedListner() {
    return this.checkInternetSpeedObs$.asObservable();
  }

  checkInternetSpeed() {
    var imageAddr = "https://images.pexels.com/photos/145939/pexels-photo-145939.jpeg?cs=srgb&dl=animal-animal-photography-big-cat-145939.jpg?n=" + Math.random();
    // var startTime, endTime, downloadSize = 1933312;
    var download = new Image();
    download.onload = () => {
      this.endTime = (new Date()).getTime();
      this.showResults()
    }
    this.startTime = (new Date()).getTime();
    download.src = imageAddr;
  }

  showResults() {
    const duration = (this.endTime - this.startTime) / 1000;
    let currentSpeed: any;
    let bitsLoaded: any = this.downloadSize * 8;
    let speedBps: any = Math.round(bitsLoaded / duration);
    let speedKbps: any = (speedBps / 1024).toFixed(2);
    let speedMbps: any = (speedKbps / 1024).toFixed(2);

    if (parseInt(speedMbps) > 0) {
      currentSpeed = speedMbps + ' Mbps';
    } else if (parseInt(speedKbps) > 0) {
      currentSpeed = speedKbps + ' Kbps';
    } else {
      currentSpeed = speedBps + 'Bps';
    }
    console.log('currentSpeed ', currentSpeed);
    this.checkInternetSpeedObs$.next({
      currentSpeed: currentSpeed
    });
    // console.log("Your connection speed is: \n" + speedBps + " bps\n" + speedKbps + " kbps\n" + speedMbps + " Mbps\n")
  }

  getDeviceDetection() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log("deviceInfo", this.deviceInfo);
    return this.deviceInfo;
  }

  checkIsDesktopApp() {
    let insideDeskTopApp = false;
    this.deviceInfo = this.deviceService.getDeviceInfo();
    // console.log("deviceInfo", this.deviceInfo);
    if (this.deviceInfo != undefined) {
      insideDeskTopApp = this.deviceInfo.userAgent.indexOf("Electron") > -1 ? true : false;
    }
    // console.log("insideDeskTopApp", insideDeskTopApp)
    return insideDeskTopApp;
  }

  getDeskTopAppUrlBasedOnOS() {
    let path;
    this.getDeviceDetection();
    if (this.deviceInfo != null) {
      if (this.deviceInfo.os.toLowerCase() == 'Windows' || this.deviceInfo.os.toLowerCase() == 'windows') {
        path = environment.WIN_DESKTOP_APP_PATH;
      } else if (this.deviceInfo.os.toLowerCase() == 'mac') {
        path = environment.MAC_DESKTOP_APP_PATH;
      } else if (this.deviceInfo.os.toLowerCase() == 'linux') {
        path = environment.LIN_DESKTOP_APP_PATH;
      }
      return path;
    }
  }

  isAppDownloadEnabled = () => {
    if (
      environment.DESKTOP_ENABLED &&
      this.getInfoFromStorage('session', 'downloadApplication') == null
    ) {
      return true
    }
    else {
      return false
    }
  }
  /*
  isAppDownloadEnabled = () => {
    if (
      environment.DESKTOP_ENABLED &&
      this.getInfoFromStorage('session', 'downloadApplication') == null &&
      !this.isMobile()
    ) {
      return true
    }
    else {
      return false
    }
  }
  */

  /**
     * Check if the user-agent is Android
     *
     * @private
     * @returns {Boolean} true/false
     */
  isAndroid = function () {
    return navigator.userAgent.match('Android');
  }

  /**
   * Check if the user-agent is iPad/iPhone/iPod
   *
   * @private
   * @returns {Boolean} true/false
   */
  isIOS = function () {
    return navigator.userAgent.match('iPad') ||
      navigator.userAgent.match('iPhone') ||
      navigator.userAgent.match('iPod');
  }

  /**
   * Check if the user is on mobile
   *
   * @private
   * @returns {Boolean} true/false
   */
  isMobile = function () {
    return this.isAndroid() || this.isIOS();
  }

  getNotificationMessage(erroKey: string): string {
    if (erroKey !== undefined && this.notificationMessage[erroKey]) {
      return this.notificationMessage[erroKey];
    }
    return "";
  }

  getTurnsConf(env: string) {
    if (env !== undefined && this.turnsConfigurations[env]) {
      return this.turnsConfigurations[env];
    }
    return [];
  }

  getEnvironmentValue(key: string): any {
    let result = null;
    if (key !== undefined) {
      let envFromStorage = this.getInfoFromStorage('session', 'environment');
      if (envFromStorage === null) {
        result = environment[key];
      } else {
        let configFromSessionStorage = envFromStorage['CONFIG_FROM_SESSION_STORAGE'];
        if (envFromStorage !== null && envFromStorage[key] !== undefined && configFromSessionStorage) {
          result = envFromStorage[key];
        } else {
          result = environment[key];
        }
      }

    }
    return result;
  }

  generateRandomAlphaNumericString(charNumber: number): string {
    let result = '';
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let charactersLength = characters.length;
    for (let i = 0; i < charNumber; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }
}
