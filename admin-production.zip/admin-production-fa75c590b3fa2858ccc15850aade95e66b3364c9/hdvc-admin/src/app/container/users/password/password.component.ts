import { Component, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { FormGroup, FormControl, FormBuilder, Validators} from '@angular/forms';
import { Subscription } from 'rxjs';
import { Route, Router } from '@angular/router';
import { UserManagementService } from '../user-management.service';
import { ActivatedRoute } from '@angular/router';
import {AuthService} from '../../../auth/auth.service';
import {CustomValidators} from '../../../../app/shared/custom-validation/customValidators';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})

export class PasswordComponent implements OnInit {
  createPasswordForm: FormGroup;
  private userSubscription = new Subscription();
  emailToken: string;
  private sub: any;
  public successMessage;

  constructor(private userService: UserManagementService, private auth:AuthService, private router: Router, private route: ActivatedRoute, private fb: FormBuilder, private authservice : AuthService) { }

  ngOnInit() {
    this.authservice.removeToken();
    this.createPasswordForm = this.fb.group({
      'password': [null, [Validators.required, CustomValidators.strongpassword]],
      'confirmPassword' : [null, Validators.required ]
    }, {
      validator: passwordMatcher // your validation method
    });

    this.sub = this.route.params.subscribe(params => {
      this.emailToken = params['emailToken'];
    });

    // Subscribe the Observables and change the router after password save
    this.userSubscription = this.userService.userProcessListener()
    .subscribe(
      (res) => {
        this.successMessage = null;
        if (res.isSuccess === true) {
          this.successMessage = "Password Saved Successfully"
          let self = this
          setTimeout(function() {
            self.authservice.logout();
            self.router.navigate(['']);
          },1000)
        }else{
          //this.errorMessage = res.data;
        }
      },
      (error) => {
        // code to handel rejection.
      }
    );


  }

  savePassword(){
     // When user click on form submit button without filling the fields then error will display.
     this.createPasswordForm.controls['password'].markAsTouched();
     this.createPasswordForm.controls['confirmPassword'].markAsTouched();
     if(this.createPasswordForm.controls['password'].hasError('Strong')){
      this.createPasswordForm.controls['password'].setErrors(null);
    }
     if (this.createPasswordForm.valid) {
        this.userService.setPassword(
        this.createPasswordForm.value.password,
        this.emailToken
        );
     } else {
       console.log('form invalid!');
     }
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}

export const passwordMatcher = (control: AbstractControl): {[key: string]: boolean} => {
  if (control.get('password') && control.get('confirmPassword')) {
    const password = control.get('password').value; // to get value in input tag
    const confirmPassword = control.get('confirmPassword').value; // to get value in input tag
    if (password !== confirmPassword) {
      control.get('confirmPassword').setErrors( {matchPassword: true});
    } else {
      control.get('confirmPassword').setErrors(null);
      return null;
    }
  }
  return null;
};
