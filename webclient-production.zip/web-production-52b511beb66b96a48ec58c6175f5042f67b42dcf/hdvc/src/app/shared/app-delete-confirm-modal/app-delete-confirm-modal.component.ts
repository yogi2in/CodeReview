import { Component, OnInit,  Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-app-delete-confirm-modal',
  templateUrl: './app-delete-confirm-modal.component.html',
  styleUrls: ['./app-delete-confirm-modal.component.css']
})
export class AppDeleteConfirmModalComponent implements OnInit {
  @Output() deleteUser: EventEmitter<any> = new EventEmitter();
  @Input() deleteUserId;
  @Input() currentUserId;
  constructor() { }

  ngOnInit() {
    console.log("deleteUserId",this.deleteUserId)
  }

  remove(event,id){
    this.deleteUser.emit({ event:event,id:id });
  }

}
