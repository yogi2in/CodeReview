import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmMeetingModalComponent } from './confirm-meeting-modal.component';

describe('ConfirmMeetingModalComponent', () => {
  let component: ConfirmMeetingModalComponent;
  let fixture: ComponentFixture<ConfirmMeetingModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmMeetingModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmMeetingModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
