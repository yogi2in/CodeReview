import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';
import { Key } from 'protractor';
import { isNull } from '@angular/compiler/src/output/output_ast';

export class CustomValidators {
  error = {};
   /* This method is used for compare two dates and check if end date is greater then start date return error */
  static compareDate(control: AbstractControl) {
   if (control.value !== null && control.parent !== undefined ) {
     const meetingEndDate = control.value;
     const meetingStartDate = control.parent.get('start_date').value;
     // const meetingEndDate = control.parent.get('meetingEndDate').value;
     const errorObj = CustomValidators.compareTwoDates(meetingStartDate, meetingEndDate);
     if (errorObj != null) {
        return { isInvalidDate: errorObj};
     }
    }
   return null;
 }

  /* This function return error if end date is less then start date */
  static compareTwoDates(meetingStartDate, meetingEndDate){
    let isPreviousDate = moment(meetingStartDate, 'DD-MM-YYYY').isBefore(moment().format("DD-MM-YYYY"));
    //let startDate = moment(meetingStartDate, 'YYYY-MM-DD');
    //let endDate = moment(meetingEndDate, 'YYYY-MM-DD');
    //End date should not be less than start date
    //let duration = moment.duration(endDate.diff(startDate));
    //let days = duration.asDays();
    if (isPreviousDate){
      return {isDateError: true, errorMessage: 'Please select valid meeting date.'};
    //}
    // else if(days < 0) {
    //   return {isDateError: true, errorMessage: 'Invalid End date.'};
    } else {
      return null;
    }
  }

  /* This function match password and confirm password value */
  static passwordMatcher (control: AbstractControl): {[key: string]: boolean} {
    if (control.get('newpassword') && control.get('confirmpassword')) {
      const password = control.get('newpassword').value; // to get value in input tag
      const confirmPassword = control.get('confirmpassword').value; // to get value in input tag
      if (password !== confirmPassword) {
        console.log('false');
        control.get('confirmpassword').setErrors( {matchPassword: true});
      } else {
        console.log('true');
        if(control.get('newpassword').hasError('Strong')){
          control.get('newpassword').setErrors(null);
          }
        return null;
      }
    }
    return null;
  }

  static strongpassword(control: AbstractControl):{[key: string]: boolean} {
    let totalstrength=0;
    if(control.value=== "" || control.value==null){
      return null
    }
    let hasNumber = /\d/.test(control.value);
    if(hasNumber)
    {
      totalstrength += 20;
    }
    let hasUpper = /[A-Z]/.test(control.value);
    if(hasUpper)
    {
      totalstrength += 20;
    }
    let hasLower = /[a-z]/.test(control.value);
    if(hasLower)
    {
      totalstrength += 20;
    }

    let val = control.value;
    if(val!=""){
    if(val.length>= 8)
    {
      totalstrength += 20;
    }
  }

    let specialchar = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(control.value)
    if(specialchar)
    {
      totalstrength += 20;
    }

    if (totalstrength>0 && totalstrength<60) {
        return {'Weak': true};
    }
    if (totalstrength<=80) {
      return {'Good': true};
    }
    if(totalstrength==100)
    {
      return {'Strong': true};
    }
    else
    {
      return null;
    }
}

}
