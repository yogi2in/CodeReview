import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { Route, Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NewsResolver } from '../_guards/auth.guard.service';
import { Subscription } from 'rxjs';
import { ProfileService } from '../container/user-profile/profile.service';
declare var jQuery;

@Component({
  selector: 'app-sidebar-panel',
  templateUrl: './sidebar-panel.component.html',
  styleUrls: ['./sidebar-panel.component.css']
})
export class SidebarPanelComponent implements OnInit {
  public dashboard;
  public adminPage;
  public licenceReports;
  public clickCounter = 0;
  showRoleManagement = false;
  permissions = {};
  @Input() collapseMenu;
  public collapseMenuBarHide;
  public profileData:any;
  public profileImage: any;
  private loggedInSubscription = new Subscription();
  private userSubscription = new Subscription();
  constructor(
    private authService: AuthService,
    private router: Router,
    private permissionService : NewsResolver,
    private profileService: ProfileService) { }

  ngOnInit() {
    console.log("side bar")
    this.getRouteOnPageRefresh();
    this.loggedInSubscription = this.authService.authProcessListener()
    .subscribe(
      (res) => {
          if(res.isSuccess){
            let user = res.data["user"];
            this.showRoleManagement = user.isSuperUser == true ? true : false;
          }
      })

      //let currenUser = this.authService.getCurrentUserObj();
      //this.showRoleManagement = currenUser != undefined && currenUser.roleName == 'PANASONIC_ADMIN' ? true : false;

      this.authService.getLoggedInUserPrivilege()
      .subscribe(
        (res) => {
          if(res.result != null && res.result.length != 0){
            let permissionData = res.result;
            this.showRoleManagement = permissionData.isSuperUser;
            console.log("showRoleManagement",this.showRoleManagement)
            permissionData.resourceActionsPairs.forEach(value => {
              this.permissions[value.resourceName] = value.actions;
            })
          }
        })
        jQuery('.child-nodes a.arrow-up').addClass('active');
        jQuery('.child-nodes a.active ~ ul').slideDown('fast');

      /*
      * User Profile subscribe for get user name
      */
    this.userSubscription = this.profileService.userProfileListner()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          this.profileData = res.userProfileData;
          this.profileImage = res.userProfileData.profileImage + "?" + Math.random()* 100000000000000000000;;
        }
      }
    );
  }


  ngOnChanges( collapseMenu): void {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.

    this.collapseMenuBarHide = this.collapseMenu;
    this.collapseMenuOnHeaderIconClick();
  }

  /*
  *  Get the current page route on page refresh.
  */
  getRouteOnPageRefresh() {
    this.router.events.subscribe((evt) => {
      if (evt instanceof NavigationEnd) {
        if (this.router.url === '/dashboard') {
          this.dashboard = true;
          this.adminPage = false;
          this.licenceReports = false;
        } else if (this.router.url === '/customer' || this.router.url === '/users' || this.router.url === '/roles' || this.router.url === '/edit-role' || this.router.url === '/add-role') {
          this.adminPage = true;
          this.licenceReports = false;
        } else if (this.router.url === '/licence-reports' || this.router.url === '/sales-report') {
          this.adminPage = false;
          this.licenceReports = true;
        } else {
          console.log("Error");
          this.adminPage = false;
          this.licenceReports = false;
        }
      }
    });
  }

  logout(){
    this.authService.logout();
      console.log("logout")
  }
  /*
  * Collapsed menu when click on header menu icon click.
  */
  collapseMenuOnHeaderIconClick() {
    if(this.collapseMenu) {
      jQuery('.child-nodes a ~ ul').slideUp('fast');
      jQuery('.child-nodes a').removeClass('arrow-up');
      jQuery('.child-nodes a.active').addClass('arrow-up');
    } else {
      jQuery('.child-nodes a.active ~ ul').slideDown('fast');
    }


  }

  /*
  * Sidebar accordian.
  */
  toggleSubMenu($event) {
      jQuery($event.currentTarget).parent('li').siblings('li').children('a').removeClass('arrow-up');
      jQuery($event.currentTarget).toggleClass('arrow-up');
      jQuery($event.currentTarget).parent('li').siblings('li').children('ul').slideUp('fast');
      jQuery($event.currentTarget).next('ul').slideToggle('fast');
  }

  ngOnDestroy(){
    // prevent memory leak when component destroyed
    this.loggedInSubscription.unsubscribe();
  }


}
