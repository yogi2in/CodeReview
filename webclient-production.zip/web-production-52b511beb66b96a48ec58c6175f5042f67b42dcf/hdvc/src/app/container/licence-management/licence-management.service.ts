import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpService } from '../../shared/services/http.service';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class LicenceManagementService {

  private licenceListProcess = new Subject<{ isSuccess: boolean, data: {}, action: string }>();
  private addEditLicenceProcess = new Subject<{ isSuccess: boolean, lotId: number, userId: number, action: string }>();
  licenceData = [];
  userList = [];

  licenceListListner() {
    return this.licenceListProcess.asObservable();
  }
  addEditLicenceListner() {
    return this.addEditLicenceProcess.asObservable();
  }
  constructor(private httpService: HttpService) {

  }

  getCustomerById(id) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/' + id,
      body: ""
    };
    this.httpService.get(param)
      .subscribe(
        (res) => {
          // after success process request for pass data in component
          if (res["result"] != null) {
            this.licenceData = res["result"].licences
            this.licenceListProcess.next({ isSuccess: true, data: { "list": this.licenceData }, action: 'customerListAndLicence' });
          }
        }
      );
  }

  getCustomerUserList(lotId, currentPage, numPerPage) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user?lotId=' + lotId + '&currentPage=' + currentPage + '&numPerPage=' + numPerPage,
      body: ""
    };
    this.httpService.get(param)
      .subscribe(
        (res) => {
          if (res["result"] != null) {            
            this.userList = res["result"];
            this.licenceListProcess.next({ isSuccess: true, data: { "list": this.userList, "paginator": res["pagination"] }, action: 'customerUserListByLicence' });
            if(this.userList.length == 0 && currentPage > 1){
              this.getCustomerUserList(lotId, 1, numPerPage);
            }
          }
        }
      );
  }

  assignLicenceToUser(body) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user',
      body: body
    };
    this.httpService.post(param)
      .subscribe(
        (res) => {
          console.log("res", res)
          this.addEditLicenceProcess.next({ isSuccess: true, lotId: body.lotId, userId: res["result"].userId, action: "assignLicenceToUser" });
        }
      );
  }

  getCustomerUserByField(lotId, currentPage, numPerPage, selectedData) {
    let queryString = null;
    if (selectedData.selectedSearchStatus != undefined && selectedData.selectedSearchStatus != null) {
      queryString = '&status=' + selectedData.selectedSearchStatus
    }
    if (selectedData.selectedSearchString != undefined && selectedData.selectedSearchString != null) {
      if (queryString != null) {
        queryString = queryString + '&' + selectedData.selectedSearchFieldName + "=" + selectedData.selectedSearchString
      } else {
        queryString = '&' + selectedData.selectedSearchFieldName + "=" + selectedData.selectedSearchString
      }

    }
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user?lotId=' + lotId + '&currentPage=' + currentPage + '&numPerPage=' + numPerPage + queryString,
      body: ""
    };
    this.httpService.get(param)
      .subscribe(
        (res) => {
          if (res["result"] != null) {
            this.userList = res["result"];
            this.licenceListProcess.next({ isSuccess: true, data: { "list": this.userList, "paginator": res["pagination"] }, action: 'getCustomerUserByField' });
          }
        }
      );

  }

  changeCustomerUserStatus(data, lotId) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user?' + 'lotId=' + lotId,
      body: data
    };
    return this.httpService.put(param)
  }

  getCustomerUserById(userId) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user/' + userId,
      body: ""
    };
    return this.httpService.get(param)
  }

  updateCustomerUser(userId, lotId, body) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/user/' + userId,
      body: body
    };
    this.httpService.put(param)
      .subscribe(
        (res) => {
          this.addEditLicenceProcess.next({ isSuccess: true, lotId: lotId, userId: userId, action: "updateCustomerUser" });
        }
      );
  }

  getLicenceByLotId(lotId, customerId) {
    const param = {
      url: environment.BASE_URI_AUTH + 'customer/licence/' + lotId + '?customerId=' + customerId,
      body: ""
    };
    return this.httpService.get(param)
  }
}
