import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProfilePicModalComponent } from './add-profile-pic-modal.component';

describe('AddProfilePicModalComponent', () => {
  let component: AddProfilePicModalComponent;
  let fixture: ComponentFixture<AddProfilePicModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddProfilePicModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProfilePicModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
