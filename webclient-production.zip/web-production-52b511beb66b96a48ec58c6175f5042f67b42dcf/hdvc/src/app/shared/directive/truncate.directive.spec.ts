import { TruncateDirective } from './truncate.directive';

describe('TruncateDirective', () => {
  it('should create an instance', () => {
    const directive = new TruncateDirective();
    expect(directive).toBeTruthy();
  });
});
