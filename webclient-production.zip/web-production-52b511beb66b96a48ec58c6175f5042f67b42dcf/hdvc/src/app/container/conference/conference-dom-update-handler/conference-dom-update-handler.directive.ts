import { Directive, OnInit, OnDestroy, Renderer2, ElementRef } from '@angular/core';
import { ConferencePageService } from '../conference-page-service.service';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[appConferenceDomUpdateHandler]'
})
export class ConferenceDomUpdateHandlerDirective implements OnInit, OnDestroy {

  private _updateAudioIconSubs = new Subscription();
  private _updateVideoIconSubs = new Subscription();
  private _presenterIconIndicatorSubs = new Subscription();

  constructor(
    private _confPageService: ConferencePageService,
    private _renderer: Renderer2,
    private _elementRef: ElementRef
  ) { }

  ngOnInit(): void {
    this._presenterIconIndicatorSubs = this._confPageService
      .updatePresenterIconIndicatorListener()
      .subscribe(
        (response: any) => {
          if (response == undefined || response.participantId === undefined) {
            return;
          }
          this.updatePresenterIndicatorIcon(response.participantId, response.visibleState);
        }
      )

    this._updateAudioIconSubs = this._confPageService
      .onUpdateAudioIconObsListener()
      .subscribe((response: any) => {
        if (response.userId === undefined || response.iconState === undefined){
          return;
        }
        this.updateAudioIconHandler(response.userId, response.iconState);
      });

    this._updateVideoIconSubs = this._confPageService
      .onUpdateVideoIconObsListener()
      .subscribe( (response: any) => {
        if (response.userId === undefined || response.iconState === undefined){
          return;
        }
        this.notifyUserStopStartVideo(response.userId, response.iconState);
        this.updateVideoIconHandler(response.userId, response.iconState);
      });
  }

  updatePresenterIndicatorIcon(participantId: string, visibleState: boolean) {
    if (participantId === undefined || typeof participantId !== 'string') {
      return;
    }
    const curPresenterElem: any = this.selectElementFromDOM(this._elementRef, '.participant-user.pstr-indicator');
    const newPresenterElem: any = this.selectElementFromDOM(this._elementRef, '#'+participantId);

    if (curPresenterElem !== null) {
      this.removeClass(curPresenterElem, 'pstr-indicator');
    }

    if (newPresenterElem !== null) {
      this.addClass(newPresenterElem, 'pstr-indicator');
    }
  }

  updateAudioIconHandler(selector: string, unMuteState: boolean) {
    if (selector === undefined) {
      return;
    }

    const audioIcon = this.selectElementFromDOM(this._elementRef, '.control_wrapper_' + selector + ' .audio-icon');
    if (audioIcon !== null) {
      if (unMuteState === true) {
        this.addClass(audioIcon, 'unmute');
      } else {
        this.removeClass(audioIcon, 'unmute');
      }
    }
  }

  updateVideoIconHandler(selector: string, showState: boolean) {
    if (selector === undefined) {
      return;
    }

    const videoIcon = this.selectElementFromDOM(this._elementRef, '.control_wrapper_' + selector + ' .video-icon');
    if (videoIcon !== null) {
      if (showState === true) {
        this.addClass(videoIcon, 'play');
      } else {
        this.removeClass(videoIcon, 'play');
      }
    }
  }

  notifyUserStopStartVideo(selector: string, showState: boolean) {
    if (selector === undefined) {
      return;
    }

    const videoWrapper = this.selectElementFromDOM(this._elementRef, '#'+selector);
    if (videoWrapper !== null) {
      if (showState === false) {
        this.addClass(videoWrapper, 'user-stop-video');
      } else {
        this.removeClass(videoWrapper, 'user-stop-video');
      }
    }
  }

  /**
   * @description The below function will handle to return the element as per selector passed
   * @param selector
   */
  selectElementFromDOM(selectorDOM: any, selector: string, selectorType?: string) {
    let selectedDOM = null;
    if (selectorDOM === undefined || selectorDOM === null) {
      return selectedDOM;
    }

    switch(selectorType) {
      case 'all':
        selectedDOM = selectorDOM.nativeElement.querySelectorAll(selector);
        break;
      default:
        if (selector.indexOf("#") > -1) {
          selector = selector.slice(1);
          selectedDOM = document.getElementById(selector);
        } else {
          selectedDOM = selectorDOM.nativeElement.querySelector(selector);
        }
        break;
    }
    return selectedDOM;
  }

  /**
   * @description The below function will handle to add class in DOM Element
   * @param listOfElements
   * @param clsName
   */
  addClass(listOfElements: any, className: string): void{
    if (
      listOfElements === undefined ||
      listOfElements === null ||
      className === undefined ||
      typeof className !== 'string'
    ) {
      return;
    }

    if (listOfElements.length > 0) {
      listOfElements.forEach((element, key) => {
        this._renderer.addClass(element, className);
      });
    } else {
      this._renderer.addClass(listOfElements, className);
    }
  }

  /**
   * @description The below function will handle to remove class from an arrays/ single element
   */
  removeClass(listOfElements: any, clsName: string): void {
    if (
      listOfElements === undefined ||
      listOfElements === null ||
      clsName === undefined ||
      typeof clsName !== 'string'
    ) {
      return;
    }

    if (listOfElements.length > 0) {
      listOfElements.forEach((element, key) => {
        this._renderer.removeClass(element, clsName);
      });
    } else {
      this._renderer.removeClass(listOfElements, clsName);
    }
  }


  ngOnDestroy(): void {
    this._updateAudioIconSubs.unsubscribe();
    this._updateVideoIconSubs.unsubscribe();
    this._presenterIconIndicatorSubs.unsubscribe();
  }

}
