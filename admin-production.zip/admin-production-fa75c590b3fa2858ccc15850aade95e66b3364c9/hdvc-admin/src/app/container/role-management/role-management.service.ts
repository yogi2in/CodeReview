import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RestApiService } from '../../_sharedService/restApi.service';
@Injectable({
  providedIn: 'root'
})
export class RoleManagementService {

  private roleProcess = new Subject<{data:{}, isSuccess: boolean, action:string}>();
  roleList = [];

  constructor(private rest :RestApiService) { }

  roleProcessListener() {
    return this.roleProcess.asObservable();
  }

  addRole(data){
    return this.rest.sendRequest('Post',environment.BASE_URI+'role',data)
  }

  updateRole(roleId,data){
    return this.rest.sendRequest('Put',environment.BASE_URI+'role/'+roleId,data)
  }

  getAllRoles(currentPage, numPerPage){
    let data = {"currentPage": currentPage, "numPerPage": numPerPage};
    //this.rest.sendRequest('Get', environment.BASE_URI + 'role', data)
    this.rest.sendRequest('Get', environment.BASE_URI + 'role/user', data)
      .subscribe(
        (res) => {
          console.log("getAllRoles", res);
          if(res["result"] != null){
            this.roleList = res["result"];
          }
          this.roleProcess.next({data: {"list": this.roleList ,"paginator": res.pagination }, isSuccess: true, action: "getAllRoles"});
        },
        err => console.log(err)
      );
  }

  getRoles(){
    let data = {};
    this.rest.sendRequest('Get',environment.BASE_URI+'role/user',data)
      .subscribe(
        (res) => {
          console.log("getRoles", res);
          if(res["result"] != null){
            this.roleList = res["result"];
          }
          this.roleProcess.next({data:{"list":this.roleList,"paginator":res.pagination}, isSuccess: true, action:"getAllRoles"});
        },
        err => console.log(err)
      );
  }

  getRoleById(roleId){
    let data = {};
    return this.rest.sendRequest('Get',environment.BASE_URI+'role/'+roleId,data)
  }

  deleteRole(roleId){
    let data = {};
    return this.rest.sendRequest('Delete',environment.BASE_URI+'role/'+roleId,data)
  }
}
