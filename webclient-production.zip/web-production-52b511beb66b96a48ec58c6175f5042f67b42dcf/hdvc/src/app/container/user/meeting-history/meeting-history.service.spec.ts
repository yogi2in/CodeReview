import { TestBed } from '@angular/core/testing';

import { MeetingHistoryService } from './meeting-history.service';

describe('MeetingHistoryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MeetingHistoryService = TestBed.get(MeetingHistoryService);
    expect(service).toBeTruthy();
  });
});
