import { LogPublisher } from "./log-publisher";
import { LogEntry } from "./log.entry.class";
import { Observable, of } from "rxjs";

// ****************************************************
// Console Logging Class
// ****************************************************

export class LogConsole extends LogPublisher {
  log(entry: LogEntry): Observable<boolean> {
    console.log(entry.buildLogString());
    console.log("");
    return of(true);
  }

  clear(): Observable<boolean> {
    console.clear();
    return of(true);
  }
}
