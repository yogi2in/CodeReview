import { NgModule, Component } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { CustomerComponent } from "./container/customer/customer.component";
import { AddCustomerComponent } from "./container/customer/add-customer/add-customer.component";
import { LicenceReportsComponent } from "./container/reporting/licence-reports/licence-reports.component";
import { UsersComponent } from "./container/users/users.component";
import { DashboardComponent } from "./container/dashboard/dashboard.component";
import { LoginComponent } from "./auth/login/login.component";
import { CreateUserComponent } from './container/users/create-user/create-user.component';
import { PasswordComponent } from './container/users/password/password.component';
import { UserProfileComponent } from './container/user-profile/user-profile.component';

import { AuthGuard } from './_guards/auth.guard.service';
import { NewsResolver } from './_guards/auth.guard.service';
import { AuthLoggedInGuard } from "./_guards/auth.loggedin.guard";
import { EditProfileComponent } from "./container/user-profile/edit-profile/edit-profile.component";
import { ForgotPasswordComponent } from "./container/forgot-password/forgot-password.component";
import { RoleManagementComponent } from "./container/role-management/role-management.component";
import { AddRoleComponent } from "./container/role-management/add-role/add-role.component";
import { PermissionDeniedComponent } from "./container/permission-denied/permission-denied.component";
import { HomeComponent } from "./container/home/home.component";
import { SalesReportComponent } from "./container/reporting/sales-report/sales-report.component";
import { MeetingReportComponent } from "./container/reporting/meeting-report/meeting-report.component";
import { ChangePasswordComponent } from "./auth/change-password/change-password.component";
import { MyProfileComponent } from "./container/user-profile/my-profile/my-profile.component";

const routes: Routes = [
    
    {
        path: '',
        component: LoginComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'create-user',
        component: CreateUserComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    {
        path: 'edit-user/:id',
        component: CreateUserComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    {
        path: 'profile',
        component: UserProfileComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: 'my-profile',
                component: MyProfileComponent
            },
            {
                path: 'change-password',
                component: ChangePasswordComponent
            }
        ]
    },
    
    {
        path: 'set-password/:emailToken',
        component: PasswordComponent
    },
    { 
        path: 'customer', 
        component: CustomerComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    { 
        path: 'add-customer', 
        component: AddCustomerComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    { 
        path: 'edit-customer/:id', 
        component: AddCustomerComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    { 
        path: 'licence-reports', 
        component: LicenceReportsComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'sales-report', 
        component: SalesReportComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'meeting-report', 
        component: MeetingReportComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'users', 
        component: UsersComponent,
        canActivate: [AuthGuard],
        resolve: {
            permission: NewsResolver
          }
    },
    { 
        path: 'dashboard', 
        component: DashboardComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'forgot-password', 
        component: ForgotPasswordComponent
        
    },
    { 
        path: 'roles', 
        component: RoleManagementComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'add-role', 
        component: AddRoleComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'edit-role/:id', 
        component: AddRoleComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'permission-denied', 
        component: PermissionDeniedComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'home', 
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: '**', 
        component: CustomerComponent,
        canActivate: [AuthGuard] 
    }
    
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    declarations: [],
    exports: [RouterModule]
})
export class AppRoutingModule { }