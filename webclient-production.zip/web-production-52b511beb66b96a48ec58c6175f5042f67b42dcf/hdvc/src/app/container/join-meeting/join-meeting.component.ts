import { Component, OnInit, OnDestroy, Renderer2, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { JoinMeetignService } from './join-meeting.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { environment } from 'src/environments/environment';
import { UtilService } from 'src/app/shared/services/utils.services';
import { ConferencePageService } from '../conference/conference-page-service.service';
import { LogService } from 'src/app/shared/logger/log.service';
//import * as deeplink from 'browser-deeplink';
declare var $;
import { AuthService } from '../../auth/auth.service';
import { DeviceSettingService } from '../device-setting/device-setting.service';

@Component({
  selector: 'app-join-meeting',
  templateUrl: './join-meeting.component.html',
  styleUrls: ['./join-meeting.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class JoinMeetingComponent implements OnInit, OnDestroy {
  public joinMeetingForm: FormGroup;
  public invalidMeetingIdError: string;
  public paramMeetingId: any;
  public invalidMeetingIdInParam: boolean = false;
  public hideMeetingIdField = false;
  public disabledMeetingBtn = false;
  public bodyElem: any;
  public meetingOwnerEmailId: string;
  public connectionLostMsgeIfAny: any;
  public selectedMeetingId;
  public isDesktopApp = false;
  public loggedUserName:  string;
  public isLoggedIn: boolean = false;
  public onStartReJoinListenerSubs = new Subscription();
  public onMeetingValidationAPIFailed = new Subscription();
  public conferenceUserGuide: string;
  public customerUserGuide: string;

  constructor(
    private joinMeetingService: JoinMeetignService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private _utilService: UtilService,
    private render: Renderer2,
    private _confPageService: ConferencePageService,
    private _logService: LogService,
    private authService: AuthService,
    private _deviceSettingsService: DeviceSettingService
    ) {
      // deeplink.setup({
      //   iOS: {
      //     storeUrl: "https://itunes.apple.com/us/app/hdvc-wave/id1460224649?mt=8",
      //     appId: 1460224649
      //   },
      //   android: {
      //     storeUrl: "https://play.google.com/store/apps/details?id=com.panasonic.hdvcwave",
      //     appId: "com.panasonic.hdvcwave"
      //   }
      // });
    }

  ngOnInit() {
    this._deviceSettingsService.stopAudioStream();
    this._deviceSettingsService.stopVideoStream();
    this.conferenceUserGuide = environment.CONFERENNCE_USER_GUID;
    this.customerUserGuide = environment.CUSTOMER_USER_GUIDE;
    this.isDesktopApp = this._utilService.checkIsDesktopApp();
    this.connectionLostMsgeIfAny = this.joinMeetingService.getConnectionLostMessage();
    this.joinMeetingService.setConnectionLostMessage('');
    this.loggedUserName = this.getUserInfo() !== null ? this.getUserInfo().fullName: '';
    // Form fields validations.
    this.joinMeetingForm = new FormGroup({
      meetingId: new FormControl(null, {
        validators: [
          Validators.required,
          Validators.maxLength(9)
        ]
      }),
      userName: new FormControl(this.loggedUserName, Validators.required)
    });

    // the below code will subscribe params to check the url has meeting id or not
    this.activeRoute.params.subscribe(
      (param: Params) => {
       var continueWIthBrowser =  this.activeRoute.snapshot.queryParamMap.get("continue");
        // check the current url has meeting id or not
        if (param.meetingId !== undefined) {
          console.log("continueWIthBrowser", continueWIthBrowser);
          if(this._utilService.isMobile() && continueWIthBrowser != 'Y'){
            this.router.navigate(['/deep-link', param.meetingId]);
          }
          this.joinMeetingForm.get('meetingId').patchValue(param.meetingId);
          // if it has meeting id in the url, then hide the field
          this.hideMeetingIdField = true;
          this.paramMeetingId = param.meetingId;
        }
      }
    );

    this.onMeetingValidationAPIFailed = this.joinMeetingService.onMeetingIDValidation().subscribe((res: any) => {
      if (res !== undefined && res.status === false) {
        // this.invalidMeetingIdError = res.msg;
        this.disabledMeetingBtn = false;
        if (this._confPageService.isSocketStateValid === false && this.joinMeetingService.isUserClickJoinButton === false) {
          let curMeetingInfo = this.joinMeetingService.curMeetingInfo;
          this._confPageService.notifyToShowReconnectLayoutObs(true, curMeetingInfo, 15000, "SOCKET_STATE_CHANGE");
          this._confPageService.isSocketStateValid = true;
        } else {
          this.joinMeetingService.setConnectionLostMessage(res.msg);
          this.connectionLostMsgeIfAny = res.msg;
          this._confPageService.notifyToShowReconnectLayoutObs(false, "", 10000, "");
        }
      }
    });

    /*
    * The below code add a class in body.
    */
    this.bodyElem = document.getElementsByTagName('body')[0];
    //this.render.addClass(this.bodyElem, 'login-page-bg');

    this.meetingOwnerEmailId = this.getUserInfo() !== null? this.getUserInfo().email: '';

    let userInfo = localStorage.getItem('currentUser');
    if(userInfo != undefined && userInfo != null) {
      this.isLoggedIn = true;
    } 
    // else {
    //   this.authService.signOut();
    // }


    // this subscription is when app component to notify
    // to rejoin when user leave meeting due to some error
    this.onStartReJoinListenerSubs = this._confPageService.onStartReJoinListener().subscribe(
      (sResponse) => {
        this._logService.debug('onStartReJoinListenerSubs--> onStartReJoinListener', sResponse);
        if (sResponse !== undefined && sResponse.reJoin !== undefined) {
          const curMeetingInfo = sResponse.meetingInfo;
          if (curMeetingInfo.meeting_refid !== undefined) {
            this.joinMeetingService.isAutoValidate = true;
            this.joinMeetingService.isValidateThroughRejoin = true;
            this.joinMeetingService.validateMeeting(
              curMeetingInfo.meeting_refid,
              curMeetingInfo.email_id,
              curMeetingInfo.userName,
              "JOIN-MEETING"
            );

            this.joinMeetingService.isUserClickJoinButton = true;
          }
        }
      }, (eResponse)=> {
        this._logService.warn('onStartReJoinListenerSubs--> onStartReJoinListener', eResponse);
      }
    )
  }

  //get the user details from local storage
  getUserInfo(): any {
    return this._utilService.getInfoFromStorage('localStorage', 'currentUser');
  }

  validateMeeting() {
    // When user click on form submit button without filling the fields then error will display.
    this.joinMeetingForm.controls['meetingId'].markAsTouched();
    this.joinMeetingForm.controls['userName'].markAsTouched();
    if (this.joinMeetingForm.valid) {
      this.disabledMeetingBtn = true;
      this.joinMeetingService.isAutoValidate = false;
      this.joinMeetingService.isUserClickJoinButton = true;
      this.connectionLostMsgeIfAny = "";
      this.joinMeetingService.validateMeeting(
        this.joinMeetingForm.value.meetingId,
        this.meetingOwnerEmailId,
        this.joinMeetingForm.value.userName,
        "JOIN-MEETING"
      )

      // setTimeout(() => {
      //   this.disabledMeetingBtn = false;
      // }, 5000);
    } else {
      if (this.paramMeetingId !== undefined) {
        this.invalidMeetingIdInParam = true;
      }
      console.log('Error, Form is not valid');
    }
  }

  joinMeeting(data){
    this.joinMeetingService.isUserClickJoinButton = true;
    this.joinMeetingService.validateMeeting(
      data.meetingId,
      data.ownerEmail,
      data.userName,
      "JOIN-MEETING"
    )
  }

  openDeskTopAppInfo(){
    this.selectedMeetingId = null;
      this.joinMeetingForm.controls['meetingId'].markAsTouched();
      this.joinMeetingForm.controls['userName'].markAsTouched();
      if (this.joinMeetingForm.valid) {
        let name = this.joinMeetingForm.value.userName;
        this.selectedMeetingId = this.joinMeetingForm.value.meetingId;
        this.validateMeeting();
      }
  }
  /*
  openDeskTopAppInfo(){
    if(this.isDesktopApp){
      this.validateMeeting();
    } else {
      this.selectedMeetingId = null;
      this.joinMeetingForm.controls['meetingId'].markAsTouched();
      this.joinMeetingForm.controls['userName'].markAsTouched();
      if (this.joinMeetingForm.valid) {
        let name = this.joinMeetingForm.value.userName;
        this.selectedMeetingId = this.joinMeetingForm.value.meetingId;

        /*
        let deviceInfo = this._utilService.getDeviceDetection();
        let downloadApplicationObj = this._utilService.getInfoFromStorage('localStorage', 'downloadApplication');
        if (
          downloadApplicationObj != null &&
          downloadApplicationObj.browser == deviceInfo.browser
        ) {
          this.validateMeeting();
        } else {
          return this.router.navigate(['/download-meeting-app', 'JOIN-MEETING', this.selectedMeetingId]);
        }
        /*
        if (this._utilService.isAppDownloadEnabled()) {
          return this.router.navigate(['/download-meeting-app', 'JOIN-MEETING', this.selectedMeetingId, name]);
        }
        else {
          this.validateMeeting();
        }
      }
    }
  }
  */

  /*
  ngAfterViewInit() {
    $("#download-deskTop-app").modal('show');
  }
  */

  onUserNameFocus(): void {
    this.invalidMeetingIdInParam = false;
  }

  ngOnDestroy(): void {
    // Called once, before the instance is destroyed.
    //this.render.removeClass(this.bodyElem, 'login-page-bg');

    // this will reset the connection lost msge
    this.joinMeetingService.resetConnectionLostMessage();
    this.onStartReJoinListenerSubs.unsubscribe();
    this.onMeetingValidationAPIFailed.unsubscribe();
    this._deviceSettingsService.stopAudioStream();
    this._deviceSettingsService.stopVideoStream();
  }

}
