import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient, HttpParams  } from '@angular/common/http';
import { RestApiService } from '../../../_sharedService/restApi.service';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LicenceService {
  private licenceProcess = new Subject<{isSuccess :boolean, data:{}}>();

  licenceListner() {
    return this.licenceProcess.asObservable();
  }

  constructor(private http: HttpClient, private restService :RestApiService) { }

  addLicenceToCustomer(data){
    return this.restService.sendRequest('Post',environment.BASE_URI+'customer/licence ',data)
  }

  updateLicence(data){
    return this.restService.sendRequest('Put',environment.BASE_URI+'customer/licence ',data)
  }

  getLicenceByLotId(lotId,customerId){
    let params = {
      "customerId":customerId,
      "setValueInHeader":true
    };
    return this.restService.sendRequest('Get',environment.BASE_URI+'customer/licence/'+lotId, params)
  }

  deleteLicence(data){
    return this.restService.sendRequest('delete',environment.BASE_URI+'customer/licence ',data)
  }


}
