import { Component, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Subscription } from 'rxjs';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ServerRequestInterceptor } from 'src/app/shared/services/serverRequest.interceptor';
import { UtilService } from 'src/app/shared/services/utils.services';
import { LocalStorageService } from 'angular-2-local-storage';

import { IpcRenderer } from "electron";
import * as fp2 from 'fingerprintjs2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm: FormGroup;
  private authSubscription = new Subscription();
  public authTokenSet: void;
  public errMessage: void;
  public bodyElem: any;
  public loginError: any;
  public isLoggedIn: boolean;
  private domain = window.location.hostname;

  private ipc: IpcRenderer
  private ipcToken: boolean=true

  constructor(
    private authService: AuthService,
    private router: Router,
    private _route: ActivatedRoute,
    private serverReqInt: ServerRequestInterceptor,
    private render: Renderer2,
    private utils: UtilService,
    private cookieService: CookieService,
    private localStorageService: LocalStorageService
  ) {
    if ((<any>window).require) {
      try {
        this.ipc = (<any>window).require("electron").ipcRenderer
        this.ipc.send("getLounchApplication", "hdvc")
        this.ipc.on("manageLounchApplication", (event, arg) => {
          if (arg) {
            let date = new Date()
            let token = arg.slice(12)
            if (token) {
              let meetingId = 678873875
              this.utils.setInfoInStorage('localStorage', 'installApplication', {
                "isAppLogin": true,
                "storageTime": date.valueOf()
              })
              if (token != "null") {
                // this.localStorageService.set('authToken', token)
                // this.authService.autoLogin(meetingId, token)
              }
            }
          }
        });
      }
      catch (error) {
        throw error
      }
    }
    else {
      console.warn("Could not load electron ipc")
    }
  }

  ngOnInit() {
    let options = {};
    fp2.get(options, function (components) {
      var values = components.map(function (component) {
        if (component.key == "hardwareConcurrency") {
          return component.value 
        }
        if (component.key == "screenResolution") {
          return component.value 
        }
        if (component.key == "availableScreenResolution") {
          return component.value 
        }
        if (component.key == "platform") {
          return component.value 
        }
        if (component.key == "webglVendorAndRenderer") {
          return component.value 
        }
        if (component.key == "fonts") {
          return component.value 
        }
        if (component.key == "audio") {
          return component.value 
        }
      })
      var murmur = fp2.x64hash128(values.join(''), 31)
      console.log("murmur: ", murmur);
    });



    this.loginForm = new FormGroup({
      email: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required),
      remindMe: new FormControl(null)
    });

    // Subscribe the Observables and change the router on schedule-meeting page
    this.authSubscription = this.authService.authProcessListener()
      .subscribe(
        (res) => {
          if (res.isSuccess && res.data.user.roleName != 'PANASONIC_ADMIN') {
            this.authService.isLoggedIn = true;
            this.authService.callHeaderProcessAfterLogin()
            this.router.navigate(['my-meetings']);
          } else {
            this.authService.isLoggedIn = false;
            if (res.isSuccess) {
              this.loginError = "Invalid User!"
            } else {
              this.loginError = res.data.message;
            }
          }
        },
        (error) => {
          // code to handel rejection.
        }
      );

    /*
    * The below code add a class in body.
    */
    this.bodyElem = document.getElementsByTagName('body')[0];
    //this.render.addClass(this.bodyElem, 'login-page-bg');


    /*
    * Remember feature.
    */
    if (this.localStorageService.get('remember') == "true") {
      this.loginForm.setValue({
        email: this.localStorageService.get('username'),
        password: this.localStorageService.get('password'),
        remindMe: this.localStorageService.get('remember'),
      });
    }

  }

  onSignIn() {
    // When user click on form submit button without filling the fields then error will display.
    this.loginForm.controls['email'].markAsTouched();
    this.loginForm.controls['password'].markAsTouched();
    this.loginForm.controls['remindMe'].markAsTouched();
    let remindMe = this.loginForm.value.remindMe == null ? false : this.loginForm.value.remindMe;
    if (this.loginForm.valid) {
      this.authService.login(
        this.loginForm.value.email,
        this.loginForm.value.password,
        remindMe
      );
      // if remember me true set data in cookies
      if (this.loginForm.value.remindMe) {
        console.log("Remind me =====>>>>> ");
        this.localStorageService.set('remember', this.loginForm.value.remindMe);
        this.localStorageService.set('username', this.loginForm.value.email);
        this.localStorageService.set('password', this.loginForm.value.password);
      } else {
        this.localStorageService.remove('remember');
        this.localStorageService.remove('username');
        this.localStorageService.remove('password');
      }
    } else {
      console.log('form invalid!');
    }

    const emailValue = this.loginForm.value.email;
    const passValue = this.loginForm.value.password;
    if (this.loginForm.value.remindMe) {
      this.localStorageService.set('remember', this.loginForm.value.remindMe);
    } else {
      this.localStorageService.remove('remember');
    }
  }

  // Destory the subscription.
  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
    //this.render.removeClass(this.bodyElem, 'login-page-bg');
  }

}

