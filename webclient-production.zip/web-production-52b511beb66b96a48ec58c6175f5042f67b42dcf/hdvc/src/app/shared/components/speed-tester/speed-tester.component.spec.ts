import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpeedTesterComponent } from './speed-tester.component';

describe('SpeedTesterComponent', () => {
  let component: SpeedTesterComponent;
  let fixture: ComponentFixture<SpeedTesterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpeedTesterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpeedTesterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
