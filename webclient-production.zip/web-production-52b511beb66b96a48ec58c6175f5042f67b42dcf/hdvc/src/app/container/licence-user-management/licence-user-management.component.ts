import { Component, OnInit } from '@angular/core';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LicenceManagementService } from '../licence-management/licence-management.service';
import { AuthService } from '../../auth/auth.service';
import { ForgotPasswordService } from '../forgot-password/forgot-password.service';
declare var $;

@Component({
  selector: 'app-licence-user-management',
  templateUrl: './licence-user-management.component.html',
  styleUrls: ['./licence-user-management.component.css']
})
export class LicenceUserManagementComponent implements OnInit {
  private userListSubscription = new Subscription();
  private addEditLicenceScription = new Subscription();
  lotId;
  userList = [];
  fields = [
    "Name",
    "Contact Number",
    "Email Address",
    "Status",
    "Actions"
  ];
  searchFields = ["userName", "mobile", "email"];
  statusList = [{ "label": "Active", "value": "ACTIVE", "code": 1 }, { "label": "InActive", "value": "INACTIVE", "code": 2 }, { "label": "Delete", "value": "DELETE", "code": 3 }];
  bulkActionList = [{ "label": "Active", "value": "ACTIVE", "code": 1 }, { "label": "Delete", "value": "DELETE", "code": 3 }];
  userStatus = [{ "label": "Active", "value": "ACTIVE", "code": 1 }, { "label": "Inactive", "value": "INACTIVE", "code": 2 }, { "label": "Password Not Set", "value": "SETPASSWORD", "code": 4 }]
  deleteUserId;
  private sub: any;
  addUserLicence: boolean = true;
  // paginator params
  currentPage = 1;
  numPerPage = environment.PAGE_SIZE;
  totalItem;
  currentUserEmail = null;
  currentUserId = null;
  selfLicenceAssigned = false;
  selfLicenceAssignedToCurrentLot = false;
  successMessage = null;
  isValidLicence = false;
  staticAlertClosed;
  message;
  showGlobalError = true;
  editUserDataObj;
  availableLicence = 0;
  usedLicence = 0;
  selectedFilterStatus;
  selectedSearchFieldName;
  selectedSearchString;
  licenceStatus;
  firstItemNumber;
  lastItemNumber;
  selectedData;
  private clearSetTimeOut;

  constructor(
    private licence: LicenceManagementService,
    private router: Router,
    private route: ActivatedRoute,
    private auth: AuthService,
    private _objForgotPasswordService: ForgotPasswordService) { }

  ngOnInit() {
    if (this.auth.getUserInfo('currentUser') != null) {
      this.currentUserEmail = this.auth.getUserInfo('currentUser').email;
      this.currentUserId = this.auth.getUserInfo('currentUser').userId;
      this.isValidLicence = this.auth.getUserInfo('currentUser').isValidLicence;
    }

    this.sub = this.route.params.subscribe(params => {
      this.lotId = params['lotId'];
    });

    this.addEditLicenceScription = this.licence.addEditLicenceListner()
      .subscribe(
        (res) => {
          this.successMessage = null;
          if (res.isSuccess === true && res.lotId == this.lotId) {

            if (res.userId == this.currentUserId) {
              this.successMessage = "You have Successfully Assigned the Licence."
              this.FadeOutLink();
            }
            if (res.action == 'assignLicenceToUser') {
              $('#add-user-modal').modal('hide');
            } else if (res.action == 'updateCustomerUser') {
              $('#add-user-modal' + res.userId).modal('hide')
            }
            //parent page display error component set true
            this.showGlobalError = true;
            this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage)
          }
        },
        (error) => { }
      )

    this.userListSubscription = this.licence.licenceListListner()
      .subscribe(
        (res) => {
          if (res.isSuccess === true && (res.action == 'customerUserListByLicence' || res.action == 'getCustomerUserByField')) {
            this.userList = res.data["list"];
            this.checkLicenceRemains();
            this.selfLicenceAssignedToCurrentLot = this.checkLoggedInUserAssignedLicenceToSelf();
            this.selfLicenceAssigned = (this.selfLicenceAssignedToCurrentLot == true && (this.licenceStatus == 1 || this.licenceStatus == 4)) ? this.selfLicenceAssignedToCurrentLot : this.auth.getUserInfo('currentUser').isValidLicence ? true : false;
            this.auth.updateLocalStorageForLicenceUser(this.selfLicenceAssigned);
            // get all paginator data
            if (res.data["paginator"] != undefined && res.data["paginator"].totalItemCount != undefined) {
              this.totalItem = res.data["paginator"].totalItemCount;
              this.currentPage = res.data["paginator"].currentPage;
              this.firstItemNumber = res.data["paginator"].firstItemNumber;
              this.lastItemNumber = res.data["paginator"].lastItemNumber;
            } else {
              this.totalItem = 0;
            }
            this.showGlobalError = true;
            $('#rootCheckbox').prop('checked', false);

          }
        }
      );
    // get user list of selected licence on page load
    console.log('this.lotId, this.currentPage, this.numPerPage ', this.lotId, this.currentPage, this.numPerPage)
    this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage);
    // On page load check remaining licence value so that add user button show /hide



  }

  checkLoggedInUserAssignedLicenceToSelf() {
    let self = this
    if (this.userList.filter(function (e) {
      return e.userId == self.currentUserId
    }).length > 0) {
      return true;
    } else {
      return false;
    }
  }

  checkLicenceRemains() {
    this.showGlobalError = true;
    let currentUser = localStorage.getItem('currentUser');
    currentUser = JSON.parse(currentUser)
    if (currentUser["customerId"] != null) {
      this.licence.getLicenceByLotId(this.lotId, currentUser["customerId"])
        .subscribe(
          (res) => {
            if (res["result"] != null) {
              // remove add user button if availableLicences is 0 or licence status is expired(3)
              this.addUserLicence = res["result"]["availableLicences"] == 0 || res["result"]["licenceStatus"] == 3 ? false : true;
              this.availableLicence = res["result"]["availableLicences"];
              this.usedLicence = res["result"]["usedLicences"];
              this.licenceStatus = res["result"]["licenceStatus"];
              if (res["result"]["licenceStatus"] == 0 || res["result"]["licenceStatus"] == 2 || res["result"]["licenceStatus"] == 3) {
                this.bulkActionList = this.bulkActionList.filter(x => x.code != 1)
              }
            }
          }
        )
    }
  }

  checkAll(ev) {
    if (this.userList == undefined) return;
    this.userList.forEach(x => {
      if (x.userId != this.currentUserId) {
        return x.state = ev.target.checked;
      }
    })
  }

  isAllChecked() {
    if (this.userList == undefined || this.userList.length == 0) return;
    return this.userList.every(x => {
      return x.state;
    });
  }
  unCheckAll() {
    if (this.userList == undefined || this.userList.length == 0) return;
    this.userList.forEach(x => {
      return x.state = false;
    })
  }

  search(val, searchfield) {
    this.showGlobalError = true;
    if (!val && searchfield == 'userStatus') {
      this.selectedFilterStatus = null;
    }
    if (val) {
      if (searchfield == 'userStatus' && val != 'All') {
        val = this.userStatus.filter(item => item.label == val)[0].value;
        this.selectedFilterStatus = val;
      } else {
        this.selectedSearchString = val;
        this.selectedSearchFieldName = searchfield;
        this.selectedFilterStatus = null;
      }
      this.currentPage = 1;
      this.selectedData = { "selectedSearchString": this.selectedSearchString, "selectedSearchFieldName": this.selectedSearchFieldName, "selectedSearchStatus": this.selectedFilterStatus };
      this.licence.getCustomerUserByField(this.lotId, this.currentPage, this.numPerPage, this.selectedData)
    } else {
      this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage)
    }
  }

  clearSearch(val) {
    if (!val) {
      this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage);
    }
  }

  executeStatusAction(status) {
    let selectedUserIds = [];
    this.showGlobalError = true;
    this.userList.filter(item => {
      if (item.state == true) {
        let id = Number(item.userId)
        selectedUserIds.push(id)
      }
    }
    );
    if (selectedUserIds.length != 0) {
      //let status = this.statusList.filter(item => item.label == event.target.value)[0].code;
      if (status.code == 3) {
        this.deleteUserId = selectedUserIds;
        $("#delete-modal").modal('show');
      } else {
        let data = {
          "ids": selectedUserIds,
          "status": status.code
        }
        this.licence.changeCustomerUserStatus(data, this.lotId)
          .subscribe(
            (res) => {              
              this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage);
              //this.userService.getAllPanasonicUser(this.currentPage,this.numPerPage);
            },
            () => {
              console.log("Finally clause");
            }
          );
      }
    } else {
      this.staticAlertClosed = false;
      this.message = "Please select at least one user";

    }
  }

  deleteUser($event) {
    this.showGlobalError = true;
    if ($event.id != undefined && $event.id != null) {
      let data = { "ids": [], "status": 3 };
      let str_array = $event.id[0].split(',');
      let array = JSON.parse("[" + str_array + "]");
      data["ids"] = array;
      this.licence.changeCustomerUserStatus(data, this.lotId)
        .subscribe(
          (res) => {
            $('#delete-modal').modal('hide');
            if (this.deleteUserId == this.currentUserId) {
              this.auth.updateLocalStorageForLicenceUser(false);
            }
            this.deleteUserId = null;
            this.licence.getCustomerUserList(this.lotId, this.currentPage, this.numPerPage);
          }
        );
    }
  }

  openModal(id) {
    this.showGlobalError = false;
    this.editUserDataObj = {};
    delete this.editUserDataObj[id];
    this.licence.getCustomerUserById(id)
      .subscribe(
        (res) => {
          if (res["result"] != null) {
            this.editUserDataObj[id] = {
              fullName: res["result"].fullName,
              countryCode: res["result"].countryCode,
              mobile: res["result"].mobile,
              email: res["result"].email,
              status: res["result"].status
            }
            clearTimeout(this.clearSetTimeOut);
            this.clearSetTimeOut = setTimeout(() => {
              $("#add-user-modal" + id).modal('show');
            }, 1000);
          }
        }
      );

  }

  getCustomerStatus(userStatus) {
    if (userStatus) {
      return status = this.userStatus.filter(item => item.code == userStatus)[0].label;
    }
  }

  // This method execute on click of pagination buttons and get next page data set according to page number
  getNextPageData(pageNumber) {
    if (this.selectedData != undefined && this.selectedData != null) {
      this.licence.getCustomerUserByField(this.lotId, pageNumber, this.numPerPage, this.selectedData)
    } else {
      this.licence.getCustomerUserList(this.lotId, pageNumber, this.numPerPage);
    }

  }

  getPagingOffset() {
    let pageLabel;
    let firstLabel = 1 + this.numPerPage * (this.currentPage - 1);
    let secondLabel = (1 + this.numPerPage * (this.currentPage - 1)) + (this.userList.length - 1);
    if (firstLabel == secondLabel) {
      return firstLabel;
    } else {
      let pageLabel = firstLabel + "-" + secondLabel;
      return pageLabel;
    }
  }

  assignLicenceToSelf() {
    let currentUser = this.auth.getUserInfo('currentUser');
    let data = {
      "fullName": currentUser.fullName,
      "countryCode": currentUser.countryCode,
      "mobile": currentUser.mobile,
      "lotId": this.lotId,
      "email": currentUser.email
    }
    this.licence.assignLicenceToUser(data)
  }

  FadeOutLink() {
    clearTimeout(this.clearSetTimeOut);
    this.clearSetTimeOut = setTimeout(() => {
      this.successMessage = null;
    }, 3000);
  }

  public resendEmail(email) {
    this.showGlobalError = true;
    this.successMessage = null;
    this._objForgotPasswordService.setPassword({ "email": email, "email-type": "resend-set-password" })
      .subscribe((response: any) => {
        this.successMessage = response.message;
        this.FadeOutLink();
      })
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.userListSubscription.unsubscribe();
    this.addEditLicenceScription.unsubscribe();
    clearTimeout(this.clearSetTimeOut);
  }

}
