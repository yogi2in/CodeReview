export interface DOMModel {
  nodeType: string;
  classArr: Array<string>;
  attrs: Array<any>;
}
