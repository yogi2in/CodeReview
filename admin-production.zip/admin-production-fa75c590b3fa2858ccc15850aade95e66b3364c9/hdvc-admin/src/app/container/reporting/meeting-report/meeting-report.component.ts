import { Component, OnInit } from '@angular/core';
import { ReportsService } from '../report.service';
import { environment } from 'src/environments/environment.prod';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';

@Component({
	selector: 'app-meeting-report',
	templateUrl: './meeting-report.component.html',
	styleUrls: ['./meeting-report.component.css']
})
export class MeetingReportComponent implements OnInit {
	public meetingReportsData: any;
	public currentPageIndex: number = 1;
	public defaultPageSize: number = environment.NUMBER_PER_PAGE;
	public showRecordsHeader: boolean = false;
	public totalRecords: number;
	public startItemNumber: number;
	public lastItemNumber: number;
	public meetingUsers: any = null;
  public currentDate = moment().toDate();
  public showExportButton: boolean = false;
  public xlsDownloadUrl;
  public pdfDownloadUrl;
	public reportMeetingHeaders = [
		'Meeting ID',
		'Title',
		'Schedule Date',
		'Actual Date',
		'Schedule start time',
		'Schedule Duration',
		'Actual Start time',
		'Actual end time'
	]
	public showLoader: boolean = false;
	public meetingReports: FormGroup;
	public isSubmitted = false;
	constructor
		(
			private reportService: ReportsService,
			public _bsDatePickerConfig: BsDatepickerConfig
		) {
		this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
		this._bsDatePickerConfig.showWeekNumbers = false;
    this.isSubmitted = false;
    this.showExportButton = false;
	}

	ngOnInit() {
		this.meetingReports = new FormGroup({
			fromDate: new FormControl(this.currentDate, Validators.required),
			toDate: new FormControl(this.currentDate, Validators.required),
			status: new FormControl(0, Validators.required)
		})
		this.isSubmitted = false;
		this.getMeetingReports(this.currentPageIndex);
	}

  /*
  * The below function get the Meeting Report Api data.
  */
	getMeetingReports(pageIndex) {
		this.isSubmitted = true;
		if (!this.meetingReports.invalid) {
			let fromDate = this.meetingReports.controls.fromDate.value;
			let toDate = this.meetingReports.controls.toDate.value;
      let status = this.meetingReports.controls.status.value;
			const data = {
        'report': true,
				'from_date': moment(fromDate).format("YYYY-MM-DD"),
        'to_date': moment(toDate).format("YYYY-MM-DD"),
        'status': status,
				'page_index': pageIndex
			}

			this.showLoader = true;
			this.currentPageIndex = pageIndex;
			this.reportService.getMeetingReports(data).subscribe(
				(res) => {
					this.meetingReportsData = res.body.data
					this.showLoader = false;
					this.showRecordsHeader = true;
					this.totalRecords = res.body.total_records;
					this.startItemNumber = ((this.currentPageIndex - 1) * this.defaultPageSize) + 1;
					this.lastItemNumber = this.currentPageIndex * this.defaultPageSize;

					if (this.lastItemNumber >= this.totalRecords) {
						this.lastItemNumber = this.totalRecords;
					}
          this.showExportButton = this.totalRecords > 0 ? true : false;
          this.xlsDownloadUrl = res.body.downloadAsXls;
          this.pdfDownloadUrl = res.body.downloadAsPdf;
				},
				(error) => {
					console.log(error);
					this.showRecordsHeader = false;
				}
			)
		}
	}

  /**
   * filter meeting report data based on meeting id and actual start datetime to show participants list
   */
	showParticipantsList(meetingId: string, actualStartDateTime: string) {
		var userList = this.meetingReportsData.filter(function (meetingData) {
			return meetingData.meetingid == meetingId
				&& meetingData.meetingstarttime == actualStartDateTime
		});

		this.meetingUsers = userList[0].users;

		console.log("this.meetingUsers", this.meetingUsers);
	}

  /*
  * The below function converting date into millisecond.
  */
	convertDateInToMillSec(fromDate, toDate) {
		let fromDateMillSec = moment(fromDate).valueOf();
		let toDateMillSec = moment(toDate).valueOf();
		let obj = {
			fromDateMillSec: fromDateMillSec,
			toDateMillSec: toDateMillSec
		}
		return obj;
	}

  /**
   default funtion returning the all controls used on html for validation and error msgs
   */
	get form() {
		return this.meetingReports.controls;
	}

	//reset form data
	resetData() {
		this.meetingReportsData = [];
		this.totalRecords = 0;
		this.showRecordsHeader = false;
    this.isSubmitted = false;
    this.showExportButton = false;
  }

  /*
  * The below function download the PDF file.
  */
 downloadPdf(pdfFileUrl: string) {
  if (pdfFileUrl === undefined || typeof pdfFileUrl !== 'string') {
    return;
  }
  window.open(pdfFileUrl, '_blank');
}

/*
* The below function download the Excel file.
*/
downloadXls(xlsFileUrl: string) {
  if (xlsFileUrl === undefined || typeof xlsFileUrl !== 'string') {
    return;
  }
  window.location.href = xlsFileUrl;
}
}
