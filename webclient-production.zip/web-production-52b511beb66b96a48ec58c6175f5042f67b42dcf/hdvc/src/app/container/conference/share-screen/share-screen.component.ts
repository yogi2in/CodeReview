import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { environment } from 'src/environments/environment';
import * as kurentoUtils from 'kurento-utils';
import { UtilService } from 'src/app/shared/services/utils.services';
import { SocketService } from 'src/app/shared/services/socket.service';
import { ConferencePageService } from '../conference-page-service.service';
import { LogService } from 'src/app/shared/logger/log.service';
declare var Participant;
declare var window;

@Component({
  selector: 'app-share-screen',
  templateUrl: './share-screen.component.html',
  styleUrls: ['./share-screen.component.css']
})

export class ShareScreenComponent implements OnInit, OnDestroy {
  @Output() notifyToStopScreenShare = new EventEmitter();
  @Output() notifyUserMediaAccessStatus = new EventEmitter();
  @Input() meetingId;
  public userId: string;
  private _webSocket: any;
  private _participant: any = {};
  private _browserInfo: any;
  private _videoStream: any;
  private _audioStream: any;
  private stopAnswer = false;
  private heartBeatIntervalId: any;
  private _turnsConfig: any = [];
  public uniqueClientId: string = "";
  public userType: string = "";
  public _selfUserId: string;

  constructor(
    private _utilService: UtilService,
    private socketService: SocketService,
    private _confPageService: ConferencePageService, 
    private _logService: LogService
  ) { }

  ngOnInit() {
    this.userType = this._utilService.getEnvironmentValue('USER_TYPE');
    this.uniqueClientId = this._utilService.generateRandomAlphaNumericString(32)+"-"+this.userType;
    this._browserInfo = this._utilService.getBrowserInfo();
    this._turnsConfig = this._utilService.getTurnsConf(environment.ENVIRONMENT_TYPE);
    if (this.meetingId !== undefined) {
      this._webSocket = new WebSocket(this.socketService.getSocketUrl());
      this._webSocket.onopen = this.onSocketOpenHandler.bind(this);
      this._webSocket.onmessage = this.onSocketMessageHandler.bind(this);
      window.addEventListener('message', this.messageEventHandler.bind(this));
    }
  }

  messageEventHandler(event) {
    if (event.data.type === undefined && typeof event.data === 'string' && event.data.length > 1) {
      if (event.data == 'ice-connected') {
        return;
      }
      let payLoad = JSON.parse(event.data);
      if (payLoad.userId && payLoad.userId === this._selfUserId) {
        this.sendMsg(JSON.parse(event.data), this._webSocket);
      }
    }
    // if (event.data.type === undefined && typeof event.data === 'string' && event.data.length > 1) {
    //   this.sendMsg(JSON.parse(event.data), this._webSocket);
    // }
  }

  onSocketOpenHandler() {
    let kip = this._utilService.getInfoFromStorage('localStorage', 'kip');
    let jip = this._utilService.getInfoFromStorage('localStorage', 'jip');
    const joinMeetingPayLoad = {
      'req': 'joinMeetingRoom',
      'user': 'screen-shared-web-user',
      'roomID': this.meetingId,
      'is_owner': 0,
      'clientId': this.uniqueClientId,
      'user_type': 'SCREEN_SHARE',
      'connection_mode': 'H264',
      'kip': kip,
      'jip': jip
    };
    this.sendMsg(joinMeetingPayLoad, this._webSocket);
  }

  sendMsg(payLoad, webSocket) {
    if (payLoad !== undefined && this._webSocket !== null && this._webSocket.readyState === 1) {
      const reqFor = payLoad.req;
      payLoad = JSON.stringify(payLoad);
      this._logService.debug('Screen Share Socket Handler -> Data Sent to Kurento >>>>', payLoad);
      this._webSocket.send(payLoad);
    }
  }

  onSocketMessageHandler(socketMsg: any) {
    const parsedMsge = JSON.parse(socketMsg.data);
    this._logService.debug('Screen Share Socket Handler -> Data From Kurento <<<<<< ', parsedMsge);
    switch (parsedMsge.rsp) {
      case 'exisUsr':
          this._selfUserId = parsedMsge.userId;
        this.connectionHeartBeat();
        this._participant = new Participant(parsedMsge.userId, parsedMsge.user);
        this.startScreenShare(parsedMsge);
        break;
      case 'iceCandidate':
        this.iceCandidateHandler(parsedMsge, this._webSocket);
        break;
      case 'answer':
        if (this.stopAnswer === true) {
          return;
        }
        this.receiveVideoResponse(parsedMsge);
        this.stopAnswer = true;
        break;
    }
  }


  iceCandidateHandler(parsedMsg, webSocket) {
    if (this._participant.rtcPeer === undefined) {
      return;
    }
    this._participant.rtcPeer.addIceCandidate(parsedMsg.candidate, function (error) {
      if (error) {
        console.log('Error adding candidate: ' + error);
        return;
      }
    });
  }

  receiveVideoResponse(result) {
    if (this._participant.rtcPeer === undefined) {
      return;
    }
    if (result !== undefined) {
      this._participant.rtcPeer.processAnswer(result.answer, function (error) {
        if (error) { return console.error(error); }
      });
    }
  }

  receiveVideoHandler(sender, senderId, isPresenter) {
    const self = this;
    const videoElement = self._participant.getVideoElement();
    videoElement.addEventListener('contextmenu', event => event.preventDefault());
    const options = {
      remoteVideo: videoElement,
      onicecandidate: self._participant.onIceCandidate.bind(self._participant)
    };

    self._participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerRecvonly(options,
      function (error) {
        if (error) {
          return console.log(error);
        }
        self._participant.rtcPeer.generateOffer(self._participant.offerToReceiveVideo.bind(self._participant));
      }
    );
  }

  startScreenShare(parsedMsge) {
    const self = this;
    self.notifyUserMediaAccessStatus.emit('init');
    const browserName = this._browserInfo.name;
    const isDesktopApp = this._utilService.checkIsDesktopApp();
    if (
      window.navigator.mediaDevices !== undefined &&
      window.navigator.mediaDevices.getDisplayMedia !== undefined &&
      environment['USE_EXTENSION_FOR_SCREEN_SHARE'] === false
    ) {
      window.navigator.mediaDevices.getDisplayMedia(
        {
          video: {
            mediaSource: 'screen'
          }
        })
        .then((screenStream) => {
          self._videoStream = screenStream;
          self.notifyUserMediaAccessStatus.emit('allowed');
          screenStream.getVideoTracks()[0].onended = function () {
            self.stopScreenShared();
          };

          const options = {
            audioStream: null,
            videoStream: screenStream,
            onicecandidate: self._participant.onIceCandidate.bind(self._participant),
            browserType: browserName,
            turnsConfig: self._turnsConfig,
            H264Codec: environment['H264_CODEC']
          };

          self._participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendonly(options,
            function (kurentoError) {
              if (kurentoError) {
                console.log('---error---- ', kurentoError);
              }
              // self._confPageService.initLocalPeerStatsObs(self._participant);
              //this will mute the audio of the user
              self._participant.rtcPeer.audioEnabled = false;
              self._participant.rtcPeer.generateOffer(self._participant.offerToReceiveScreen.bind(self._participant));
            }
          );
        }, (error) => {
          self.notifyUserMediaAccessStatus.emit('denied');
          self.stopScreenShared('fromChild');
          console.log('User Denied To access');
        })
    } else {
      window.getScreenId(
        (error, sourceId, screen_constraints) => {
          if (error === 'not-installed' && isDesktopApp === false) {
            self.notifyUserMediaAccessStatus.emit('');
            this.confirmPopUp(
              'Please install screen sharing extension for ' + browserName + '. Restart your browser once installed the extension.',
              'https://chrome.google.com/webstore/detail/screen-capturing/ajhifddimkapgcifgcodmmfdlknahffk'
            );
            return;
          }

          if (error === 'installed-disabled' && isDesktopApp === false) {
            self.notifyUserMediaAccessStatus.emit('');
            this.confirmPopUp('Please install or enable ' + browserName + ' extension.', 'chrome://extensions');
            // window.open('chrome://extensions', '_blank');
            return;
          }

          if (error === 'permission-denied' && isDesktopApp === false) {
            self.notifyUserMediaAccessStatus.emit();
            self.stopScreenShared();
            return;
          }
          let optionsConstraint = this._utilService.getInfoFromStorage('session', 'optionalScreenConstraint');

          if (screen_constraints.video !== undefined && screen_constraints.video.mandatory !== undefined) {
            // screen_constraints.video.mandatory.minFrameRate = 5;
            // screen_constraints.video.mandatory.maxFrameRate = 20;
            screen_constraints.video.optional = optionsConstraint

          }


          self._participant.screenShareConstraints = screen_constraints;
          console.log('screen_constraints ---> ', screen_constraints);

          self._participant.screenShare = true;
          window.navigator.getUserMedia = window.navigator.mozGetUserMedia || window.navigator.webkitGetUserMedia;
          window.navigator.getUserMedia(screen_constraints, function (videoStream) {
            self._videoStream = videoStream;
            window.videoStreamTest = videoStream;
            self.notifyUserMediaAccessStatus.emit('allowed');
            videoStream.getVideoTracks()[0].onended = function () {
              self.stopScreenShared();
            };
            // self.participant.getVideoElement().src = URL.createObjectURL(videoStream);
            // window.navigator.getUserMedia = window.navigator.mozGetUserMedia || window.navigator.webkitGetUserMedia;
            window.navigator.getUserMedia({ video: false, audio: true }, function (audioStream) {
              self._audioStream = audioStream;
              const options = {
                audioStream: audioStream,
                videoStream: videoStream,
                onicecandidate: self._participant.onIceCandidate.bind(self._participant),
                browserType: browserName,
                turnsConfig: self._turnsConfig,
                H264Codec: self._utilService.getEnvironmentValue('H264_CODEC')
              };

              self._participant.rtcPeer = new kurentoUtils.WebRtcPeer.WebRtcPeerSendonly(options,
                function (kurentoError) {
                  if (kurentoError) {
                    console.log('---error---- ', kurentoError);
                  }
                  // self._confPageService.initLocalPeerStatsObs(self._participant);
                  //this will mute the audio of the user
                  self._participant.rtcPeer.audioEnabled = false;
                  self._participant.rtcPeer.generateOffer(self._participant.offerToReceiveScreen.bind(self._participant));
                }
              );
              // self.isScreenShareInited = true;
            }, (audioError) => {
              self.notifyUserMediaAccessStatus.emit('denied');
              self.stopScreenShared('fromChild');
              console.log('System not able to get audio Stream: ', audioError);
            });
          }, (videoError) => {
            self.notifyUserMediaAccessStatus.emit('denied');
            self.stopScreenShared('fromChild');
            console.log('System not able to get audio Stream: ', videoError);
          });
        }
      );
    }
  }

  confirmPopUp(msg, urlToOpen) {
    const confirmBox = confirm(msg);
    if (confirmBox === true) {
      window.open(urlToOpen, '_blank');
    }
    this.stopScreenShared();
  }

  stopScreenShared(evtTriggerBy?: string) {
    clearInterval(this.heartBeatIntervalId);
    this.notifyToStopScreenShare.emit(evtTriggerBy);
    this.ngOnDestroy();
  }

  connectionHeartBeat() {
    console.log("share screen heartbeat called", this.heartBeatIntervalId);
    if (this.heartBeatIntervalId) {
      clearInterval(this.heartBeatIntervalId);
    }

    this.heartBeatIntervalId = setInterval(() => {
      console.log("share screen heartbeat sent");
      this.sendMsg({
        'req': 'hrtbeat'
      }, this._webSocket);
    }, environment.HEARTBEAT_INTERVAL);
  }

  ngOnDestroy() {
    clearInterval(this.heartBeatIntervalId);
    if (this._webSocket !== null && this._webSocket !== undefined && this._webSocket.readyState === 1) {
      // stop all the video and audio stream
      if (this._videoStream !== undefined) {
        this._videoStream.getTracks().forEach(track => track.stop());
      }

      if (this._audioStream !== undefined) {
        this._audioStream.getTracks().forEach(track => track.stop());
      }

      // notify all user that screen shared has been stoped
      this.sendMsg({
        req: 'mediaChangeOffer',
        userId: this.userId,
        offer: null,
        share_scr: false
      }, this._webSocket);

      // // now leave room for the new user that added for screen shared
      // this.sendMsg(
      //   {'req': 'leaveMeetingRoom'}, this._webSocket
      // );

      // dispose and make the connection null
      if (this._participant !== undefined) {
        this._participant.dispose();
        this._webSocket.close();
        this._webSocket = null;
      }
    }
  }
}
