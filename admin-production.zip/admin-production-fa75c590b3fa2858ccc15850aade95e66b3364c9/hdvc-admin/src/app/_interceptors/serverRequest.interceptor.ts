/**
 * serverRequestInterceptor  capture all http request and add auth token also catch the failed request error and throw it to request service.
 */
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { AuthService } from '../auth/auth.service';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class serverRequestInterceptor implements HttpInterceptor {
  
  constructor(public auth: AuthService) {}
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // this method add the token to request and process the request
    let header = {
      Authorization: `Bearer ${this.auth.getToken()}`
    }
    if(request.params.get('setValueInHeader')){
      header["customerId"] = request.params.get('customerId')
    }
    request = request.clone({
      setHeaders:header
    });
    
    return next.handle(request) // process request
    .pipe(                     // after response if req failed catch block executed
      catchError( (error: HttpErrorResponse) => { 
        console.log("error",error)
        let errorObj = {};
        console.log("From serverRequestInterceptor--- error",error["error"]);
         // Client Side Error
         if (error.error instanceof ErrorEvent) {        
           errorObj = {status: 0, message: error.error.message}
         } 
         else {  // Server Side Error (currently api reponse is different format so that multiple block added)
          let errorResponse = error["error"];
          if(errorResponse["result"] != undefined && errorResponse["result"] != null && errorResponse["result"].message != null){
            errorObj = {status: error.status, message: errorResponse["result"].message}
          }else if(errorResponse["result"] != undefined && errorResponse["result"].length != 0 && errorResponse["result"][0].message != null){
            errorObj = {status: error.status, message: errorResponse["result"][0].message}
          }
          else if(errorResponse != undefined && errorResponse.message != null && errorResponse["result"] != null && errorResponse["result"].length == 0){
            errorObj = {status: error.status, message: errorResponse.message}
          }
          else{
            errorObj = {status: error.status, message: error["error"].message}
          } 
          
         }
         return throwError(errorObj); // throw the error
       })
    )
  }
}