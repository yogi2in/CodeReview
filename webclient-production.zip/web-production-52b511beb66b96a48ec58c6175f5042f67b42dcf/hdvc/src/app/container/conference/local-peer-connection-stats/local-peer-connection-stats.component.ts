import { Component, OnInit, ViewEncapsulation, OnDestroy, Input } from '@angular/core';
import { ConferencePageService } from '../conference-page-service.service';
import { Subscription } from 'rxjs';
import { JoinMeetignService } from '../../join-meeting/join-meeting.service';
import { LogService } from 'src/app/shared/logger/log.service';
import { UtilService } from 'src/app/shared/services/utils.services';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-local-peer-connection-stats',
  templateUrl: './local-peer-connection-stats.component.html',
  styleUrls: ['./local-peer-connection-stats.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class LocalPeerConnectionStatsComponent implements OnInit {
  private _localPeerConnection: any;
  public onInitLocalPeersSubs = new Subscription();
  public onNotifyAverageBytesSendRange = new Subscription();
  public audioSent: any;
  public videoSent: any;
  public videoSentCodec: any = '';
  public audioSentCodec: any = '';
  public prevVideoSent = 0;
  public prevAudioSent = 0;
  public prevAudioSentTime: any;
  public prevVideoSentTime: any;
  public totalBirateSent = 0;
  public totalBitrateReceived = 0;
  public curActualResolution: any;
  public currentBandWidth: any = 128;
  public prevResponsesReceived = 0;
  public RTCIceCandidatePairTimeoutId: any;
  public RTCIceCandidatePairResponseRecievedCounter = 0;
  public RTCIceCandidatePairResponseSentCounter = 0;
  public RTCStoppedAudioSentCounter = 0;
  public RTCStoppedVideoSentCounter = 0;
  public autoRedirectTimeoutId: any;
  public videoConstraints: any;
  public frameSentCount: any = 0;
  public prevframeSentCount: any = 0;
  private statsInterval: any;
  private nullReportCounter = 0;
  private sendVideoFailedMsgeIntervalId: any;
  private notifyCurBandwidthUsageIntervalId: any;
  private _browserInfo: any;
  private rtcCodes: any = {};
  private bytesSentArray = [];
  private curIndex;
  public totalBitrateReceivedPerSec = 0;
  public totalBitrateSentPerSec = 0;
  public prevBitrateSentPerSec = 0;
  public prevLocalBitrateReceivedPerSec = 0;
  public localVideoElement: any;
  public minWidthResolution: any;
  public maxWidthResolution: any;
  public minResolution: any;
  public maxResolution: any;
  public selfPacketLost = 0;
  public remotePacketLost = 0;
  public selfJiiter = 0;
  public statsCounter = 0;
  public statsLoopCounter = 0;
  public prevVideoSentBytes = 0;
  public prevAudioVideoRecvBytes = 0;
  public firstWindowWidth;
  public timeStamp : any = 0;
  public audioSendLoopCounter = 0;
  public videoSendLoopCounter = 0;
  public audioVideoRecvLoopCounter = 0;
  public prevTotalBytesSent = 0;
  public lowBandwidthCounter = 0;
  @Input() appLocation: string;
  public newSDPOfferTimeoutId: any;
  public videoBitRateStoppedCounter = 0;

  public prevTotalBitrateSent: any = 0;
  public prevTotalBitrateReceived: any = 0;
  public prevStatsCounter: any = 0;
  public prevRemoteCounter: any = 0;
  public prevMinResolution: any = 0;
  public prevMaxResolution: any = 0;
  public prevSelfPacketLost: any = 0;
  public prevRemotePacketLost: any = 0;
  public prevMaxJitter: any = 0;
  public prevAvgJitter: any = 0;
  public averageBytesSentCheckRange: any;

  constructor(
    private _confPageService: ConferencePageService,
    private _joinMeetingService: JoinMeetignService,
    private _logService: LogService,
    private _utilService: UtilService
  ) { }

  ngOnInit() {
    this.firstWindowWidth = window.innerWidth;
    this._browserInfo = this._utilService.getBrowserInfo();
    this.averageBytesSentCheckRange = environment['AVERAGE_BYTES_SENT_CHECK'];
    let bandwidthUsageIntervalTimmer = environment['CURRENT_BANDWIDTH_USAGE_API_INTERVAL'] !== undefined ? environment['CURRENT_BANDWIDTH_USAGE_API_INTERVAL'] : 30000;
    if (this.firstWindowWidth < 992 && this.appLocation === 'modal') {
      this.onInitLocalPeersSubs = this._confPageService.onInitLocalPeerStatsListener()
      .subscribe(
        (response: any) => {
          clearInterval(this.statsInterval);
          this.RTCStoppedAudioSentCounter = 0;
          this.RTCStoppedAudioSentCounter = 0;
          this.RTCIceCandidatePairResponseRecievedCounter = 0;
          this.getSenderStats(response.localPeer);
        }
      )
      this.notifyCurBandwidthUsageIntervalId = setInterval(() => {
        this.notifyTotalBandwidthUsage();
      }, bandwidthUsageIntervalTimmer);
    }
    if (this.firstWindowWidth >= 992 && this.appLocation === 'dropDown') {
      this.onInitLocalPeersSubs = this._confPageService.onInitLocalPeerStatsListener()
      .subscribe(
        (response: any) => {
          clearInterval(this.statsInterval);
          this.RTCStoppedAudioSentCounter = 0;
          this.RTCStoppedAudioSentCounter = 0;
          this.RTCIceCandidatePairResponseRecievedCounter = 0;
          this.getSenderStats(response.localPeer);
        }
      )
      this.notifyCurBandwidthUsageIntervalId = setInterval(() => {
        this.notifyTotalBandwidthUsage();
      }, bandwidthUsageIntervalTimmer);
    }

    this.onNotifyAverageBytesSendRange = this._confPageService.notifyAverageBytesSendRange().subscribe(
      (response: any) => {
        console.log('response -----> neww ', response);
        if (response !== undefined && response.newCheckPoint !== undefined) {
          this.averageBytesSentCheckRange = response.newCheckPoint;
        }
      }
    )
  }

  notifyTotalBandwidthUsage() {
    this.remotePacketLost = this.commulateTotalPacketLost(this._confPageService.remoteUsersPacketLost);
    if (this.totalBirateSent == 0 || this.minResolution == undefined || this.maxResolution == undefined) {
      return;
    }

    this.prevTotalBitrateSent = this.totalBirateSent !== undefined && this.totalBirateSent !== 0 ? this.totalBirateSent : this.prevTotalBitrateSent;
    this.prevTotalBitrateReceived = this.totalBitrateReceived !== undefined || this.totalBitrateReceived !== 0 ?  this.totalBitrateReceived: this.prevTotalBitrateReceived;
    this.prevStatsCounter = this.statsCounter != undefined && this.statsCounter != 0 ? this.statsCounter : this.prevStatsCounter;
    this.prevRemoteCounter = this._confPageService.remoteCounter != undefined && this._confPageService.remoteCounter != 0 ? this._confPageService.remoteCounter : this.prevRemoteCounter;
    this.prevMinResolution = this.minResolution != undefined && this.minResolution != 0 ? this.minResolution : this.prevMinResolution;
    this.prevMaxResolution = this.maxResolution != undefined && this.maxResolution != 0 ? this.maxResolution : this.prevMaxResolution;
    this.prevSelfPacketLost = this.selfPacketLost != undefined && this.selfPacketLost != 0 ? this.selfPacketLost : this.prevSelfPacketLost;
    this.prevRemotePacketLost = this.remotePacketLost != undefined && this.remotePacketLost != 0 ? this.remotePacketLost : this.prevRemotePacketLost;
    this.prevMaxJitter = this._confPageService.maxJitter != undefined && this._confPageService.maxJitter != 0 ? this._confPageService.maxJitter : this.prevMaxJitter;
    this.prevAvgJitter = this._confPageService.avgJitter != undefined && this._confPageService.avgJitter != 0 ? this._confPageService.avgJitter : this.prevAvgJitter;

    this._confPageService.notifyTotalBandwidthUsageObs(
      this.prevTotalBitrateSent,
      this.prevTotalBitrateReceived,
      this.prevStatsCounter,
      this.prevRemoteCounter,
      this.prevMinResolution,
      this.prevMaxResolution,
      this.prevSelfPacketLost,
      this.prevRemotePacketLost,
      this.prevMaxJitter,
      this.prevAvgJitter);
  }

  getSenderStats(participant: any) {
    if (participant.rtcPeer === undefined) {
      return;
    }
    this._utilService.sendAlertMessage('hide','');
    this.curIndex = this.curIndex === undefined ? 0 : this.curIndex + 1;
    clearInterval(this.statsInterval);
    this.localVideoElement = participant.rtcPeer.localVideo;
    const senders = participant.rtcPeer.getSenders();
    this.statsInterval = setInterval(() => {
      ++this.statsCounter;
      participant.rtcPeer.getStats().then((statsResponse) => {
        statsResponse.forEach(stats=> {
          this.handleLocalPeersStats(stats);
        })
      });
      this.statsLoopCounter = this.statsLoopCounter > 5 ? 1 : this.statsLoopCounter + 1;
    }, 1000);

    // this.statsInterval = setInterval(() => {
    //   ++this.statsCounter;
    //   participant.rtcPeer.getStats().then((statsResponse) => {
    //     statsResponse.forEach(stats=> {
    //       this.handleLocalPeersStats(stats);
    //     });
    //   });
    //   this.statsLoopCounter = this.statsLoopCounter > 4 ? 0 : this.statsLoopCounter + 1;
    // }, 1000);


  }

  handleLocalPeersStats(localStats: any) {
    if (localStats === null) {
      ++this.nullReportCounter;
      return;
    }
    if (this._browserInfo.name.toLowerCase() === 'chrome' || this._browserInfo.name.toLowerCase() === 'opera') {
      this.createRTCCodecList(localStats);
      this.statsForChrome(localStats);
    } else {
      this.statsForFireForx(localStats);
    }
  }

  createRTCCodecList(localStats) {
    if (localStats.id !== undefined &&
        (
          localStats.id.indexOf('RTCCodec_1_Outbound') > -1 ||
          localStats.id.indexOf('RTCCodec_video_Outbound') > -1 ||
          localStats.id.indexOf('RTCCodec_0_Outbound') > -1 ||
          localStats.id.indexOf('RTCCodec_audio_Outbound') > -1
        )
      ) {
      if (this.rtcCodes[localStats.id] === undefined) {
        this.rtcCodes[localStats.id] = localStats.mimeType.split("/")[1];
      }
    }
  }

  statsForChrome(localStats: any) {
    // if (this.RTCStoppedAudioSentCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.');
    //   this._logService.debug('Client not able to sent audio --> this.RTCStoppedAudioSentCounter ', this.RTCStoppedAudioSentCounter, this.prevAudioSent);
    //   this._logService.warn('Client not able to sent audio --> this.RTCStoppedAudioSentCounter ', this.RTCStoppedAudioSentCounter, this.prevAudioSent);
    //   this.RTCStoppedAudioSentCounter = 0;
    // }

    // if (this.RTCStoppedVideoSentCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.')
    //   this._logService.debug('Client not able to sent videos --> this.RTCStoppedVideoSentCounter ', this.RTCStoppedVideoSentCounter, this.prevVideoSent);
    //   this._logService.warn('Client not able to sent videos --> this.RTCStoppedVideoSentCounter ', this.RTCStoppedVideoSentCounter, this.prevVideoSent);
    //   this.RTCStoppedVideoSentCounter = 0;
    // }

    // if (this.RTCIceCandidatePairResponseRecievedCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.')
    //   this._logService.debug("Client not able to received videos stream --> this.RTCIceCandidatePairResponseRecievedCounter ", this.RTCIceCandidatePairResponseRecievedCounter);
    //   this._logService.warn('Client not able to received videos stream --> this.RTCIceCandidatePairResponseRecievedCounter ', this.RTCIceCandidatePairResponseRecievedCounter);
    //   this.RTCIceCandidatePairResponseRecievedCounter = 0;
    // }

    // this block will help get the resultion

    // if (localStats.id.indexOf('RTCIceCandidatePair') !== undefined && localStats.availableOutgoingBitrate !== undefined) {
    //   console.log('availableOutgoingBitrate ', localStats.availableOutgoingBitrate, this.unitToBytesForBandwidth(localStats.availableOutgoingBitrate));
    // }

    if (
      localStats.type !== undefined &&
      localStats.id.indexOf('RTCMediaStreamTrack') > -1 &&
      localStats.kind === 'video' &&
      localStats.remoteSource === false
      ) {
        // console.log('frame height ', localStats.frameWidth, localStats.frameHeight);
        if (this.localVideoElement !== null) {
          let pixcelValue = this.getPixcelValue(this.localVideoElement.videoWidth, this.localVideoElement.videoHeight);
          this.curActualResolution =  "[" + pixcelValue + "] " + this.localVideoElement.videoWidth+"X"+this.localVideoElement.videoHeight;
          this.frameSentCount = localStats.framesSent - this.prevframeSentCount;
          this.prevframeSentCount = localStats.framesSent;
          if (this.minWidthResolution !== undefined && this.maxWidthResolution !== undefined) {
            if (this.minResolution < this.localVideoElement.videoWidth) {
              this.minResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
              this.minWidthResolution = this.localVideoElement.videoWidth;
            } else if (this.maxWidthResolution < this.localVideoElement.videoWidth) {
              this.maxResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
              this.maxWidthResolution = this.localVideoElement.videoWidth;
            }
          } else {
            this.minResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
            this.maxResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
            this.minWidthResolution = this.localVideoElement.videoWidth;
            this.maxWidthResolution = this.localVideoElement.videoWidth;
          }
        }
    }

    // this blow will help to get audio sent and code type


    if (
      localStats.type !== undefined &&
      localStats.type === 'outbound-rtp' &&
      (localStats.kind === 'audio' || localStats.mediaType === 'audio')
    ) {
       if (this.prevAudioSent === localStats.bytesSent) {
        // ++this.RTCStoppedAudioSentCounter;
      } else {
        // clearInterval(this.sendVideoFailedMsgeIntervalId);
        // this.RTCStoppedAudioSentCounter  = 0;
        this.audioSent =  (localStats.bytesSent - this.prevAudioSent)  * 8;
      }
      this.prevAudioSent = localStats.bytesSent;
      this.audioSentCodec = this.rtcCodes[localStats.codecId] !== undefined ? this.rtcCodes[localStats.codecId].toUpperCase() : "";
      this.checkAudioSentState(localStats.bytesSent, this.statsLoopCounter);
      this.selfPacketLost = 0;
      this.timeStamp = localStats.timestamp;
    }

    // this blow will help to get audio sent and code type
    if (localStats.type !== undefined && localStats.type === 'outbound-rtp' &&
      (
        localStats.kind === 'video' || localStats.mediaType === 'video'
      )
    ) {
      this.videoSentCodec = this.rtcCodes[localStats.codecId] !== undefined ? this.rtcCodes[localStats.codecId].toUpperCase() : "";
      if (this.prevVideoSent === localStats.bytesSent) {
        //++this.RTCStoppedAudioSentCounter;
      } else {
        // clearInterval(this.sendVideoFailedMsgeIntervalId);
        // this.RTCStoppedAudioSentCounter = 0;
        this.videoSent = (localStats.bytesSent - this.prevVideoSent) * 8; //this.unitToBytesForBandwidth((localStats.bytesSent - this.prevVideoSent)*8);
      }
      this.prevVideoSent = localStats.bytesSent;
      this.checkVideoSentState(localStats.bytesSent, this.statsLoopCounter);
      this.checkAverageSendBandWidth(this.prevVideoSent + this.prevAudioSent, this.statsLoopCounter);
      this.timeStamp = localStats.timestamp;
    }

    // this blow will handle total bytes sent and received
    if (localStats.id.indexOf('RTCTransport') > -1 && localStats.type === 'transport') {
      this.checkAudioVideoReceivedState(localStats.bytesReceived, this.statsLoopCounter);
      this.timeStamp = localStats.timestamp;
      if (localStats.bytesSent !== undefined) {
        this.bytesSentArray[this.curIndex] = localStats.bytesSent * 8;
        this.totalBirateSent = this.calcuateTotalBitrateSent(this.bytesSentArray); // this.unitToBytesForBandwidth(localStats.bytesSent*8);
        this.totalBitrateSentPerSec = (localStats.bytesSent - this.prevBitrateSentPerSec) * 8;
        this.totalBitrateReceived = this._confPageService.totalBitRateReceived * 8;
        this.totalBitrateReceivedPerSec = this._confPageService.totalBitRateReceivedPerSec * 8;
        this.prevBitrateSentPerSec = localStats.bytesSent;
      }
    }
  }

  statsForFireForx(localStats: any) {
    // if (this.RTCStoppedAudioSentCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.');
    //   this._logService.warn('Client not able to sent audio --> this.RTCStoppedAudioSentCounter ', this.RTCStoppedAudioSentCounter, this.prevAudioSent);
    //   this.RTCStoppedAudioSentCounter = 0;
    // }

    // if (this.RTCStoppedVideoSentCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.')
    //   this._logService.warn('Client not able to sent videos --> this.RTCStoppedVideoSentCounter ', this.RTCStoppedVideoSentCounter, this.prevVideoSent);
    //   this.RTCStoppedVideoSentCounter = 0;
    // }

    // if (this.RTCIceCandidatePairResponseRecievedCounter >= 12) {
    //   this.sendUserToJoinMeetingPage();
    //   this._utilService.sendAlertMessage('Network issue detected. Audio/Video may be impaired.')
    //   this._logService.warn('Client not able to received videos stream --> this.RTCIceCandidatePairResponseRecievedCounter ', this.RTCIceCandidatePairResponseRecievedCounter);
    //   this.RTCIceCandidatePairResponseRecievedCounter = 0;
    // }

    // this block will handle to check video
    if (localStats.id.indexOf('outbound_rtp_video') > -1 && localStats.kind === 'video') {
     // console.log('localStats video ', localStats.id, localStats);
      if (this.prevVideoSent === localStats.bytesSent) {
        // ++this.RTCStoppedVideoSentCounter;
      } else {
        this.videoSent = (localStats.bytesSent - this.prevVideoSent) * 8; //this.unitToBytesForBandwidth((localStats.bytesSent - this.prevVideoSent)*8);
      }
      this.prevVideoSent = localStats.bytesSent;
      this.checkVideoSentState(localStats.bytesSent, this.statsLoopCounter);
      this.checkAverageSendBandWidth(this.prevAudioSent + this.prevVideoSent, this.statsLoopCounter);

      if (this.localVideoElement !== null && this.localVideoElement.videoWidth > 10) {
        let pixcelValue = this.getPixcelValue(this.localVideoElement.videoWidth, this.localVideoElement.videoHeight);
        this.curActualResolution =  "[" + pixcelValue + "] " + this.localVideoElement.videoWidth+"X"+this.localVideoElement.videoHeight ;
      }

      //code for frame count
      this.frameSentCount = parseInt(localStats.framerateMean)//localStats.framesSent - this.prevframeSentCount;
      this.prevframeSentCount = localStats.framesSent;

      if (this.minWidthResolution !== undefined && this.maxWidthResolution !== undefined) {
        if (this.minResolution < this.localVideoElement.videoWidth) {
          this.minResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
          this.minWidthResolution = this.localVideoElement.videoWidth;
        } else if (this.maxWidthResolution < this.localVideoElement.videoWidth) {
          this.maxResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
          this.maxWidthResolution = this.localVideoElement.videoWidth;
        }
      } else {
        this.minResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
        this.maxResolution = this.localVideoElement.videoWidth + " X " + this.localVideoElement.videoHeight;
        this.minWidthResolution = this.localVideoElement.videoWidth;
        this.maxWidthResolution = this.localVideoElement.videoWidth;
      }
    }

    // this block will handle for audio data
    if (localStats.id.indexOf('outbound_rtp_audio') > -1 && localStats.kind === 'audio') {
      //console.log('localStats audio ', localStats.id, localStats);
      if (this.prevAudioSent === localStats.bytesSent) {
        // ++this.RTCStoppedAudioSentCounter;
      } else {
        // clearInterval(this.sendVideoFailedMsgeIntervalId);
        // this.RTCStoppedAudioSentCounter  = 0;
        this.audioSent =  ((localStats.bytesSent - this.prevAudioSent)/2) * 8;
      }
      this.prevAudioSent = localStats.bytesSent;
      this.checkAudioSentState(localStats.bytesSent, this.statsLoopCounter);
      this.selfPacketLost = 0;
    }

    if (localStats.id.indexOf('outbound_rtcp_video') && localStats.kind === 'video') {
      // if (localStats.bytesReceived === this.prevLocalBitrateReceivedPerSec) {
      //   ++this.RTCIceCandidatePairResponseRecievedCounter;
      // }else {
      //   this.RTCIceCandidatePairResponseRecievedCounter = 0;
      // }
      // this.prevLocalBitrateReceivedPerSec = localStats.bytesReceived;
      this.checkAudioVideoReceivedState(localStats.bytesReceived, this.statsLoopCounter);
      this.bytesSentArray[this.curIndex] = (this.prevAudioSent + this.prevVideoSent) * 8;
      this.totalBirateSent = this.calcuateTotalBitrateSent(this.bytesSentArray); // this.unitToBytesForBandwidth(localStats.bytesSent*8);
      this.totalBitrateSentPerSec = (localStats.bytesSent - this.prevBitrateSentPerSec) * 8;
      this.totalBitrateReceived = this._confPageService.totalBitRateReceived * 8;
      this.totalBitrateReceivedPerSec = this._confPageService.totalBitRateReceivedPerSec * 8;
      this.prevBitrateSentPerSec = localStats.bytesSent;
    }
  }

  calcuateTotalBitrateSent(sentBitrateArr) {
    let result = 0;
    sentBitrateArr.map((arrValue) => {
      result = result + arrValue;
    })
    return result;
  }

  getPixcelValue(resWidth, resHeight) {
    let resultPixcelValue = "";
    switch(resWidth) {
      case 1600:
       resultPixcelValue = 'UXGA';
        break;
      case 1280:
        resultPixcelValue = '720p(HD)';
        break;
      case 800:
        resultPixcelValue = 'SVGA';
       break;
      case 640:
        if (resHeight === 480) {
          resultPixcelValue = 'VGA'
        } else if(resHeight === 360) {
          resultPixcelValue = '360p(nHD)';
        }
        break;
      case 352:
        resultPixcelValue = 'CIF';
        break;
      case 320:
        resultPixcelValue = 'QVGA';
        break;
      case 176:
        resultPixcelValue = 'QCIF';
        break;
      case 160:
        resultPixcelValue = 'QQVGA'
        break;
    }
    return resultPixcelValue;
  }

  unitToBytesForBandwidth(unit: any) {
    if (unit === 0 || unit === undefined || unit < 0) {
      return 0 + ' Kbps';
    }
    let unitToBytes = (unit / 1024);
    return unitToBytes.toFixed(2) + ' Kbps';
  }

  unitToBytes(unit: any) {
    if (unit === 0 || unit === undefined || unit < 0) {
      return 0 + ' Kbps';
    }
    let unitToBytes = (unit / 1000) * 8;
    return unitToBytes.toFixed(2) + ' Kbps';
  }

  convertToKbps(bytes: any) {
    if (bytes === 0 || bytes === undefined || bytes < 0) {
      return 0 + ' Kbps';
    }
    let unitToBytes = (bytes / 1000) * 8;
    return unitToBytes.toFixed(2);
  }

  sendUserToJoinMeetingPage() {
    // this._joinMeetingService.setConnectionLostMessage('Something went wrong! Please try again.');
    this._confPageService.notifyUserToRedreictToJoinMeeting();
    clearInterval(this.statsInterval);
    clearTimeout(this.RTCIceCandidatePairTimeoutId);
  }

  commulateTotalPacketLost(remoteUsersPacketLost) {
    let totalPacketLost = 0;
    if (remoteUsersPacketLost === undefined) {
      return totalPacketLost;
    }

    let userKeys = Object.keys(remoteUsersPacketLost);
    if (userKeys.length > 0) {
      userKeys.map(userId => {
        if (remoteUsersPacketLost[userId] !== undefined) {
          totalPacketLost = totalPacketLost + remoteUsersPacketLost[userId]["video"] + remoteUsersPacketLost[userId]["audio"];
        }
      });
    }
    return totalPacketLost;
  }

  checkAudioSentState(curAudioSentBytes: any, counter: any) {
    if (counter === environment.LOCAL_STATS_CHECK_LOOP_COUNTER) {
      this._logService.debug('checkAudioSentState ', curAudioSentBytes, counter);
      if (this.prevAudioSent === curAudioSentBytes) {
        ++this.RTCStoppedAudioSentCounter;
      } else {
        this.RTCStoppedVideoSentCounter = 0;
        this.RTCStoppedAudioSentCounter = 0;
        this.RTCIceCandidatePairResponseRecievedCounter = 0;
        if (this._confPageService.isVideoPaused === false) {
          this._utilService.sendAlertMessage('hide','');
        }
      }
      this.prevAudioSent = curAudioSentBytes;
      this.onAudioVideoSendStopped(this.RTCStoppedAudioSentCounter, curAudioSentBytes, 'audio');
    }
  }

  checkVideoSentState(curVideoSentBytes: any, counter: any) {
    if (counter === environment.LOCAL_STATS_CHECK_LOOP_COUNTER) {
      this._logService.debug("checkVideoSentState ", curVideoSentBytes, counter);
      if (this.prevVideoSentBytes === curVideoSentBytes) {
        ++this.RTCStoppedVideoSentCounter;
      } else {
        clearTimeout(this.newSDPOfferTimeoutId);
        this.RTCStoppedVideoSentCounter = 0;
        this.RTCStoppedAudioSentCounter = 0;
        this.RTCIceCandidatePairResponseRecievedCounter = 0;
        // if (this._confPageService.isVideoPaused === false) {
        //   this._utilService.sendAlertMessage('hide','');
        // }
        //this._utilService.sendAlertMessage('hide','');
      }

      // special case when camera unplug
      if (this.prevVideoSentBytes === curVideoSentBytes && curVideoSentBytes !== 0) {
        ++this.videoBitRateStoppedCounter;
      } else {
        this.videoBitRateStoppedCounter = 0;
      }

      this.prevVideoSentBytes = curVideoSentBytes;
      this.onAudioVideoSendStopped(this.RTCStoppedAudioSentCounter, curVideoSentBytes, 'video');

      if (this.videoBitRateStoppedCounter >= 2){
        this._confPageService.notifyToRetryIceCandidateObs();
        this.videoBitRateStoppedCounter = 0;
      }
    }
  }

  checkAudioVideoReceivedState(curAudioVideoRecvBytes: any, counter: any) {
    if (counter === environment.LOCAL_STATS_CHECK_LOOP_COUNTER) {
      // this._logService.debug('checkAudioVideoReceivedState ', curAudioVideoRecvBytes, counter)
      if (this.prevAudioVideoRecvBytes === curAudioVideoRecvBytes) {
        ++this.RTCIceCandidatePairResponseRecievedCounter;
      } else {
        this.RTCStoppedVideoSentCounter = 0;
        this.RTCStoppedAudioSentCounter = 0;
        this.RTCIceCandidatePairResponseRecievedCounter = 0;
        // if (this._confPageService.isVideoPaused === false) {
        //   this._utilService.sendAlertMessage('hide','');
        // }
        //this._utilService.sendAlertMessage('hide','');
      }
      this.prevAudioVideoRecvBytes = curAudioVideoRecvBytes;
      // this.onAudioVideoRecvStopped(this.RTCIceCandidatePairResponseRecievedCounter);
    }
  }

  checkAverageSendBandWidth(totalBytesSent: any, curCheckCounter: any) {
    if (this._confPageService.isVideoPaused === false && this._confPageService.isBandwidthCheckEnable === true) {
      if (curCheckCounter === environment.LOCAL_STATS_CHECK_LOOP_COUNTER) {
        this._logService.debug("checkAverageSendBandWidth", totalBytesSent, curCheckCounter);
        // console.log('this.lowBandwidthCounter ', this.lowBandwidthCounter);
        if (this.lowBandwidthCounter >= environment.AVERAGE_BANDWIDTH_CHECK_COUNTER) {
          // this._confPageService.notifyToPausedVideoObs(false);
          // this._confPageService.isVideoPaused = false;
          this._confPageService.isBandwidthCheckEnable = false;
          this._utilService.sendAlertMessage('Poor connectivity. Consider switching your video off.','no-action');
          this.lowBandwidthCounter = 0;
        }
        let totalBytesSentInLastFiveSec = totalBytesSent - this.prevTotalBytesSent;
        let avgBytesSent: any = this.convertToKbps(totalBytesSentInLastFiveSec/6);
        // console.log('this.lowBandwidthCounter ', this.lowBandwidthCounter, avgBytesSent, environment.AVERAGE_BYTES_SENT_CHECK)
        if (avgBytesSent < this.averageBytesSentCheckRange) {
          ++this.lowBandwidthCounter;
        } else {
          this.lowBandwidthCounter = 0;
        }
        this.prevTotalBytesSent = totalBytesSent;
      }
    }
  }

  onAudioVideoSendStopped(curCounter: number, curBytesSent: any, sentFor: string): void {
    // console.log('onAudioVideoSendStopped --> audio/ video send counter, curBytesSent ', curCounter, curBytesSent)
    switch(curCounter) {
      case 14:
        // check the counter increase due to iceing
        if (curBytesSent === 0) {
          this._joinMeetingService.setConnectionLostMessage('Unable to connect using your browser. Please try desktop app instead or contact your network administrator.');
          this._logService.debug('onAudioVideoSendStopped --> Seems Iceing Failed --> send user to joining page')
          this.sendUserToJoinMeetingPage();
        } else {
          this._logService.debug('onAudioVideoSendStopped --> Retry and send new sdp offer');
          this._confPageService.notifyToRetryIceCandidateObs();
          this._utilService.sendAlertMessage('Poor network condition. You might face some issue in quality.', 'warn');
        }
        break;
      // case 6:
      //   if (this._confPageService.isVideoPaused === false) {
      //     // stop the video
      //     this._confPageService.notifyToPausedVideoObs(false);
      //     this._utilService.sendAlertMessage('Bad send connection and stopping video.' , 'warn');
      //   } else {
      //     this._utilService.sendAlertMessage('Bad send connection.', 'warn');
      //   }
      //   break;
      // case 12:
      //   if (this._confPageService.isVideoPaused === false) {
      //     // stop the video
      //     this._confPageService.notifyToPausedVideoObs(false);
      //     this._utilService.sendAlertMessage('Persistantly deteorating send connection and stopping video. ' + curCounter, 'warn');
      //   } else {
      //     this._utilService.sendAlertMessage('Persistantly deteorating send connection.', 'warn');
      //   }
      //   break;
      case 60:
        this._joinMeetingService.setConnectionLostMessage('Persistantly deteorating send connection. Please try again after some time.');
        this.sendUserToJoinMeetingPage();
        break;
    }
  }

  onAudioVideoRecvStopped(curCounter): void {
    // console.log('onAudioVideoRecvStopped --> received stop counter --> ', curCounter)
    this._logService.debug("onAudioVideoRecvStopped", curCounter);
    switch(curCounter) {
      case 50:
        this._logService.debug('onAudioVideoRecvStopped --> Retry and send new sdp offer');
        this._utilService.sendAlertMessage('Poor network condition. You might face some issue in quality.', 'warn');
        this._confPageService.notifyToRetryIceCandidateObs();
        break;
      // case 6:
      //   this._utilService.sendAlertMessage('Bad receive connection.' + curCounter, 'warn');
      //   break;
      // default:
      //   if (curCounter >= 12) {
      //     this._utilService.sendAlertMessage('Persistantly deteorating receive connection.' + curCounter, 'warn');
      //   }
      //   break;
    }
  }

  // onVideoSendStopped(curCounter, curBytesSent) {
  //   switch(curCounter) {
  //     case 3:
  //       // check the counter increase due to iceing
  //       if (curBytesSent === 0) {

  //       } else {
  //         this._utilService.sendAlertMessage('Poor send connection', 'warn');
  //       }
  //       break;
  //     case 6:
  //       if (this._confPageService.isVideoPaused === false) {
  //         // stop the video
  //         this._utilService.sendAlertMessage('Bad send connection and stopping video.', 'warn');
  //       } else {
  //         this._utilService.sendAlertMessage('Bad send connection', 'warn');
  //       }
  //       break;
  //     case 12:
  //       if (this._confPageService.isVideoPaused === false) {
  //         // stop the video
  //         this._utilService.sendAlertMessage('Persistantly deteorating send connection and stopping video.', 'warn');
  //       } else {
  //         this._utilService.sendAlertMessage('Persistantly deteorating send connection', 'warn');
  //       }
  //       break;
  //     case 24:
  //       this._joinMeetingService.setConnectionLostMessage('Persistantly deteorating send connection. Please try again after some time.');
  //       this.sendUserToJoinMeetingPage();
  //       break;
  //   }
  // }




  /**
   *
   * @description The below function will execute when the conference component exit
   */
  ngOnDestroy() {
    this.onInitLocalPeersSubs.unsubscribe();
    this.onNotifyAverageBytesSendRange.unsubscribe();
    this.RTCIceCandidatePairResponseSentCounter  = 0;
    clearInterval(this.statsInterval);
    clearTimeout(this.RTCIceCandidatePairTimeoutId);
    clearInterval(this.sendVideoFailedMsgeIntervalId);
    clearInterval(this.notifyCurBandwidthUsageIntervalId);
    this.notifyTotalBandwidthUsage();
  }
}
