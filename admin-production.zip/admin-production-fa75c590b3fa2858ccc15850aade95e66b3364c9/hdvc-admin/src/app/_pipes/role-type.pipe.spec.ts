import { RoleTypePipe } from './role-type.pipe';

describe('RoleTypePipe', () => {
  it('create an instance', () => {
    const pipe = new RoleTypePipe();
    expect(pipe).toBeTruthy();
  });
});
