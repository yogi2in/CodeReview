export interface MeetingConfig{
  default_audio: number;
  default_layout: number;
  default_video: number;
  is_owner: number;
  jip: string;            //   "192.168.30.70"
  kip: string;            //    "192.168.30.70"
  message: string;        //      ""
  url: string;            //"wss://tuc.truringsoftek.co.in:5501/groupcall"
}
