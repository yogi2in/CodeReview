import { Component, OnInit, OnDestroy } from '@angular/core';
import { MyMeetingService} from '../my-meetings/my-meeting.service';
import { environment } from 'src/environments/environment';
import { UtilService } from '../../shared/services/utils.services';
import * as moment from 'moment-timezone';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { CookieService } from 'ngx-cookie-service';
import { LocalStorageService } from 'angular-2-local-storage';
import { from, Subscription } from 'rxjs';
import {JoinMeetignService} from '../join-meeting/join-meeting.service';
import { LogService } from 'src/app/shared/logger/log.service';
import { ConferencePageService } from 'src/app/container/conference/conference-page-service.service';
import { DeviceSettingService } from '../device-setting/device-setting.service';

@Component({
  selector: 'app-my-meetings',
  templateUrl: './my-meetings.component.html',
  styleUrls: ['./my-meetings.component.css']
})
export class MyMeetingsComponent implements OnInit, OnDestroy {
  public default_page_size = environment.PAGE_SIZE;
  public allmeetings: any;
  public todaymeetings: any;
  public tomorrowmeetings: any;
  public othermeetings: any;
  public totalrecords: number;
  public isCustomerAdmin: boolean;
  public allpastmeetings: any;
  public totalpastrecords: number;
  public pageize: Number = 10;
  public pastMeetingPageNo: Number = 1;
  public maxDate = moment().subtract(1,'days').toDate();
  public mindate:any;
  public title: string;
  public selecteddate: Date;
  public momentdate = moment();
  public upComingMeetingPageNo: Number = 1;
  public zone: string = moment.tz(moment.tz.guess()).zoneAbbr();
  public showLoader: boolean = false;
  public noMeeting: boolean = false;
  public noPastMeeting: boolean = false;
  public retryFetchMeetingDetailsInterval: any;
  public retryCounter = 1;
  public showConnectionError: boolean = false;
  public errorInEstablishingConnection: any;
  private onlineOfflineStateChangeSubs = new Subscription();
  public onStartReJoinListenerSubs = new Subscription();
  public onMeetingValidationAPIFailed = new Subscription();
  public hideValidationErrorTimeoutId: any;
  public errorMsgeWrapper: any;
  private clearSetTimeOut;

  constructor(
    private _objMeetingService: MyMeetingService,
    private _objUtils: UtilService,
    public _bsDatePickerConfig: BsDatepickerConfig,
    private cookieService: CookieService,
    private localStorageService: LocalStorageService,
    private _joinMeetingService: JoinMeetignService,
    private _confPageService: ConferencePageService,
    private _logService: LogService, 
    private _deviceSettingsService: DeviceSettingService
  ) {
    // console.log("BACK: ", window.history.state)
    //this._bsDatePickerConfig.maxDate = moment().subtract(1,'days').toDate();
    this._bsDatePickerConfig.dateInputFormat = 'DD-MM-YYYY';
    this._bsDatePickerConfig.showWeekNumbers = false;
  }

  ngOnInit() {
    this._deviceSettingsService.stopAudioStream();
    this._deviceSettingsService.stopVideoStream();
    this.errorInEstablishingConnection = this._joinMeetingService.getConnectionLostMessage();

    clearTimeout(this.clearSetTimeOut);
    this.clearSetTimeOut = setTimeout( () => {
      this.errorInEstablishingConnection = null;
    }, 3000);

    if (this.localStorageService.get('authToken') != null) {
      let currentUser = localStorage.getItem('currentUser');
      currentUser = JSON.parse(currentUser)
      if((currentUser["roleName"] == 'CUSTOMER_ADMIN' || currentUser["roleName"] == 'USER') && currentUser["isValidLicence"] == true){
        this.isCustomerAdmin = true;
      }
      this.title='';
      this.pageize == environment.PAGE_SIZE;
      this.selecteddate = null;
       this.fetchPastMeeting(1);
    } else {
      this.isCustomerAdmin = false;
    }
    this.fetchMeetingsDetails(1);

    this.onStartReJoinListenerSubs = this._confPageService.onStartReJoinListener().subscribe(
      (sResponse) => {
        this._logService.debug('onStartReJoinListenerSubs--> onStartReJoinListener', sResponse);
        if (sResponse !== undefined && sResponse.reJoin !== undefined) {
          const curMeetingInfo = sResponse.meetingInfo;
          if (curMeetingInfo.meeting_refid !== undefined) {
            this._joinMeetingService.isAutoValidate = true;
            this._joinMeetingService.isValidateThroughRejoin = true;
            this._logService.debug('onStartReJoinListenerSubs--> onStartReJoinListener under my meetings', curMeetingInfo);
            this._joinMeetingService.validateMeeting(
              curMeetingInfo.meeting_refid,
              curMeetingInfo.email_id,
              curMeetingInfo.userName,
              "MEETING-DETAILS"
            )
            this._joinMeetingService.isUserClickJoinButton = true;
          }
        }

      }, (eResponse)=> {
        this._logService.warn('onStartReJoinListenerSubs--> onStartReJoinListener', eResponse);
      }
    );

    this.onMeetingValidationAPIFailed = this._joinMeetingService.onMeetingIDValidation().subscribe((res: any) => {
      if (res !== undefined && res.status === false) {
        if (
          res.msg !== undefined &&
          res.msg.indexOf("Unable") == -1 &&
          this._joinMeetingService.meetingValidationIndex !== null) {
          this.showValidationErrorMsg(this._joinMeetingService.meetingValidationIndex, res.msg);
        } else {
          // this.invalidMeetingIdError = res.msg;
          // this.disabledMeetingBtn = false;
          let curMeetingInfo = this._joinMeetingService.curMeetingInfo;
          if (this._confPageService.isSocketStateValid === false) {
            this._confPageService.notifyToShowReconnectLayoutObs(true, curMeetingInfo, 15000, "SOCKET_STATE_CHANGE");
            this._confPageService.isSocketStateValid = true;
          } else {
            this._joinMeetingService.setConnectionLostMessage(res.msg);
          }
        }
      }
    });
  }

  //get the user details from local storage
  getUserInfo(): any {
    return this._objUtils.getInfoFromStorage('localStorage', 'currentUser');
  }

  /**
   * get the meeting details for the logged in user
   */
  fetchMeetingsDetails(page) {
    console.log("fetchMeetingsDetailsfetchMeetingsDetails");
    this.showLoader = true;
    this.upComingMeetingPageNo = page;
    const filter = {
      emailId:  this.getUserInfo().email.replace("+", "%2B"),
      title: this.title,
      fromdate: this.getCurrentDate(),
      pageIndex: page == undefined ? 1 : page
    }

    this._objMeetingService.fetchMeetingDetails(filter)
    .subscribe((response:any) => {
      if(response.body != undefined && response.body.data != undefined && response.body.data != null && response.body.data.length > 0){
        this.showLoader = false;
        this.allmeetings = response.body.data;
        this.totalrecords = response.body.total_records;
      } else {
        this.showLoader = false;
        this.noMeeting = true;
      }
      this.showConnectionError = false;
    },
    error => {
      if (error.message !== undefined && error.message === 'Invalid Request Parameter.') {
        let retryFetchMeetingDetailsInterval = setInterval(() => {
          console.log('this.retryCounter ', this.retryCounter);
          if (this.retryCounter > 2) {
            this.showLoader = false;
            this.showConnectionError = true;
            clearInterval(retryFetchMeetingDetailsInterval);
          }else {
            this.fetchMeetingsDetails(1);
            clearInterval(retryFetchMeetingDetailsInterval);
          }
          ++this.retryCounter;
        }, 10000);
      }
      console.log('error', error);
    });
  }

  formatMeetingTime(date){
    return moment.tz(date, moment.tz.guess()).format("hh:mm A");
  }

  /*
  *  The Below function fetch the past meeting details.
  */
  fetchPastMeeting(page: number) {
    const filter={
      emailId:  this.getUserInfo().email.replace("+", "%2B"),
      title: this.title,
      fromdate: this.selecteddate,
      pageIndex: page == undefined ? 1 : page
    }

    this._objMeetingService.fetchPastMeetingDetails(filter)
      .subscribe((response:any) => {
        if(response.body != undefined && response.body.data != undefined && response.body.data != null && response.body.data.length > 0){
          this.allpastmeetings = response.body.data;
          this.totalpastrecords = response.body.total_records;
          this.pastMeetingPageNo = page;
        } else {
          this.noPastMeeting = true;
        }

    },
    error => {
      console.log('error', error);
    });
  }

  /*
  *  The below function get the current date.
  */
  getCurrentDate() {
    let date = new Date();
    date.setDate(date.getDate());
    let todate = moment(date).format("YYYY-MM-DD");
    return todate;
  }

  /*
  *  The below function get the current date.
  */
  getTomorrowDate(data) {
    let meetingDate = moment(data).calendar();
    if (meetingDate.indexOf('Today') >-1) {
      return 'Today';
    } else if(meetingDate.indexOf('Tomorrow') > -1) {
      return 'Tomorrow';
    }else {
      return data;
    }
  }

  /*
  *  The below function call when click on delete meeting.
  */
  deleteMeetingData(obj){
    let meetingId = obj.meetingId
    let type = obj.type
    let pageIndex = obj.pageIndex

    this.allmeetings = [];
    this.showLoader = true;

    this._objMeetingService.deleteMeeting(meetingId, type)
    .subscribe((data : any) => {
        if(data.statusCode==200 && data.body.message!=""){
          pageIndex = type == 'Y' ? 1 : pageIndex;
          this.fetchMeetingsDetails(pageIndex);
        }
    },
    error => {
      console.log('error', error);
    });
  }

  /**
   * @description The below function will handle to show error msge when user try to join meeting from my meeting page
   * @param idx
   * @param msge
   */
  showValidationErrorMsg(idx: number, msge: string): void {
    if (idx !== undefined) {
      this.errorMsgeWrapper = document.querySelector('.meeting-validation-error_'+idx);
      if (this.errorMsgeWrapper !== null) {
        this.errorMsgeWrapper.innerText = msge;
        this._joinMeetingService.meetingValidationIndex = null;
        this.hideValidationErrorTimeoutId = setTimeout(() => {
          this.errorMsgeWrapper.innerText = "";
        }, 5000)
      }
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearInterval(this.retryFetchMeetingDetailsInterval);
    this.onStartReJoinListenerSubs.unsubscribe();
    this.onMeetingValidationAPIFailed.unsubscribe();
    clearTimeout(this.hideValidationErrorTimeoutId);
    if (this.errorMsgeWrapper) {
      this.errorMsgeWrapper.innerText = "";
    }
    clearTimeout(this.clearSetTimeOut);
  }

}
