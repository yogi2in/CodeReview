import { Component, OnInit, OnDestroy } from '@angular/core';
import { ConferencePageService } from '../conference-page-service.service';
import { JoinMeetignService } from '../../join-meeting/join-meeting.service';
import { LogService } from 'src/app/shared/logger/log.service';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-remote-peer-connection-stats',
  templateUrl: './remote-peer-connection-stats.component.html',
  styleUrls: ['./remote-peer-connection-stats.component.css']
})
export class RemotePeerConnectionStatsComponent implements OnInit, OnDestroy {
  private _remotePeersStateListenerSubs = new Subscription();

  private _remotePeersRTC: any = [];
  private _remoteStatsIntervalIds: any = {};
  public totalVideoBytesReceived = 0;
  public totalAudioBytesReceived = 0;
  public totalBitrateReceived = 0;
  public totalSentBitRate = 0;
  public previousVideoReceived: any = {};
  public previousAudeoReceived: any = {};
  public videoReceivedSpan: any;
  public audioReceivedSpan: any;
  public audioVideoIntervalId: any;
  public sendToServerIntervalId: any;
  public sendToServerIntervalTime = environment['SERVER_INTERVAL_FOR_BITRATE']
  public remoteCounter = 1;
  public totalPacketLost: any = {};
  public remoteUsersPacketLost = 0;
  public avgJitter: any = 0;;
  public maxJitter: any = 0;
  public remoteUsersJitters: any = {};
  constructor(
    private _confPageService: ConferencePageService,
    private _joinMeetingService: JoinMeetignService,
    private _logService: LogService
  ) { }

  ngOnInit(): void {
    this.videoReceivedSpan = document.querySelector('.total-bitrate-received');
    this.audioReceivedSpan = document.querySelector('.total-audio-received');
    this._remotePeersStateListenerSubs = this._confPageService.onInitRemotePeersStatsListener()
      .subscribe(
        (response: any) => {
          this.showRemoteBytesReceived();
          this.getRemoteConnectionStats(response.remotePeer.rtcPeer, response.remotePeerUserId)
        }
      )
      this._confPageService.onStopRemotePeerStatsListener().subscribe(
        (response: any) => {
          if (response !== undefined && response.remotePeerUserId !== undefined) {
            this.cancelInterval(response.remotePeerUserId);
          }
        }
      )

      this.audioVideoIntervalId = setInterval(() => {
        this.totalBitrateReceived = this.totalVideoBytesReceived + this.totalAudioBytesReceived;
        this._confPageService.totalBitRateReceivedPerSec = this.totalBitrateReceived - this._confPageService.prevTotalBitRateReceivedPerSec;
        this._confPageService.prevTotalBitRateReceivedPerSec = this.totalBitrateReceived;
        this._confPageService.totalBitRateReceived = this.totalBitrateReceived;
        this.totalSentBitRate = this._confPageService.totalBitrateSent;
        this._confPageService.remoteCounter = this.remoteCounter;
        this.updateMaxAvgJitters(this.remoteUsersJitters);
        this._confPageService.maxJitter = this.maxJitter;
        this._confPageService.avgJitter = this.avgJitter;
        // console.log('this.totalSentBitRate ', this.totalSentBitRate,  ' this.totalReceivedBitRate ', this.totalReceivedBitRate );
        // this.updateInnerHTML(this.videoReceivedSpan, this.convertToUnit(this.totalReceivedBitRate));
        // this.updateInnerHTML(this.audioReceivedSpan, this.convertToUnit(this.totalAudioBytesReceived));
      }, 1000);

  }

  getRemoteConnectionStats(remoteConnectionPeer: any, remotePeerUserId: any): void {
    this.previousVideoReceived[remotePeerUserId] = 0;
    this.previousAudeoReceived[remotePeerUserId] = 0;
    this._confPageService.remoteUsersPacketLost[remotePeerUserId] = {};
    this.remoteUsersJitters[remotePeerUserId] = {};
    this._remoteStatsIntervalIds[remotePeerUserId] = setInterval(() => {
      remoteConnectionPeer.getStats().then(result => {
        result.forEach(stats => {
          if (
            stats.type === 'inbound-rtp' &&
            (
              stats.id.indexOf('RTCInboundRTPVideoStream') > -1 ||
              stats.id.indexOf('inbound_rtp_video') > -1)
            ) {
              this.totalVideoBytesReceived = this.totalVideoBytesReceived + stats.bytesReceived - this.previousVideoReceived[remotePeerUserId];
              this.previousVideoReceived[remotePeerUserId] = stats.bytesReceived;
              this._confPageService.remoteUsersPacketLost[remotePeerUserId]["video"] = stats.packetsLost;
              this.remoteUsersJitters[remotePeerUserId]['videoJitter'] = stats.jitter !== undefined ? stats.jitter : 0;
          }
          if (
            stats.type === 'inbound-rtp' &&
            (stats.id.indexOf('RTCInboundRTPAudioStream') > -1 || stats.id.indexOf('inbound_rtp_audio') >-1)
          ) {
            this.totalAudioBytesReceived = this.totalAudioBytesReceived + stats.bytesReceived - this.previousAudeoReceived[remotePeerUserId];
            this.previousAudeoReceived[remotePeerUserId] = stats.bytesReceived;
            this._confPageService.remoteUsersPacketLost[remotePeerUserId]["audio"] = stats.packetsLost;
            this.remoteUsersJitters[remotePeerUserId]['audioJitter'] = stats.jitter !== undefined ? stats.jitter : 0;
          }
        })
      })
      ++this.remoteCounter;
    }, 1000);
  }

  showRemoteBytesReceived(): void {
    this.removeClass('.remote-video-received');
    this.removeClass('.remote-audio-received');
  }

  removeClass(selector: string) {
    let selectedElm = document.querySelector(selector);
    if (selectedElm !== null) {
      selectedElm.classList.remove('d-none');
    }
  }

  updateInnerHTML(selectedElm: any, innerHTML: any) {
    if (selectedElm !== null) {
      selectedElm.innerHTML = innerHTML;
    }
  }

  convertToUnit(bytes: any) {
    if (bytes === null || bytes === null || bytes === 0) {
      return 0 + '/kbps';
    }
    bytes = bytes/1024;
    if (bytes < 1024) {
      return bytes.toFixed(2) + '/kbps';
    } else {
      return (bytes/ 1024).toFixed(2) + '/mbps';
    }
  }

  cancelInterval(intervalId?: string):void {
    if (intervalId !== undefined && this._remoteStatsIntervalIds[intervalId] !== undefined) {
      clearInterval(this._remoteStatsIntervalIds[intervalId]);
    } else {

    }
  }
  clearAllIntervals() {
    let intervalIdsObject = Object.keys(this._remoteStatsIntervalIds);
    intervalIdsObject.map((id)=> {
      if (this._remoteStatsIntervalIds[id] !== undefined) {
        clearInterval(this._remoteStatsIntervalIds[id]);
      }
    })
  }

  updateMaxAvgJitters(remoteUserJitter: any): void {
    if (remoteUserJitter !== undefined) {
      let remoteUsersIds = Object.keys(remoteUserJitter);
      let totalJitter = 0;
      let totalUsers = remoteUsersIds.length;
      if (totalUsers > 0) {
        remoteUsersIds.forEach((userId) => {
          totalJitter = totalJitter + remoteUserJitter[userId]['videoJitter'] + remoteUserJitter[userId]['audioJitter'];
        })
        if (totalJitter > 0) {
          this.avgJitter = (totalJitter / totalUsers).toFixed(4);
          this.maxJitter = this.avgJitter > this.maxJitter ? this.avgJitter : this.maxJitter;
        }
      }

    }
  }

  ngOnDestroy(): void {
    clearInterval(this.audioVideoIntervalId);
    this.clearAllIntervals();
    this._remotePeersStateListenerSubs.unsubscribe();
    this._confPageService.remoteUsersPacketLost =  {};
    this._confPageService.avgJitter = 0;
    this._confPageService.maxJitter = 0;
  }

}
