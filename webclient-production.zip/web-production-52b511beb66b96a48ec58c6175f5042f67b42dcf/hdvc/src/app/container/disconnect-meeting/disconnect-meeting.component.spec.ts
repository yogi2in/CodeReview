import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisconnectMeetingComponent } from './disconnect-meeting.component';

describe('DisconnectMeetingComponent', () => {
  let component: DisconnectMeetingComponent;
  let fixture: ComponentFixture<DisconnectMeetingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisconnectMeetingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisconnectMeetingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
