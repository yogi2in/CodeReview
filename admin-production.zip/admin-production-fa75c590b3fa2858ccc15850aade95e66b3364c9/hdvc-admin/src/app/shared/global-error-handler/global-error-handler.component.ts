import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { RestApiService } from '../../_sharedService/restApi.service';
import { AuthService } from '../../auth/auth.service';
import { Route, Router } from '@angular/router';
import { Input } from '@angular/core';

@Component({
  selector: 'app-global-error-handler',
  templateUrl: './global-error-handler.component.html',
  styleUrls: ['./global-error-handler.component.css']
})
export class GlobalErrorHandlerComponent implements OnInit {
  private errorSubscription = new Subscription();
  errorMessage:string = null;
  successMessage:string = null;
  @Input() showMsg :string = null;
  constructor(private rest :RestApiService, private auth: AuthService, private router: Router, ) { }

  ngOnInit() {
    // Subscribe the Observables and change the router on schedule-meeting page
    this.errorSubscription = this.rest.errorProcessorListener()
    .subscribe(
      (response) => {
        console.log("response from=====",response)
        if (response.isError == false){
          if(response.successMsg != ""){
            this.successMessage = response.successMsg;
            return this.errorMessage = null;
        }
       }else{
        this.mapErrorAndDisplay(response.errorObj)
       } 
      },
      
    );
    // for permission denied error for other role of user
    this.errorSubscription = this.auth.authPermissionErrorListener()
    .subscribe(
      (errorResponse) => {
       if (errorResponse.isError == false) return this.errorMessage = null;
       this.mapErrorAndDisplay(errorResponse.errorObj)
      },
      
    );
  }

  public mapErrorAndDisplay(errorResponse){
    this.errorMessage = null;
    if(errorResponse.status == 500){
      this.errorMessage = "Internal Server Error";
    }else if(errorResponse.status == 404){
      this.errorMessage = "Page Not found";
      this.router.navigate(['customer']); // will change it once 404 page done
    }else if(errorResponse.status == 401){   //Unauthorize
      this.auth.logout();
      this.router.navigate(['']);
    }else if(errorResponse.message == 'UserLinkedToAnotherCustomer'){
      this.errorMessage = "This Email is already linked to another customer."
    }
    else{
      this.errorMessage = errorResponse.message;
    }

    this.FadeOutLink();
  }

  FadeOutLink() {
    setTimeout( () => {
          this.errorMessage = null;
        }, 3000);
   }

   
   
  }


