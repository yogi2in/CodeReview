import { Injectable } from '@angular/core';
import { HttpService} from 'src/app/shared/services/http.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  constructor(private httpService: HttpService) { }

  setPassword(dataParams)
  {
    const payload = {
      email:dataParams.email  //.replace("+", "%2B")
    }
    let urlsegment = 'password-forgot';
    if(dataParams["email-type"] != undefined){
      urlsegment = 'password-forgot?email-type='+'resend-set-password';
    }
    const param = {
      url : environment.BASE_URI_AUTH +urlsegment,
      body: payload
    }
    return this.httpService.post(param);
  }
}
