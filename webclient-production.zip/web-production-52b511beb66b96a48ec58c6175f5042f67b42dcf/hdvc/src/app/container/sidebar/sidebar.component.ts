import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../auth/auth.service';
import { UtilService } from '../../shared/services/utils.services';
import { Subscription } from 'rxjs';
import { UserService } from '../user/user.service';
declare var jQuery;


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  public showScheduleMeeting: boolean = false;
  public isLoggedIn: boolean = false;
  private headerSubscription = new Subscription();
  private signOutSubsctiption = new Subscription();
  public profilePicSubscription = new Subscription();
  public profileImage;
  public userName;
  public isCustomerAdmin: boolean = false;

  constructor(
    private authService: AuthService,
    private _utilService: UtilService,
    private _userService: UserService) { }

  ngOnInit() {
    this.headerSubscription = this.authService.showHeaderForLoginUserListner()
      .subscribe(
        (res) => {
          this.checkAuthToken();
        })
    //called on page load
    this.checkAuthToken();

    /*
  *  The below code will execute when user singOut form porfile page.
  */
    this.signOutSubsctiption = this.authService.isSignOutPage()
      .subscribe(
        (res) => {
          this.isLoggedIn = res.isLoggedIn;
        },
        (err) => {
          console.log("Header component page error", err);
        }
      )

    let userData = this._utilService.getInfoFromStorage('localStorage', 'currentUser');
    if(userData != undefined && userData != null){
      this.profileImage = userData.profileImage;
      this.userName = userData.customerName;
    }
    
    this.profilePicSubscription = this._userService.profilePicListener().subscribe(
      (res) => {
        this.profileImage = res.profilePic;
      }
    )

  }

  checkAuthToken() {
    if (this.authService.userExists()) { //method checking token and token expiry time
      this.isLoggedIn = true;
      const currentUser = this._utilService.getInfoFromStorage('local', 'currentUser'); // localStorage.getItem('currentUser');
      if (currentUser === null) {
        return;
      }
      this.isCustomerAdmin = currentUser["roleName"] == 'CUSTOMER_ADMIN' ? true :false;
      this.showScheduleMeeting = currentUser["isValidLicence"];
    } else {
      this.isLoggedIn = false;
      this.isCustomerAdmin = false;
      return;
    }
  }

  /*
  *  The below function show and hide the sidebar.
  */
  hideSidebar(){
    let windowWidth = window.outerWidth;
    if(windowWidth < 992) {
      jQuery('.sidebar-layout').toggleClass('active');
      jQuery('.tab-menu-bar').toggleClass('active');
    } else {
      return;
    }
  }

  tabUserDetails(evt){
    jQuery('.child-menu').toggleClass('active');
    jQuery('.user-profile-image').toggleClass('active');
  }

  signOut() {
    this.authService.signOut();
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.headerSubscription.unsubscribe();
    this.signOutSubsctiption.unsubscribe();
    this.profilePicSubscription.unsubscribe();
  }
}

