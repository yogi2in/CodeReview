import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterApiData'
})
export class FilterApiDataPipe implements PipeTransform {
  /*
  *  This below finction fiter data, if any value is null or undefined 
  *  that will be removed and provide the latest data with out null or undefined.
  */
 
  transform(value: any, args?: any): any {
    let filterDataArr = [];
    value.filter( (data)=>{
      if(data != null && data != undefined){
        filterDataArr.push(data);
      }
    })
    return filterDataArr;
  }

}
