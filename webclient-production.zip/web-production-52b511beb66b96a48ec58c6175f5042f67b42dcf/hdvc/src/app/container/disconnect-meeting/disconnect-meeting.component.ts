import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disconnect-meeting',
  templateUrl: './disconnect-meeting.component.html',
  styleUrls: ['./disconnect-meeting.component.css']
})
export class DisconnectMeetingComponent implements OnInit {
  public isLoggedIn: boolean = true;
  constructor() { }

  ngOnInit() {
    let userInfo = localStorage.getItem('currentUser');
    if (userInfo != undefined && userInfo != null) {
      this.isLoggedIn = false;
    }
  }

}
