import { Injectable } from '@angular/core';
import { Subject, ObservableLike } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PagingInfo } from 'src/app/container/conference/paging-info';
import { UtilService } from 'src/app/shared/services/utils.services';
import { JoinMeetignService } from '../join-meeting/join-meeting.service';
import { UserInfo } from './_models/user-info';

@Injectable({
  providedIn: 'root'
})
export class ConferencePageService {
  private _usersInfo: any = {};
  public hostName: string = "";
  public layoutTypeENUMS: any;
  private _localParticipant: any;
  private _allParticipants: any = {};
  private _updateAudioIconObs$ = new Subject<{userId: string, iconState: boolean}>();
  private _updateVideoIconObs$ = new Subject<{userId: string, iconState: boolean}>();
  private _updatePresenterIconIndicatorObs$ = new Subject<{participantId: string, visibleState: boolean}>();
  private _initLocalPeerStatsObs$ = new Subject<{localPeer: any}>();
  private _initRemotePeersStatsObs$ = new Subject<{remotePeer: any, remotePeerUserId: any}>();
  private _stopRemotePeerStatsObs$ = new Subject<{remotePeerUserId: string}>();
  private mostActiveUserObs$ = new Subject<{userId: string, userName: string, layoutType: string}>();
  private mostActiveUserDuringScreenShareObs$ = new Subject<{userId: string}>();
  private confPagingInfoObs$ = new Subject<{pagingInfo: PagingInfo}>();
  private fetchActiveParticpantsObs$ = new Subject<{pageNumber: number, layoutCount: number, layoutType: string}>();
  private redirectToJoinMeetingObs$ = new Subject();
  private notifyToPausedVideoObs$ = new Subject<{pausedVideo: boolean}>();
  private sentBandwidthUsageObs$ = new Subject<{
    totalBitrateSent: number,
    totalBitrateRecv: number,
    bitrateSentPerSec: any,
    bitrateRecvPerSec: any,
    minResolution: any,
    maxResolution: any
    localPacketLost: any,
    remotePacketLost: any,
    maxJitter: any,
    avgJitter: any}>();
  private notifyToRetryIceCandidateObs$ = new Subject();
  private notifyToShowReconnectLayoutObs$ = new Subject<{showReconnect: boolean, meetingInfo: any, delay: any, errorKey: string}>();
  private notifyToStartReJoinObs$ = new Subject<{reJoin: boolean, meetingInfo: any}>();
  private notifyAverageBytesSendRangeObs$ = new Subject<{newCheckPoint: any}>();
  private notifyBitrateChangeObs$ = new Subject<{selectedBandwidth: any, layoutType: any}>()
  private _mostActiveUserId: string;
  private _curPageMostActiveUsersArr: any;
  private _layoutType: string;
  public resetMostActiveUser: boolean = false;
  public isScreenShareStarted: boolean = false;
  public isWhiteBoardStarted: boolean = false;
  public totalBitrateSent = 0;
  public totalBitRateReceived = 0;
  public totalBitRateReceivedPerSec = 0;
  public prevTotalBitRateReceivedPerSec = 0;
  public remoteCounter = 0;
  public remoteUsersPacketLost: any = {};
  public maxJitter: any = 0;
  public avgJitter: any = 0;
  public isVideoPaused: boolean = false;
  public isSocketStateValid: boolean = true;
  public isBandwidthCheckEnable: boolean = true;

  constructor(
    private _utilService: UtilService,
    private _joinMeetingService: JoinMeetignService
  ) {
    this.layoutTypeENUMS = environment.LAYOUT_TYPE_ENUMS;
  }

  setLocalParticipant(participant: any): void {
    if (participant === undefined) {
      return;
    }
    this._localParticipant = participant;
  }

  getLocalParticipant() {
    if (this._localParticipant === undefined) {
      return null;
    }
    return this._localParticipant;
  }

  updateParticipants(participantId: string, participantObj: any): void {
    if (participantId === undefined || participantObj === undefined) {
      return;
    }

    this._allParticipants[participantId] = participantObj;
  }

  getParticipants(participantId?: string) {
    if (participantId === undefined) {
      return this._allParticipants;
    }

    if (this._allParticipants[participantId] !== undefined) {
      return this._allParticipants[participantId];
    } else {
      return null;
    }
  }

  // subsriber when participant start/stop audio/video share
  onUpdateAudioIconObsListener() {
    return this._updateAudioIconObs$.asObservable();
  }

  // observable when user change video control mute/unmute, stop/start video share
  updateAudioIconObs(userId: string, iconState: boolean) {
    if (userId === undefined || iconState === undefined) {
      return;
    }

    this._updateAudioIconObs$.next({userId: userId, iconState: iconState});
  }

  onUpdateVideoIconObsListener() {
    return this._updateVideoIconObs$.asObservable();
  }

  // observable when user change video control mute/unmute, stop/start video share
  updateVideoIconObs(userId: string,  iconState: boolean) {
    if (userId === undefined || iconState === undefined) {
      return;
    }
    this._updateVideoIconObs$.next({userId: userId, iconState: iconState});
  }



  updatePresenterIconIndicatorObs(participantId: string, visibleState: boolean) {
    if (participantId === undefined || typeof participantId !== 'string') {
      return;
    }
    this._updatePresenterIconIndicatorObs$.next(
      {
        participantId: participantId,
        visibleState: visibleState
      }
    )
  }

  updatePresenterIconIndicatorListener() {
    return this._updatePresenterIconIndicatorObs$.asObservable();
  }


  initLocalPeerStatsObs(localPeer: any) {
    if (localPeer === undefined) {
      return;
    }
    this._initLocalPeerStatsObs$.next({localPeer: localPeer});
  }

  onInitLocalPeerStatsListener() {
    return this._initLocalPeerStatsObs$.asObservable();
  }

  initRemotePeerConnectionsStatsObs(remotePeer: any, remotePeerUserId: string) {
    if (remotePeer === undefined) {
      return;
    }
    this._initRemotePeersStatsObs$.next({remotePeer: remotePeer, remotePeerUserId: remotePeerUserId});
  }

  onInitRemotePeersStatsListener() {
    return this._initRemotePeersStatsObs$.asObservable();
  }

  stopRemotePeerStatsObs(remotePeerUserId: string) {
    if (remotePeerUserId === undefined) {
      return;
    }
    this._stopRemotePeerStatsObs$.next({remotePeerUserId: remotePeerUserId});
  }

  onStopRemotePeerStatsListener() {
    return this._stopRemotePeerStatsObs$.asObservable();
  }

  notifyTotalBandwidthUsageObs(
      totalBitrateSent,
      totalBitrateRecv,
      localStatsCounter,
      remoteStatsCounter,
      minResolution,
      maxResolution,
      localPacketLost,
      remotePacketLost,
      maxJitter,
      avgJitter
    ) {
    totalBitrateSent = totalBitrateSent === undefined ? 0 : totalBitrateSent;
    totalBitrateRecv = totalBitrateRecv === undefined ? 0 : totalBitrateRecv;
    this.sentBandwidthUsageObs$.next(
      {
        totalBitrateSent: totalBitrateSent,
        totalBitrateRecv: totalBitrateRecv,
        bitrateSentPerSec: totalBitrateSent / localStatsCounter,
        bitrateRecvPerSec: totalBitrateRecv / remoteStatsCounter,
        minResolution: minResolution,
        maxResolution: maxResolution,
        localPacketLost: localPacketLost,
        remotePacketLost: remotePacketLost,
        maxJitter: maxJitter,
        avgJitter: avgJitter
      }
    );
  }

  totalBandwidthUsageListener() {
    return this.sentBandwidthUsageObs$.asObservable();
  }

  /**
   * @description This will notify most-active-user handler directive with user id
   * @param userId
   */
  notifyMostActiveUser(userId: string, userName: string, layoutType: string) {
    if (userId === undefined) {
      return;
    }
    layoutType = this.getLayoutType();
    this.mostActiveUserObs$.next(
      {
        userId: userId,
        userName: userName,
        layoutType: layoutType
      }
    );
  }

  /**
   * @description The listener for most active user
   */
  mostActiveUserListener() {
    return this.mostActiveUserObs$.asObservable();
  }

  mostActiveUserDuringScreenShare(userId: string) {
    this.mostActiveUserDuringScreenShareObs$.next({userId: userId});
  }

  mostActiveUserDuringScreenShareListener() {
    return this.mostActiveUserDuringScreenShareObs$.asObservable();
  }

  /**
   * @description The below observable will notify any update in the paging info details
   * @param pagingInfo
   */
  notifyPagingInfo$(pagingInfo: PagingInfo) {
    if (pagingInfo === undefined) {
      return;
    }
    this.confPagingInfoObs$.next({pagingInfo: pagingInfo});
  }

  pagingInfoListener() {
    return this.confPagingInfoObs$.asObservable();
  }

  fetchActiveParticipantList$(pageNumber: number, layoutCount: number, layoutType: string) {
    if (pageNumber === undefined || layoutCount === undefined) {
      return;
    }
    this.fetchActiveParticpantsObs$.next(
      {
        pageNumber: pageNumber,
        layoutCount: layoutCount,
        layoutType: layoutType
      }
    );
  }

  fetchActiveParticipantsListener() {
    return this.fetchActiveParticpantsObs$.asObservable();
  }

  notifyUserToRedreictToJoinMeeting() {
    this.redirectToJoinMeetingObs$.next();
  }

  redirectUserToJoinMeetingListener(){
    return this.redirectToJoinMeetingObs$.asObservable();
  }

  setMostActiveUserId(userId: string) {
    if (userId === undefined || userId === null) {
      return;
    }
    this._mostActiveUserId = userId;
  }

  getMostActiveUserId() {
    if (this._mostActiveUserId === undefined || this._mostActiveUserId === null) {
      return null;
    }
    return this._mostActiveUserId
  }

  setCurPageMostActiveUsersInfo(activeUsersArr: any) {
    if (activeUsersArr === undefined || activeUsersArr === null) {
      return;
    }
    this._curPageMostActiveUsersArr = activeUsersArr;
  }

  getCurPageMostActiveUsersInfo() {
    if (this._curPageMostActiveUsersArr === undefined || this._curPageMostActiveUsersArr === null) {
      return null;
    }
    return this._curPageMostActiveUsersArr;
  }

  setLayoutType(layoutType: string) {
    if (typeof layoutType === 'undefined') {
      return;
    }
    this._layoutType = layoutType;
    this._utilService.setInfoInStorage('local', 'layoutType', this._layoutType);
  }

  getLayoutType() {
    const layoutObj = this.layoutTypeENUMS;
    const defaultLayout = this._joinMeetingService.getMeetingConfig('default_layout');
    if (this.isScreenShareStarted || this.isWhiteBoardStarted) {
      return layoutObj[1];
    }

    if (window.innerWidth <= 991) {
      return layoutObj[2];
    }

    if (defaultLayout === null) {
      return layoutObj[1];
    }

    return  layoutObj[defaultLayout] !== undefined ? layoutObj[defaultLayout] : layoutObj[defaultLayout][2];
  }

  getThumbnailCount(layoutType: any) {
    let thumbnailCount = 4;
    let windowHeight = window.innerHeight;
    // if current layout is grid then return thumbnail 4
    if (layoutType === this.layoutTypeENUMS[2] && !this.isScreenShareStarted && !this.isWhiteBoardStarted) {
      return thumbnailCount;
    }
    // 161 is the height of any thumbnail in speaker layout
    thumbnailCount = windowHeight / 161;
    // from total of any thumbnail there is 5 more padding need to remove
    thumbnailCount = (windowHeight - ((thumbnailCount - 1) * 5)) /161;
    return Math.floor(thumbnailCount);
  }

  updateUserInfo(userId: string, userInfo?: UserInfo, keyName?: string, fieldValue?: any): void {
    if (userId === undefined || typeof userId !== 'string') {
      return;
    }
    if (keyName !== undefined && typeof keyName === 'string' && fieldValue !== undefined && this._usersInfo[userId] !== undefined) {
      this._usersInfo[userId][keyName] = fieldValue;
    }
    this._usersInfo[userId] = userInfo;
  }

  getUserInfo (userId: string, keyName?: string): UserInfo {
    if (keyName !== undefined && typeof keyName === 'string') {
      if (this._usersInfo[userId][keyName] !== undefined) {
        return this._usersInfo[userId][keyName];
      }
    }
    return this._usersInfo[userId];
  }

  removeUserFromUserInfo(userId?: string): void {
    if (userId === undefined || typeof userId !== 'string') {
      this._usersInfo = {};
    }
    if (this._usersInfo[userId] !== undefined) {
      delete this._usersInfo[userId];
    }
  }

  notifyToPausedVideoObs(pausedState: boolean) {
    if (pausedState !== undefined) {
      this.notifyToPausedVideoObs$.next({pausedVideo: pausedState})
    }
  }

  onPausedVideosListener() {
    return this.notifyToPausedVideoObs$.asObservable();
  }

  notifyToRetryIceCandidateObs() {
    this.notifyToRetryIceCandidateObs$.next();
  }

  onNotifyToRetryIceCandidateListener() {
    return this.notifyToRetryIceCandidateObs$.asObservable();
  }


  notifyToShowReconnectLayoutObs(showReconnect: boolean, meetingInfo: any, delay: any, errorKey: string) {
    this.notifyToShowReconnectLayoutObs$.next({showReconnect: showReconnect, meetingInfo: meetingInfo, delay: delay, errorKey: errorKey});
  }

  onShowReconnectListener() {
    return this.notifyToShowReconnectLayoutObs$.asObservable();
  }

  notifyToStartReJoinObs(reJoinState: boolean, meetingInfo: any) {
    this.notifyToStartReJoinObs$.next({reJoin: reJoinState, meetingInfo: meetingInfo})
  }

  onStartReJoinListener() {
    return this.notifyToStartReJoinObs$.asObservable();
  }

  notifyAverageBytesSendRangeObs(newCheckPointRange) {
    this.notifyAverageBytesSendRangeObs$.next({newCheckPoint: newCheckPointRange});
  }

  notifyAverageBytesSendRange() {
    return this.notifyAverageBytesSendRangeObs$.asObservable();
  }

  notifyBitrateChangeObs(selectedBandwidth: any, layoutType: any) {
    this.notifyBitrateChangeObs$.next(
      {
        selectedBandwidth: selectedBandwidth, 
        layoutType: layoutType
      }
    );
  }

  onBitrateChange() {
    return this.notifyBitrateChangeObs$.asObservable();
  }

}
