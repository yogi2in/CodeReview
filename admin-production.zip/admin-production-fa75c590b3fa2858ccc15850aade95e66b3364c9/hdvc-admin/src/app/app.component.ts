import { Component, Renderer2, Output } from '@angular/core';
import { AuthService } from './auth/auth.service';
import { GlobalErrorHandlerComponent } from './shared/global-error-handler/global-error-handler.component';
import { HttpRequest } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
import { LocalStorageService } from 'angular-2-local-storage';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // public bodyElem: any;
  public sideNavWidth: any = 0;
  public isLoginPage = false;
  isLoggedInUser = false;
  public bodyElem = document.getElementsByTagName('body')[0];
  public hideLoader = true;
  private authSubscription = new Subscription();
  @Output() public collapseMenu = true;

  constructor(
    private authService: AuthService,
    private render: Renderer2,
    private cookieService: CookieService,
    private localStorageService: LocalStorageService
  ) { }

  ngOnInit(): void {
    /*
    * The below code add a class in body.
    */
    //this.bodyElem = document.getElementsByTagName('body')[0];
    this.render.addClass(this.bodyElem, 'login-page-bg');

    this.authSubscription = this.authService.authProcessListener()
      .subscribe(
        (res) => {
          if (res.isSuccess === true) {
            this.hideLoader = true;
            this.hideLoaderData();
          } else {
            this.hideLoader = true;
            this.hideLoaderData();
          }
        }
      );

  }

  //
  ngAfterContentInit() {
    this.hideLoaderData();
  }

  isLoggedIn() {
    let token = this.authService.getToken();
    let isAfter = this.authService.checkTokenExpiryTime(this.localStorageService.get('tokenExpirationTime'))
    if (token && token != null && token != undefined && isAfter == false) {
      this.isLoggedInUser = true;
      return true;
    } else {
      this.isLoggedInUser = false;
      // this.authService.logout();
      return false;
    }
  }

  /*
  * Show / hide the sidebar.
  */
  isSideBar(data) {
    let windowWidth = window.outerWidth;
    if (windowWidth < 992) {
      setTimeout(() => {
        if (data === undefined || data === null) {
          this.sideNavWidth = 0;
          this.render.removeClass(this.bodyElem, 'sidebar-collapsed');
          this.render.removeClass(this.bodyElem, 'sidebar-now-visiable');
          this.collapseMenu = true;
        } else if (data) {
          this.sideNavWidth = 250;
          this.render.removeClass(this.bodyElem, 'sidebar-collapsed');
          this.render.addClass(this.bodyElem, 'sidebar-now-visiable');
          this.collapseMenu = false;
        } else {
          this.sideNavWidth = 0;
          this.render.removeClass(this.bodyElem, 'sidebar-now-visiable');
          this.render.addClass(this.bodyElem, 'sidebar-collapsed');
          this.collapseMenu = true;
        }
      }, 100);
    } else {
      this.sideNavWidth = 250;
    }
  }


  // ngOnInit(): void {
  //   /*
  //   * The below code add a class in body.
  //   */
  //  //this.bodyElem = document.getElementsByTagName('body')[0];
  //  this.render.addClass(this.bodyElem, 'login-page-bg');

  //  this.authSubscription = this.authService.authProcessListener()
  //   .subscribe(
  //     (res) => {
  //       if (res.isSuccess === true) {
  //         this.hideLoader = true;
  //         this.hideLoaderData();
  //       } else {
  //         this.hideLoader = true;
  //         this.hideLoaderData();
  //       }
  //     }
  //   );

  // }
  // ngAfterContentInit() {
  //   this.hideLoaderData();
  // }

  hideLoaderData() {
    setTimeout(() => {
      this.hideLoader = false;
    }, 2000);
  }

  // Destory the subscription.
  ngOnDestroy(): void {
    this.authSubscription.unsubscribe();
  }
}
