import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './auth/login/login.component';
import { ScheduleMeetingComponent } from './container/schedule-meeting/schedule-meeting.component';
import { JoinMeetingComponent } from './container/join-meeting/join-meeting.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ConferenceComponent } from './container/conference/conference.component';
import { MyProfileComponent } from './container/user/my-profile/my-profile.component';
import { MyMeetingsComponent } from './container/my-meetings/my-meetings.component';
import { ForgotPasswordComponent } from './container/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './container/reset-password/reset-password.component';
import { SettingsComponent } from './container/settings/settings.component';
import { MeetingHistoryComponent } from './container/user/meeting-history/meeting-history.component';
import { UserComponent } from './container/user/user.component';
import { EditProfileComponent } from './container/user/edit-profile/edit-profile.component';
import { AuthGuard } from './auth/auth.guard';
import { PermissionGuard } from './shared/guards/permission.guard';
import { AuthLoggedInGuard } from './auth/auth.loggedin.guard';
import { MeetingEndComponent } from './container/meeting-end/meeting-end.component';
import { LicenceManagementComponent } from './container/licence-management/licence-management.component';
import { LicenceUserManagementComponent } from './container/licence-user-management/licence-user-management.component';
import { ChangePasswordComponent } from './container/user/change-password/change-password.component';
import { ReportsComponent } from './container/reports/reports.component';
import { DesktopAppDownloadComponent } from './container/desktop-app-download/desktop-app-download.component';
import { DeepLinkComponent } from './container/deep-link/deep-link.component';
import { DeviceSettingComponent } from './container/device-setting/device-setting.component';
import { DisconnectMeetingComponent } from './container/disconnect-meeting/disconnect-meeting.component';

const routes: Routes = [
  {
    path: 'login',
    canActivate: [AuthGuard],
    component: LoginComponent
  },
  {
    path: 'schedule-meeting',
    canActivate: [AuthLoggedInGuard, PermissionGuard],
    component: ScheduleMeetingComponent
  },
  {
    path: 'edit-meeting/:meetingId',
    canActivate: [AuthLoggedInGuard],
    component: ScheduleMeetingComponent
  },
  {
    path: 'device-settings',
    component: DeviceSettingComponent
  },
  {
    path: 'join-meeting/:meetingId',
    component: JoinMeetingComponent
  },

  {
    path: 'join-meeting',
    component: JoinMeetingComponent
  },
  {
    path: 'conference',
    component: ConferenceComponent
  },
  {
    path: 'user',
    canActivate: [AuthLoggedInGuard],
    component: UserComponent,
    children: [
      {
        path: 'my-profile',
        canActivate: [AuthLoggedInGuard],
        component: MyProfileComponent
      },
      {
        path: 'edit-profile',
        component: EditProfileComponent
      },
      {
        path: 'change-password',
        component: ChangePasswordComponent
      },
      // {
      //     path: 'meeting-history',
      //     component: MeetingHistoryComponent
      // }
    ]
  },
  {
    path: 'my-meetings',
    canActivate: [AuthLoggedInGuard],
    component: MyMeetingsComponent
  },
  {
    path: 'download-meeting-app/:section/:mid/:name',
    // canActivate: [AuthLoggedInGuard],
    component: DesktopAppDownloadComponent
  },
  {
    path: 'licence-management',
    canActivate: [AuthLoggedInGuard],
    component: LicenceManagementComponent
  },
  {
    path: 'licence-user-list/:lotId',
    canActivate: [AuthLoggedInGuard],
    component: LicenceUserManagementComponent
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent
  },
  {
    path: 'set-password/:emailToken',
    component: ResetPasswordComponent
  },
  {
    path: 'settings',
    canActivate: [AuthLoggedInGuard],
    component: SettingsComponent
  },
  {
    path: 'meeting-ended',
    //canActivate: [AuthLoggedInGuard],
    component: MeetingEndComponent
  },
  {
    path: 'meeting-disconnect',
    //canActivate: [AuthLoggedInGuard],
    component: DisconnectMeetingComponent
  },
  {
    path: 'reports',
    canActivate: [AuthLoggedInGuard],
    component: ReportsComponent
  },
  {
    path: 'deep-link/:meetingId',
    component: DeepLinkComponent
  },
  {
    path: '',
    redirectTo: 'schedule-meeting',
    pathMatch: 'full'
  },
  {
    path: '**',
    component: PageNotFoundComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { useHash: false })
  ],
  declarations: [
    // LoginComponent,
    // ScheduleMeetingComponent,
    // JoinMeetingComponent,
    // PageNotFoundComponent,
    // ConferenceComponent
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
