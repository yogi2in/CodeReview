// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  ENVIRONMENT_TYPE: 'DEV',
  production: false,
  SOCKET_URL: "wss://hdvc.impressicocrm.com:5501/groupcall", //"wss://voicewss.truringsoftek.co.in:5501/groupcall", //
  BASE_URL: "https://hdvc.impressicocrm.com",
  BASE_URI: "https://nk0s7odd60.execute-api.us-east-1.amazonaws.com/Panasonic-UCC/",
  BASE_URI_AUTH: "https://hdvcserver.impressicocrm.com/api/",
  DAFAULT_MAX_PARTICIPANTS: 200,
  MAX_PARTICIPANTS: 199,
  HOST: "https://hdvc.impressicocrm.com",
  PAGE_SIZE: 10,
  HEARTBEAT_INTERVAL:5000,
  LAYOUT_TYPE_ENUMS: {
    "1": "SPEAKER_VIEW",
    "2": "GRID_VIEW"
  },
  DESKTOP_ENABLED: true,
  WIN_DESKTOP_APP_PATH:"https://hdvc.impressicocrm.com/windows/panasonic.exe",
  LIN_DESKTOP_APP_PATH:"https://hdvc.impressicocrm.com/linux/panasonic",
  MAC_DESKTOP_APP_PATH:"https://hdvc.impressicocrm.com/mac/panasonic.dmg",
  CONFERENNCE_USER_GUID: "https://drive.google.com/file/d/1hXRDIVj79399DK-jxM2ynKzDvjg8GOWj/view?usp=sharing",
  CUSTOMER_USER_GUIDE: "https://drive.google.com/file/d/1KUWY6_4IQOMyoOeZWRIiR2kF0PYhyjOn/view?usp=sharing",
  LOG_LEVEL: [1, 3], // All = 0,   Debug = 1,  Info = 2,  Warn = 3,  Error = 4,  Fatal = 5,  Off = 6
  LOG_TYPE: [0], // 0 - console, 1 - localstorage , 2 - send to api
  WHITEBOARD_IFRAME_URL: "https://hdvc.impressicocrm.com/whiteboard",
  ADAPTIVE_VIEW: true,
  MIN_GRID_VIEW: 9,
  MAX_GRID_VIEW: 16,
  CURRENT_BANDWIDTH_USAGE_API_INTERVAL: 30000,
  LOCAL_STATS_CHECK_LOOP_COUNTER: 5,
  AVERAGE_BYTES_SENT_CHECK: 80,
  AVERAGE_BANDWIDTH_CHECK_COUNTER: 10,
  H264_CODEC: true,
  H264_ALL_PEER: false,
  USE_EXTENSION_FOR_SCREEN_SHARE: true,
  CONFIG_FROM_SESSION_STORAGE: true,
  USER_TYPE: 'WEB',
  ENABLED_DEVICE_SETTINGS: true
};

// "https://hdvc.impressicocrm.com/whiteboard",

export enum Enums {
  ACTIVE = "Active",
  NOT_STARTED = "Not Started",
  EXPIRED = "Expired",
  EXPIRING_SOON = "Expiring Soon",
  DELETED = "Deleted",
}

/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
