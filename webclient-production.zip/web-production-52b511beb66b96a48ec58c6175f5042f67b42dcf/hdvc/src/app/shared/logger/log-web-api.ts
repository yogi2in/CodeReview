import { LogPublisher } from "./log-publisher";
import { HttpClient } from "@angular/common/http";
import { LogEntry } from "./log.entry.class";
import { LogLocalStorage } from "./log-local-storage"
import { Observable, of, from } from "rxjs";

import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

export class LogWebApi extends LogPublisher {
  webApiLogEntry: any[] = [];

  constructor(private http: HttpClient) {
    // Must call super from derive4d classes
    super();
    this.location = `${environment.BASE_URI}device-logs`;
  }

  // Add log entry to back edn data store
  log(entry: LogEntry): Observable<any> {
    let headers = { headers: new Headers({'Content-Type': 'application/json'})};

    console.log('LogEntry ', entry);
    if (entry.level == 4) {
      this.handleApiForLogging(entry)
    }

    if (this.webApiLogEntry !== undefined && this.webApiLogEntry.length < 10) {

      this.webApiLogEntry.push(entry);
    } else if(this.webApiLogEntry.length >=10){
      // console.log("Now Send The Log As It Is More Than 10 Entry: ", this.webApiLogEntry)
      
      this.webApiLogEntry=[]
    }
    let localStorageLog = JSON.parse(localStorage.getItem(new LogLocalStorage().location)) || [];
    if (localStorageLog.length >= 10) {
      this.handleApiForLogging(localStorageLog)
      new LogLocalStorage().clear()
    }
    return of(true);
    // return this.http.post(this.location, entry)
    //   .map(response => response.json())
    //   .catch(this.handleErros);
  }

  clear(): Observable<boolean> {
    return of(true);
  }

  private handleApiForLogging = (logs) => {
    console.log("Logging: ", logs)
    this.http.post<any>(this.location, logs)
      .pipe(map(res => {
        console.log("LoggingRes: ", res)
      }));
  }

  //private methods
  private handleErros(error: any): Observable<any> {
    let errors: string[] = [];
    let msg: string = "";

    msg = "Status: " + error.status;
    msg += " - Status Text: " + error.statusText();

    if (error.json()) {
      msg += " - Exception Message: " + error.json().exceptionMessage;
    }

    error.push(msg);
    console.log('An Error Occured: ', errors);
    return Observable.throw(errors);
  }
}
