import { Injectable, OnInit } from '@angular/core';
import { Subject, config, Observable } from 'rxjs';
import { Router } from '@angular/router';
import { UtilService } from 'src/app/shared/services/utils.services';
import { SocketService } from 'src/app/shared/services/socket.service';
import { HttpService } from 'src/app/shared/services/http.service';
import { environment } from 'src/environments/environment';
import { PagingInfo } from 'src/app/container/conference/paging-info';
import { type } from 'os';


@Injectable({
  providedIn: 'root'
})
export class JoinMeetignService implements OnInit {
  private participantInfo: any;
  private meetingProcess = new Subject<{ isMeetingSuccess: boolean, data: any }>();
  private connectionLostMessage: string = '';
  private socketInstance: any;
  private exisUsrInfo: any;
  private _meetingConfig: any; // = MeetingCconfig;
  private validationAPIRetryCounter: number = 0;
  public isUserClickJoinButton: boolean = false;
  public isValidateThroughRejoin: boolean = false;
  public isAutoValidate: boolean = false;
  private socketInstanceObs$ = new Subject<{ status: boolean, msg: string }>();
  private isMeetingValidObs$ = new Subject<{ status: boolean, msg: string }>();
  private notifyValidationSuccessfullObs$ = new Subject<{ validate: boolean }>();
  public meetingValidationIndex: any = null;
  public videoConstraints: any = {
    "128_bitrate": {
      frameRate: {
        min: 6,
        max: 15
      },
      width: {
        min: 100,
        max: 176
      },
      height: {
        min: 90,
        max: 99
      }
    },
    "256_bitrate": {
      frameRate: {
        min: 25,
        max: 35
      },
      width: {
        min: 300, 
        max: 720
      }, 
      height: {
        min: 200, 
        max: 500
      }
      // mandatory: {
      //   "minWidth": 300,
      //   "maxWidth": 720,
      //   "minHeight": 200,
      //   "maxHeight": 502,
      //   "minFrameRate": 25
      // }
      // frameRate: {
      //   min: 15,
      //   max:20
      // },

      // width: {exact: 480}, height: {exact: 360}
      // width: {exact: 360}, height: {exact: 270}
      // width: {
      //   min: 300,
      //   max: 720
      // },
      // height: {
      //   min: 200,
      //   max: 540
      // }
    },
    "512_bitrate": {
      width: { exact: 1280 }, height: { exact: 720 }
      // frameRate: {
      //   min: 25,
      //   max:30
      // },
      // width: {
      //   min: 300,
      //   max: 1280
      // },
      // height: {
      //   min: 200,
      //   max: 720
      // }
    }
  }

  public videoConstraintsForFireFox: any = {
    "128_bitrate": {
      frameRate: {
        min: 6,
        max: 30
      },
      width: {
        min: 100,
        max: 176
      },
      height: {
        min: 90,
        max: 99
      }
    },
    "256_bitrate": {
      frameRate: {
        min: 25,
        max: 35
      },
      width: {
        min: 300, 
        max: 720
      }, 
      height: {
        min: 200, 
        max: 500
      }
    },
    "512_bitrate": {
      width: { exact: 1280 }, height: { exact: 720 }
      // frameRate: {
      //   min: 25,
      //   max:45
      // },
      // width: {
      //   min: 1280,
      //   max: 1280
      // },
      // height: {
      //   min: 200,
      //   max: 720
      // }
    }
  }

  public layoutTypeENUMS: any;
  public curMeetingInfo: any = {};
  private _isDeviceSettingsEnable: boolean;
  private clearSetTimeOut;

  constructor(private _router: Router,
    private _utilService: UtilService,
    private _socketService: SocketService,
    private httpService: HttpService) {
    this.layoutTypeENUMS = environment.LAYOUT_TYPE_ENUMS;
    this._isDeviceSettingsEnable = this._utilService.getEnvironmentValue('ENABLED_DEVICE_SETTINGS');
  }

  ngOnInit() { 
    
  }

  initSocketConnection() {
    this.socketInstance = this._socketService.getSocketInstance();
    this.socketInstance.onmessage = this.msgHandler.bind(this);
    this.socketInstance.onopen = this.onConnectionOpenHandler.bind(this);
    this.socketInstance.onerror = this.onConnectionErrorHandler.bind(this);
  }

  onConnectionErrorHandler() {
    this.isMeetingValidObs$.next({
      status: false,
      msg: 'Oops! something went wrong.'
    });
  }

  // Creating the custom Observable.
  meetingSuccessListener() {
    return this.meetingProcess.asObservable();
  }

  socketConnectionListener() {
    this.socketInstanceObs$.asObservable();
  }

  onConnectionOpenHandler(msg) {
    if (msg !== undefined && msg.type !== undefined && msg.type === 'open') {
      this.socketInstanceObs$.next({
        status: true,
        msg: 'Socket Connected'
      });
    }
  }

  onMeetingIDValidation() {
    return this.isMeetingValidObs$.asObservable();
  }

  msgHandler(msg) {
    const parsedMessage = JSON.parse(msg.data);
    // console.log("parsedMessageparsedMessage", parsedMessage);
    switch (parsedMessage.rsp) {
      // case 'joinMeetingRoom':
      //   if (parsedMessage.status === false) {
      //     this.isMeetingValidObs$.next({
      //       status: false,
      //       msg: 'Invalid meeting ID!'
      //     });
      //   }
      //   break;
      case 'exisUsr':

        break;
      default:
        this.socketInstance.close();
        break;
    }
  }

  // Post the meeting details.
  validateMeeting(
    meetingId: any,
    MeetingOwnerEmailId: string,
    userName: string,
    reqFrom: string,
    redirect?: boolean
  ) {

    const participantInfo = {
      meeting_refid: meetingId,
      email_id: MeetingOwnerEmailId
    };

    this.curMeetingInfo = participantInfo;

    const param = {
      url: environment.BASE_URI + "meeting/validate_meeting",
      body: participantInfo
    };

    this.httpService.post(param)
      .subscribe((response: any) => {
        if (response.body !== undefined && response.body.message == "" && response.body.url !== undefined) {
          this.validationAPIRetryCounter = 0;
          let meetingConfig = response.body;
          if (!environment.production) {
            meetingConfig.url = environment.SOCKET_URL;
          }

          this.setMeetingConfig(meetingConfig);
          if (environment.production) {
            this._utilService.setInfoInStorage('localStorage', 'socketUrl', response.body.url);
          }
          else {
            this._utilService.setInfoInStorage('localStorage', 'socketUrl', environment.SOCKET_URL);
          }

          this._utilService.setInfoInStorage('localStorage', 'is_owner', response.body.is_owner);
          this._utilService.setInfoInStorage('localStorage', 'kip', response.body.kip);
          this._utilService.setInfoInStorage('localStorage', 'jip', response.body.jip);

          const participantInfo = {
            meetingId: meetingId,
            userName: userName
          };
          this._utilService.setInfoInStorage('session', 'participantInfo', participantInfo);
          if (redirect === undefined) {
            if (this._utilService.isMobile() || this._utilService.checkIsDesktopApp()) {
              //this._router.navigate(['/conference'])
              if (this.isValidateThroughRejoin) {
                this._router.navigate(['/conference']);
                this.isValidateThroughRejoin = false;
              } else {
                if (this._isDeviceSettingsEnable) {
                  this._router.navigate(['/device-settings']);
                } else {
                  this._router.navigate(['/conference']);
                }
                // this._router.navigate(['/device-settings']);
              } 
              
              this.notifyValidationSuccessfullObs(false)
            }
            else {
              if (!this._utilService.isAppDownloadEnabled()) {
                //this._router.navigate(['/conference'])
                if (this.isValidateThroughRejoin) {
                  this._router.navigate(['/conference']);
                  this.isValidateThroughRejoin = false;
                } else {
                  if (this._isDeviceSettingsEnable) {
                    this._router.navigate(['/device-settings']);
                  } else {
                    this._router.navigate(['/conference']);
                  }
                } 
                this.notifyValidationSuccessfullObs(false)
              }
              else {
                reqFrom = (reqFrom != "") ? reqFrom : "JOIN-MEETING"
                this._router.navigate(['/download-meeting-app', reqFrom, meetingId, userName])
                this.notifyValidationSuccessfullObs(true)
              }
            }
            /*
            this._router.navigate(['/conference']);
            this.notifyValidationSuccessfullObs(false);
            */
          } else {
            this.notifyValidationSuccessfullObs(true);
          }
          //this.initSocketConnection();
          //this.joinMeeting(meetingId, userName);
        }
        else {
          if (
            response.body !== undefined &&
            response.body.url === undefined &&
            response.body.message.length > 1
          ) {
            this.isMeetingValidObs$.next({
              status: false,
              msg: response.body.message
            });
          } else {
            this.isMeetingValidObs$.next({
              status: false,
              msg: response.body == undefined || response.body.url === undefined ? "Unable to contact server at this time. Please check internet connectivity & try again." : response.body.message
            });
          }
        }
      },
        error => {
          if (this.isAutoValidate === true) {
            this.isMeetingValidObs$.next({
              status: false,
              msg: 'Unable to reconnect. Please try later.'
            });
          } else {
            this.isMeetingValidObs$.next({
              status: false,
              msg: 'Unable to contact server at this time. Please check internet connectivity & try again.'
            });
          }

          // if (redirect === undefined) {
          //   this.isMeetingValidObs$.next({
          //     status: false,
          //     msg: 'We could not find the resource you requested! Please try again.'
          //   });
          //   // this._router.navigate(['/conference']);
          // } else {
          //   this.isMeetingValidObs$.next({
          //     status: false,
          //     msg: 'Unable to connect server at this time. Please check internet connection & try again.'
          //   });
          //   // this.notifyValidationSuccessfullObs(false);
          // }
        });
    // this.httpService.post(param)
    //   .subscribe((response: any) => {
    //     if (response.body !== undefined && response.body.message == "" && response.body.url !== undefined) {
    //       this.validationAPIRetryCounter = 0;
    //       let meetingConfig = response.body;
    //       if (!environment.production) {
    //         meetingConfig.url = environment.SOCKET_URL;
    //       }

    //     this._utilService.setInfoInStorage('localStorage', 'is_owner', response.body.is_owner);
    //     this._utilService.setInfoInStorage('localStorage', 'kip', response.body.kip);
    //     this._utilService.setInfoInStorage('localStorage', 'jip', response.body.jip);

    //     const participantInfo = {
    //       meetingId: meetingId,
    //       userName: userName
    //     };
    //     this._utilService.setInfoInStorage('session', 'participantInfo', participantInfo);
    //     if (redirect === undefined) {
    //       if (this._utilService.isMobile() || this._utilService.checkIsDesktopApp()) {
    //         this._router.navigate(['/device-settings']);
    //         // this._router.navigate(['/conference'])
    //         this.notifyValidationSuccessfullObs(false)
    //       }
    //       else {
    //         if (!this._utilService.isAppDownloadEnabled()) {
    //           // this._router.navigate(['/conference'])
    //           this._router.navigate(['/device-settings']);
    //           this.notifyValidationSuccessfullObs(false)
    //         }
    //         else {
    //           if (!this._utilService.isAppDownloadEnabled()) {
    //             this._router.navigate(['/conference'])
    //             this.notifyValidationSuccessfullObs(false)
    //           }
    //           else {
    //             reqFrom = (reqFrom != "") ? reqFrom : "JOIN-MEETING"
    //             this._router.navigate(['/download-meeting-app', reqFrom, meetingId, userName])
    //             this.notifyValidationSuccessfullObs(true)
    //           }
    //         }
    //         /*
    //         this._router.navigate(['/conference']);
    //         this.notifyValidationSuccessfullObs(false);
    //         */
    //       } 
    //     }else {
    //         this.notifyValidationSuccessfullObs(true);
    //       }
    //       //this.initSocketConnection();
    //       //this.joinMeeting(meetingId, userName);
    //     }
    //     else {
    //       if (
    //         response.body !== undefined &&
    //         response.body.url === undefined &&
    //         response.body.message.length > 1
    //       ) {
    //         this.isMeetingValidObs$.next({
    //           status: false,
    //           msg: response.body.message
    //         });
    //       } else {
    //         this.isMeetingValidObs$.next({
    //           status: false,
    //           msg: response.body == undefined || response.body.url === undefined ? "Unable to contact server at this time. Please check internet connectivity & try again." : response.body.message
    //         });
    //       }
    //     }
    //   },
    //     error => {
    //       if (this.isAutoValidate === true) {
    //         this.isMeetingValidObs$.next({
    //           status: false,
    //           msg: 'Unable to reconnect. Please try later.'
    //         });
    //       } else {
    //         this.isMeetingValidObs$.next({
    //           status: false,
    //           msg: 'Unable to contact server at this time. Please check internet connectivity & try again.'
    //         });
    //       }

    //       // if (redirect === undefined) {
    //       //   this.isMeetingValidObs$.next({
    //       //     status: false,
    //       //     msg: 'We could not find the resource you requested! Please try again.'
    //       //   });
    //       //   // this._router.navigate(['/conference']);
    //       // } else {
    //       //   this.isMeetingValidObs$.next({
    //       //     status: false,
    //       //     msg: 'Unable to connect server at this time. Please check internet connection & try again.'
    //       //   });
    //       //   // this.notifyValidationSuccessfullObs(false);
    //       // }
    //     });
  }

  // Post the meeting details.
  joinMeeting(meetingId: any, userName: string) {
    const participantInfo = {
      meetingId: meetingId,
      userName: userName
    };

    const jip = this._utilService.getInfoFromStorage('local', 'jip');
    const kip = this._utilService.getInfoFromStorage('local', 'kip');
    const joinMeetingPayLoad = {
      'req': 'joinMeetingRoom',
      'user': userName,
      'roomID': meetingId,
      'jip': jip,
      'kip': kip
    };
    clearTimeout(this.clearSetTimeOut);
    this.clearSetTimeOut = setTimeout(() => {
      if (this.socketInstance !== undefined && this.socketInstance !== null && this.socketInstance.readyState === 1) {
        this.participantInfo = participantInfo;
        this.socketInstance.send(
          JSON.stringify(joinMeetingPayLoad)
        );
      }
    }, 1000);
  }

  getExistUserInfo() {
    return this.exisUsrInfo;
  }

  resetExistUserInfo() {
    if (this.exisUsrInfo !== undefined) {
      delete this.exisUsrInfo;
    }
  }

  setConnectionLostMessage(connectionMsge?: any) {
    if (connectionMsge !== undefined && connectionMsge.length > 1) {
      this.connectionLostMessage = connectionMsge;
    }
  }

  getConnectionLostMessage() {
    if (this.connectionLostMessage === undefined || this.connectionLostMessage.length < 1) {
      return '';
    }
    return this.connectionLostMessage;
  }

  resetConnectionLostMessage() {
    this.connectionLostMessage = '';
  }

  getMediaConstraints(browserType: string) {
    return (browserType !== undefined && browserType === 'firefox') ? this.videoConstraintsForFireFox : this.videoConstraints;
  }

  /**
   * CODE MORE MEETING CONFIG START HERE
   */

  setMeetingConfig(meetingConfig: any) {
    if (meetingConfig === undefined) {
      return;
    }

    this._meetingConfig = meetingConfig;
    this._utilService.setInfoInStorage('session', 'meeting_config', this._meetingConfig);
  }

  updateMeetingConfig(fieldName: string, fieldValue: any) {
    let meetingConfig = this.getMeetingConfig();
    if (meetingConfig !== null && meetingConfig[fieldName] !== undefined) {
      meetingConfig[fieldName] = fieldValue;
      this.setMeetingConfig(meetingConfig);
    }
  }

  getMeetingConfig(configKey?: string) {
    let meetingInfo: any;
    meetingInfo = this._meetingConfig !== undefined ? this._meetingConfig : null;

    if (meetingInfo === null) {
      meetingInfo = this._utilService.getInfoFromStorage('session', 'meeting_config');
    }

    if (meetingInfo === null) {
      return null;
    } else {
      if (configKey !== undefined && meetingInfo[configKey] !== undefined) {
        return meetingInfo[configKey];
      } else {
        return meetingInfo;
      }
    }
  }

  notifyValidationSuccessfullObs(validationState: boolean): void {
    this.notifyValidationSuccessfullObs$.next({ validate: validationState });
  }

  meetingValidationListenner() {
    return this.notifyValidationSuccessfullObs$.asObservable();
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    clearTimeout(this.clearSetTimeOut);
  }
}
