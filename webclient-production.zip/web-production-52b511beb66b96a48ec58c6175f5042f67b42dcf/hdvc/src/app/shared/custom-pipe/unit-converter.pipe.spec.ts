import { UnitConverterPipe } from './unit-converter.pipe';

describe('UnitConverterPipe', () => {
  it('create an instance', () => {
    const pipe = new UnitConverterPipe();
    expect(pipe).toBeTruthy();
  });
});
