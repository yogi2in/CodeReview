import { UserInfo } from "./user-info";

export class UserId {
  userId: string;
  userInfo: UserInfo
}
