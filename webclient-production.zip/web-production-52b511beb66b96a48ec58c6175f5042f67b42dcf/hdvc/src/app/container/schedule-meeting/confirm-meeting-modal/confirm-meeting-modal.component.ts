import { Component, OnInit, Input, ElementRef, Output, EventEmitter } from '@angular/core';
declare var $;

@Component({
  selector: 'app-confirm-meeting-modal',
  templateUrl: './confirm-meeting-modal.component.html',
  styleUrls: ['./confirm-meeting-modal.component.css']
})
export class ConfirmMeetingModalComponent implements OnInit {

  @Input() meetingUrl: string;
  @Input() reScheduleMeetingMessage;
  @Output() closeModal: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit() {
    if (this.meetingUrl !== undefined) {
      $('#confirm-meeting-modal').modal('show');
    }

    $('#confirm-meeting-modal').on('hidden.bs.modal', () => {
      // notify schedule meeting component to reset the form
      this.closeModal.emit();
    });
  }

  copyMeetingUrl(elem: any) {
    elem.select();
    document.execCommand('copy');
  }

}
