export interface HttpResponseModel {
  status: string;
  data: any;
  reqFor: string;
}
