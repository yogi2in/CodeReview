import { Component, OnInit, OnDestroy} from '@angular/core';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { UtilService } from '../../services/utils.services';
import { Subscription } from 'rxjs';
import { ConferencePageService } from 'src/app/container/conference/conference-page-service.service';

@Component({
  selector: 'app-alert-popup',
  templateUrl: './alert-popup.component.html',
  styleUrls: ['./alert-popup.component.css']
})
export class AlertPopupComponent implements OnInit, OnDestroy {
  public popupMessage: string;
  public showPopup = false;
  public showDangerMsg: boolean = false;
  private alertMessageSubs: Subscription;
  private clearTimeOutId: any;
  private isPopupForBandwidthWarn: boolean = false;

  constructor(private utilService: UtilService, private _confPageService: ConferencePageService) { }

  ngOnInit() {
    this.alertMessageSubs = this.utilService.alertMesssageListener().subscribe(
      (res: any) => {
        if (res.message !== undefined) {
          if (res.message !== 'hide') {
            this.popupMessage = res.message;
            this.showPopup = true;
            this.showDangerMsg = res.msgLevel !== undefined ? res.msgLevel === 'danger' : false;
            if (res.msgLevel === undefined || res.msgLevel == '' || res.msgLevel === 'no-action') {
              let timeoutTimmer = res.msgLevel !== undefined && res.msgLevel === 'no-action' ? 15000 : 3000;
              this.isPopupForBandwidthWarn = timeoutTimmer === 15000 ? true : false;
              clearTimeout(this.clearTimeOutId);
              console.log('timeoutTimmer ', timeoutTimmer);
              this.clearTimeOutId = setTimeout(() => {
                console.log('execute timeout ')
                this.showPopup = false;
                this.popupMessage = '';
                if (this.isPopupForBandwidthWarn) {
                  this._confPageService.isBandwidthCheckEnable = true;
                  this.isPopupForBandwidthWarn = false;
                }
              }, timeoutTimmer);
            }
          } else {
            this.popupMessage = "";
            this.showPopup = false;
          }
        }
      }
    );
  }

  onClick(){
    this.popupMessage = "";
    this.showPopup = false;
    if (this.isPopupForBandwidthWarn) {
      this._confPageService.isBandwidthCheckEnable = true;
      this.isPopupForBandwidthWarn = false;
    }
    clearTimeout(this.clearTimeOutId);
  }

  ngOnDestroy() {
    this.alertMessageSubs.unsubscribe();
    clearTimeout(this.clearTimeOutId);
  }
}
