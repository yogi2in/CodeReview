import { LogPublisher } from "./log-publisher";
import { LogEntry } from "./log.entry.class";
import { Observable, of } from "rxjs";

export class LogLocalStorage extends LogPublisher {
  constructor() {
    //must call super from derived classes
    super();
    this.location = 'logging';
  }

  //Append Log Entry to local storage
  log(entry: LogEntry): Observable<boolean> {
    let ret: boolean = false;
    let values: LogEntry[];

    try {
      // Retrieving prvious values from local storage
      values = JSON.parse(localStorage.getItem(this.location)) || [];

      // Add new log entry to array
      values.push(entry);

      // Store array into local storage
      localStorage.setItem(this.location, JSON.stringify(values));

      // set return true
      ret = true;
    } catch(ex) {
      // display error in console
      console.log(ex);
    }
    return of(ret);
  }

  // clear all log entries from local storage
  clear(): Observable<boolean> {
    localStorage.removeItem(this.location);
    return of(true);
  }
}
