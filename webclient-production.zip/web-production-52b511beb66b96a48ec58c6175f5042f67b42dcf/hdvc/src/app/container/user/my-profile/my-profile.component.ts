import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MyProfileService } from './my-profile.service';
import { Profile } from './Profile';
import { CustomValidators } from '../../../shared/custom-validation/customValidators';
import { UtilService } from '../../../shared/services/utils.services';
import { FindValueSubscriber } from 'rxjs/internal/operators/find';
import { AuthService } from 'src/app/auth/auth.service';
import { Subscription } from 'rxjs';
import { UserService } from '../user.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
    // creates instance of FormGroup called ChangePasswordForm
    // ChangePasswordForm: FormGroup;
    submittedPasswordForm = false;
    editing = false; // change pwd label editing flag by default false
    //routerName;
    public userprofile: any;
    Errormsg: string;
    private userSubscription = new Subscription();
    public profilePicUrl: string;


  constructor(
    private authService: AuthService,
    private utils: UtilService, 
    private fb: FormBuilder, 
    private router: Router, 
    private myProfileService: MyProfileService,
    private _userService: UserService ) {
    // when router url is edit-profile set routerName and load edit profile component
    // if (this.router.url === '/edit-profile') {
    //     this.routerName = 'EDIT-PROFILE';
    // } else {
    //     this.routerName = 'MY-PROFILE';
    //     // this.buildChangePasswordForm(); // build form controls for change pwd form on my profile page

    // }
  }

  /* This ngOnInit life cycle method get my profile data from service */
  ngOnInit() {
    // Subscribe the Observables after success and set profile data
    this.userSubscription = this.myProfileService.userProfileListner()
    .subscribe(
      (res) => {
        if (res.isSuccess === true) {
          this.userprofile = res.userProfileData;
        }
      }
    );

   this.getuserProfileDetails();
   this.profilePicUrl = this._userService.profilePicUrl;
  }

  getuserProfileDetails() {
    this.myProfileService.getuserProfile()
    .subscribe((response:any) => {
      this.userprofile = response.result;
    },
    error => {
      console.log('error', error);
    });
  }



  /* This function create form group for change pwd form */
  // public buildChangePasswordForm() {
  //  // use FormBuilder to create a form group
  //   this.ChangePasswordForm = this.fb.group({
  //      'passwordGroup': this.fb.group({
  //       oldpassword: ['', [Validators.required]],
  //       newpassword: ['', [Validators.required,
  //       //Validators.pattern('^(?=.*[A-Z])(?=.*[!@#$&*\^%\*\.])(?=.*[0-9])(?=.*[a-z]).{8,}$')
  //       CustomValidators.strongpassword
  //       ]],
  //       confirmpassword: ['', [Validators.required]]
  //     }, {
  //       validator: CustomValidators.passwordMatcher // your validation method
  //     }),
  //   });
  // }

  /* This function is called on edit password button click and display editable form for change pwd */
  // toggleNewPassword() {
  //   this.Errormsg='';
  //   this.editing = true; // set editing true
  //   const oldpasswordControl = this.ChangePasswordForm.controls['passwordGroup'].get('oldpassword');
  //   const passwordControl = this.ChangePasswordForm.controls['passwordGroup'].get('newpassword');
  //   const newPasswordControl = this.ChangePasswordForm.controls['passwordGroup'].get('confirmpassword');
  //   newPasswordControl.setValue(null); // reset value with null on toggle
  //   passwordControl.setValue(null); // password value with null on toggle
  //   oldpasswordControl.setValue(null); // password value with null on toggle
  // }

  /* This function will call when click on cancel btn to hide the password field.
   * */
  // toggleHidePassword() {
  //   this.editing = false; // set editing false to hide the field.
  // }

  /* This function is called for save new password */
  // public saveResetPassword() {
  //   if(this.ChangePasswordForm.controls.passwordGroup.get('newpassword').hasError('Strong')){
  //   this.ChangePasswordForm.controls.passwordGroup.get('newpassword').setErrors(null);
  //   }
  //   this.submittedPasswordForm = true;
  //   if (this.ChangePasswordForm.invalid) {
  //     return;
  //   } else {
  //     const resetpass = {
  //       oldPassword :this.ChangePasswordForm.controls['passwordGroup'].get('oldpassword').value,//"test@123",// need to ask for this
  //       newPassword: this.ChangePasswordForm.value.passwordGroup.newpassword
  //     };

  //     this.myProfileService.updateuserpassword(resetpass)
  //     .subscribe((response:any) => {
  //       this.submittedPasswordForm = false;
  //     this.editing = false;
  //    console.log("password change successfully");
  //     },
  //     error => {
  //       this.editing = true;
  //       this.Errormsg= error.message.message=="Validation Error"?error.message.result[0].message:error.message.message;
  //       console.log('error', error);
  //     });
  //   }
  // }

  /* This function convert password to start format to display as label */
  // hashPassword(password: string) {
  //   return '*'.repeat(password.length);
  // }

  /* This function called after profile pic model close */
  onCloseModal() {
    // after modal close callback
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.userSubscription.unsubscribe();
  }
}

