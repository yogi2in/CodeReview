import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ImageCropperModule } from 'ngx-image-cropper';
import { CookieService } from 'ngx-cookie-service';

import { AppComponent } from './app.component';
import { SidebarPanelComponent } from './sidebar-panel/sidebar-panel.component';
import { CustomerComponent } from './container/customer/customer.component';
import { AddCustomerComponent } from './container/customer/add-customer/add-customer.component';
import {AddCustomerFormSectionComponent} from './container/customer/add-customer/add-customer-form-section/add-customer-form-section.component';
//import { EditCustomerComponent } from './container/customer/edit-customer/edit-customer.component';
import { AppRoutingModule } from './app.route.module';
import { LicenceReportsComponent } from './container/reporting/licence-reports/licence-reports.component';
import { UsersComponent } from './container/users/users.component';
import { DashboardComponent } from './container/dashboard/dashboard.component';
import { LoginComponent } from './auth/login/login.component';
import { CreateUserComponent } from './container/users/create-user/create-user.component';

import { serverRequestInterceptor } from './_interceptors/serverRequest.interceptor';

import { PasswordComponent } from './container/users/password/password.component';
import { UserProfileComponent } from './container/user-profile/user-profile.component';
import { GlobalErrorHandlerComponent } from './shared/global-error-handler/global-error-handler.component';

import { FilterPipe } from './_pipes/filter.pipe';
import { UnitConverterPipe } from './_pipes/unit-converter.pipe';
import { ParticipantMinutesPipe } from './_pipes/participant-minutes.pipe';
import { AddProfilePicModalComponent } from './container/user-profile/add-profile-pic-modal/add-profile-pic-modal.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { LicenceManagementComponent } from './container/customer/licence-management/licence-management.component';
import { DeleteConfirmModalComponent } from './shared/delete-confirm-modal/delete-confirm-modal.component';
import { EditProfileComponent } from './container/user-profile/edit-profile/edit-profile.component';
import { ForgotPasswordComponent } from './container/forgot-password/forgot-password.component';
import { TypeaheadModule } from 'ngx-bootstrap';
import { RoleManagementComponent } from './container/role-management/role-management.component';
import { AddRoleComponent } from './container/role-management/add-role/add-role.component';
import { GetKeysPipe } from './container/role-management/get-keys.pipe';
import { PermissionDeniedComponent } from './container/permission-denied/permission-denied.component';
import { HomeComponent } from './container/home/home.component';
import { LocalStorageModule } from 'angular-2-local-storage';
import { SalesReportComponent } from './container/reporting/sales-report/sales-report.component';
import { RoleTypePipe } from './_pipes/roleType.pipe';
import { MeetingReportComponent } from './container/reporting/meeting-report/meeting-report.component';
import { UserSidebarComponent } from './container/user-profile/user-sidebar/user-sidebar.component';
import { MyProfileComponent } from './container/user-profile/my-profile/my-profile.component';

@NgModule({
  declarations: [
    AppComponent,
    SidebarPanelComponent,
    CustomerComponent,
    AddCustomerComponent,
    //EditCustomerComponent,
    LicenceReportsComponent,
    UsersComponent,
    DashboardComponent,
    AddCustomerFormSectionComponent,
    LoginComponent,
    CreateUserComponent,
    PasswordComponent,
    UserProfileComponent,
    GlobalErrorHandlerComponent,
    FilterPipe,
    AddProfilePicModalComponent,
    HeaderComponent,
    FooterComponent,
    ChangePasswordComponent,
    LicenceManagementComponent,
    DeleteConfirmModalComponent,
    EditProfileComponent,
    ForgotPasswordComponent,
    RoleManagementComponent,
    AddRoleComponent,
    GetKeysPipe,
    PermissionDeniedComponent,
    HomeComponent,
    SalesReportComponent,
    RoleTypePipe,
    MeetingReportComponent,
    ParticipantMinutesPipe,
    UserSidebarComponent,
    MyProfileComponent,
    UnitConverterPipe
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ImageCropperModule,
    BsDatepickerModule.forRoot(),
    AccordionModule.forRoot(),
    TypeaheadModule.forRoot(),
    LocalStorageModule.forRoot({
      prefix: 'Panasonic_admin',
      storageType: 'localStorage'
  })
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: serverRequestInterceptor,
    multi: true
  },
  CookieService,

],
  bootstrap: [AppComponent]
})
export class AppModule { }
