import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { device } from './_model/device';
import { UtilService } from 'src/app/shared/services/utils.services';

@Injectable({
  providedIn: 'root'
})
export class DeviceSettingService {
  private _audioInputDeviceList: any = [];
  private _audioOutputDeviceLilst: any = [];
  private _videoInputDeviceList: any = [];

  private _selectedAudioInputDeviceId: any;
  private _selectedVideoInputDeviceId: any;
  private _selectedAudioOutputDeviceId: any;
  private _tempSelectedAudioInputDeviceId: any;
  private _tempSelectedVideoInputDeviceId: any;
  private _tempSelectedAudioOutputDeviceId: any;

  private _audioStream: any;
  private _videoStream: any;
  private _tempAudioStream: any;
  private _tempVideoStream: any;

  private _updateDeviceListObs$ = new Subject<{ deviceListUpdated: boolean }>();
  private _notifyAccessToAudioDeviceObs$ = new Subject<{ deviceId: any, isDeviceAccessGranted: boolean, audioStream: any, errorMsge: any, errorCode: any, ignoreResponse: boolean }>();
  private _notifyAccessToVideoDeviceObs$ = new Subject<{ deviceId: any, isDeviceAccessGranted: boolean, videoStream: any, errorMsge: any, errorCode: any, ignoreResponse: boolean }>();
  private _deviceSettingsError = {
    "NO_AUDIO_INPUT": "Oops! No Audio Input available",
    "NO_VIDEO_INPUT": "Oops! No Video Input available",
    "AUDIO_INPUT_ACCESS_DENIED": "Oops! Audio input access has been denied. Please allow to join the meeting!",
    "VIDEO_INPUT_ACCESS_DENIED": "Oops! Video input access has been denied. Please allow to join the meeting!",
  }

  private _isAudioMediaStreamChange: boolean = false;
  private _isVideoMediaStreamChange: boolean = false;
  private _isAudioOutputDestinationChange: boolean = false;

  constructor(private _utilService: UtilService) {
    // window.navigator.getUserMedia = window.navigator.mozGetUserMedia || window.navigator.webkitGetUserMedia;
  }

  getUserAudioMedia(deviceId: string, optionaParameter: any, notificationRequire: boolean) {
    if (notificationRequire) {
      this.stopStream(this._audioStream, 'audio');
    }
    console.log('notificationRequire audio ', deviceId, notificationRequire)
    const audioConstraints = {
      audio: {
        deviceId: deviceId,
        echoCancellation: { exact: true },
        noiseSuppression: { exact: true },
        autoGainControl: { exact: true }
      }
    };
    if (notificationRequire) {
      this._selectedAudioInputDeviceId = deviceId;
    } else {
      this._tempSelectedAudioInputDeviceId = deviceId;
    }

    navigator.mediaDevices.getUserMedia(audioConstraints).then(
      (audioStream: any) => {
        if (!notificationRequire) {
          this._tempAudioStream = audioStream;
          this._isAudioMediaStreamChange = true;
        } else {
          this._audioStream = audioStream;
        }

        this._notifyAccessToAudioDeviceObs$.next(
          {
            deviceId: deviceId,
            isDeviceAccessGranted: true,
            audioStream: audioStream,
            errorMsge: "",
            errorCode: null,
            ignoreResponse: !notificationRequire
          }
        );
      }, (error: any) => {
        this._audioStream = null;
        this._tempAudioStream = null;
        if (notificationRequire) {
          this._notifyAccessToAudioDeviceObs$.next(
            {
              deviceId: this._selectedAudioInputDeviceId,
              isDeviceAccessGranted: false,
              audioStream: null,
              errorMsge: error.message,
              errorCode: error.code,
              ignoreResponse: !notificationRequire
            }
          );
        }
      }
    )
  }

  getUserVideoDevice(deviceId: string, videoConstraintParam: any, notificationRequire: boolean) {
    console.log('notificationRequire video ', deviceId, notificationRequire)
    if (notificationRequire) {
      this.stopStream(this._videoStream, 'video');
    }

    if (videoConstraintParam === null) {
      videoConstraintParam = {
        frameRate: {
          min: 10,
          max: 30
        },
        width: {
          max: 720,
          min: 700,
        },
        height: {
          max: 405,
          min: 390
        }
      }
    }
    videoConstraintParam.deviceId = deviceId;

    const videoConstraints = {
      video: videoConstraintParam
    };

    if (notificationRequire) {
      this._selectedVideoInputDeviceId = deviceId;
    } else {
      this._tempSelectedVideoInputDeviceId = deviceId;
    }
    navigator.mediaDevices.getUserMedia(videoConstraints).then(
      (videoStream: any) => {

        if (!notificationRequire) {
          this._tempVideoStream = videoStream;
          this._isVideoMediaStreamChange = true;
        } else {
          this._videoStream = videoStream;
        }
        this._notifyAccessToVideoDeviceObs$.next(
          {
            deviceId: deviceId,
            isDeviceAccessGranted: true,
            videoStream: videoStream,
            errorMsge: "",
            errorCode: null,
            ignoreResponse: !notificationRequire
          }
        );
      }, (error: any) => {
        console.log('video error --> ', error, error.message);
        this._videoStream = null;
        this._tempVideoStream = null;
        this._notifyAccessToVideoDeviceObs$.next(
          {
            deviceId: this._selectedVideoInputDeviceId,
            isDeviceAccessGranted: false,
            videoStream: null,
            errorMsge: error.message,
            errorCode: error.code,
            ignoreResponse: !notificationRequire
          }
        );
      }
    )
  }

  onAccessAudioDevice() {
    return this._notifyAccessToAudioDeviceObs$.asObservable();
  }

  onAccessVideoDevice() {
    return this._notifyAccessToVideoDeviceObs$.asObservable();
  }

  getEnumerateDevices() {
    // if any of the devlice list is more than one, then not need to call enumerted device list 

    if (
      this._audioInputDeviceList.length > 0 ||
      this._audioOutputDeviceLilst.length > 0 ||
      this._videoInputDeviceList.length > 0) {

      this._notifyAccessToAudioDeviceObs$.next(
        {
          deviceId: this._selectedAudioInputDeviceId,
          isDeviceAccessGranted: true,
          audioStream: this._audioStream,
          errorMsge: "",
          errorCode: null,
          ignoreResponse: true
        }
      );

      this._notifyAccessToVideoDeviceObs$.next(
        {
          deviceId: this._selectedVideoInputDeviceId,
          isDeviceAccessGranted: true,
          videoStream: this._videoStream,
          errorMsge: "",
          errorCode: null,
          ignoreResponse: true
        }
      );
      // return;
    }
    navigator.mediaDevices.enumerateDevices().then(this.gotDevices.bind(this)).catch(this.handleError);
  }

  gotDevices(deviceInfos): void {
    deviceInfos.map((deviceInfo: any) => {
      if (deviceInfo.deviceId != "default" && deviceInfo.deviceId != "communications") {
        if (deviceInfo.kind === 'audioinput') {
          this._audioInputDeviceList.push(deviceInfo)
        } else if (deviceInfo.kind === 'audiooutput') {
          this._audioOutputDeviceLilst.push(deviceInfo)
        } else if (deviceInfo.kind === 'videoinput') {
          this._videoInputDeviceList.push(deviceInfo)
        } else {
          console.log('Some other kind of source/device: ', deviceInfo);
        }
      }
    });
    this._updateDeviceListObs$.next({ deviceListUpdated: true });
  }

  resetDeviceList() {
    this._audioInputDeviceList = [];
    this._audioOutputDeviceLilst = [];
    this._videoInputDeviceList = [];
  }

  handleError(error): void {

  }

  onUpdateDeviceList(): Observable<any> {
    return this._updateDeviceListObs$.asObservable();
  }

  getDeviceList(deviceType: string): device[] {
    let deviceList = [];
    switch (deviceType) {
      case 'audioInput':
        deviceList = this._audioInputDeviceList;
        break;
      case 'videoInput':
        deviceList = this._videoInputDeviceList;
        break;
      case 'audioOutput':
        deviceList = this._audioOutputDeviceLilst;
        break;
    }
    return deviceList;
  }



  updateSelectedDeviceId(deviceId: string, deviceType: string): void {
    if (deviceId && deviceType) {
      switch (deviceType) {
        case 'audio':
          this._selectedAudioInputDeviceId = deviceId;
          this._utilService.setInfoInStorage('session', 'audioDeviceId', deviceId);
          break;
        case 'video':
          this._selectedVideoInputDeviceId = deviceId;
          this._utilService.setInfoInStorage('session', 'videoDeviceId', deviceId);
          break;
        case 'output':
          this._selectedAudioOutputDeviceId = deviceId;
          this._utilService.setInfoInStorage('session', 'outputDeviceId', deviceId);
          break;
      }
      // if (deviceType === 'audio') {
      //   this._selectedAudioInputDeviceId = deviceId;
      //   this._utilService.setInfoInStorage('session', 'audioDeviceId', deviceId);
      // } else if (deviceType === 'video') {
      //   this._selectedVideoInputDeviceId = deviceId;
      //   this._utilService.setInfoInStorage('session', 'videoDeviceId', deviceId);
      // } else if (deviceType === 'output') {
      //   console.log('deviceId -- output ', deviceId);
      //   this._selectedAudioOutputDeviceId = deviceId;
      //   this._utilService.setInfoInStorage('session', 'outputDeviceId', deviceId);
      // }
    }
  }

  getSelectedDeviceId(deviceType: string): string | null {
    let selectedId = null;
    if (deviceType !== undefined && typeof deviceType === 'string') {
      if (deviceType === 'audio' || deviceType === 'video') {
        selectedId = deviceType === 'audio' ? this._selectedAudioInputDeviceId : this._selectedVideoInputDeviceId
      } else if(deviceType === 'tempAudio' || deviceType === 'tempVideo') {
        selectedId = deviceType === 'tempAudio' ? this._tempSelectedAudioInputDeviceId : this._tempSelectedVideoInputDeviceId
      } else {
        selectedId = deviceType !== 'tempOutput' ? this._selectedAudioOutputDeviceId : this._tempSelectedAudioOutputDeviceId;
      }

      if (selectedId === null || selectedId === undefined) {
        switch (deviceType) {
          case 'audio':
            selectedId = this._utilService.getInfoFromStorage('session', 'audioDeviceId');
            break;
          case 'video':
            selectedId = this._utilService.getInfoFromStorage('session', 'videoDeviceId');
            break;
          case 'output':
            selectedId = this._utilService.getInfoFromStorage('session', 'outputDeviceId');
            break;
          case 'tempAudio':
            selectedId = this._tempSelectedAudioInputDeviceId;
            break;
          case 'tempVideo':
            selectedId = this._tempSelectedVideoInputDeviceId;
            break;
          case 'tempOutput':
            selectedId = this._tempSelectedAudioOutputDeviceId;
            break;
        }
      }
    }
    return selectedId;
  }

  updateAllSelectedDeviceId() {
    let tempAudioDeviceId = this.getSelectedDeviceId('tempAudio');
    let tempVideoDeviceId = this.getSelectedDeviceId('tempVideo');
    let tempAudioOutputDeviceId = this.getSelectedDeviceId('tempOutput');

    if (tempAudioDeviceId) {
      this.updateSelectedDeviceId(tempAudioDeviceId, 'audio');
    }

    if (tempVideoDeviceId) {
      this.updateSelectedDeviceId(tempVideoDeviceId, 'video');
    }

    if(tempAudioOutputDeviceId) {
      this.updateSelectedDeviceId(tempAudioOutputDeviceId, 'output');
    }
  }

  resetAllTempDeviceId() {
    this._tempSelectedAudioInputDeviceId = null;
    this._tempSelectedVideoInputDeviceId = null;
    this._tempSelectedAudioOutputDeviceId = null;
  }

  storeStreamTrack(stream: any, streamType: string): void {
    if (streamType) {
      if (streamType == 'audio') {
        this._audioStream = stream;
      } else if (streamType == 'video') {
        this._videoStream = stream;
      }
    }
  }

  getTempMediaStream(streamType: string) {
    let resultStream = null;
    if (streamType) {
      resultStream = streamType === 'audio' ? this._tempAudioStream : this._tempVideoStream;
    }
    return resultStream !== undefined ? resultStream : null;
  }

  getStoredStream(streamType: string): any {
    let resultStream = null;
    if (streamType) {
      resultStream = streamType === 'audio' ? this._audioStream : this._videoStream;
    }
    return resultStream; // !== undefined ? resultStream : null;
  }

  stopStream(inputStream: any, streamType: string, ignoreReset?: boolean): void {
    if (inputStream && streamType) {
      this.stopTrack(inputStream);
      if (!ignoreReset) {
        this.resetMediaStream(streamType, true);
      }
      // switch (streamType) {
      //   case 'audio':
      //     this.stopTrack(inputStream);
      //     if (!ignoreReset)  {
      //       this.resetMediaStream('audio', true);
      //     }          
      //     break;
      //   case 'video':
      //     this.stopTrack(inputStream);
      //     this.resetMediaStream('video', true);
      //     break;
      // }
    }
  }

  stopTempStream(streamType: string): void {
    if (streamType) {
      let tempStream;
      switch (streamType) {
        case 'audio':
          tempStream = this.getTempMediaStream('audio');
          this.stopStream(tempStream, 'audio', true);
          this.resetMediaStream('audio', false);
          break;
        case 'video':
          tempStream = this.getTempMediaStream('video');
          this.stopStream(tempStream, 'video', true);
          this.resetMediaStream('video', false);
          break;
      }
    }
  }

  resetMediaStream(mediaType: string, actualStream: boolean): void {
    if (mediaType !== undefined) {
      switch (mediaType) {
        case 'audio':
          if (actualStream) {
            this._audioStream = null;
          } else {
            this._tempAudioStream = null;
          }
          break;
        case 'video':
          if (actualStream) {
            this._videoStream = null;
          } else {
            this._tempVideoStream = null;
          }
          break;
      }
    }
  }

  stopAudioStream() {
    this.stopStream(this._audioStream, 'audio');
  }

  stopVideoStream() {
    this.stopStream(this._videoStream, 'video');
  }

  stopTrack(inputStream: any): void {
    inputStream.getTracks().forEach(track => {
      track.stop();
    });
  }

  getErrorMsg(errorKey: string): string {
    let resultMsge = this._deviceSettingsError && this._deviceSettingsError[errorKey] !== undefined ? this._deviceSettingsError[errorKey] : "Unknow Error";
    return resultMsge;
  }

  attachSinkId(deviceId: string, element: any, tempId?: boolean) {
    // this._selectedAudioOutputDeviceId = deviceId;
    if (typeof element.sinkId !== 'undefined') {
      element.setSinkId(deviceId)
        .then(() => {
          if (tempId) {
            this._tempSelectedAudioOutputDeviceId = deviceId;
            console.log(`Success, temp audio output device attached: ${deviceId}`);
          } else {
            this.updateSelectedDeviceId(deviceId, 'output');
            console.log(`Success, audio output device attached: ${deviceId}`);
          }          
          
        })
        .catch(error => {
          let errorMessage = error;
          if (error.name === 'SecurityError') {
            errorMessage = `You need to use HTTPS for selecting audio output device: ${error}`;
          }
          console.error(errorMessage);
          // Jump back to first output device in the list as it's the default.
          // audioOutputSelect.selectedIndex = 0;
        });
    } else {
      console.warn('Browser does not support output device selection.');
    }
  }

  updateDeviceChangeStatus(mediaType: string, changeState: boolean) {
    if (mediaType === undefined) {
      return;
    }
    let changeStatus: boolean = false;
    switch (mediaType) {
      case 'audio':
        this._isAudioMediaStreamChange = changeState;
        break;
      case 'video':
        this._isVideoMediaStreamChange = changeState;
        break;
      case 'output':
        this._isAudioOutputDestinationChange = changeState;
        break;
    }
  }

  isDeviceSettingChange(mediaType: string): boolean {
    let changeStatus: boolean = false;
    switch (mediaType) {
      case 'audio':
        changeStatus = this._isAudioMediaStreamChange;
        break;
      case 'video':
        changeStatus = this._isVideoMediaStreamChange;
        break;
      case 'output':
        changeStatus = this._isAudioOutputDestinationChange;
        break;
    }
    return changeStatus
  }

  resetDeviceSettingChangeStatus(): void {
    this._isAudioMediaStreamChange = false;
    this._isVideoMediaStreamChange = false;
    this._isAudioOutputDestinationChange = false;
  }
}
